// ============================================================================
// OmniVault Content Script v3.0.1 — Closed Shadow DOM, Auto-Capture & Autofill
// Supports React / Vue / Angular / Next.js / Shadow DOM & 2-Step SSO Logins
// ============================================================================

(() => {
  if (window !== window.top) return;
  if (window.__omnivaultContentLoaded) return;
  window.__omnivaultContentLoaded = true;

  const STEP1_USER_SESSION_KEY = "__omnivault_step1_user_v290";
  const UNPAIRED_HINT_SESSION_KEY = "__omnivault_unpaired_hint_shown";
  const knownPasswordInputs = new WeakSet();
  let activeMenuEl = null;
  let activeMenuFilterFn = null;
  let activeMenuAnchor = null;
  let saveBannerEl = null;
  let domainMatchCache = { fetchedAt: 0, matches: [], paired: false };
  let liveCredCache = { pwEl: null, username: "", password: "", updatedAt: 0 };

  function isOwnOverlayEvent(e) {
    const t = e && e.target;
    if (!t) return false;
    if (activeMenuEl && (t === activeMenuEl || (activeMenuEl.contains && activeMenuEl.contains(t)))) {
      return true;
    }
    if (saveBannerEl && (t === saveBannerEl || (saveBannerEl.contains && saveBannerEl.contains(t)))) {
      return true;
    }
    return false;
  }

  function isLoopbackHost(hostname) {
    const h = String(hostname || "").toLowerCase().replace(/^\[|\]$/g, "");
    return h === "localhost" || h === "127.0.0.1" || h === "::1";
  }

  function isSafePageOrigin() {
    if (location.protocol === "https:") return true;
    if (location.protocol === "http:" && isLoopbackHost(location.hostname)) {
      return true;
    }
    return false;
  }

  function safeSendMessage(payload, callback) {
    try {
      if (!chrome?.runtime?.id) return;
      chrome.runtime.sendMessage(payload, (res) => {
        if (chrome.runtime.lastError) {
          if (typeof callback === "function") callback(null);
          return;
        }
        if (typeof callback === "function") callback(res);
      });
    } catch (_) {
      if (typeof callback === "function") callback(null);
    }
  }

  function setNativeInputValue(el, val) {
    if (!el) return;
    el.focus();
    const prevVal = el.value;
    const proto = Object.getPrototypeOf(el);
    const desc =
      Object.getOwnPropertyDescriptor(proto, "value") ||
      Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value");
    if (desc && desc.set) {
      desc.set.call(el, val);
    } else {
      el.value = val;
    }
    // Reset React 16-19 internal _valueTracker so controlled inputs commit state immediately
    if (el._valueTracker && typeof el._valueTracker.setValue === "function") {
      try {
        el._valueTracker.setValue(prevVal);
      } catch (_) {}
    }
    try {
      el.dispatchEvent(
        new InputEvent("input", { bubbles: true, cancelable: true, inputType: "insertText", data: val })
      );
    } catch (_) {
      el.dispatchEvent(new Event("input", { bubbles: true }));
    }
    el.dispatchEvent(new Event("change", { bubbles: true }));
    el.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, key: "Unidentified" }));
  }

  const knownShadowHosts = new Set();
  const observedShadowRoots = new WeakSet();
  const inputMetaCache = new WeakMap();
  const textSecurityCache = new WeakMap();
  const standaloneUserCache = new WeakMap();
  const MUTATION_DEBOUNCE_MS = 150;

  let domMutationEpoch = 1;
  let initialShadowScanDone = false;
  let cachedDocInputsEpoch = -1;
  let cachedDocInputs = [];
  let cachedHasVisiblePwEpoch = -1;
  let cachedHasVisiblePw = false;
  let cachedVisiblePwEl = null;

  let mutationDebounceTimer = null;
  const pendingAddedNodes = new Set();
  let pendingHadRemovals = false;

  function invalidateDomInputCaches() {
    domMutationEpoch++;
    cachedDocInputsEpoch = -1;
    cachedHasVisiblePwEpoch = -1;
    cachedVisiblePwEl = null;
  }

  function observeShadowRootIfOpen(shadowRoot) {
    if (!shadowRoot || observedShadowRoots.has(shadowRoot) || typeof MutationObserver !== "function") {
      return;
    }
    observedShadowRoots.add(shadowRoot);
    try {
      domObserver.observe(shadowRoot, { childList: true, subtree: true });
    } catch (_) {}
  }

  function inspectSubtreeForShadowHosts(rootNode, budget = { remaining: 400 }) {
    if (!rootNode || !(rootNode instanceof Element) || budget.remaining <= 0) return;
    if (rootNode === activeMenuEl || rootNode === saveBannerEl) return;
    budget.remaining--;
    if (rootNode.shadowRoot) {
      knownShadowHosts.add(rootNode);
      observeShadowRootIfOpen(rootNode.shadowRoot);
    }
    if (typeof document.createTreeWalker !== "function") return;
    try {
      const walker = document.createTreeWalker(rootNode, NodeFilter.SHOW_ELEMENT);
      let node;
      while ((node = walker.nextNode()) && budget.remaining > 0) {
        budget.remaining--;
        if (node.shadowRoot) {
          knownShadowHosts.add(node);
          observeShadowRootIfOpen(node.shadowRoot);
        }
      }
    } catch (_) {}
  }

  function flushDomMutations() {
    mutationDebounceTimer = null;
    const budget = { remaining: 400 };
    if (pendingHadRemovals) {
      pendingHadRemovals = false;
      for (const host of Array.from(knownShadowHosts)) {
        if (!host || !host.isConnected || !host.shadowRoot) {
          knownShadowHosts.delete(host);
        }
      }
    }
    for (const node of pendingAddedNodes) {
      if (node && node.isConnected) {
        inspectSubtreeForShadowHosts(node, budget);
      }
    }
    pendingAddedNodes.clear();
    invalidateDomInputCaches();

    // Multi-step SPA transition detection: if a newly rendered password input took focus, refresh match cache
    const active = document.activeElement;
    if (
      active instanceof HTMLInputElement &&
      active !== activeMenuAnchor &&
      isSafePageOrigin() &&
      isPasswordLikeInput(active) &&
      isVisibleInput(active)
    ) {
      if (!activeMenuEl && domainMatchCache.paired && Date.now() - domainMatchCache.fetchedAt > 3000) {
        domainMatchCache.fetchedAt = 0;
      }
    }
  }

  const domObserver =
    typeof MutationObserver === "function"
      ? new MutationObserver((records) => {
          let sawRelevant = false;
          for (const rec of records) {
            if (rec.addedNodes && rec.addedNodes.length > 0) {
              for (const n of rec.addedNodes) {
                if (n instanceof Element && n !== activeMenuEl && n !== saveBannerEl) {
                  pendingAddedNodes.add(n);
                  sawRelevant = true;
                }
              }
            }
            if (rec.removedNodes && rec.removedNodes.length > 0) {
              for (const n of rec.removedNodes) {
                if (n instanceof Element && n !== activeMenuEl && n !== saveBannerEl) {
                  pendingHadRemovals = true;
                  sawRelevant = true;
                  break;
                }
              }
            }
          }
          if (!sawRelevant) return;
          if (mutationDebounceTimer !== null) {
            clearTimeout(mutationDebounceTimer);
          }
          mutationDebounceTimer = setTimeout(flushDomMutations, MUTATION_DEBOUNCE_MS);
        })
      : null;

  function startDomMutationObserver() {
    if (!domObserver) return;
    const target = document.documentElement || document.body;
    if (target) {
      try {
        domObserver.observe(target, { childList: true, subtree: true });
      } catch (_) {}
    } else {
      document.addEventListener(
        "DOMContentLoaded",
        () => {
          const root = document.documentElement || document.body;
          if (root) {
            try {
              domObserver.observe(root, { childList: true, subtree: true });
            } catch (_) {}
          }
        },
        { once: true }
      );
    }
  }

  if (isSafePageOrigin()) {
    startDomMutationObserver();
  }

  function registerShadowHostsFromEvent(e) {
    if (!e || typeof e.composedPath !== "function") return;
    try {
      const path = e.composedPath();
      let addedAny = false;
      for (const node of path) {
        if (node && node instanceof ShadowRoot && node.host) {
          if (!knownShadowHosts.has(node.host)) {
            knownShadowHosts.add(node.host);
            observeShadowRootIfOpen(node);
            addedAny = true;
          }
        } else if (node && node.shadowRoot) {
          if (!knownShadowHosts.has(node)) {
            knownShadowHosts.add(node);
            observeShadowRootIfOpen(node.shadowRoot);
            addedAny = true;
          }
        }
      }
      if (addedAny) invalidateDomInputCaches();
    } catch (_) {}
  }

  function ensureInitialShadowHostScan() {
    if (initialShadowScanDone) return;
    initialShadowScanDone = true;
    const rootNode = document.documentElement || document.body;
    if (!rootNode || typeof document.createTreeWalker !== "function") return;
    inspectSubtreeForShadowHosts(rootNode, { remaining: 1000 });
  }

  function isElementActuallyVisible(el, requireEditable) {
    if (!el || el.disabled || (requireEditable && el.readOnly)) return false;
    if (el.isConnected === false) return false;
    // Modern 2026-2027 native Blink C++ visibility check (avoids 8x parent getComputedStyle reflows)
    if (typeof el.checkVisibility === "function") {
      if (!el.checkVisibility({ checkOpacity: true, checkVisibilityCSS: true })) {
        return false;
      }
      if (el.closest && el.closest("[inert], [aria-hidden='true']")) return false;
      const rect = el.getBoundingClientRect();
      return rect.width >= 30 && rect.height >= 14;
    }
    // Legacy fallback when checkVisibility is unavailable
    if (el.closest && el.closest("[inert], [aria-hidden='true'], [hidden]")) return false;
    const rect = el.getBoundingClientRect();
    if (rect.width < 30 || rect.height < 14) return false;
    let cur = el;
    for (let i = 0; i < 8 && cur && cur instanceof Element; i++) {
      const st = window.getComputedStyle(cur);
      if (st.display === "none" || st.visibility === "hidden" || Number(st.opacity) <= 0.05) {
        return false;
      }
      cur = cur.parentElement || (cur.getRootNode && cur.getRootNode().host) || null;
    }
    return true;
  }

  function isVisibleInput(el) {
    return isElementActuallyVisible(el, true);
  }

  function isVisibleReadableInput(el) {
    return isElementActuallyVisible(el, false);
  }

  function queryAllInputsDeep(root = document, depth = 0, seen = null) {
    if (!root || depth > 5) return [];
    if (depth === 0 && root === document) {
      ensureInitialShadowHostScan();
      if (cachedDocInputsEpoch === domMutationEpoch) {
        return cachedDocInputs;
      }
    }
    const visited = seen || new Set();
    if (visited.has(root)) return [];
    visited.add(root);

    const results = [];
    const direct = root.querySelectorAll ? root.querySelectorAll("input") : [];
    for (const inp of direct) {
      results.push(inp);
    }
    for (const host of knownShadowHosts) {
      if (!host || !host.isConnected || !host.shadowRoot) {
        knownShadowHosts.delete(host);
        continue;
      }
      if (root === document || (root.contains && root.contains(host))) {
        results.push(...queryAllInputsDeep(host.shadowRoot, depth + 1, visited));
      }
    }
    if (depth === 0 && root === document) {
      cachedDocInputs = results;
      cachedDocInputsEpoch = domMutationEpoch;
    }
    return results;
  }

  function hasVisiblePasswordOnPage() {
    if (cachedHasVisiblePwEpoch === domMutationEpoch) {
      if (!cachedHasVisiblePw) return false;
      if (cachedVisiblePwEl && cachedVisiblePwEl.isConnected && isVisibleInput(cachedVisiblePwEl)) {
        return true;
      }
    }
    const allInputs = queryAllInputsDeep(document);
    let foundPw = null;
    for (let i = 0; i < allInputs.length; i++) {
      const inp = allInputs[i];
      if (isPasswordLikeInput(inp) && isVisibleInput(inp)) {
        foundPw = inp;
        break;
      }
    }
    cachedHasVisiblePw = Boolean(foundPw);
    cachedVisiblePwEl = foundPw;
    cachedHasVisiblePwEpoch = domMutationEpoch;
    return cachedHasVisiblePw;
  }

  function normalizeVi(str) {
    return String(str || "")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[đĐ]/g, "d")
      .toLowerCase();
  }

  function matchesUsernameLeftToRight(username, rawPrefix) {
    const qNorm = normalizeVi(String(rawPrefix || "").trim());
    if (!qNorm) return true;
    const uNorm = normalizeVi(String(username || "").trim());
    return Boolean(uNorm) && uNorm.startsWith(qNorm);
  }

  const NON_PASSWORD_INPUT_TYPES = new Set([
    "hidden",
    "submit",
    "button",
    "checkbox",
    "radio",
    "file",
    "image",
    "reset",
    "search",
    "email",
    "url",
    "date",
    "datetime-local",
    "month",
    "week",
    "time",
    "number",
    "range",
    "color"
  ]);
  const PASSWORD_CUE_REGEX = /(pass|pwd|mat.?khau|secret|mask|pin)/i;
  const OTP_CUE_REGEX =
    /(otp|totp|2fa|mfa|two.?factor|verification.?code|auth.?code|security.?code|ma.?xac.?thuc|ma.?otp|smart.?otp)/i;

  function getInputMetadata(el) {
    const ariaLabel = el.getAttribute ? el.getAttribute("aria-label") || "" : "";
    const sig = `${el.name || ""}\0${el.id || ""}\0${el.autocomplete || ""}\0${el.placeholder || ""}\0${ariaLabel}`;
    const cached = inputMetaCache.get(el);
    if (cached && cached.sig === sig) {
      return cached.meta;
    }
    const labelText = (el.labels && el.labels[0] ? el.labels[0].textContent : "") || ariaLabel;
    const meta = normalizeVi(
      `${el.name || ""} ${el.id || ""} ${el.autocomplete || ""} ${el.placeholder || ""} ${labelText}`
    );
    inputMetaCache.set(el, { sig, meta });
    return meta;
  }

  function isOtpLikeInput(el) {
    if (!(el instanceof HTMLInputElement)) return false;
    const ac = (el.autocomplete || "").toLowerCase();
    if (ac.includes("one-time-code")) return true;
    const meta = getInputMetadata(el);
    if (OTP_CUE_REGEX.test(meta)) {
      return true;
    }
    if (el.maxLength >= 1 && el.maxLength <= 6 && /(code|ma|digit|so)/i.test(meta)) {
      return true;
    }
    return false;
  }

  function isPasswordLikeInput(el) {
    if (!(el instanceof HTMLInputElement)) return false;
    const t = (el.type || "").toLowerCase();
    if (NON_PASSWORD_INPUT_TYPES.has(t)) {
      return false;
    }
    if (isOtpLikeInput(el)) return false;
    // Fast DOM properties checked BEFORE any getComputedStyle call!
    if (t === "password") {
      knownPasswordInputs.add(el);
      return true;
    }
    const ac = (el.autocomplete || "").toLowerCase();
    if (ac.includes("current-password") || ac.includes("new-password")) {
      knownPasswordInputs.add(el);
      return true;
    }
    if (knownPasswordInputs.has(el)) return true;

    const meta = getInputMetadata(el);
    const cls = typeof el.className === "string" ? el.className : "";
    const hasInlineTextSec = Boolean(el.style && el.style.webkitTextSecurity);
    if (!hasInlineTextSec && !PASSWORD_CUE_REGEX.test(meta) && !PASSWORD_CUE_REGEX.test(cls)) {
      return false;
    }
    const styleSig = `${cls}|${el.style ? el.style.cssText : ""}`;
    const cachedSec = textSecurityCache.get(el);
    if (cachedSec && cachedSec.sig === styleSig) {
      return cachedSec.masked;
    }
    try {
      const st = window.getComputedStyle(el);
      const masked = Boolean(st.webkitTextSecurity && st.webkitTextSecurity !== "none");
      textSecurityCache.set(el, { sig: styleSig, masked });
      if (masked) {
        knownPasswordInputs.add(el);
        return true;
      }
    } catch (_) {}
    return false;
  }

  function isNonLoginNoiseInput(el, meta) {
    if (el.type === "search" || el.type === "number" || el.type === "hidden") return true;
    if (el.closest('[role="search"]')) return true;
    if (
      /(search|tim.?kiem|filter|bo.?loc|chat|comment|binh.?luan|reply|promo|voucher|coupon|ma.?giam|otp|totp|2fa|verification|ma.?xac.?thuc|captcha)/.test(
        meta
      )
    ) {
      return true;
    }
    if (el.maxLength >= 4 && el.maxLength <= 6 && /(code|ma|pin|otp)/.test(meta)) {
      return true;
    }
    return false;
  }

  function isStandaloneLoginUsernameInput(el) {
    if (!(el instanceof HTMLInputElement)) return false;
    const t = (el.type || "text").toLowerCase();
    if (!["text", "email", "tel", ""].includes(t)) return false;

    const urlPath = `${location.hostname} ${location.pathname} ${location.hash}`.toLowerCase();
    const meta = getInputMetadata(el);
    const cached = standaloneUserCache.get(el);
    if (
      cached &&
      cached.epoch === domMutationEpoch &&
      cached.meta === meta &&
      cached.type === t &&
      cached.urlPath === urlPath
    ) {
      return cached.result;
    }

    const compute = () => {
      if (isNonLoginNoiseInput(el, meta)) return false;

      const ac = (el.autocomplete || "").toLowerCase();
      if (/(username|email|webauthn)/.test(ac)) return true;

      const strongUserCue =
        /(user|userid|username|login|identifier|account|email|e-mail|phone|mobile|sdt|so.?dien.?thoai|tai.?khoan|ten.?dang.?nhap|cif|ma.?khach.?hang)/.test(
          meta
        );
      if (!strongUserCue) return false;

      const urlIsAuth =
        /(login|signin|sign-in|auth|sso|oauth|account|id\.|passport|dang-nhap|dangnhap|digibank|ibank|ebank|smartbanking)/.test(
          urlPath
        );
      if (urlIsAuth) return true;

      const container = el.closest("form, [role='dialog'], main, section") || document.body;
      const btnText = normalizeVi(
        Array.from(container.querySelectorAll("button, input[type='submit'], [role='button']"))
          .slice(0, 8)
          .map((b) => b.textContent || b.value || "")
          .join(" ")
      );
      return /(dang.?nhap|tiep.?tuc|next|continue|sign.?in|log.?in)/.test(btnText);
    };

    const result = compute();
    standaloneUserCache.set(el, { epoch: domMutationEpoch, meta, type: t, urlPath, result });
    return result;
  }

  function resolveUsernameScope(pwInput) {
    if (!pwInput || pwInput === document.body) return document;
    const form = pwInput.closest ? pwInput.closest("form") : null;
    if (form) return form;
    let cur = pwInput.parentElement;
    for (let i = 0; i < 6 && cur; i++) {
      const inps = queryAllInputsDeep(cur);
      if (inps.length >= 2) return cur;
      cur = cur.parentElement;
    }
    return document;
  }

  function findUsernameFieldNear(pwInput, allowReadOnly = false) {
    const scope = resolveUsernameScope(pwInput);
    const visFn = allowReadOnly ? isVisibleReadableInput : isVisibleInput;
    const candidates = queryAllInputsDeep(scope).filter((el) => {
      if (!visFn(el) || el === pwInput || isPasswordLikeInput(el)) return false;
      const t = (el.type || "text").toLowerCase();
      return ["text", "email", "tel", ""].includes(t);
    });

    const scored = candidates.map((el) => {
      const meta = getInputMetadata(el);
      const ac = (el.autocomplete || "").toLowerCase();
      let score = 0;
      if (/(username|email|webauthn)/.test(ac)) score += 8;
      if (
        /(user|login|identifier|email|mail|phone|tel|sdt|so.?dien.?thoai|tai.?khoan|ten.?dang.?nhap|account|cif)/.test(
          meta
        )
      ) {
        score += 6;
      }
      if (
        pwInput &&
        pwInput !== document.body &&
        typeof el.compareDocumentPosition === "function" &&
        (el.compareDocumentPosition(pwInput) & Node.DOCUMENT_POSITION_FOLLOWING)
      ) {
        score += 2;
      }
      if (isNonLoginNoiseInput(el, meta)) score -= 12;
      return { el, score };
    });
    scored.sort((a, b) => b.score - a.score);
    return scored.length > 0 && scored[0].score >= 0 ? scored[0].el : null;
  }

  function extractBestUsernameNear(pwInput) {
    const usrEl = findUsernameFieldNear(pwInput, true);
    const direct = usrEl ? String(usrEl.value || "").trim() : "";
    if (direct) return direct;
    if (Date.now() - liveCredCache.updatedAt < 300_000 && liveCredCache.username) {
      return liveCredCache.username;
    }
    try {
      const s1 = sessionStorage.getItem(STEP1_USER_SESSION_KEY) || "";
      if (s1) return s1;
    } catch (_) {}
    const idChip =
      typeof document.querySelector === "function"
        ? document.querySelector("[data-identifier], [data-email]")
        : null;
    if (idChip) {
      const chipVal = String(
        idChip.getAttribute("data-identifier") || idChip.getAttribute("data-email") || ""
      ).trim();
      if (chipVal) return chipVal;
    }
    return "";
  }

  function pickPrimaryPasswordInput(pwInputs) {
    const nonEmpty = (pwInputs || []).filter((inp) => inp && inp.value);
    if (nonEmpty.length === 0) return null;
    if (nonEmpty.length === 1) return nonEmpty[0];
    const preferredNew = nonEmpty.find((inp) => {
      const ac = (inp.autocomplete || "").toLowerCase();
      const meta = getInputMetadata(inp);
      if (ac.includes("new-password")) {
        return !/(confirm|repeat|retype|nhap.?lai|xac.?nhan)/i.test(meta);
      }
      return /(new|moi)/i.test(meta) && !/(confirm|repeat|retype|nhap.?lai|xac.?nhan)/i.test(meta);
    });
    return preferredNew || nonEmpty[nonEmpty.length - 1];
  }

  function fillCredentialsOnPage(username, password, anchorInput = null) {
    const allInputs = queryAllInputsDeep(document);
    const pwInputs = allInputs.filter((el) => isPasswordLikeInput(el) && isVisibleInput(el));
    const pwField =
      anchorInput && isPasswordLikeInput(anchorInput) && isVisibleInput(anchorInput)
        ? anchorInput
        : pwInputs[0] || null;

    if (pwField) {
      const userField =
        anchorInput && !isPasswordLikeInput(anchorInput) && isVisibleInput(anchorInput)
          ? anchorInput
          : findUsernameFieldNear(pwField);
      let filledUser = false;
      let filledPw = false;
      if (userField && username) {
        setNativeInputValue(userField, username);
        filledUser = true;
      }
      if (password) {
        setNativeInputValue(pwField, password);
        filledPw = true;
      }
      if (filledUser || filledPw) {
        return { filled: true, mode: filledUser && filledPw ? "both" : "password_only" };
      }
    }

    // Multi-step login Step 1 (username/email/phone screen with no password field yet)
    if (username) {
      const targetUser =
        anchorInput &&
        !isPasswordLikeInput(anchorInput) &&
        isVisibleInput(anchorInput) &&
        isStandaloneLoginUsernameInput(anchorInput)
          ? anchorInput
          : allInputs.find((el) => isVisibleInput(el) && isStandaloneLoginUsernameInput(el)) ||
            findUsernameFieldNear(document.body);

      if (targetUser) {
        setNativeInputValue(targetUser, username);
        try {
          sessionStorage.setItem(STEP1_USER_SESSION_KEY, username);
        } catch (_) {}
        return { filled: true, mode: "username_only" };
      }
    }

    return { filled: false, mode: "none" };
  }

  function closeInlineMenu() {
    if (activeMenuEl) {
      activeMenuEl.remove();
      activeMenuEl = null;
    }
    activeMenuFilterFn = null;
    activeMenuAnchor = null;
  }

  const DROPDOWN_PAGE_SIZE = 40;
  const INLINE_MENU_CSS = `
    .ov-panel {
      position: fixed;
      z-index: 2147483646;
      background: rgba(255, 255, 255, 0.99);
      border: 1.5px solid #BBD0EA;
      border-radius: 12px;
      box-shadow: 0 12px 30px rgba(7, 14, 26, 0.18);
      padding: 6px;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      color: #070E1A;
      box-sizing: border-box;
      pointer-events: auto;
    }
    .ov-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 6px;
      padding: 4px 8px 6px;
      border-bottom: 1px solid #DCE8F8;
      font-size: 11.2px;
      font-weight: 800;
      color: #1D4ED8;
    }
    .ov-badge {
      background: #E6EFFD;
      color: #1D4ED8;
      border: 1px solid #BFD6F8;
      border-radius: 999px;
      padding: 1px 7px;
      font-size: 10.5px;
      font-weight: 800;
      white-space: nowrap;
      flex-shrink: 0;
    }
    .ov-search-wrap {
      padding: 5px 2px 2px;
    }
    .ov-search {
      width: 100%;
      box-sizing: border-box;
      padding: 6px 9px;
      border: 1.2px solid #BBD0EA;
      border-radius: 8px;
      background: #F8FBFF;
      color: #070E1A;
      font-size: 12px;
      font-weight: 600;
      outline: none;
      font-family: inherit;
    }
    .ov-list {
      overflow-y: auto;
      overscroll-behavior: contain;
      display: flex;
      flex-direction: column;
      gap: 2px;
      margin-top: 4px;
      padding-right: 2px;
    }
    .ov-row {
      display: flex;
      flex-direction: column;
      align-items: flex-start;
      width: 100%;
      border: none;
      background: transparent;
      cursor: pointer;
      padding: 7px 9px;
      border-radius: 8px;
      text-align: left;
      box-sizing: border-box;
      font-family: inherit;
    }
    .ov-row:hover {
      background: #EAF2FC;
    }
    .ov-title {
      font-size: 13px;
      font-weight: 800;
      color: #070E1A;
      width: 100%;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .ov-sub {
      font-size: 11.4px;
      font-weight: 600;
      color: #26364B;
      margin-top: 2px;
      width: 100%;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .ov-empty {
      padding: 10px 8px;
      text-align: center;
      font-size: 11.8px;
      color: #475B76;
      font-weight: 600;
    }
  `;
  let sharedInlineMenuSheet = null;

  function getInlineMenuStyleSheet() {
    if (sharedInlineMenuSheet) return sharedInlineMenuSheet;
    if (typeof CSSStyleSheet === "function") {
      try {
        const sheet = new CSSStyleSheet();
        if (typeof sheet.replaceSync === "function") {
          sheet.replaceSync(INLINE_MENU_CSS);
          sharedInlineMenuSheet = sheet;
          return sheet;
        }
      } catch (_) {}
    }
    return null;
  }

  function prepareDomainMatches(rawList) {
    return (Array.isArray(rawList) ? rawList : []).map((m) => ({
      ...m,
      foldedUser: normalizeVi(String(m.username || "").trim()),
      foldedTitle: normalizeVi(String(m.service_name || "").trim())
    }));
  }

  function showInlineAutofillMenu(anchorInput, matches, isStep1UserOnly = false) {
    closeInlineMenu();
    if (!matches || matches.length === 0 || !isSafePageOrigin()) return;

    const preparedMatches =
      typeof matches[0].foldedUser === "string" ? matches : prepareDomainMatches(matches);

    const rect = anchorInput.getBoundingClientRect();
    const showSearch = preparedMatches.length > 5;
    const panelWidth = Math.max(280, Math.min(360, rect.width));
    const spaceBelow = window.innerHeight - rect.bottom - 12;
    const spaceAbove = rect.top - 12;
    const placeAbove = spaceBelow < 210 && spaceAbove > spaceBelow;
    const availHeight = Math.max(165, Math.min(340, placeAbove ? spaceAbove : spaceBelow));
    const chromeHeight = showSearch ? 78 : 40;
    const listMaxHeight = Math.max(110, Math.min(252, availHeight - chromeHeight));
    const leftPx = Math.max(8, Math.min(window.innerWidth - panelWidth - 8, rect.left));

    const host = document.createElement("div");
    // HIGH-EXT-01: Keep Light-DOM host geometry & display strictly invariant so page JS cannot probe filter results.
    host.style.cssText =
      "all: initial; position: fixed; z-index: 2147483646; top: 0; left: 0; width: 0; height: 0; overflow: visible; pointer-events: none; display: block;";
    const shadow = host.attachShadow({ mode: "closed" });

    const sheet = getInlineMenuStyleSheet();
    if (sheet && "adoptedStyleSheets" in shadow) {
      try {
        shadow.adoptedStyleSheets = [sheet];
      } catch (_) {
        const styleEl = document.createElement("style");
        styleEl.textContent = INLINE_MENU_CSS;
        shadow.appendChild(styleEl);
      }
    } else {
      const styleEl = document.createElement("style");
      styleEl.textContent = INLINE_MENU_CSS;
      shadow.appendChild(styleEl);
    }

    const panel = document.createElement("div");
    panel.className = "ov-panel";
    panel.style.left = `${leftPx}px`;
    panel.style.width = `${panelWidth}px`;
    if (placeAbove) {
      panel.style.bottom = `${Math.max(8, window.innerHeight - rect.top + 5)}px`;
    } else {
      panel.style.top = `${Math.max(8, rect.bottom + 5)}px`;
    }
    for (const evtName of ["wheel", "keydown", "keyup", "keypress"]) {
      panel.addEventListener(evtName, (ev) => ev.stopPropagation());
    }

    const header = document.createElement("div");
    header.className = "ov-header";
    const headerTitle = document.createElement("span");
    headerTitle.textContent = isStep1UserOnly
      ? "OmniVault — Chọn tài khoản (Bước 1)"
      : "OmniVault — Chọn tài khoản tự điền";
    const countBadge = document.createElement("span");
    countBadge.className = "ov-badge";
    countBadge.textContent = `${preparedMatches.length} TK`;
    header.appendChild(headerTitle);
    header.appendChild(countBadge);
    panel.appendChild(header);

    let searchBox = null;
    if (showSearch) {
      const searchWrap = document.createElement("div");
      searchWrap.className = "ov-search-wrap";
      searchBox = document.createElement("input");
      searchBox.className = "ov-search";
      searchBox.type = "text";
      searchBox.placeholder = `🔎 Tìm nhanh trong ${preparedMatches.length} tài khoản...`;
      searchBox.autocomplete = "off";
      searchBox.spellcheck = false;
      searchBox.addEventListener("mousedown", (ev) => ev.stopPropagation());
      searchBox.addEventListener("input", () => renderList(searchBox.value, true));
      searchWrap.appendChild(searchBox);
      panel.appendChild(searchWrap);
    }

    const listWrap = document.createElement("div");
    listWrap.className = "ov-list";
    listWrap.style.maxHeight = `${listMaxHeight}px`;
    panel.appendChild(listWrap);

    const isPwAnchor = isPasswordLikeInput(anchorInput);
    const useUserPrimary =
      preparedMatches.length > 1 ||
      preparedMatches.some(
        (it) =>
          it.domain &&
          String(it.service_name || "").trim().toLowerCase() === String(it.domain || "").trim().toLowerCase()
      );

    let currentFiltered = preparedMatches;
    let renderedCount = 0;

    const selectItem = (m) => {
      closeInlineMenu();
      safeSendMessage(
        {
          type: "REQUEST_CREDENTIAL_FILL",
          itemId: m.id,
          step1Only: isStep1UserOnly
        },
        (res) => {
          if (!res || !res.ok) return;
          fillCredentialsOnPage(res.username || "", res.password || "", anchorInput);
        }
      );
    };

    // Single delegated mousedown handler on list container (replaces 3*M per-item closures!)
    listWrap.addEventListener("mousedown", (ev) => {
      if (!ev.isTrusted) return;
      const targetEl = ev.target instanceof Element ? ev.target : ev.target?.parentElement;
      const btn = targetEl && targetEl.closest ? targetEl.closest("button.ov-row") : null;
      if (!btn) return;
      ev.preventDefault();
      ev.stopPropagation();
      const idx = Number(btn.dataset.ovIdx);
      const chosen = Number.isInteger(idx) ? currentFiltered[idx] : null;
      if (chosen) {
        selectItem(chosen);
      }
    });

    const appendNextBatch = () => {
      if (renderedCount >= currentFiltered.length) return;
      const end = Math.min(currentFiltered.length, renderedCount + DROPDOWN_PAGE_SIZE);
      const frag = document.createDocumentFragment();
      for (let i = renderedCount; i < end; i++) {
        const m = currentFiltered[i];
        const row = document.createElement("button");
        row.type = "button";
        row.className = "ov-row";
        row.dataset.ovIdx = String(i);

        const title = document.createElement("div");
        title.className = "ov-title";

        const sub = document.createElement("div");
        sub.className = "ov-sub";

        const starPrefix = m.is_favorite ? "★ " : "";
        if (m.username && useUserPrimary) {
          title.textContent = `${starPrefix}${m.username}`;
          const baseSub = m.service_name || m.domain || "Tài khoản đã lưu";
          sub.textContent = m.step1_matched ? `✓ Khớp bước 1 • ${baseSub}` : baseSub;
        } else {
          title.textContent = `${starPrefix}${m.service_name || "Tài khoản"}`;
          const domainTag =
            m.domain && !String(m.service_name || "").toLowerCase().includes(String(m.domain).toLowerCase())
              ? m.domain
              : "";
          const baseSub = domainTag
            ? `${m.username || "Điền mật khẩu"} • ${domainTag}`
            : m.username || "Điền mật khẩu đã lưu";
          sub.textContent = m.step1_matched ? `✓ Khớp bước 1 • ${baseSub}` : baseSub;
        }

        row.appendChild(title);
        row.appendChild(sub);
        frag.appendChild(row);
      }
      listWrap.appendChild(frag);
      renderedCount = end;
    };

    listWrap.addEventListener(
      "scroll",
      () => {
        if (
          renderedCount < currentFiltered.length &&
          listWrap.scrollTop + listWrap.clientHeight >= listWrap.scrollHeight - 40
        ) {
          appendNextBatch();
        }
      },
      { passive: true }
    );

    const renderList = (rawFilter = "", fromSearchBox = false) => {
      const qNorm = normalizeVi(String(rawFilter || "").trim());
      if (!qNorm) {
        currentFiltered = preparedMatches;
      } else if (!isPwAnchor) {
        currentFiltered = preparedMatches.filter(
          (m) => Boolean(m.foldedUser) && m.foldedUser.startsWith(qNorm)
        );
      } else {
        currentFiltered = preparedMatches.filter((m) =>
          m.foldedUser ? m.foldedUser.startsWith(qNorm) : m.foldedTitle.startsWith(qNorm)
        );
      }

      // Toggle visibility strictly inside closed ShadowRoot — NEVER mutate Light-DOM host.style.display!
      if (!isPwAnchor && !fromSearchBox && qNorm && currentFiltered.length === 0) {
        panel.style.display = "none";
      } else {
        panel.style.display = "block";
      }

      countBadge.textContent = qNorm
        ? `${currentFiltered.length}/${preparedMatches.length} TK`
        : `${preparedMatches.length} TK`;

      listWrap.textContent = "";
      listWrap.scrollTop = 0;
      renderedCount = 0;

      if (currentFiltered.length === 0) {
        const emptyRow = document.createElement("div");
        emptyRow.className = "ov-empty";
        emptyRow.textContent = "Không có tài khoản nào bắt đầu bằng ký tự vừa nhập.";
        listWrap.appendChild(emptyRow);
        return;
      }

      appendNextBatch();
    };

    if (searchBox) {
      searchBox.addEventListener("keydown", (ev) => {
        if (ev.key === "Escape") {
          ev.preventDefault();
          closeInlineMenu();
          try {
            anchorInput.focus();
          } catch (_) {}
        } else if (ev.key === "Enter" && ev.isTrusted && currentFiltered.length > 0) {
          ev.preventDefault();
          selectItem(currentFiltered[0]);
        }
      });
    }

    let initVal = "";
    if (!isPwAnchor) {
      initVal = String(anchorInput.value || "");
    } else {
      const nearbyUser = extractBestUsernameNear(anchorInput);
      const nearFolded = normalizeVi(nearbyUser);
      if (nearFolded && preparedMatches.some((m) => m.foldedUser && m.foldedUser.startsWith(nearFolded))) {
        initVal = nearbyUser;
      }
    }
    if (searchBox && initVal) searchBox.value = initVal;
    renderList(initVal, false);

    shadow.appendChild(panel);
    document.documentElement.appendChild(host);
    activeMenuEl = host;
    activeMenuAnchor = anchorInput;
    activeMenuFilterFn = !isPwAnchor
      ? (typedVal) => {
          if (searchBox) searchBox.value = typedVal;
          renderList(typedVal, false);
        }
      : null;
  }

  function resolveEventElement(e) {
    if (typeof e.composedPath === "function") {
      const path = e.composedPath();
      if (Array.isArray(path) && path[0] instanceof Element) {
        return path[0];
      }
    }
    return e.target instanceof Element ? e.target : null;
  }

  function resolveEventInput(e) {
    const el = resolveEventElement(e);
    return el instanceof HTMLInputElement ? el : null;
  }

  function persistStep1Username(rawUser) {
    const u = String(rawUser || "").trim();
    if (!u) return;
    liveCredCache.username = u;
    liveCredCache.updatedAt = Date.now();
    try {
      sessionStorage.setItem(STEP1_USER_SESSION_KEY, u);
    } catch (_) {}
  }

  function updateLiveCredFromInput(el, precomputed = null) {
    if (!(el instanceof HTMLInputElement) || !isSafePageOrigin()) return;
    const isPw = precomputed && typeof precomputed.isPw === "boolean" ? precomputed.isPw : isPasswordLikeInput(el);
    if (isPw) {
      if (el.value) {
        liveCredCache = {
          pwEl: el,
          username: extractBestUsernameNear(el) || liveCredCache.username,
          password: el.value,
          updatedAt: Date.now()
        };
      }
      return;
    }
    const isStandaloneUser =
      precomputed && typeof precomputed.isStandaloneUser === "boolean"
        ? precomputed.isStandaloneUser
        : isStandaloneLoginUsernameInput(el);
    if (isStandaloneUser && el.value.trim()) {
      const u = el.value.trim();
      liveCredCache.username = u;
      liveCredCache.updatedAt = Date.now();
      const hasVisiblePw =
        precomputed && typeof precomputed.hasVisiblePw === "boolean"
          ? precomputed.hasVisiblePw
          : hasVisiblePasswordOnPage();
      if (!hasVisiblePw) {
        persistStep1Username(u);
      }
    }
  }

  document.addEventListener(
    "focusin",
    (e) => {
      if (!e.isTrusted) return;
      registerShadowHostsFromEvent(e);
      if (isOwnOverlayEvent(e) || !isSafePageOrigin()) return;
      const t = resolveEventInput(e);
      if (!t || !isVisibleInput(t)) return;

      const isPw = isPasswordLikeInput(t);
      const hasVisiblePwOnPage = isPw || hasVisiblePasswordOnPage();
      const isStandaloneUser = !isPw && isStandaloneLoginUsernameInput(t);
      const isStep1User = isStandaloneUser && !hasVisiblePwOnPage;
      const isPairedUserNextToPw = isStandaloneUser && hasVisiblePwOnPage;

      if (!isPw && !isStep1User && !isPairedUserNextToPw) return;

      const preferredUsername = isPw ? extractBestUsernameNear(t) : String(t.value || "").trim();
      safeSendMessage({ type: "GET_DOMAIN_MATCHES", preferredUsername }, (res) => {
        if (!res || !res.paired || res.locked) return;
        const list = prepareDomainMatches(res.matches);
        domainMatchCache = { fetchedAt: Date.now(), matches: list, paired: true };
        if (list.length > 0) {
          showInlineAutofillMenu(t, list, isStep1User);
        }
      });
    },
    true
  );

  document.addEventListener(
    "input",
    (e) => {
      if (!e.isTrusted) return;
      if (isOwnOverlayEvent(e)) return;
      const el = resolveEventInput(e);
      if (!el || !isSafePageOrigin()) return;

      // Single-pass input handling (eliminates duplicate queryAllInputsDeep + visibility scans per keystroke)
      const isPw = isPasswordLikeInput(el);
      if (isPw) {
        updateLiveCredFromInput(el, { isPw: true });
        return;
      }

      if (el === activeMenuAnchor && activeMenuFilterFn) {
        const val = el.value || "";
        if (val.trim()) {
          liveCredCache.username = val.trim();
          liveCredCache.updatedAt = Date.now();
          if (!hasVisiblePasswordOnPage()) {
            persistStep1Username(val.trim());
          }
        }
        activeMenuFilterFn(val);
        return;
      }

      const isStandaloneUser = isStandaloneLoginUsernameInput(el);
      if (!isStandaloneUser) return;

      const hasVisiblePwOnPage = hasVisiblePasswordOnPage();
      updateLiveCredFromInput(el, {
        isPw: false,
        isStandaloneUser: true,
        hasVisiblePw: hasVisiblePwOnPage
      });

      if (!activeMenuEl && isVisibleInput(el)) {
        const isStep1User = !hasVisiblePwOnPage;
        if (
          Date.now() - domainMatchCache.fetchedAt < 12000 &&
          domainMatchCache.paired &&
          domainMatchCache.matches.length > 0
        ) {
          showInlineAutofillMenu(el, domainMatchCache.matches, isStep1User);
        } else {
          const preferredUsername = String(el.value || "").trim();
          safeSendMessage({ type: "GET_DOMAIN_MATCHES", preferredUsername }, (res) => {
            if (!res || !res.paired || res.locked) return;
            const list = prepareDomainMatches(res.matches);
            domainMatchCache = { fetchedAt: Date.now(), matches: list, paired: true };
            if (list.length > 0) {
              showInlineAutofillMenu(el, list, isStep1User);
            }
          });
        }
      }
    },
    true
  );

  document.addEventListener(
    "change",
    (e) => {
      if (!e.isTrusted) return;
      if (isOwnOverlayEvent(e)) return;
      updateLiveCredFromInput(resolveEventInput(e));
    },
    true
  );

  document.addEventListener(
    "mousedown",
    (e) => {
      if (activeMenuEl && !isOwnOverlayEvent(e) && resolveEventElement(e) !== activeMenuAnchor) {
        closeInlineMenu();
      }
    },
    true
  );

  window.addEventListener("scroll", closeInlineMenu, { passive: true });

  // Render auto-save / confirm-update / undo / locked notice inside closed Shadow DOM
  function showCaptureNoticeBanner(notice) {
    if (!notice || !isSafePageOrigin()) return;
    if (notice.kind === "unpaired") {
      try {
        if (sessionStorage.getItem(UNPAIRED_HINT_SESSION_KEY)) return;
        sessionStorage.setItem(UNPAIRED_HINT_SESSION_KEY, "1");
      } catch (_) {}
    }

    const mount = () => {
      if (!document.documentElement) return;
      if (saveBannerEl) saveBannerEl.remove();

      const outer = document.createElement("div");
      outer.style.cssText =
        "all: initial; position: fixed; top: 0; right: 0; width: 0; height: 0; overflow: visible; pointer-events: none; z-index: 2147483647;";
      const shadow = outer.attachShadow({ mode: "closed" });

      const box = document.createElement("div");
      box.style.cssText = `
        position: fixed; top: 16px; right: 16px; z-index: 2147483647;
        width: 330px; background: #FFFFFF; border: 1.5px solid #BBD0EA;
        border-radius: 14px; box-shadow: 0 14px 34px rgba(7, 14, 26, 0.22);
        padding: 13px 15px; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
        color: #070E1A; box-sizing: border-box; pointer-events: auto;
      `;

      const heading = document.createElement("div");
      const desc = document.createElement("div");
      desc.style.cssText =
        "font-size: 12.2px; font-weight: 600; color: #26364B; margin: 5px 0 11px; word-break: break-word; line-height: 1.4;";

      const actions = document.createElement("div");
      actions.style.cssText = "display: flex; gap: 8px; justify-content: flex-end;";

      let dismissMs = 8500;

      if (notice.kind === "confirm_update") {
        dismissMs = 20000;
        heading.style.cssText = "font-size: 13.8px; font-weight: 800; color: #1D4ED8;";
        heading.textContent = "Cập nhật mật khẩu đã lưu?";
        desc.textContent = `${notice.host || location.hostname}${
          notice.username ? " • " + notice.username : ""
        } vừa đăng nhập bằng mật khẩu mới khác với bản đang lưu trong OmniVault.`;

        const confirmBtn = document.createElement("button");
        confirmBtn.type = "button";
        confirmBtn.textContent = "Cập nhật";
        confirmBtn.style.cssText = `
          padding: 6px 12px; border-radius: 9px; border: 1px solid #1D4ED8;
          background: #1D4ED8; color: #FFFFFF; font-size: 12px; font-weight: 700; cursor: pointer;
        `;

        const dismissBtn = document.createElement("button");
        dismissBtn.type = "button";
        dismissBtn.textContent = "Giữ bản cũ";
        dismissBtn.style.cssText = `
          padding: 6px 12px; border-radius: 9px; border: 1px solid #BBD0EA;
          background: #F1F5FB; color: #26364B; font-size: 12px; font-weight: 700; cursor: pointer;
        `;

        confirmBtn.addEventListener("click", (ev) => {
          if (!ev.isTrusted) return;
          confirmBtn.disabled = true;
          dismissBtn.disabled = true;
          confirmBtn.textContent = "Đang cập nhật...";
          safeSendMessage({ type: "CONFIRM_PENDING_UPDATE", proposalId: notice.noticeId }, (res) => {
            if (res && res.ok) {
              heading.style.color = "#059669";
              heading.textContent = "✓ OmniVault đã cập nhật mật khẩu";
              confirmBtn.hidden = true;
              dismissBtn.hidden = true;
              if (res.noticeId) {
                const undoBtn = document.createElement("button");
                undoBtn.type = "button";
                undoBtn.textContent = "Hoàn tác";
                undoBtn.style.cssText = `
                  padding: 6px 12px; border-radius: 9px; border: 1px solid #FCA5A5;
                  background: #FEF2F2; color: #B91C1C; font-size: 12px; font-weight: 700; cursor: pointer;
                `;
                undoBtn.addEventListener("click", (uev) => {
                  if (!uev.isTrusted) return;
                  undoBtn.disabled = true;
                  undoBtn.textContent = "Đang hoàn tác...";
                  safeSendMessage({ type: "UNDO_AUTO_SAVED_LOGIN", noticeId: res.noticeId }, (ures) => {
                    if (ures && ures.ok) {
                      heading.style.color = "#475569";
                      heading.textContent = "Đã hoàn tác cập nhật mật khẩu";
                      undoBtn.hidden = true;
                      setTimeout(() => {
                        if (outer.isConnected) outer.remove();
                      }, 1200);
                    } else {
                      undoBtn.textContent = "Lỗi hoàn tác";
                    }
                  });
                });
                actions.prepend(undoBtn);
              } else {
                setTimeout(() => {
                  if (outer.isConnected) outer.remove();
                }, 1500);
              }
            } else {
              confirmBtn.textContent = "Hết hạn / Lỗi";
            }
          });
        });

        dismissBtn.addEventListener("click", (ev) => {
          if (!ev.isTrusted) return;
          safeSendMessage({ type: "DISMISS_PENDING_UPDATE", proposalId: notice.noticeId });
          outer.remove();
        });

        actions.appendChild(dismissBtn);
        actions.appendChild(confirmBtn);
      } else if (notice.kind === "auto_saved") {
        heading.style.cssText = "font-size: 13.8px; font-weight: 800; color: #059669;";
        heading.textContent =
          notice.mode === "updated"
            ? "✓ OmniVault đã cập nhật mật khẩu"
            : "✓ OmniVault đã tự lưu mật khẩu";
        desc.textContent = `${notice.host || location.hostname}${notice.username ? " • " + notice.username : ""}`;

        const undoBtn = document.createElement("button");
        undoBtn.type = "button";
        undoBtn.textContent = "Hoàn tác";
        undoBtn.style.cssText = `
          padding: 6px 12px; border-radius: 9px; border: 1px solid #FCA5A5;
          background: #FEF2F2; color: #B91C1C; font-size: 12px; font-weight: 700; cursor: pointer;
        `;
        undoBtn.addEventListener("click", (ev) => {
          if (!ev.isTrusted) return;
          undoBtn.disabled = true;
          undoBtn.textContent = "Đang hoàn tác...";
          safeSendMessage({ type: "UNDO_AUTO_SAVED_LOGIN", noticeId: notice.noticeId }, (res) => {
            if (res && res.ok) {
              heading.style.color = "#475569";
              heading.textContent = "Đã hoàn tác lưu mật khẩu";
              undoBtn.hidden = true;
              setTimeout(() => {
                if (outer.isConnected) outer.remove();
              }, 1200);
            } else {
              undoBtn.textContent = "Lỗi hoàn tác";
            }
          });
        });
        actions.appendChild(undoBtn);
      } else if (notice.kind === "locked_pending") {
        dismissMs = 12000;
        heading.style.cssText = "font-size: 13.8px; font-weight: 800; color: #B45309;";
        heading.textContent = "🔒 Kho OmniVault đang khóa PIN";
        desc.textContent = `Vì bảo mật, mật khẩu của ${notice.host || location.hostname}${
          notice.username ? " • " + notice.username : ""
        } chưa được giữ tạm khi kho khóa. Bấm biểu tượng OmniVault để nhập PIN mở khóa trước khi lưu.`;
      } else {
        dismissMs = 10000;
        heading.style.cssText = "font-size: 13.8px; font-weight: 800; color: #1D4ED8;";
        heading.textContent = "OmniVault chưa kết nối thiết bị";
        desc.textContent =
          "Bấm biểu tượng tiện ích OmniVault và dán Mã Kết Nối từ điện thoại để tự động lưu & đồng bộ mật khẩu.";
      }

      if (notice.kind !== "confirm_update") {
        const closeBtn = document.createElement("button");
        closeBtn.type = "button";
        closeBtn.textContent = "Đóng";
        closeBtn.style.cssText = `
          padding: 6px 12px; border-radius: 9px; border: 1px solid #BBD0EA;
          background: #F1F5FB; color: #26364B; font-size: 12px; font-weight: 700; cursor: pointer;
        `;
        closeBtn.addEventListener("click", (ev) => {
          if (!ev.isTrusted) return;
          outer.remove();
        });
        actions.appendChild(closeBtn);
      }

      box.appendChild(heading);
      box.appendChild(desc);
      box.appendChild(actions);
      shadow.appendChild(box);
      document.documentElement.appendChild(outer);
      saveBannerEl = outer;

      setTimeout(() => {
        if (outer.isConnected) outer.remove();
      }, dismissMs);
    };

    if (document.documentElement) {
      mount();
    } else {
      document.addEventListener("DOMContentLoaded", mount, { once: true });
    }
  }

  function isLikelySubmitButton(btn) {
    if (!btn) return false;
    const rawType = btn.getAttribute ? btn.getAttribute("type") : null;
    const hasOwningForm = Boolean(btn.form || (btn.closest && btn.closest("form")));
    const btnType = (
      rawType ||
      (btn instanceof HTMLButtonElement && hasOwningForm
        ? "submit"
        : btn instanceof HTMLInputElement
        ? btn.type
        : "")
    ).toLowerCase();
    const aria = btn.getAttribute ? btn.getAttribute("aria-label") || "" : "";
    const title = btn.title || "";
    const id = btn.id || "";
    const cls = typeof btn.className === "string" ? btn.className : "";
    const txt = btn.textContent || "";
    const val = btn.value || "";
    const btnMeta = normalizeVi(`${aria} ${title} ${id} ${cls} ${txt} ${val}`);
    const labelMeta = normalizeVi(`${aria} ${title} ${txt} ${val}`).trim();

    if (
      /(show|hide|view|toggle|visibility|eye|reveal|hien|an.?mat.?khau|clear|xoa|reset|cancel|huy|close|dong|back|quay.?lai|forgot|quen|help|tro.?giup|copy|sao.?chep|generate|tao.?mat.?khau)/i.test(
        btnMeta
      )
    ) {
      return false;
    }

    const explicitAuthCue =
      /(dang.?nhap|dang.?ky|login|log.?in|sign.?in|signin|sign.?up|signup|register|doi.?mat.?khau|change.?password|reset.?password|mat.?khau|password|auth|authenticate|logon|log.?on)/i;
    const genericNonAuthCue =
      /(?:^|\b)(save|luu|next|tiep|tiep.?theo|tiep.?tuc|continue|done|xong|finish|hoan.?tat)(?:\b|$)/i;

    // AF-03 / INV-06: Generic "save"/"luu"/"next"/"tiep" buttons must never trigger credential capture
    // unless explicitly paired with an authentication/password label.
    if (genericNonAuthCue.test(labelMeta) && !explicitAuthCue.test(labelMeta)) {
      return false;
    }

    if (btnType === "submit" || btnType === "image") {
      if (!rawType && !txt.trim()) {
        const rect = btn.getBoundingClientRect ? btn.getBoundingClientRect() : { width: 0 };
        if (
          rect.width > 0 &&
          rect.width < 46 &&
          !/(submit|login|signin|dang.?nhap|enter)/i.test(btnMeta)
        ) {
          return false;
        }
      }
      return true;
    }

    return explicitAuthCue.test(btnMeta);
  }

  let lastCaptureSig = "";
  let lastCaptureAt = 0;

  function submitCapturedCredentialsNow(pwEl) {
    if (!isSafePageOrigin()) return;
    const fallbackPw = Date.now() - liveCredCache.updatedAt < 120_000 ? liveCredCache.password : "";
    const password = (pwEl && pwEl.value) || fallbackPw;
    if (!password) return;

    const refEl = pwEl || liveCredCache.pwEl || document.body;
    const username = extractBestUsernameNear(refEl);
    const sig = `${location.hostname}|${username}|${password}`;
    const now = Date.now();
    if (sig === lastCaptureSig && now - lastCaptureAt < 2500) return;
    lastCaptureSig = sig;
    lastCaptureAt = now;

    safeSendMessage({ type: "SUBMIT_LOGIN_CAPTURE", username, password }, (res) => {
      if (!res) return;
      if (
        res.notice &&
        (res.status === "auto_saved" ||
          res.status === "confirm_update" ||
          res.status === "locked_pending" ||
          res.status === "unpaired")
      ) {
        safeSendMessage({ type: "ACK_TAB_CAPTURE_NOTICE", noticeId: res.notice.noticeId });
        showCaptureNoticeBanner(res.notice);
      }
    });
  }

  document.addEventListener(
    "submit",
    (e) => {
      if (!e.isTrusted) return;
      if (!isSafePageOrigin()) return;
      const form = resolveEventElement(e);
      if (!(form instanceof HTMLFormElement)) return;
      const formInputs = queryAllInputsDeep(form);
      let pw = pickPrimaryPasswordInput(formInputs.filter((inp) => isPasswordLikeInput(inp)));
      if (
        !pw &&
        liveCredCache.pwEl &&
        Date.now() - liveCredCache.updatedAt < 5000 &&
        form.contains(liveCredCache.pwEl)
      ) {
        pw = liveCredCache.pwEl;
      }
      if (!pw) {
        const step1Usr = formInputs.find((inp) => isStandaloneLoginUsernameInput(inp) && inp.value.trim());
        if (step1Usr) {
          persistStep1Username(step1Usr.value.trim());
        }
        return;
      }
      submitCapturedCredentialsNow(pw);
    },
    true
  );

  // Capture modern SPA logins (React/Next/Vue) synchronously before frameworks clear fields or redirect
  document.addEventListener(
    "click",
    (e) => {
      if (!e.isTrusted) return;
      registerShadowHostsFromEvent(e);
      if (!isSafePageOrigin()) return;
      const targetEl = resolveEventElement(e);
      const btn =
        targetEl && targetEl.closest
          ? targetEl.closest(
              "button, input[type='submit'], input[type='button'], input[type='image'], [role='button'], a[class*='btn'], a[class*='login'], a[class*='submit'], a[href='#'], a[href^='javascript']"
            )
          : null;
      if (!btn || !isLikelySubmitButton(btn)) return;

      const scopeRoot = btn.closest("form, [role='dialog'], main, section") || document;
      const scopeInputs = queryAllInputsDeep(scopeRoot);
      let pw = pickPrimaryPasswordInput(
        scopeInputs.filter((inp) => isPasswordLikeInput(inp) && isVisibleInput(inp))
      );
      if (!pw && scopeRoot !== document) {
        pw = pickPrimaryPasswordInput(
          queryAllInputsDeep(document).filter((inp) => isPasswordLikeInput(inp) && isVisibleInput(inp))
        );
      }
      if (
        !pw &&
        liveCredCache.password &&
        Date.now() - liveCredCache.updatedAt < 15_000 &&
        liveCredCache.pwEl &&
        liveCredCache.pwEl.isConnected
      ) {
        pw = liveCredCache.pwEl;
      }

      if (pw) {
        submitCapturedCredentialsNow(pw);
      } else {
        const step1Usr = scopeInputs.find(
          (inp) => isStandaloneLoginUsernameInput(inp) && inp.value.trim() && isVisibleInput(inp)
        );
        if (step1Usr) {
          persistStep1Username(step1Usr.value.trim());
        }
      }
    },
    true
  );

  document.addEventListener(
    "keydown",
    (e) => {
      if (!e.isTrusted) return;
      if (e.key !== "Enter" || !isSafePageOrigin()) return;
      registerShadowHostsFromEvent(e);
      const target = resolveEventInput(e);
      if (!target) return;
      if (
        isPasswordLikeInput(target) &&
        (target.value || (liveCredCache.pwEl === target && liveCredCache.password))
      ) {
        submitCapturedCredentialsNow(target);
        return;
      }
      if (isStandaloneLoginUsernameInput(target)) {
        const scope = target.closest("form, [role='dialog'], main, section") || document;
        const pw = pickPrimaryPasswordInput(
          queryAllInputsDeep(scope).filter((inp) => isPasswordLikeInput(inp) && isVisibleInput(inp))
        );
        if (pw) {
          submitCapturedCredentialsNow(pw);
        } else if (target.value.trim()) {
          persistStep1Username(target.value.trim());
        }
      }
    },
    true
  );

  // Listen for direct 1-tap Autofill command from Popup and proactive capture notices pushed by Service Worker
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (sender && sender.id && sender.id !== chrome.runtime.id) return false;
    if (msg && msg.type === "FILL_LOGIN_NOW") {
      if (!isSafePageOrigin()) {
        sendResponse({ filled: false, mode: "unsafe_origin" });
        return true;
      }
      const res = fillCredentialsOnPage(msg.username || "", msg.password || "");
      sendResponse({ filled: res.filled, mode: res.mode });
      return true;
    }
    if (msg && msg.type === "SHOW_TAB_CAPTURE_NOTICE" && msg.notice) {
      if (!isSafePageOrigin()) {
        sendResponse({ ok: false, shown: false });
        return true;
      }
      showCaptureNoticeBanner(msg.notice);
      sendResponse({ ok: true, shown: true });
      return true;
    }
    return false;
  });
})();
