if (typeof importScripts === "function") {
  importScripts("crypto_totp.js");
}

const SYNC_ALARM_NAME = "omnivault_periodic_sync";
const AUTOLOCK_ALARM_NAME = "omnivault_autolock";
const UPDATE_CHECK_ALARM_NAME = "omnivault_github_update_check";

const LATEST_RELEASE_STORAGE_KEY = "omnivault_github_release_v1";
const GITHUB_RELEASE_API_URL = "https://api.github.com/repos/Minhtuan0506/omnivault-extension/releases/latest";
const GITHUB_VERSION_JSON_URL = "https://minhtuan0506.github.io/omnivault-extension/version.json";
const DEFAULT_UNPACKED_ZIP_URL = "https://minhtuan0506.github.io/omnivault-extension/OmniVault-GiaiNen-latest.zip";
const DEFAULT_AUTOUPDATE_KIT_URL = "https://minhtuan0506.github.io/omnivault-extension/OmniVault-TuDongCapNhat-Windows.zip";
const DEFAULT_RELEASE_HTML_URL = "https://github.com/Minhtuan0506/omnivault-extension/releases/latest";
const UPDATE_CACHE_TTL_MS = 15 * 60 * 1000;

const TAB_NOTICES_KEY = "omnivault_tab_notices_v1";
const UNDO_RECORDS_KEY = "omnivault_undo_records_v1";
const LOCKED_CAPTURES_KEY = "omnivault_locked_captures_v1";
const PENDING_UPDATES_KEY = "omnivault_pending_updates_v1";

const TAB_NOTICE_TTL_MS = 120_000;
const UNDO_RECORD_TTL_MS = 300_000;
const UNDO_RECORD_MAX = 20;
const LOCKED_CAPTURE_TTL_MS = 600_000;
const LOCKED_CAPTURE_MAX = 10;
const PENDING_UPDATE_TTL_MS = 120_000;
const PENDING_UPDATE_MAX = 15;

const memorySessionFallback = Object.create(null);
const pendingTabNotices = new Map();
let pendingTabNoticesHydrated = false;

function sanitizeGitHubUpdateUrl(rawUrl, fallbackUrl) {
  return OmniVaultCore.isAllowedGitHubUpdateUrl(rawUrl) ? String(rawUrl).trim() : fallbackUrl;
}

async function getSessionJson(key, fallback) {
  try {
    if (chrome?.storage?.session?.get) {
      const data = await chrome.storage.session.get(key);
      if (data && data[key] !== undefined) {
        return data[key];
      }
      return fallback;
    }
  } catch (_) {}
  return memorySessionFallback[key] !== undefined ? memorySessionFallback[key] : fallback;
}

async function setSessionJson(key, val) {
  memorySessionFallback[key] = val;
  try {
    if (chrome?.storage?.session?.set) {
      await chrome.storage.session.set({ [key]: val });
    }
  } catch (_) {}
}

async function ensurePendingTabNoticesHydrated() {
  if (pendingTabNoticesHydrated) return;
  pendingTabNoticesHydrated = true;
  const raw = await getSessionJson(TAB_NOTICES_KEY, {});
  const pruned = pruneMapByTtl(raw, TAB_NOTICE_TTL_MS, UNDO_RECORD_MAX);
  pendingTabNotices.clear();
  for (const [k, v] of Object.entries(pruned)) {
    pendingTabNotices.set(String(k), v);
  }
}

async function storePendingTabNotice(tabId, notice) {
  if (tabId == null || !notice) return;
  await ensurePendingTabNoticesHydrated();
  pendingTabNotices.set(String(tabId), notice);
  const pruned = pruneMapByTtl(
    Object.fromEntries(pendingTabNotices.entries()),
    TAB_NOTICE_TTL_MS,
    UNDO_RECORD_MAX
  );
  pendingTabNotices.clear();
  for (const [k, v] of Object.entries(pruned)) {
    pendingTabNotices.set(String(k), v);
  }
  await setSessionJson(TAB_NOTICES_KEY, pruned);
}

async function removePendingTabNotice(tabId, expectedNoticeId = null) {
  if (tabId == null) return false;
  await ensurePendingTabNoticesHydrated();
  const key = String(tabId);
  const existing = pendingTabNotices.get(key);
  if (!existing) return false;
  if (expectedNoticeId && existing.noticeId !== expectedNoticeId) return false;
  pendingTabNotices.delete(key);
  const pruned = pruneMapByTtl(
    Object.fromEntries(pendingTabNotices.entries()),
    TAB_NOTICE_TTL_MS,
    UNDO_RECORD_MAX
  );
  await setSessionJson(TAB_NOTICES_KEY, pruned);
  return true;
}

function pushTabNoticeToTab(tabId, notice, attempt = 0) {
  if (!chrome?.tabs?.sendMessage || tabId == null || !notice) return;
  try {
    chrome.tabs.sendMessage(
      tabId,
      { type: "SHOW_TAB_CAPTURE_NOTICE", notice },
      (resp) => {
        if (chrome.runtime.lastError || !resp || !resp.shown) {
          if (attempt === 0) {
            setTimeout(() => {
              const stillThere = pendingTabNotices.get(String(tabId));
              if (stillThere && stillThere.noticeId === notice.noticeId) {
                pushTabNoticeToTab(tabId, notice, 1);
              }
            }, 350);
          }
          return;
        }
        removePendingTabNotice(tabId, notice.noticeId).catch(() => {});
      }
    );
  } catch (_) {}
}

async function clearEphemeralCaptureCaches() {
  for (const k of Object.keys(memorySessionFallback)) {
    delete memorySessionFallback[k];
  }
  pendingTabNotices.clear();
  pendingTabNoticesHydrated = true;
  try {
    if (chrome?.storage?.session?.remove) {
      await chrome.storage.session.remove([
        TAB_NOTICES_KEY,
        UNDO_RECORDS_KEY,
        LOCKED_CAPTURES_KEY,
        PENDING_UPDATES_KEY
      ]);
    }
  } catch (_) {}
}

function pruneMapByTtl(mapObj, ttlMs, maxEntries, tsField = "createdAt") {
  const now = Date.now();
  const entries = Object.entries(mapObj || {}).filter(([, v]) => v && now - Number(v[tsField] || 0) < ttlMs);
  entries.sort((a, b) => Number(b[1][tsField] || 0) - Number(a[1][tsField] || 0));
  const out = {};
  for (const [k, v] of entries.slice(0, maxEntries)) {
    out[k] = v;
  }
  return out;
}

function upsertCapturedCredentialInState(
  st,
  { host, serviceName, username, password, now, allowOverwriteExistingPassword = false }
) {
  const cleanUser = String(username || "").trim();
  const cleanPass = String(password || "");
  const cleanHost = String(host || "").trim();
  const items = Array.isArray(st.items) ? st.items : [];
  st.items = items;
  if (!st.deletedIds || typeof st.deletedIds !== "object") {
    st.deletedIds = {};
  }

  let existingIdx = items.findIndex((it) => {
    const domScore = OmniVaultCore.itemMatchesDomain(it, cleanHost);
    if (domScore < 3) return false;
    if (cleanUser) {
      return String(it.username || "").trim().toLowerCase() === cleanUser.toLowerCase();
    }
    return !String(it.username || "").trim();
  });

  if (existingIdx < 0 && cleanUser) {
    existingIdx = items.findIndex(
      (it) =>
        OmniVaultCore.itemMatchesDomain(it, cleanHost) >= 3 &&
        !String(it.username || "").trim() &&
        it.password === cleanPass
    );
  }

  if (existingIdx < 0 && !cleanUser) {
    const matchingPassOnHost = items.some(
      (it) => OmniVaultCore.itemMatchesDomain(it, cleanHost) >= 3 && it.password === cleanPass
    );
    if (matchingPassOnHost) {
      return { status: "already_saved" };
    }
  }

  if (existingIdx >= 0) {
    const prev = items[existingIdx];
    if (prev.password === cleanPass && (!cleanUser || String(prev.username || "").trim() === cleanUser)) {
      return { status: "already_saved" };
    }
    // Never silently overwrite an existing different password without explicit user confirmation
    if (prev.password && prev.password !== cleanPass && !allowOverwriteExistingPassword) {
      return { status: "needs_confirm_update", existingItem: prev };
    }
    const prevUsername = prev.username || "";
    const prevWasEmpty = !prev.password;
    const prevPasswordChanged = Boolean(prev.password && prev.password !== cleanPass);
    const updated = { ...prev };
    if (cleanUser) updated.username = cleanUser;
    if (prevPasswordChanged) {
      updated.password_history = [
        { password: prev.password, changed_at_ms: now },
        ...(Array.isArray(prev.password_history) ? prev.password_history : [])
      ].slice(0, 10);
    }
    updated.password = cleanPass;
    const prevDomains = Array.isArray(updated.web_domains) ? updated.web_domains : [];
    if (cleanHost && !prevDomains.includes(cleanHost)) {
      updated.web_domains = [...prevDomains, cleanHost];
    }
    updated.updated_at_ms = now;
    delete st.deletedIds[prev.id];
    const saved = OmniVaultCore.normalizeVaultItem(updated);
    items[existingIdx] = saved;
    return {
      status: "auto_saved",
      mode: "updated",
      item: saved,
      prevUsername,
      prevWasEmpty,
      prevPasswordHistoryChangedAt: prevPasswordChanged ? now : 0
    };
  }

  const title = String(
    serviceName || OmniVaultCore.prettifyDomainTitle(cleanHost) || cleanHost || "Tài khoản Web"
  ).trim();
  const saved = OmniVaultCore.normalizeVaultItem({
    id: crypto.randomUUID(),
    service_name: title,
    username: cleanUser,
    password: cleanPass,
    web_domains: cleanHost ? [cleanHost] : [],
    created_at_ms: now,
    updated_at_ms: now
  });
  items.push(saved);
  return {
    status: "auto_saved",
    mode: "created",
    item: saved,
    prevUsername: "",
    prevWasEmpty: true,
    prevPasswordHistoryChangedAt: 0
  };
}

async function reinjectContentScriptsOnOpenTabs() {
  try {
    if (!chrome?.tabs?.query || !chrome?.scripting?.executeScript) return;
    const tabs = await chrome.tabs.query({ url: ["https://*/*", "http://*/*"] });
    for (const tab of Array.isArray(tabs) ? tabs : []) {
      if (tab && tab.id != null && OmniVaultCore.isSafeAutofillUrl(tab.url || "")) {
        chrome.scripting
          .executeScript({ target: { tabId: tab.id, allFrames: false }, files: ["content.js"] })
          .catch(() => {});
      }
    }
  } catch (_) {}
}

function compareVersions(a, b) {
  const pa = String(a || "0").replace(/^v/i, "").split(".").map((x) => parseInt(x, 10) || 0);
  const pb = String(b || "0").replace(/^v/i, "").split(".").map((x) => parseInt(x, 10) || 0);
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const va = pa[i] || 0;
    const vb = pb[i] || 0;
    if (va !== vb) return va - vb;
  }
  return 0;
}

async function setUpdateActionBadge(hasUpdate) {
  try {
    if (!chrome?.action?.setBadgeText) return;
    await chrome.action.setBadgeText({ text: hasUpdate ? "NEW" : "" });
    if (hasUpdate && chrome.action.setBadgeBackgroundColor) {
      await chrome.action.setBadgeBackgroundColor({ color: "#dc2626" });
    }
  } catch (_) {}
}

async function readStoredUpdateMeta() {
  try {
    const data = await chrome.storage.local.get(LATEST_RELEASE_STORAGE_KEY);
    return (data && data[LATEST_RELEASE_STORAGE_KEY]) || {};
  } catch (_) {
    return {};
  }
}

async function writeStoredUpdateMeta(meta) {
  try {
    await chrome.storage.local.set({ [LATEST_RELEASE_STORAGE_KEY]: meta });
  } catch (_) {}
}

function isTrustedExtensionPageSender(sender) {
  if (!sender) return false;
  if (sender.id && chrome?.runtime?.id && sender.id !== chrome.runtime.id) {
    return false;
  }
  if (!sender.tab) return true;
  const extOrigin = typeof chrome?.runtime?.getURL === "function" ? chrome.runtime.getURL("") : "";
  const senderUrl = String(sender.url || sender.tab.url || "");
  return Boolean(extOrigin && senderUrl.startsWith(extOrigin));
}

async function openExtensionUpdaterWindow(autoStart = false) {
  const baseUrl = chrome?.runtime?.getURL ? chrome.runtime.getURL("updater.html") : "updater.html";
  const targetUrl = autoStart ? `${baseUrl}?auto=1` : baseUrl;

  try {
    if (chrome?.tabs?.query) {
      const existingTabs = await chrome.tabs.query({ url: `${baseUrl}*` });
      if (Array.isArray(existingTabs) && existingTabs.length > 0) {
        const existing = existingTabs[0];
        if (existing.windowId != null && chrome?.windows?.update) {
          await chrome.windows.update(existing.windowId, { focused: true }).catch(() => {});
        }
        if (existing.id != null && chrome?.tabs?.update) {
          await chrome.tabs
            .update(existing.id, { active: true, url: autoStart ? targetUrl : undefined })
            .catch(() => {});
        }
        return { ok: true, reused: true };
      }
    }
  } catch (_) {}

  if (chrome?.windows?.create) {
    try {
      await chrome.windows.create({
        url: targetUrl,
        type: "popup",
        width: 472,
        height: 620,
        focused: true
      });
      return { ok: true, reused: false };
    } catch (_) {}
  }

  if (chrome?.tabs?.create) {
    await chrome.tabs.create({ url: targetUrl, active: true });
    return { ok: true, reused: false };
  }
  return { ok: false, error: "Không mở được cửa sổ cập nhật tiện ích." };
}

function buildUpdateResponse(meta, extra = {}) {
  const manifest = chrome?.runtime?.getManifest ? chrome.runtime.getManifest() : {};
  const currentVersion = String(manifest.version || "0.0.0");
  const isCrxManaged = Boolean(manifest.update_url);
  const latestVersion = String(meta?.latestVersion || currentVersion).replace(/^v/i, "");
  let pendingCrx = String(meta?.pendingCrxReloadVersion || "").replace(/^v/i, "");
  if (pendingCrx && compareVersions(pendingCrx, currentVersion) <= 0) {
    pendingCrx = "";
  }
  const hasUpdate = compareVersions(latestVersion, currentVersion) > 0 || Boolean(pendingCrx);
  return {
    ok: true,
    currentVersion,
    latestVersion,
    hasUpdate,
    isCrxManaged,
    changelog: String(meta?.changelog || ""),
    unpackedZipUrl: sanitizeGitHubUpdateUrl(meta?.unpackedZipUrl, DEFAULT_UNPACKED_ZIP_URL),
    unpackedLatestUrl: sanitizeGitHubUpdateUrl(meta?.unpackedLatestUrl, DEFAULT_UNPACKED_ZIP_URL),
    versionJsonUrl: sanitizeGitHubUpdateUrl(meta?.versionJsonUrl, GITHUB_VERSION_JSON_URL),
    zipSha256: String(meta?.zipSha256 || "").trim().toLowerCase(),
    signatureRsaB64: String(meta?.signatureRsaB64 || "").trim(),
    autoUpdateKitUrl: sanitizeGitHubUpdateUrl(meta?.autoUpdateKitUrl, DEFAULT_AUTOUPDATE_KIT_URL),
    releaseHtmlUrl: sanitizeGitHubUpdateUrl(meta?.releaseHtmlUrl, DEFAULT_RELEASE_HTML_URL),
    pendingCrxReloadVersion: pendingCrx,
    checkedAtMs: Number(meta?.checkedAtMs || 0),
    ...extra
  };
}

async function fetchSignedVersionJson(preferredAssetUrl, now) {
  const candidates = [];
  if (preferredAssetUrl && OmniVaultCore.isAllowedGitHubUpdateUrl(preferredAssetUrl)) {
    candidates.push(String(preferredAssetUrl).trim());
  }
  candidates.push(`${GITHUB_VERSION_JSON_URL}?t=${now}`);

  for (let i = 0; i < candidates.length; i++) {
    const url = candidates[i];
    try {
      const verRes = await fetch(url, { cache: "no-store" });
      if (!verRes.ok) continue;
      const vj = await verRes.json();
      const ver = String(vj?.version || "").replace(/^v/i, "").trim();
      if (!ver) continue;
      return {
        latestVersion: ver,
        changelog: String(vj?.changelog || "").trim(),
        unpackedZipUrl: sanitizeGitHubUpdateUrl(vj?.unpacked_zip_url, DEFAULT_UNPACKED_ZIP_URL),
        unpackedLatestUrl: sanitizeGitHubUpdateUrl(vj?.unpacked_latest, DEFAULT_UNPACKED_ZIP_URL),
        versionJsonUrl: sanitizeGitHubUpdateUrl(
          preferredAssetUrl || GITHUB_VERSION_JSON_URL,
          GITHUB_VERSION_JSON_URL
        ),
        zipSha256: String(vj?.zip_sha256 || "").trim().toLowerCase(),
        signatureRsaB64: String(vj?.signature_rsa_b64 || "").trim(),
        autoUpdateKitUrl: sanitizeGitHubUpdateUrl(
          vj?.autoupdate_kit_url,
          DEFAULT_AUTOUPDATE_KIT_URL
        ),
        releaseHtmlUrl: sanitizeGitHubUpdateUrl(vj?.release_url, DEFAULT_RELEASE_HTML_URL)
      };
    } catch (_) {}
  }
  return null;
}

async function checkGitHubExtensionUpdate(force = false) {
  const manifest = chrome?.runtime?.getManifest ? chrome.runtime.getManifest() : {};
  const currentVersion = String(manifest.version || "0.0.0");
  const cached = await readStoredUpdateMeta();
  const now = Date.now();

  const cacheHasUpdate = Boolean(
    cached?.latestVersion && compareVersions(cached.latestVersion, currentVersion) > 0
  );
  const cacheHasSignedMeta = Boolean(cached?.zipSha256 && cached?.signatureRsaB64);

  if (
    !force &&
    cached?.latestVersion &&
    now - Number(cached.checkedAtMs || 0) < UPDATE_CACHE_TTL_MS &&
    (!cacheHasUpdate || cacheHasSignedMeta)
  ) {
    const resp = buildUpdateResponse(cached);
    await setUpdateActionBadge(resp.hasUpdate);
    return resp;
  }

  let parsed = null;
  let versionAssetUrl = "";
  let lastErr = "";

  try {
    const res = await fetch(GITHUB_RELEASE_API_URL, {
      headers: { Accept: "application/vnd.github+json" },
      cache: "no-store"
    });
    if (res.ok) {
      const rel = await res.json();
      const assets = Array.isArray(rel?.assets) ? rel.assets : [];
      const unpackedAsset = assets.find((a) => /OmniVault-GiaiNen-.*\.zip$/i.test(String(a?.name || "")));
      const kitAsset = assets.find((a) => /OmniVault-TuDongCapNhat-Windows\.zip$/i.test(String(a?.name || "")));
      const verAsset = assets.find((a) => /^version\.json$/i.test(String(a?.name || "")));
      if (verAsset?.browser_download_url && OmniVaultCore.isAllowedGitHubUpdateUrl(verAsset.browser_download_url)) {
        versionAssetUrl = String(verAsset.browser_download_url).trim();
      }
      parsed = {
        latestVersion: String(rel?.tag_name || rel?.name || "").replace(/^v/i, "").trim(),
        changelog: String(rel?.body || "").trim(),
        unpackedZipUrl: sanitizeGitHubUpdateUrl(
          unpackedAsset?.browser_download_url,
          DEFAULT_UNPACKED_ZIP_URL
        ),
        unpackedLatestUrl: DEFAULT_UNPACKED_ZIP_URL,
        versionJsonUrl: versionAssetUrl || GITHUB_VERSION_JSON_URL,
        zipSha256: "",
        signatureRsaB64: "",
        autoUpdateKitUrl: sanitizeGitHubUpdateUrl(
          kitAsset?.browser_download_url,
          DEFAULT_AUTOUPDATE_KIT_URL
        ),
        releaseHtmlUrl: sanitizeGitHubUpdateUrl(rel?.html_url, DEFAULT_RELEASE_HTML_URL)
      };
    } else {
      lastErr = `GitHub API HTTP ${res.status}`;
    }
  } catch (e) {
    lastErr = String(e?.message || e || "Network error");
  }

  // Always hydrate cryptographic verification fields (zip_sha256 & signature_rsa_b64) from signed version.json
  const signedMeta = await fetchSignedVersionJson(versionAssetUrl, now);
  if (signedMeta) {
    if (!parsed || !parsed.latestVersion) {
      parsed = signedMeta;
    } else if (compareVersions(signedMeta.latestVersion, parsed.latestVersion) >= 0) {
      parsed = {
        ...parsed,
        latestVersion: signedMeta.latestVersion,
        changelog: parsed.changelog || signedMeta.changelog,
        unpackedZipUrl:
          compareVersions(signedMeta.latestVersion, parsed.latestVersion) > 0
            ? signedMeta.unpackedZipUrl
            : parsed.unpackedZipUrl || signedMeta.unpackedZipUrl,
        unpackedLatestUrl: signedMeta.unpackedLatestUrl || DEFAULT_UNPACKED_ZIP_URL,
        versionJsonUrl: versionAssetUrl || signedMeta.versionJsonUrl || GITHUB_VERSION_JSON_URL,
        zipSha256: signedMeta.zipSha256,
        signatureRsaB64: signedMeta.signatureRsaB64,
        autoUpdateKitUrl: parsed.autoUpdateKitUrl || signedMeta.autoUpdateKitUrl,
        releaseHtmlUrl: parsed.releaseHtmlUrl || signedMeta.releaseHtmlUrl
      };
    }
  }

  if (parsed && parsed.latestVersion) {
    let pendingCrx = String(cached?.pendingCrxReloadVersion || "").replace(/^v/i, "");
    if (pendingCrx && compareVersions(pendingCrx, currentVersion) <= 0) {
      pendingCrx = "";
    }
    const nextMeta = {
      ...parsed,
      pendingCrxReloadVersion: pendingCrx,
      checkedAtMs: now
    };
    await writeStoredUpdateMeta(nextMeta);
    const resp = buildUpdateResponse(nextMeta);
    await setUpdateActionBadge(resp.hasUpdate);
    return resp;
  }

  const fallbackResp = buildUpdateResponse(cached, { ok: false, error: lastErr || "Không kiểm tra được GitHub" });
  await setUpdateActionBadge(fallbackResp.hasUpdate);
  return fallbackResp;
}

async function lockVaultAndClearCaches() {
  await clearEphemeralCaptureCaches();
  await OmniVaultCore.lockExtensionSession();
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create(SYNC_ALARM_NAME, { periodInMinutes: 5 });
  chrome.alarms.create(UPDATE_CHECK_ALARM_NAME, { periodInMinutes: 120 });
  reinjectContentScriptsOnOpenTabs();
  readStoredUpdateMeta().then((meta) => {
    const manifestVer = chrome?.runtime?.getManifest ? chrome.runtime.getManifest().version : "0.0.0";
    if (meta?.pendingCrxReloadVersion && compareVersions(meta.pendingCrxReloadVersion, manifestVer) <= 0) {
      meta.pendingCrxReloadVersion = "";
      writeStoredUpdateMeta(meta);
    }
  });
  checkGitHubExtensionUpdate(true).catch(() => {});
});

chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create(SYNC_ALARM_NAME, { periodInMinutes: 5 });
  chrome.alarms.create(UPDATE_CHECK_ALARM_NAME, { periodInMinutes: 120 });
  OmniVaultCore.enforceSessionExpiryIfNeeded().catch(() => {});
  checkGitHubExtensionUpdate(false).catch(() => {});
});

if (chrome?.runtime?.onUpdateAvailable?.addListener) {
  chrome.runtime.onUpdateAvailable.addListener(async (details) => {
    const nextVer = String(details?.version || "").replace(/^v/i, "").trim();
    const meta = await readStoredUpdateMeta();
    meta.pendingCrxReloadVersion = nextVer || meta.latestVersion || "new";
    if (nextVer && (!meta.latestVersion || compareVersions(nextVer, meta.latestVersion) > 0)) {
      meta.latestVersion = nextVer;
    }
    await writeStoredUpdateMeta(meta);
    await setUpdateActionBadge(true);
    try {
      if (typeof chrome.runtime.getContexts === "function") {
        const openUi = await chrome.runtime.getContexts({ contextTypes: ["POPUP", "TAB"] });
        if (!Array.isArray(openUi) || openUi.length === 0) {
          chrome.runtime.reload();
        }
      }
    } catch (_) {}
  });
}

if (chrome?.idle?.setDetectionInterval && chrome?.idle?.onStateChanged?.addListener) {
  try {
    chrome.idle.setDetectionInterval(15 * 60);
    chrome.idle.onStateChanged.addListener(async (newState) => {
      if (newState === "idle" || newState === "locked") {
        await lockVaultAndClearCaches();
      } else if (newState === "active") {
        await OmniVaultCore.enforceSessionExpiryIfNeeded().catch(() => {});
      }
    });
  } catch (_) {}
}

if (chrome?.windows?.onFocusChanged?.addListener) {
  try {
    chrome.windows.onFocusChanged.addListener(async () => {
      const nowLocked = await OmniVaultCore.enforceSessionExpiryIfNeeded().catch(() => false);
      if (nowLocked) {
        await clearEphemeralCaptureCaches();
      }
    });
  } catch (_) {}
}

if (chrome?.storage?.onChanged?.addListener) {
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (typeof OmniVaultCore.handleStorageChanged === "function") {
      OmniVaultCore.handleStorageChanged(changes, areaName);
    }
    if (areaName === "session" && changes && changes[OmniVaultCore.OMNIVAULT_SESSION_KEY]) {
      if (!changes[OmniVaultCore.OMNIVAULT_SESSION_KEY].newValue) {
        clearEphemeralCaptureCaches().catch(() => {});
      }
    }
  });
}

// Proactive push of pending tab capture notices ONLY for tabs that actually have a pending entry
if (chrome?.tabs?.onUpdated?.addListener) {
  chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (!changeInfo || changeInfo.status !== "complete") return;
    if (pendingTabNoticesHydrated && pendingTabNotices.size === 0) return;
    (async () => {
      try {
        await ensurePendingTabNoticesHydrated();
        const notice = pendingTabNotices.get(String(tabId));
        if (!notice) return;
        if (Date.now() - Number(notice.createdAt || 0) >= TAB_NOTICE_TTL_MS) {
          await removePendingTabNotice(tabId, notice.noticeId);
          return;
        }
        const tabUrl = tab?.url || "";
        if (!OmniVaultCore.isSafeAutofillUrl(tabUrl)) return;
        pushTabNoticeToTab(tabId, notice, 0);
      } catch (_) {}
    })();
  });
}

if (chrome?.tabs?.onRemoved?.addListener) {
  chrome.tabs.onRemoved.addListener((tabId) => {
    if (pendingTabNotices.has(String(tabId))) {
      removePendingTabNotice(tabId).catch(() => {});
    }
  });
}

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === AUTOLOCK_ALARM_NAME) {
    await lockVaultAndClearCaches();
    return;
  }
  if (alarm.name === UPDATE_CHECK_ALARM_NAME) {
    await checkGitHubExtensionUpdate(false).catch(() => {});
    return;
  }
  if (alarm.name === SYNC_ALARM_NAME) {
    try {
      const { state: st } = await OmniVaultCore.getCachedVaultStateAndIndex();
      if (!st.locked && st.pairing && !st.pairing.localOnly) {
        await OmniVaultCore.syncBrowserVaultBidirectional(false);
      }
    } catch (_) {
      // Silent retry on next cycle
    }
  }
});

function resolveVerifiedSenderHost(sender) {
  if (sender?.frameId && sender.frameId !== 0) {
    return "";
  }
  const tabUrl = sender?.tab?.url || "";
  const frameUrl = sender?.url || tabUrl;
  if (!OmniVaultCore.isSafeAutofillUrl(tabUrl) || !OmniVaultCore.isSafeAutofillUrl(frameUrl)) {
    return "";
  }
  const tabHost = OmniVaultCore.extractCleanDomain(tabUrl);
  const frameHost = OmniVaultCore.extractCleanDomain(frameUrl);
  if (!tabHost || !frameHost || tabHost !== frameHost) return "";
  return frameHost;
}

function computeUsernameAffinity(itemUsername, preferredUserLc, host) {
  if (!preferredUserLc) return 0;
  const u = String(itemUsername || "").trim().toLowerCase();
  if (!u) return 0;
  if (u === preferredUserLc) return 4;
  if (host === "accounts.google.com" || host === "google.com" || host.endsWith(".google.com")) {
    const stripGmail = (s) => s.replace(/@(gmail|googlemail)\.com$/i, "");
    const uBase = stripGmail(u);
    const pBase = stripGmail(preferredUserLc);
    if (uBase && uBase === pBase) return 3;
  }
  if (OmniVaultCore.matchesUsernamePrefix(itemUsername, preferredUserLc)) {
    return 2;
  }
  return 0;
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || typeof msg !== "object") return false;

  if (msg.type === "GET_DOMAIN_MATCHES") {
    (async () => {
      try {
        const host = resolveVerifiedSenderHost(sender);
        if (!host) {
          sendResponse({ paired: false, matches: [] });
          return;
        }
        const { state: st, byDomain } = await OmniVaultCore.getCachedVaultStateAndIndex();
        if (st.locked) {
          sendResponse({ paired: true, locked: true, matches: [] });
          return;
        }
        if (!st.pairing) {
          sendResponse({ paired: false, matches: [] });
          return;
        }
        const preferredUsername = String(msg.preferredUsername || "").trim().toLowerCase();
        // O(1) inverted domain index lookup (strict INV-07 subdomain isolation: only www. stripped)
        const domainHits = byDomain.get(host) || [];
        const ranked = new Array(domainHits.length);
        for (let i = 0; i < domainHits.length; i++) {
          const hit = domainHits[i];
          ranked[i] = {
            score: hit.score,
            userBoost: computeUsernameAffinity(hit.item.username, preferredUsername, host),
            item: hit.item
          };
        }
        ranked.sort((a, b) => {
          if (b.userBoost !== a.userBoost) return b.userBoost - a.userBoost;
          if (b.score !== a.score) return b.score - a.score;
          const favDiff = (b.item.is_favorite ? 1 : 0) - (a.item.is_favorite ? 1 : 0);
          if (favDiff !== 0) return favDiff;
          const timeDiff = (Number(b.item.last_autofilled_ms) || 0) - (Number(a.item.last_autofilled_ms) || 0);
          if (timeDiff !== 0) return timeDiff;
          return String(a.item.username || a.item.service_name || "").localeCompare(
            String(b.item.username || b.item.service_name || ""),
            "vi"
          );
        });
        // EXT-02: Never send plaintext passwords on passive focus — return metadata only!
        sendResponse({
          paired: true,
          matches: ranked.slice(0, 1000).map((r) => ({
            id: r.item.id,
            service_name: r.item.service_name,
            username: r.item.username,
            domain: (Array.isArray(r.item.web_domains) && r.item.web_domains[0]) || host,
            is_favorite: Boolean(r.item.is_favorite),
            step1_matched: r.userBoost >= 3
          }))
        });
      } catch (e) {
        sendResponse({ paired: false, matches: [], error: String(e.message || e) });
      }
    })();
    return true;
  }

  if (msg.type === "REQUEST_CREDENTIAL_FILL") {
    (async () => {
      try {
        const host = resolveVerifiedSenderHost(sender);
        if (!host) {
          sendResponse({ ok: false, error: "Trang không an toàn để tự động điền." });
          return;
        }
        const targetId = String(msg.itemId || "");
        const { state: st, byId } = await OmniVaultCore.getCachedVaultStateAndIndex();
        if (st.locked) {
          sendResponse({
            ok: false,
            error: "Kho OmniVault đang khóa. Hãy bấm biểu tượng tiện ích để nhập PIN."
          });
          return;
        }
        if (!st.pairing) {
          sendResponse({ ok: false, error: "Chưa kết nối OmniVault." });
          return;
        }
        const item = byId.get(targetId);
        if (!item || OmniVaultCore.itemMatchesDomain(item, host) < 2) {
          sendResponse({
            ok: false,
            error: "Tài khoản không khớp tên miền đã xác thực."
          });
          return;
        }
        // Update lightweight hot recency map + RAM cache WITHOUT re-encrypting the vault blob!
        await OmniVaultCore.recordItemAutofilled(item.id, Date.now());
        if (st.hasPinLock) {
          await OmniVaultCore.touchAutoLockAlarm();
        }
        sendResponse({
          ok: true,
          username: item.username || "",
          password: msg.step1Only ? "" : item.password || ""
        });
      } catch (e) {
        sendResponse({ ok: false, error: String(e.message || e) });
      }
    })();
    return true;
  }

  if (msg.type === "SUBMIT_LOGIN_CAPTURE") {
    (async () => {
      try {
        const host = resolveVerifiedSenderHost(sender);
        if (!host) {
          sendResponse({ ok: false, status: "unsafe_origin" });
          return;
        }
        const username = String(msg.username || "").trim();
        const password = String(msg.password || "");
        if (!password) {
          sendResponse({ ok: false, status: "empty_password" });
          return;
        }
        const tabId = sender?.tab?.id;
        const now = Date.now();

        const outcome = await OmniVaultCore.mutateVaultState(async (st) => {
          if (st.locked) {
            // HIGH-EXT-04: Never store plaintext passwords in chrome.storage.session while locked!
            // Retain only non-secret origin/username hint so user can unlock first.
            const list = await getSessionJson(LOCKED_CAPTURES_KEY, []);
            const fresh = (Array.isArray(list) ? list : []).filter(
              (c) => c && now - Number(c.capturedAt || 0) < LOCKED_CAPTURE_TTL_MS
            );
            const dedupKey = `${host}|${username.toLowerCase()}`;
            const filtered = fresh.filter(
              (c) => `${c.host}|${String(c.username || "").toLowerCase()}` !== dedupKey
            );
            filtered.unshift({
              id: crypto.randomUUID(),
              host,
              serviceName: OmniVaultCore.prettifyDomainTitle(host) || host,
              username,
              capturedAt: now
            });
            await setSessionJson(LOCKED_CAPTURES_KEY, filtered.slice(0, LOCKED_CAPTURE_MAX));

            const notice = {
              noticeId: crypto.randomUUID(),
              kind: "locked_pending",
              host,
              username,
              createdAt: now
            };
            if (tabId != null) {
              await storePendingTabNotice(tabId, notice);
            }
            return {
              save: false,
              result: { response: { ok: true, status: "locked_pending", notice }, shouldSync: false }
            };
          }

          if (!st.pairing) {
            const notice = {
              noticeId: crypto.randomUUID(),
              kind: "unpaired",
              host,
              username,
              createdAt: now
            };
            if (tabId != null) {
              await storePendingTabNotice(tabId, notice);
            }
            return {
              save: false,
              result: { response: { ok: true, status: "unpaired", notice }, shouldSync: false }
            };
          }

          const res = upsertCapturedCredentialInState(st, {
            host,
            serviceName: msg.serviceName,
            username,
            password,
            now,
            allowOverwriteExistingPassword: false
          });
          if (res.status === "already_saved") {
            return {
              save: false,
              result: { response: { ok: true, status: "already_saved" }, shouldSync: false }
            };
          }

          if (res.status === "needs_confirm_update") {
            // HIGH-EXT-02: Require explicit user confirmation before overwriting an existing different password!
            const proposalId = crypto.randomUUID();
            const pendingMap = pruneMapByTtl(
              await getSessionJson(PENDING_UPDATES_KEY, {}),
              PENDING_UPDATE_TTL_MS,
              PENDING_UPDATE_MAX
            );
            pendingMap[proposalId] = {
              proposalId,
              itemId: res.existingItem.id,
              host,
              serviceName: res.existingItem.service_name,
              username: username || res.existingItem.username || "",
              newPassword: password,
              createdAt: now
            };
            await setSessionJson(PENDING_UPDATES_KEY, pendingMap);

            const notice = {
              noticeId: proposalId,
              kind: "confirm_update",
              host,
              serviceName: res.existingItem.service_name,
              username: username || res.existingItem.username || "",
              createdAt: now
            };
            if (tabId != null) {
              await storePendingTabNotice(tabId, notice);
            }
            if (st.hasPinLock) {
              await OmniVaultCore.touchAutoLockAlarm();
            }
            return {
              save: false,
              result: { response: { ok: true, status: "confirm_update", notice }, shouldSync: false }
            };
          }

          if (st.hasPinLock) {
            await OmniVaultCore.touchAutoLockAlarm();
          }

          const noticeId = crypto.randomUUID();
          const undos = pruneMapByTtl(
            await getSessionJson(UNDO_RECORDS_KEY, {}),
            UNDO_RECORD_TTL_MS,
            UNDO_RECORD_MAX
          );
          // Store metadata-only undo entry (zero plaintext passwords or TOTP secrets in session storage)
          undos[noticeId] = {
            noticeId,
            mode: res.mode,
            itemId: res.item.id,
            prevUsername: res.prevUsername || "",
            prevWasEmpty: Boolean(res.prevWasEmpty),
            prevPasswordHistoryChangedAt: Number(res.prevPasswordHistoryChangedAt) || 0,
            host,
            username: res.item.username,
            createdAt: now
          };
          await setSessionJson(UNDO_RECORDS_KEY, undos);

          const notice = {
            noticeId,
            kind: "auto_saved",
            mode: res.mode,
            host,
            serviceName: res.item.service_name,
            username: res.item.username,
            createdAt: now
          };
          if (tabId != null) {
            await storePendingTabNotice(tabId, notice);
          }

          return {
            save: true,
            result: {
              response: { ok: true, status: "auto_saved", mode: res.mode, notice },
              shouldSync: true
            }
          };
        });

        sendResponse(outcome.response);
        if (outcome.shouldSync) {
          try {
            await OmniVaultCore.syncBrowserVaultBidirectional(true);
          } catch (_) {}
        }
      } catch (e) {
        sendResponse({ ok: false, error: String(e.message || e) });
      }
    })();
    return true;
  }

  if (msg.type === "CONFIRM_PENDING_UPDATE") {
    (async () => {
      try {
        const host = resolveVerifiedSenderHost(sender);
        const proposalId = String(msg.proposalId || "");
        if (!host || !proposalId) {
          sendResponse({ ok: false, error: "Yêu cầu xác nhận không hợp lệ" });
          return;
        }
        const now = Date.now();
        const outcome = await OmniVaultCore.mutateVaultState(async (st) => {
          if (st.locked || !st.pairing) {
            return {
              save: false,
              result: { response: { ok: false, error: "Kho đang khóa" }, shouldSync: false }
            };
          }
          const pendingMap = await getSessionJson(PENDING_UPDATES_KEY, {});
          const proposal = pendingMap && pendingMap[proposalId] ? pendingMap[proposalId] : null;
          if (!proposal || proposal.host !== host) {
            return {
              save: false,
              result: {
                response: { ok: false, error: "Đề xuất cập nhật không tồn tại hoặc sai tên miền" },
                shouldSync: false
              }
            };
          }
          delete pendingMap[proposalId];
          await setSessionJson(
            PENDING_UPDATES_KEY,
            pruneMapByTtl(pendingMap, PENDING_UPDATE_TTL_MS, PENDING_UPDATE_MAX)
          );
          if (now - Number(proposal.createdAt || 0) > PENDING_UPDATE_TTL_MS) {
            return {
              save: false,
              result: { response: { ok: false, error: "Hết thời gian xác nhận cập nhật" }, shouldSync: false }
            };
          }
          const res = upsertCapturedCredentialInState(st, {
            host: proposal.host,
            serviceName: proposal.serviceName,
            username: proposal.username,
            password: proposal.newPassword,
            now,
            allowOverwriteExistingPassword: true
          });
          if (res.status !== "auto_saved") {
            return {
              save: false,
              result: { response: { ok: true, status: res.status }, shouldSync: false }
            };
          }
          if (st.hasPinLock) {
            await OmniVaultCore.touchAutoLockAlarm();
          }
          const noticeId = crypto.randomUUID();
          const undos = pruneMapByTtl(
            await getSessionJson(UNDO_RECORDS_KEY, {}),
            UNDO_RECORD_TTL_MS,
            UNDO_RECORD_MAX
          );
          undos[noticeId] = {
            noticeId,
            mode: res.mode,
            itemId: res.item.id,
            prevUsername: res.prevUsername || "",
            prevWasEmpty: Boolean(res.prevWasEmpty),
            prevPasswordHistoryChangedAt: Number(res.prevPasswordHistoryChangedAt) || 0,
            host: proposal.host,
            username: res.item.username,
            createdAt: now
          };
          await setSessionJson(UNDO_RECORDS_KEY, undos);
          return {
            save: true,
            result: {
              response: {
                ok: true,
                status: "updated",
                noticeId,
                host: proposal.host,
                username: res.item.username
              },
              shouldSync: true
            }
          };
        });
        sendResponse(outcome.response);
        if (outcome.shouldSync) {
          try {
            await OmniVaultCore.syncBrowserVaultBidirectional(true);
          } catch (_) {}
        }
      } catch (e) {
        sendResponse({ ok: false, error: String(e.message || e) });
      }
    })();
    return true;
  }

  if (msg.type === "DISMISS_PENDING_UPDATE") {
    (async () => {
      try {
        const host = resolveVerifiedSenderHost(sender);
        const proposalId = String(msg.proposalId || "");
        if (host && proposalId) {
          const pendingMap = await getSessionJson(PENDING_UPDATES_KEY, {});
          if (pendingMap && pendingMap[proposalId] && pendingMap[proposalId].host === host) {
            delete pendingMap[proposalId];
            await setSessionJson(
              PENDING_UPDATES_KEY,
              pruneMapByTtl(pendingMap, PENDING_UPDATE_TTL_MS, PENDING_UPDATE_MAX)
            );
          }
        }
        sendResponse({ ok: true });
      } catch (_) {
        sendResponse({ ok: false });
      }
    })();
    return true;
  }

  if (msg.type === "CONSUME_TAB_CAPTURE_NOTICE") {
    if (sender?.frameId && sender.frameId !== 0) {
      sendResponse({ notice: null });
      return false;
    }
    (async () => {
      try {
        const tabId = sender?.tab?.id;
        const tabUrl = sender?.tab?.url || "";
        if (tabId == null || !OmniVaultCore.isSafeAutofillUrl(tabUrl)) {
          sendResponse({ notice: null });
          return;
        }
        await ensurePendingTabNoticesHydrated();
        const notice = pendingTabNotices.get(String(tabId)) || null;
        if (notice) {
          await removePendingTabNotice(tabId, notice.noticeId);
        }
        if (notice && Date.now() - Number(notice.createdAt || 0) < TAB_NOTICE_TTL_MS) {
          sendResponse({ notice });
        } else {
          sendResponse({ notice: null });
        }
      } catch (_) {
        sendResponse({ notice: null });
      }
    })();
    return true;
  }

  if (msg.type === "ACK_TAB_CAPTURE_NOTICE") {
    (async () => {
      try {
        const tabId = sender?.tab?.id;
        const noticeId = String(msg.noticeId || "");
        if (tabId != null && noticeId) {
          await removePendingTabNotice(tabId, noticeId);
        }
        sendResponse({ ok: true });
      } catch (_) {
        sendResponse({ ok: false });
      }
    })();
    return true;
  }

  if (msg.type === "UNDO_AUTO_SAVED_LOGIN") {
    (async () => {
      try {
        const host = resolveVerifiedSenderHost(sender);
        const noticeId = String(msg.noticeId || "");
        if (!host || !noticeId) {
          sendResponse({ ok: false, error: "Yêu cầu hoàn tác không hợp lệ" });
          return;
        }
        const outcome = await OmniVaultCore.mutateVaultState(async (st) => {
          if (st.locked || !st.pairing) {
            return {
              save: false,
              result: { response: { ok: false, error: "Kho đang khóa" }, shouldSync: false }
            };
          }
          const undos = await getSessionJson(UNDO_RECORDS_KEY, {});
          const undo = undos && undos[noticeId] ? undos[noticeId] : null;
          if (!undo || undo.host !== host) {
            return {
              save: false,
              result: { response: { ok: false, error: "Yêu cầu hoàn tác không hợp lệ" }, shouldSync: false }
            };
          }
          delete undos[noticeId];
          await setSessionJson(
            UNDO_RECORDS_KEY,
            pruneMapByTtl(undos, UNDO_RECORD_TTL_MS, UNDO_RECORD_MAX)
          );
          if (Date.now() - Number(undo.createdAt || 0) > UNDO_RECORD_TTL_MS) {
            return {
              save: false,
              result: { response: { ok: false, error: "Hết thời gian hoàn tác" }, shouldSync: false }
            };
          }
          const now = Date.now();
          if (!st.deletedIds || typeof st.deletedIds !== "object") {
            st.deletedIds = {};
          }
          if (undo.mode === "created") {
            st.items = (st.items || []).filter((x) => x.id !== undo.itemId);
            st.deletedIds[undo.itemId] = now;
          } else if (undo.mode === "updated") {
            const idx = (st.items || []).findIndex((x) => x.id === undo.itemId);
            if (idx >= 0) {
              const cur = { ...st.items[idx] };
              cur.username = undo.prevUsername || "";
              if (undo.prevWasEmpty) {
                cur.password = "";
              } else if (
                Array.isArray(cur.password_history) &&
                cur.password_history.length > 0
              ) {
                const histIdx = undo.prevPasswordHistoryChangedAt
                  ? cur.password_history.findIndex(
                      (h) => Number(h.changed_at_ms) === Number(undo.prevPasswordHistoryChangedAt)
                    )
                  : 0;
                const pickIdx = histIdx >= 0 ? histIdx : 0;
                const prevEntry = cur.password_history[pickIdx];
                if (prevEntry && typeof prevEntry.password === "string") {
                  cur.password = prevEntry.password;
                  cur.password_history = cur.password_history.filter((_, i) => i !== pickIdx);
                }
              }
              cur.updated_at_ms = now;
              st.items[idx] = OmniVaultCore.normalizeVaultItem(cur);
              delete st.deletedIds[undo.itemId];
            }
          }
          if (st.hasPinLock) {
            await OmniVaultCore.touchAutoLockAlarm();
          }
          return {
            save: true,
            result: { response: { ok: true, mode: undo.mode }, shouldSync: true }
          };
        });
        sendResponse(outcome.response);
        if (outcome.shouldSync) {
          try {
            await OmniVaultCore.syncBrowserVaultBidirectional(true);
          } catch (_) {}
        }
      } catch (e) {
        sendResponse({ ok: false, error: String(e.message || e) });
      }
    })();
    return true;
  }

  if (msg.type === "FLUSH_LOCKED_CAPTURES") {
    (async () => {
      try {
        if (sender?.tab || (sender?.id && sender.id !== chrome.runtime.id)) {
          sendResponse({ ok: false, savedCount: 0, pendingHosts: [] });
          return;
        }
        const outcome = await OmniVaultCore.withVaultMutationLock(async () => {
          // HIGH-EXT-04: Always check locked status BEFORE clearing the session hint queue!
          const st = await OmniVaultCore.loadExtensionState();
          if (st.locked || !st.pairing) {
            return { ok: false, savedCount: 0, pendingHosts: [] };
          }
          const list = await getSessionJson(LOCKED_CAPTURES_KEY, []);
          await setSessionJson(LOCKED_CAPTURES_KEY, []);
          const now = Date.now();
          const pendingHosts = [];
          for (const c of Array.isArray(list) ? list : []) {
            if (!c || now - Number(c.capturedAt || 0) >= LOCKED_CAPTURE_TTL_MS) {
              continue;
            }
            if (c.host && !pendingHosts.includes(c.host)) {
              pendingHosts.push(c.host);
            }
          }
          return { ok: true, savedCount: 0, pendingHosts };
        });
        sendResponse(outcome);
      } catch (_) {
        sendResponse({ ok: false, savedCount: 0, pendingHosts: [] });
      }
    })();
    return true;
  }

  if (msg.type === "GET_EXTENSION_UPDATE_STATUS") {
    if (!isTrustedExtensionPageSender(sender)) {
      sendResponse({ ok: false });
      return false;
    }
    checkGitHubExtensionUpdate(Boolean(msg.force))
      .then((res) => sendResponse(res))
      .catch((e) => sendResponse({ ok: false, error: String(e?.message || e) }));
    return true;
  }

  if (msg.type === "OPEN_EXTENSION_UPDATER") {
    if (!isTrustedExtensionPageSender(sender)) {
      sendResponse({ ok: false });
      return false;
    }
    openExtensionUpdaterWindow(Boolean(msg.autoStart))
      .then((res) => sendResponse(res))
      .catch((e) => sendResponse({ ok: false, error: String(e?.message || e) }));
    return true;
  }

  if (msg.type === "APPLY_EXTENSION_UPDATE_NOW") {
    if (!isTrustedExtensionPageSender(sender)) {
      sendResponse({ ok: false });
      return false;
    }
    (async () => {
      try {
        const manifest = chrome?.runtime?.getManifest ? chrome.runtime.getManifest() : {};
        const isCrxManaged = Boolean(manifest.update_url);
        const stored = await readStoredUpdateMeta();
        if (isCrxManaged && typeof chrome?.runtime?.requestUpdateCheck === "function") {
          if (stored?.pendingCrxReloadVersion) {
            sendResponse({
              ok: true,
              reloading: true,
              status: "update_available",
              version: stored.pendingCrxReloadVersion
            });
            setTimeout(() => chrome.runtime.reload(), 200);
            return;
          }
          chrome.runtime.requestUpdateCheck((status, details) => {
            if (status === "update_available") {
              sendResponse({
                ok: true,
                reloading: true,
                status,
                version: details?.version || stored?.latestVersion || ""
              });
              setTimeout(() => chrome.runtime.reload(), 200);
            } else {
              sendResponse({ ok: true, reloading: false, status: status || "no_update" });
            }
          });
          return;
        }
        sendResponse({ ok: true, reloading: true, status: "reload_unpacked" });
        setTimeout(() => chrome.runtime.reload(), 150);
      } catch (e) {
        sendResponse({ ok: false, reloading: false, error: String(e?.message || e) });
      }
    })();
    return true;
  }

  if (msg.type === "CLEAR_EPHEMERAL_CAPTURES") {
    if (sender?.tab || (sender?.id && sender.id !== chrome.runtime.id)) {
      sendResponse({ ok: false });
      return false;
    }
    clearEphemeralCaptureCaches()
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (msg.type === "UNLOCK_EXTENSION_WITH_PIN") {
    if (sender?.tab || (sender?.id && sender.id !== chrome.runtime.id)) {
      sendResponse({ ok: false, error: "Không được phép." });
      return false;
    }
    (async () => {
      try {
        // Executed inside Service Worker so closing Popup mid-unlock cannot abort 310k->600k upgrade!
        const state = await OmniVaultCore.unlockExtensionWithPin(msg.pin);
        sendResponse({ ok: true, state });
      } catch (e) {
        sendResponse({ ok: false, error: String(e?.message || e) });
      }
    })();
    return true;
  }

  if (msg.type === "SET_EXTENSION_PIN") {
    if (sender?.tab || (sender?.id && sender.id !== chrome.runtime.id)) {
      sendResponse({ ok: false, error: "Không được phép." });
      return false;
    }
    (async () => {
      try {
        await OmniVaultCore.setExtensionPin(msg.newPin, msg.currentPin ?? null);
        const state = await OmniVaultCore.loadExtensionState();
        sendResponse({ ok: true, state });
      } catch (e) {
        sendResponse({ ok: false, error: String(e?.message || e) });
      }
    })();
    return true;
  }

  if (msg.type === "CLEAR_EXTENSION_PIN") {
    if (sender?.tab || (sender?.id && sender.id !== chrome.runtime.id)) {
      sendResponse({ ok: false, error: "Không được phép." });
      return false;
    }
    (async () => {
      try {
        await OmniVaultCore.clearExtensionPin(msg.currentPin);
        const state = await OmniVaultCore.loadExtensionState();
        sendResponse({ ok: true, state });
      } catch (e) {
        sendResponse({ ok: false, error: String(e?.message || e) });
      }
    })();
    return true;
  }

  if (msg.type === "RESET_EXTENSION_VAULT") {
    if (sender?.tab || (sender?.id && sender.id !== chrome.runtime.id)) {
      sendResponse({ ok: false });
      return false;
    }
    (async () => {
      await clearEphemeralCaptureCaches();
      await OmniVaultCore.resetExtensionVault();
    })()
      .then(() => sendResponse({ ok: true }))
      .catch((e) => sendResponse({ ok: false, error: String(e?.message || e) }));
    return true;
  }

  return false;
});
