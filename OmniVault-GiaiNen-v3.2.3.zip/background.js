if (typeof importScripts === "function") {
  importScripts("crypto_totp.js");
}

try {
  chrome?.storage?.session?.setAccessLevel?.({ accessLevel: "TRUSTED_CONTEXTS" })?.catch?.(() => {});
} catch (_) {}

const SYNC_ALARM_NAME = "omnivault_periodic_sync";
const AUTOLOCK_ALARM_NAME = "omnivault_autolock";
const UPDATE_CHECK_ALARM_NAME = "omnivault_github_update_check";
const DEFERRED_AUTO_UPDATE_ALARM_NAME = "omnivault_deferred_auto_update";
const PENDING_UPDATES_CLEANUP_ALARM_NAME = "omnivault_pending_updates_cleanup";
const UPDATE_CHECK_INTERVAL_MINUTES = 20;

const LATEST_RELEASE_STORAGE_KEY = "omnivault_github_release_v1";
const NATIVE_UPDATER_HOST_NAME = "vn.canhan.omnivault.updater";
const AUTO_UPDATE_BG_STORAGE_KEY = "omnivault_auto_update_bg_v1";
const GITHUB_RELEASE_API_URL = "https://api.github.com/repos/Minhtuan0506/omnivault-extension/releases/latest";
const GITHUB_VERSION_JSON_URL = "https://minhtuan0506.github.io/omnivault-extension/version.json";
const DEFAULT_UNPACKED_ZIP_URL = "https://minhtuan0506.github.io/omnivault-extension/OmniVault-GiaiNen-latest.zip";
const DEFAULT_AUTOUPDATE_KIT_URL = "https://minhtuan0506.github.io/omnivault-extension/OmniVault-TuDongCapNhat-Windows.zip";
const DEFAULT_RELEASE_HTML_URL = "https://github.com/Minhtuan0506/omnivault-extension/releases/latest";
const UPDATE_CACHE_TTL_MS = 15 * 60 * 1000;
const GITHUB_FETCH_TIMEOUT_MS = 20_000;

const TAB_NOTICES_KEY = "omnivault_tab_notices_v1";
const UNDO_RECORDS_KEY = "omnivault_undo_records_v1";
const LOCKED_CAPTURES_KEY = "omnivault_locked_captures_v1";
const PENDING_UPDATES_KEY = "omnivault_pending_updates_v1";
const PENDING_INLINE_UNLOCK_KEY = "omnivault_pending_inline_unlock_v1";
const STEP1_USERS_KEY = "omnivault_step1_users_v1";
const UNPAIRED_HINTS_KEY = "omnivault_unpaired_hints_v1";

const TAB_NOTICE_TTL_MS = 120_000;
const UNDO_RECORD_TTL_MS = 300_000;
const UNDO_RECORD_MAX = 20;
const LOCKED_CAPTURE_TTL_MS = 600_000;
const LOCKED_CAPTURE_MAX = 10;
const PENDING_UPDATE_TTL_MS = 300_000;
const PENDING_UPDATE_MAX = 15;
const PENDING_INLINE_UNLOCK_TTL_MS = 300_000;
const STEP1_USER_TTL_MS = 300_000;
const STEP1_USER_MAX = 40;
const UNPAIRED_HINT_TTL_MS = 1_800_000;
const UNPAIRED_HINT_MAX = 40;

const VI_COLLATOR = new Intl.Collator("vi");
const memorySessionFallback = Object.create(null);
const pendingTabNotices = new Map();
let pendingTabNoticesHydrated = false;

function isStoreDistributionBuild() {
  const manifest = chrome?.runtime?.getManifest ? chrome.runtime.getManifest() : {};
  const updateUrl = String(manifest.update_url || "").toLowerCase();
  if (
    updateUrl.includes("clients2.google.com") ||
    updateUrl.includes("edge.microsoft.com")
  ) {
    return true;
  }
  const perms = Array.isArray(manifest.permissions) ? manifest.permissions : [];
  // Chrome Web Store & Edge Add-ons ZIPs strip both `key` and `nativeMessaging`.
  // Sideloaded GitHub unpacked/CRX packages retain them.
  return !manifest.key && !perms.includes("nativeMessaging");
}

function bgFetchWithTimeout(url, options = {}, timeoutMs = GITHUB_FETCH_TIMEOUT_MS) {
  if (typeof OmniVaultCore?.fetchWithTimeout === "function") {
    return OmniVaultCore.fetchWithTimeout(url, options, timeoutMs, fetch);
  }
  return fetch(url, options);
}

function sanitizeGitHubUpdateUrl(rawUrl, fallbackUrl) {
  return OmniVaultCore.isAllowedGitHubUpdateUrl(rawUrl) ? String(rawUrl).trim() : fallbackUrl;
}

async function getSessionJson(key, fallback) {
  try {
    if (chrome?.storage?.session?.get) {
      const data = await chrome.storage.session.get(key);
      if (data && data[key] !== undefined) {
        return data[key];
      }
      return fallback;
    }
  } catch (_) {}
  return memorySessionFallback[key] !== undefined ? memorySessionFallback[key] : fallback;
}

async function setSessionJson(key, val) {
  memorySessionFallback[key] = val;
  try {
    if (chrome?.storage?.session?.set) {
      await chrome.storage.session.set({ [key]: val });
    }
  } catch (_) {}
}

async function ensurePendingTabNoticesHydrated() {
  if (pendingTabNoticesHydrated) return;
  pendingTabNoticesHydrated = true;
  const raw = await getSessionJson(TAB_NOTICES_KEY, {});
  const pruned = pruneMapByTtl(raw, TAB_NOTICE_TTL_MS, UNDO_RECORD_MAX);
  pendingTabNotices.clear();
  for (const [k, v] of Object.entries(pruned)) {
    pendingTabNotices.set(String(k), v);
  }
}

async function storePendingTabNotice(tabId, notice) {
  if (tabId == null || !notice) return;
  await ensurePendingTabNoticesHydrated();
  pendingTabNotices.set(String(tabId), notice);
  const pruned = pruneMapByTtl(
    Object.fromEntries(pendingTabNotices.entries()),
    TAB_NOTICE_TTL_MS,
    UNDO_RECORD_MAX
  );
  pendingTabNotices.clear();
  for (const [k, v] of Object.entries(pruned)) {
    pendingTabNotices.set(String(k), v);
  }
  await setSessionJson(TAB_NOTICES_KEY, pruned);
}

async function removePendingTabNotice(tabId, expectedNoticeId = null) {
  if (tabId == null) return false;
  await ensurePendingTabNoticesHydrated();
  const key = String(tabId);
  const existing = pendingTabNotices.get(key);
  if (!existing) return false;
  if (expectedNoticeId && existing.noticeId !== expectedNoticeId) return false;
  pendingTabNotices.delete(key);
  const pruned = pruneMapByTtl(
    Object.fromEntries(pendingTabNotices.entries()),
    TAB_NOTICE_TTL_MS,
    UNDO_RECORD_MAX
  );
  await setSessionJson(TAB_NOTICES_KEY, pruned);
  return true;
}

function pushTabNoticeToTab(tabId, notice, attempt = 0) {
  if (!chrome?.tabs?.sendMessage || tabId == null || !notice) return;
  try {
    chrome.tabs.sendMessage(
      tabId,
      { type: "SHOW_TAB_CAPTURE_NOTICE", notice },
      (resp) => {
        if (chrome.runtime.lastError || !resp || !resp.shown) {
          if (attempt === 0) {
            setTimeout(() => {
              const stillThere = pendingTabNotices.get(String(tabId));
              if (stillThere && stillThere.noticeId === notice.noticeId) {
                pushTabNoticeToTab(tabId, notice, 1);
              }
            }, 350);
          }
          return;
        }
        removePendingTabNotice(tabId, notice.noticeId).catch(() => {});
      }
    );
  } catch (_) {}
}

async function clearEphemeralCaptureCaches(opts = {}) {
  const preserveLockedPrompts = Boolean(opts && opts.preserveLockedPrompts);
  const keysToClear = [
    TAB_NOTICES_KEY,
    UNDO_RECORDS_KEY,
    PENDING_UPDATES_KEY,
    STEP1_USERS_KEY,
    UNPAIRED_HINTS_KEY
  ];
  if (!preserveLockedPrompts) {
    keysToClear.push(LOCKED_CAPTURES_KEY, PENDING_INLINE_UNLOCK_KEY);
  }
  for (const k of keysToClear) {
    delete memorySessionFallback[k];
  }
  pendingTabNotices.clear();
  pendingTabNoticesHydrated = true;
  try {
    chrome?.alarms?.clear?.(PENDING_UPDATES_CLEANUP_ALARM_NAME);
  } catch (_) {}
  try {
    if (chrome?.storage?.session?.remove) {
      await chrome.storage.session.remove(keysToClear);
    }
  } catch (_) {}
}

function pruneMapByTtl(mapObj, ttlMs, maxEntries, tsField = "createdAt") {
  const now = Date.now();
  const entries = Object.entries(mapObj || {}).filter(([, v]) => v && now - Number(v[tsField] || 0) < ttlMs);
  entries.sort((a, b) => Number(b[1][tsField] || 0) - Number(a[1][tsField] || 0));
  const out = {};
  for (const [k, v] of entries.slice(0, maxEntries)) {
    out[k] = v;
  }
  return out;
}

function isCompatibleRedirectHost(origHost, currentHost) {
  const a = OmniVaultCore.extractCleanDomain(origHost);
  const b = OmniVaultCore.extractCleanDomain(currentHost);
  if (!a || !b) return false;
  if (a === b) return true;
  const siteA = OmniVaultCore.baseRegistrableDomain(a);
  const siteB = OmniVaultCore.baseRegistrableDomain(b);
  return Boolean(siteA && siteB && siteA === siteB);
}

function makeTabHostSessionKey(tabId, host) {
  return `${tabId}|${host}`;
}

async function setStep1UsernameForTabHost(tabId, host, rawUsername) {
  if (tabId == null || !host) return;
  const key = makeTabHostSessionKey(tabId, host);
  const cleanUser = String(rawUsername || "").trim().slice(0, 256);
  const map = pruneMapByTtl(await getSessionJson(STEP1_USERS_KEY, {}), STEP1_USER_TTL_MS, STEP1_USER_MAX);
  if (cleanUser) {
    map[key] = { tabId, host, username: cleanUser, createdAt: Date.now() };
  } else {
    delete map[key];
  }
  await setSessionJson(STEP1_USERS_KEY, pruneMapByTtl(map, STEP1_USER_TTL_MS, STEP1_USER_MAX));
}

async function getStep1UsernameForTabHost(tabId, host) {
  if (tabId == null || !host) return "";
  const map = pruneMapByTtl(await getSessionJson(STEP1_USERS_KEY, {}), STEP1_USER_TTL_MS, STEP1_USER_MAX);
  const exact = map[makeTabHostSessionKey(tabId, host)];
  if (exact && exact.username) return String(exact.username);
  // Same-tab compatible-site fallback (e.g. login.example.com -> auth.example.com)
  let best = null;
  for (const rec of Object.values(map)) {
    if (
      rec &&
      rec.tabId === tabId &&
      rec.username &&
      isCompatibleRedirectHost(rec.host, host) &&
      (!best || Number(rec.createdAt || 0) > Number(best.createdAt || 0))
    ) {
      best = rec;
    }
  }
  return best ? String(best.username) : "";
}

async function clearStep1UsernameForTabHost(tabId, host = null) {
  if (tabId == null) return;
  const raw = await getSessionJson(STEP1_USERS_KEY, {});
  if (!raw || typeof raw !== "object" || Object.keys(raw).length === 0) return;
  let changed = false;
  for (const [k, rec] of Object.entries(raw)) {
    if (!rec) continue;
    if (rec.tabId === tabId && (!host || rec.host === host || isCompatibleRedirectHost(rec.host, host))) {
      delete raw[k];
      changed = true;
    }
  }
  if (changed) {
    await setSessionJson(STEP1_USERS_KEY, pruneMapByTtl(raw, STEP1_USER_TTL_MS, STEP1_USER_MAX));
  }
}

async function checkAndMarkUnpairedHint(tabId, host) {
  if (tabId == null || !host) return false;
  const key = makeTabHostSessionKey(tabId, host);
  const map = pruneMapByTtl(await getSessionJson(UNPAIRED_HINTS_KEY, {}), UNPAIRED_HINT_TTL_MS, UNPAIRED_HINT_MAX);
  if (map[key]) {
    return true;
  }
  map[key] = { tabId, host, createdAt: Date.now() };
  await setSessionJson(UNPAIRED_HINTS_KEY, pruneMapByTtl(map, UNPAIRED_HINT_TTL_MS, UNPAIRED_HINT_MAX));
  return false;
}

async function clearTabEphemeralMaps(tabId) {
  if (tabId == null) return;
  await clearStep1UsernameForTabHost(tabId, null).catch(() => {});
  try {
    const rawHints = await getSessionJson(UNPAIRED_HINTS_KEY, {});
    if (rawHints && typeof rawHints === "object" && Object.keys(rawHints).length > 0) {
      let changed = false;
      for (const [k, rec] of Object.entries(rawHints)) {
        if (rec && rec.tabId === tabId) {
          delete rawHints[k];
          changed = true;
        }
      }
      if (changed) {
        await setSessionJson(
          UNPAIRED_HINTS_KEY,
          pruneMapByTtl(rawHints, UNPAIRED_HINT_TTL_MS, UNPAIRED_HINT_MAX)
        );
      }
    }
  } catch (_) {}
}

function usernamesMatchForAccount(savedUser, typedUser, cleanHost) {
  const a = String(savedUser || "").trim().toLowerCase();
  const b = String(typedUser || "").trim().toLowerCase();
  if (!a && !b) return true;
  if (!a || !b) return false;
  if (a === b) return true;
  const h = String(cleanHost || "").toLowerCase();
  if (h === "accounts.google.com" || h === "google.com" || h.endsWith(".google.com")) {
    const stripGmail = (s) => s.replace(/@(gmail|googlemail)\.com$/i, "");
    return stripGmail(a) === stripGmail(b);
  }
  return false;
}

function upsertCapturedCredentialInState(
  st,
  {
    host,
    serviceName,
    username,
    password,
    currentPassword = "",
    targetItemId = "",
    now,
    allowOverwriteExistingPassword = false
  }
) {
  const cleanUser = String(username || "").trim();
  const cleanPass = String(password || "");
  const cleanCurrentPass = String(currentPassword || "");
  const cleanHost = OmniVaultCore.extractCleanDomain(host || "");
  const cleanTargetId = String(targetItemId || "").trim();
  const items = Array.isArray(st.items) ? st.items : [];
  st.items = items;
  if (!st.deletedIds || typeof st.deletedIds !== "object") {
    st.deletedIds = {};
  }

  let existingIdx = -1;

  // 1. Direct target item ID (when user clicks Confirm on a pending update proposal)
  if (cleanTargetId) {
    existingIdx = items.findIndex((it) => it && it.id === cleanTargetId);
    if (existingIdx < 0) {
      return { status: "target_not_found" };
    }
  }

  // 2. Match same domain + same username (prefer exact web_domain score >= 3, fallback Android-bridged score >= 2)
  if (existingIdx < 0 && cleanUser) {
    existingIdx = items.findIndex(
      (it) =>
        OmniVaultCore.itemMatchesDomain(it, cleanHost) >= 3 &&
        usernamesMatchForAccount(it.username, cleanUser, cleanHost)
    );
    if (existingIdx < 0) {
      existingIdx = items.findIndex(
        (it) =>
          OmniVaultCore.itemMatchesDomain(it, cleanHost) >= 2 &&
          usernamesMatchForAccount(it.username, cleanUser, cleanHost)
      );
    }
  }

  // 3. Backfill username onto an empty-username entry on the same host with identical password
  if (existingIdx < 0 && cleanUser) {
    existingIdx = items.findIndex(
      (it) =>
        OmniVaultCore.itemMatchesDomain(it, cleanHost) >= 2 &&
        !String(it.username || "").trim() &&
        it.password === cleanPass
    );
  }

  // 4. Password-change / Reset-password forms with NO username field on page
  if (existingIdx < 0 && !cleanUser) {
    // 4a. Match exact account whose saved password equals the current/old password entered on the change-password form!
    if (cleanCurrentPass && cleanCurrentPass !== cleanPass) {
      existingIdx = items.findIndex(
        (it) => OmniVaultCore.itemMatchesDomain(it, cleanHost) >= 3 && it.password === cleanCurrentPass
      );
      if (existingIdx < 0) {
        existingIdx = items.findIndex(
          (it) => OmniVaultCore.itemMatchesDomain(it, cleanHost) >= 2 && it.password === cleanCurrentPass
        );
      }
    }
    // 4b. Check if this password is already saved on this host (avoid duplicate noise)
    if (existingIdx < 0) {
      const matchingPassOnHost = items.some(
        (it) => OmniVaultCore.itemMatchesDomain(it, cleanHost) >= 2 && it.password === cleanPass
      );
      if (matchingPassOnHost) {
        return { status: "already_saved" };
      }
    }
    // 4c. Match existing empty-username item on this host
    if (existingIdx < 0) {
      existingIdx = items.findIndex(
        (it) => OmniVaultCore.itemMatchesDomain(it, cleanHost) >= 2 && !String(it.username || "").trim()
      );
    }
    // 4d. Single-account host fallback (e.g. Reset Password page without username or old password field)
    if (existingIdx < 0) {
      const hostIndices = [];
      for (let i = 0; i < items.length; i++) {
        if (OmniVaultCore.itemMatchesDomain(items[i], cleanHost) >= 2) {
          hostIndices.push(i);
        }
      }
      if (hostIndices.length === 1) {
        existingIdx = hostIndices[0];
      }
    }
  }

  if (existingIdx >= 0) {
    const prev = items[existingIdx];
    if (
      prev.password === cleanPass &&
      (!cleanUser || usernamesMatchForAccount(prev.username, cleanUser, cleanHost))
    ) {
      return { status: "already_saved" };
    }
    // Never silently overwrite an existing different password without explicit user confirmation
    if (prev.password && prev.password !== cleanPass && !allowOverwriteExistingPassword) {
      return { status: "needs_confirm_update", existingItem: prev };
    }
    const prevUsername = prev.username || "";
    const prevWasEmpty = !prev.password;
    const prevPasswordChanged = Boolean(prev.password && prev.password !== cleanPass);
    const updated = { ...prev };
    if (cleanUser) {
      const preserveFullEmail =
        Boolean(prev.username) &&
        prev.username.includes("@") &&
        !cleanUser.includes("@") &&
        usernamesMatchForAccount(prev.username, cleanUser, cleanHost);
      if (!preserveFullEmail) {
        updated.username = cleanUser;
      }
    }
    if (prevPasswordChanged) {
      updated.password_history = [
        { password: prev.password, changed_at_ms: now },
        ...(Array.isArray(prev.password_history) ? prev.password_history : [])
      ].slice(0, 10);
    }
    updated.password = cleanPass;
    const prevDomains = Array.isArray(updated.web_domains) ? updated.web_domains : [];
    if (cleanHost && !prevDomains.includes(cleanHost)) {
      updated.web_domains = [...prevDomains, cleanHost];
    }
    updated.updated_at_ms = now;
    delete st.deletedIds[prev.id];
    const saved = OmniVaultCore.normalizeVaultItem(updated);
    items[existingIdx] = saved;
    return {
      status: "auto_saved",
      mode: "updated",
      item: saved,
      prevUsername,
      prevWasEmpty,
      prevPasswordHistoryChangedAt: prevPasswordChanged ? now : 0
    };
  }

  const title = String(
    serviceName || OmniVaultCore.prettifyDomainTitle(cleanHost) || cleanHost || "Tài khoản Web"
  ).trim();
  const saved = OmniVaultCore.normalizeVaultItem({
    id: crypto.randomUUID(),
    service_name: title,
    username: cleanUser,
    password: cleanPass,
    web_domains: cleanHost ? [cleanHost] : [],
    created_at_ms: now,
    updated_at_ms: now
  });
  items.push(saved);
  return {
    status: "auto_saved",
    mode: "created",
    item: saved,
    prevUsername: "",
    prevWasEmpty: true,
    prevPasswordHistoryChangedAt: 0
  };
}

async function reinjectContentScriptsOnOpenTabs() {
  try {
    if (!chrome?.tabs?.query || !chrome?.scripting?.executeScript) return;
    const tabs = await chrome.tabs.query({ url: ["https://*/*", "http://*/*"] });
    for (const tab of Array.isArray(tabs) ? tabs : []) {
      if (tab && tab.id != null && OmniVaultCore.isSafeAutofillUrl(tab.url || "")) {
        chrome.scripting
          .executeScript({ target: { tabId: tab.id, allFrames: false }, files: ["content.js"] })
          .catch(() => {});
      }
    }
  } catch (_) {}
}

function compareVersions(a, b) {
  const pa = String(a || "0").replace(/^v/i, "").split(".").map((x) => parseInt(x, 10) || 0);
  const pb = String(b || "0").replace(/^v/i, "").split(".").map((x) => parseInt(x, 10) || 0);
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const va = pa[i] || 0;
    const vb = pb[i] || 0;
    if (va !== vb) return va - vb;
  }
  return 0;
}

async function setUpdateActionBadge(hasUpdate) {
  try {
    if (!chrome?.action?.setBadgeText) return;
    await chrome.action.setBadgeText({ text: hasUpdate ? "NEW" : "" });
    if (hasUpdate && chrome.action.setBadgeBackgroundColor) {
      await chrome.action.setBadgeBackgroundColor({ color: "#dc2626" });
    }
  } catch (_) {}
}

async function readStoredUpdateMeta() {
  try {
    const data = await chrome.storage.local.get(LATEST_RELEASE_STORAGE_KEY);
    return (data && data[LATEST_RELEASE_STORAGE_KEY]) || {};
  } catch (_) {
    return {};
  }
}

async function writeStoredUpdateMeta(meta) {
  try {
    await chrome.storage.local.set({ [LATEST_RELEASE_STORAGE_KEY]: meta });
  } catch (_) {}
}

let nativeSelfUpdateInFlight = false;
let silentAutoUpdateInFlight = false;
let pendingSilentAutoUpdate = false;
let openUiPortCount = 0;

async function hasOpenExtensionUi() {
  if (openUiPortCount > 0) return true;
  try {
    if (typeof chrome?.runtime?.getContexts === "function") {
      const openUi = await chrome.runtime.getContexts({ contextTypes: ["POPUP", "TAB"] });
      if (Array.isArray(openUi) && openUi.length > 0) {
        return true;
      }
    }
  } catch (_) {}
  return false;
}

async function readAutoUpdateBgEnabled() {
  try {
    const data = await chrome.storage.local.get(AUTO_UPDATE_BG_STORAGE_KEY);
    if (data && typeof data[AUTO_UPDATE_BG_STORAGE_KEY] === "boolean") {
      return data[AUTO_UPDATE_BG_STORAGE_KEY];
    }
  } catch (_) {}
  return true;
}

async function writeAutoUpdateBgEnabled(enabled) {
  const val = Boolean(enabled);
  try {
    await chrome.storage.local.set({ [AUTO_UPDATE_BG_STORAGE_KEY]: val });
  } catch (_) {}
  return val;
}

function sendNativeUpdaterMessage(payload, timeoutMs = 45000) {
  return new Promise((resolve) => {
    if (typeof chrome?.runtime?.sendNativeMessage !== "function") {
      resolve({ ok: false, available: false, error: "Trình duyệt chưa hỗ trợ nativeMessaging." });
      return;
    }
    let settled = false;
    const timer = setTimeout(() => {
      if (!settled) {
        settled = true;
        resolve({ ok: false, error: "Quá thời gian chờ Native Updater Host." });
      }
    }, timeoutMs);

    try {
      chrome.runtime.sendNativeMessage(NATIVE_UPDATER_HOST_NAME, payload, (resp) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        const lastErr = chrome.runtime.lastError;
        if (lastErr) {
          resolve({
            ok: false,
            available: false,
            error: String(lastErr.message || "Chưa kích hoạt Native Updater Host.")
          });
          return;
        }
        resolve(resp && typeof resp === "object" ? resp : { ok: false, error: "Phản hồi Native Host không hợp lệ." });
      });
    } catch (e) {
      if (!settled) {
        settled = true;
        clearTimeout(timer);
        resolve({ ok: false, available: false, error: String(e?.message || e) });
      }
    }
  });
}

async function readLatestPasswordExportViaNative(maxAgeMinutes = 1440) {
  const MAX_TOTAL_BYTES = 16 * 1024 * 1024;
  const MAX_CHUNKS = 36;
  const clampedAge = Math.max(1, Math.min(10080, Math.floor(Number(maxAgeMinutes) || 1440)));

  const first = await sendNativeUpdaterMessage(
    { action: "read_latest_export", maxAgeMinutes: clampedAge, offsetBytes: 0 },
    15000
  );
  if (!first || first.available === false) {
    return { ok: false, nativeAvailable: false, found: false, error: String(first?.error || "") };
  }
  if (!first.ok) {
    return { ok: false, nativeAvailable: true, found: false, error: String(first.error || "Không đọc được file xuất.") };
  }
  if (!first.found) {
    return { ok: true, nativeAvailable: true, found: false };
  }

  const fileName = String(first.fileName || "");
  const sha256 = String(first.sha256 || "");
  const sizeBytes = Number(first.sizeBytes || 0);
  const lastWriteMs = Number(first.lastWriteMs || 0);
  if (sizeBytes <= 0 || sizeBytes > MAX_TOTAL_BYTES) {
    return { ok: false, nativeAvailable: true, found: false, error: "Kích thước file vượt quá giới hạn an toàn 16 MB." };
  }

  const chunks = [OmniVaultCore.base64ToBytes(String(first.chunkB64 || ""))];
  let totalRead = chunks[0].byteLength;
  let hasMore = Boolean(first.hasMore);
  let nextOffset = Number(first.nextOffsetBytes || totalRead);
  let iter = 1;

  while (hasMore && iter < MAX_CHUNKS) {
    const part = await sendNativeUpdaterMessage(
      {
        action: "read_latest_export",
        maxAgeMinutes: clampedAge,
        expectedFileName: fileName,
        offsetBytes: nextOffset
      },
      15000
    );
    if (!part || !part.ok || !part.found) {
      return { ok: false, nativeAvailable: true, found: false, error: String(part?.error || "Đọc nối tiếp file xuất thất bại.") };
    }
    if (String(part.sha256 || "") !== sha256) {
      return { ok: false, nativeAvailable: true, found: false, error: "File đang bị thay đổi trong lúc đọc — hãy thử lại." };
    }
    const bytes = OmniVaultCore.base64ToBytes(String(part.chunkB64 || ""));
    totalRead += bytes.byteLength;
    if (totalRead > MAX_TOTAL_BYTES) {
      return { ok: false, nativeAvailable: true, found: false, error: "Kích thước file vượt quá giới hạn an toàn 16 MB." };
    }
    chunks.push(bytes);
    hasMore = Boolean(part.hasMore);
    nextOffset = Number(part.nextOffsetBytes || totalRead);
    iter++;
  }

  const merged = new Uint8Array(totalRead);
  let pos = 0;
  for (const c of chunks) {
    merged.set(c, pos);
    pos += c.byteLength;
  }
  const text = new TextDecoder("utf-8").decode(merged);
  return {
    ok: true,
    nativeAvailable: true,
    found: true,
    fileName,
    sha256,
    sizeBytes,
    lastWriteMs,
    text
  };
}

async function deleteVerifiedPasswordExportViaNative({ fileName, sha256, sizeBytes }) {
  const res = await sendNativeUpdaterMessage(
    {
      action: "delete_verified_export",
      fileName: String(fileName || ""),
      expectedSha256: String(sha256 || ""),
      expectedSizeBytes: Number(sizeBytes || 0)
    },
    10000
  );
  if (!res || res.available === false) {
    return { ok: false, nativeAvailable: false, deleted: false, error: String(res?.error || "") };
  }
  return {
    ok: Boolean(res.ok),
    nativeAvailable: true,
    deleted: Boolean(res.deleted),
    alreadyMissing: Boolean(res.alreadyMissing),
    fileName: String(res.fileName || fileName || ""),
    error: String(res.error || "")
  };
}

async function probeNativeUpdaterHost() {
  const autoUpdateBgEnabled = await readAutoUpdateBgEnabled();
  const resp = await sendNativeUpdaterMessage({ action: "ping" }, 8000);
  if (resp && resp.ok && resp.ready) {
    return {
      ok: true,
      available: true,
      hostVersion: String(resp.hostVersion || "1.0.0"),
      dirName: String(resp.dirName || "OmniVault"),
      dirPath: String(resp.dirPath || ""),
      currentVersion: String(resp.currentVersion || ""),
      autoUpdateBgEnabled
    };
  }
  return {
    ok: true,
    available: false,
    autoUpdateBgEnabled,
    error: String(resp?.error || "")
  };
}

async function runNativeSelfUpdate({ allowSilentReload = true, force = false, deferReloadIfUiOpen = false } = {}) {
  if (nativeSelfUpdateInFlight) {
    return { ok: false, busy: true, error: "Đang chạy cập nhật tự động..." };
  }
  nativeSelfUpdateInFlight = true;
  try {
    const res = await sendNativeUpdaterMessage({ action: "update", force: Boolean(force) }, 60000);
    if (!res || !res.ok) {
      return {
        ok: false,
        reloading: false,
        error: String(res?.error || "Cập nhật tự động qua Native Host thất bại.")
      };
    }
    const loadedVer = chrome?.runtime?.getManifest ? String(chrome.runtime.getManifest().version || "0.0.0") : "0.0.0";
    const diskVer = String(res.version || "").replace(/^v/i, "").trim();
    const diskAheadOfRam = Boolean(diskVer && compareVersions(diskVer, loadedVer) > 0);
    const trulyUpToDate = Boolean(res.alreadyUpToDate) && !diskAheadOfRam;

    if (trulyUpToDate) {
      pendingSilentAutoUpdate = false;
      try {
        chrome?.alarms?.clear?.(DEFERRED_AUTO_UPDATE_ALARM_NAME);
      } catch (_) {}
      await setUpdateActionBadge(false);
      return {
        ok: true,
        alreadyUpToDate: true,
        reloading: false,
        version: diskVer,
        writtenCount: 0,
        dirName: String(res.dirName || ""),
        dirPath: String(res.dirPath || "")
      };
    }

    // Re-check immediately before reload in silent mode so we NEVER interrupt an opened Popup/Unlock/Import/Updater UI
    if (allowSilentReload && deferReloadIfUiOpen && (await hasOpenExtensionUi())) {
      pendingSilentAutoUpdate = true;
      try {
        chrome?.alarms?.create?.(DEFERRED_AUTO_UPDATE_ALARM_NAME, { delayInMinutes: 1 });
      } catch (_) {}
      return {
        ok: true,
        alreadyUpToDate: false,
        reloading: false,
        deferredReload: true,
        version: diskVer,
        writtenCount: Number(res.writtenCount || 0),
        sha256: String(res.sha256 || ""),
        dirName: String(res.dirName || ""),
        dirPath: String(res.dirPath || "")
      };
    }

    pendingSilentAutoUpdate = false;
    try {
      chrome?.alarms?.clear?.(DEFERRED_AUTO_UPDATE_ALARM_NAME);
    } catch (_) {}
    await setUpdateActionBadge(false);

    if (allowSilentReload && typeof chrome?.runtime?.reload === "function") {
      setTimeout(async () => {
        try {
          if (deferReloadIfUiOpen && (await hasOpenExtensionUi())) {
            pendingSilentAutoUpdate = true;
            try {
              chrome?.alarms?.create?.(DEFERRED_AUTO_UPDATE_ALARM_NAME, { delayInMinutes: 1 });
            } catch (_) {}
            return;
          }
          chrome.runtime.reload();
        } catch (_) {}
      }, 220);
    }
    return {
      ok: true,
      alreadyUpToDate: false,
      reloading: Boolean(allowSilentReload),
      version: diskVer,
      writtenCount: Number(res.writtenCount || 0),
      sha256: String(res.sha256 || ""),
      dirName: String(res.dirName || ""),
      dirPath: String(res.dirPath || "")
    };
  } finally {
    nativeSelfUpdateInFlight = false;
  }
}

async function maybeRunSilentBackgroundAutoUpdate(updateResp) {
  if (
    !updateResp ||
    !updateResp.hasUpdate ||
    updateResp.isCrxManaged ||
    nativeSelfUpdateInFlight ||
    silentAutoUpdateInFlight
  ) {
    return false;
  }
  silentAutoUpdateInFlight = true;
  try {
    const bgEnabled = await readAutoUpdateBgEnabled();
    if (!bgEnabled) return false;

    // Never reload mid-interaction if Popup / Unlock / Updater / Import UI is currently open;
    // instead defer so closing the UI triggers silent update immediately!
    if (await hasOpenExtensionUi()) {
      pendingSilentAutoUpdate = true;
      try {
        chrome?.alarms?.create?.(DEFERRED_AUTO_UPDATE_ALARM_NAME, { delayInMinutes: 1 });
      } catch (_) {}
      return false;
    }

    const probe = await probeNativeUpdaterHost();
    if (!probe.available) {
      pendingSilentAutoUpdate = false;
      return false;
    }

    if (await hasOpenExtensionUi()) {
      pendingSilentAutoUpdate = true;
      try {
        chrome?.alarms?.create?.(DEFERRED_AUTO_UPDATE_ALARM_NAME, { delayInMinutes: 1 });
      } catch (_) {}
      return false;
    }

    pendingSilentAutoUpdate = false;
    const res = await runNativeSelfUpdate({
      allowSilentReload: true,
      force: false,
      deferReloadIfUiOpen: true
    });
    return Boolean(res && res.ok);
  } finally {
    silentAutoUpdateInFlight = false;
  }
}

function isTrustedExtensionPageSender(sender) {
  if (!sender) return false;
  if (chrome?.runtime?.id && sender.id !== chrome.runtime.id) {
    return false;
  }
  if (!sender.tab) return true;
  const extOrigin = typeof chrome?.runtime?.getURL === "function" ? chrome.runtime.getURL("") : "";
  const senderUrl = String(sender.url || sender.tab.url || "");
  return Boolean(extOrigin && senderUrl.startsWith(extOrigin));
}

async function openExtensionUpdaterWindow(autoStart = false) {
  const baseUrl = chrome?.runtime?.getURL ? chrome.runtime.getURL("updater.html") : "updater.html";
  const targetUrl = autoStart ? `${baseUrl}?auto=1` : baseUrl;

  try {
    if (chrome?.tabs?.query) {
      const existingTabs = await chrome.tabs.query({ url: `${baseUrl}*` });
      if (Array.isArray(existingTabs) && existingTabs.length > 0) {
        const existing = existingTabs[0];
        if (existing.windowId != null && chrome?.windows?.update) {
          await chrome.windows.update(existing.windowId, { focused: true }).catch(() => {});
        }
        if (existing.id != null && chrome?.tabs?.update) {
          await chrome.tabs
            .update(existing.id, { active: true, url: autoStart ? targetUrl : undefined })
            .catch(() => {});
        }
        return { ok: true, reused: true };
      }
    }
  } catch (_) {}

  if (chrome?.windows?.create) {
    try {
      await chrome.windows.create({
        url: targetUrl,
        type: "popup",
        width: 416,
        height: 540,
        focused: true
      });
      return { ok: true, reused: false };
    } catch (_) {}
  }

  if (chrome?.tabs?.create) {
    await chrome.tabs.create({ url: targetUrl, active: true });
    return { ok: true, reused: false };
  }
  return { ok: false, error: "Không mở được cửa sổ cập nhật tiện ích." };
}

async function openInlineUnlockWindow({ tabId, origWindowId, host, deviceNameHint, anchorRect }) {
  const baseUrl = chrome?.runtime?.getURL ? chrome.runtime.getURL("unlock.html") : "unlock.html";
  const qs = new URLSearchParams();
  if (host) qs.set("host", String(host));
  if (deviceNameHint) qs.set("device", String(deviceNameHint));
  const targetUrl = qs.toString() ? `${baseUrl}?${qs.toString()}` : baseUrl;

  await setSessionJson(PENDING_INLINE_UNLOCK_KEY, {
    tabId: tabId ?? null,
    origWindowId: origWindowId ?? null,
    host: String(host || ""),
    createdAt: Date.now()
  });

  try {
    if (chrome?.tabs?.query) {
      const existingTabs = await chrome.tabs.query({ url: `${baseUrl}*` });
      if (Array.isArray(existingTabs) && existingTabs.length > 0) {
        const existing = existingTabs[0];
        if (existing.id != null && chrome?.tabs?.update) {
          await chrome.tabs.update(existing.id, { active: true, url: targetUrl }).catch(() => {});
        }
        if (existing.windowId != null && chrome?.windows?.update) {
          await chrome.windows.update(existing.windowId, { focused: true }).catch(() => {});
        }
        return { ok: true, reused: true };
      }
    }
  } catch (_) {}

  const winWidth = 316;
  const winHeight = 224;
  const createOpts = {
    url: targetUrl,
    type: "popup",
    width: winWidth,
    height: winHeight,
    focused: true
  };

  if (anchorRect && typeof anchorRect === "object") {
    const rawLeft = Number(anchorRect.screenLeft);
    const rawTop = Number(anchorRect.screenTop);
    const availLeft = Number.isFinite(Number(anchorRect.availLeft)) ? Number(anchorRect.availLeft) : 0;
    const availTop = Number.isFinite(Number(anchorRect.availTop)) ? Number(anchorRect.availTop) : 0;
    const maxW = Number(anchorRect.screenWidth) || 0;
    const maxH = Number(anchorRect.screenHeight) || 0;
    if (Number.isFinite(rawLeft) && Number.isFinite(rawTop)) {
      const minLeft = Math.round(availLeft + 12);
      const minTop = Math.round(availTop + 12);
      const clampedLeft =
        maxW > winWidth
          ? Math.max(minLeft, Math.min(Math.round(rawLeft), Math.round(availLeft + maxW - winWidth - 12)))
          : Math.max(minLeft, Math.round(rawLeft));
      const clampedTop =
        maxH > winHeight
          ? Math.max(minTop, Math.min(Math.round(rawTop), Math.round(availTop + maxH - winHeight - 12)))
          : Math.max(minTop, Math.round(rawTop));
      createOpts.left = clampedLeft;
      createOpts.top = clampedTop;
    }
  }

  if (chrome?.windows?.create) {
    try {
      await chrome.windows.create(createOpts);
      return { ok: true, reused: false };
    } catch (_) {
      // Retry without left/top if OS multi-monitor bounds reject coordinates
      try {
        delete createOpts.left;
        delete createOpts.top;
        await chrome.windows.create(createOpts);
        return { ok: true, reused: false };
      } catch (_) {}
    }
  }

  if (chrome?.tabs?.create) {
    await chrome.tabs.create({ url: targetUrl, active: true });
    return { ok: true, reused: false };
  }
  return { ok: false, error: "Không mở được khung nhập PIN mở khóa." };
}

async function notifyPendingUnlockTabIfAny() {
  const pending = await getSessionJson(PENDING_INLINE_UNLOCK_KEY, null);
  await setSessionJson(PENDING_INLINE_UNLOCK_KEY, null);
  try {
    if (chrome?.storage?.session?.remove) {
      await chrome.storage.session.remove(PENDING_INLINE_UNLOCK_KEY);
    }
  } catch (_) {}

  if (!pending || pending.tabId == null) return false;
  if (Date.now() - Number(pending.createdAt || 0) > PENDING_INLINE_UNLOCK_TTL_MS) {
    return false;
  }

  try {
    if (pending.origWindowId != null && chrome?.windows?.update) {
      await chrome.windows.update(pending.origWindowId, { focused: true }).catch(() => {});
    }
  } catch (_) {}

  try {
    if (chrome?.tabs?.sendMessage) {
      chrome.tabs.sendMessage(
        pending.tabId,
        { type: "VAULT_UNLOCKED_REFRESH_AUTOFILL", host: pending.host || "" },
        () => {
          void chrome.runtime.lastError;
        }
      );
      return true;
    }
  } catch (_) {}
  return false;
}

function buildUpdateResponse(meta, extra = {}) {
  const manifest = chrome?.runtime?.getManifest ? chrome.runtime.getManifest() : {};
  const currentVersion = String(manifest.version || "0.0.0");
  const isCrxManaged = Boolean(manifest.update_url);
  const latestVersion = String(meta?.latestVersion || currentVersion).replace(/^v/i, "");
  let pendingCrx = String(meta?.pendingCrxReloadVersion || "").replace(/^v/i, "");
  if (pendingCrx && compareVersions(pendingCrx, currentVersion) <= 0) {
    pendingCrx = "";
  }
  const hasUpdate = compareVersions(latestVersion, currentVersion) > 0 || Boolean(pendingCrx);
  return {
    ok: true,
    currentVersion,
    latestVersion,
    hasUpdate,
    isCrxManaged,
    changelog: String(meta?.changelog || ""),
    unpackedZipUrl: sanitizeGitHubUpdateUrl(meta?.unpackedZipUrl, DEFAULT_UNPACKED_ZIP_URL),
    unpackedLatestUrl: sanitizeGitHubUpdateUrl(meta?.unpackedLatestUrl, DEFAULT_UNPACKED_ZIP_URL),
    versionJsonUrl: sanitizeGitHubUpdateUrl(meta?.versionJsonUrl, GITHUB_VERSION_JSON_URL),
    zipSha256: String(meta?.zipSha256 || "").trim().toLowerCase(),
    signatureRsaB64: String(meta?.signatureRsaB64 || "").trim(),
    autoUpdateKitUrl: sanitizeGitHubUpdateUrl(meta?.autoUpdateKitUrl, DEFAULT_AUTOUPDATE_KIT_URL),
    releaseHtmlUrl: sanitizeGitHubUpdateUrl(meta?.releaseHtmlUrl, DEFAULT_RELEASE_HTML_URL),
    pendingCrxReloadVersion: pendingCrx,
    checkedAtMs: Number(meta?.checkedAtMs || 0),
    ...extra
  };
}

async function fetchSignedVersionJson(preferredAssetUrl, now) {
  const candidates = [];
  if (preferredAssetUrl && OmniVaultCore.isAllowedGitHubUpdateUrl(preferredAssetUrl)) {
    candidates.push(String(preferredAssetUrl).trim());
  }
  candidates.push(`${GITHUB_VERSION_JSON_URL}?t=${now}`);

  for (let i = 0; i < candidates.length; i++) {
    const url = candidates[i];
    try {
      const verRes = await bgFetchWithTimeout(url, { cache: "no-store" }, GITHUB_FETCH_TIMEOUT_MS);
      if (!verRes.ok) continue;
      const vj = await verRes.json();
      const ver = String(vj?.version || "").replace(/^v/i, "").trim();
      if (!ver) continue;
      return {
        latestVersion: ver,
        changelog: String(vj?.changelog || "").trim(),
        unpackedZipUrl: sanitizeGitHubUpdateUrl(vj?.unpacked_zip_url, DEFAULT_UNPACKED_ZIP_URL),
        unpackedLatestUrl: sanitizeGitHubUpdateUrl(vj?.unpacked_latest, DEFAULT_UNPACKED_ZIP_URL),
        versionJsonUrl: sanitizeGitHubUpdateUrl(
          preferredAssetUrl || GITHUB_VERSION_JSON_URL,
          GITHUB_VERSION_JSON_URL
        ),
        zipSha256: String(vj?.zip_sha256 || "").trim().toLowerCase(),
        signatureRsaB64: String(vj?.signature_rsa_b64 || "").trim(),
        autoUpdateKitUrl: sanitizeGitHubUpdateUrl(
          vj?.autoupdate_kit_url,
          DEFAULT_AUTOUPDATE_KIT_URL
        ),
        releaseHtmlUrl: sanitizeGitHubUpdateUrl(vj?.release_url, DEFAULT_RELEASE_HTML_URL)
      };
    } catch (_) {}
  }
  return null;
}

async function checkGitHubExtensionUpdate(force = false, opts = {}) {
  const allowSilentBgUpdate = opts?.allowSilentBgUpdate !== false;
  const manifest = chrome?.runtime?.getManifest ? chrome.runtime.getManifest() : {};
  const currentVersion = String(manifest.version || "0.0.0");
  const cached = await readStoredUpdateMeta();
  const now = Date.now();

  // Store builds (Chrome Web Store / Edge Add-ons) update exclusively via official store channels —
  // never poll GitHub release metadata or trigger off-store self-updates.
  if (isStoreDistributionBuild()) {
    let pendingCrx = String(cached?.pendingCrxReloadVersion || "").replace(/^v/i, "");
    if (pendingCrx && compareVersions(pendingCrx, currentVersion) <= 0) {
      pendingCrx = "";
    }
    const hasUpdate = Boolean(pendingCrx);
    await setUpdateActionBadge(hasUpdate);
    return {
      ok: true,
      currentVersion,
      latestVersion: pendingCrx || currentVersion,
      hasUpdate,
      isCrxManaged: true,
      isStoreManaged: true,
      changelog: "",
      pendingCrxReloadVersion: pendingCrx,
      checkedAtMs: now
    };
  }

  const cacheHasUpdate = Boolean(
    cached?.latestVersion && compareVersions(cached.latestVersion, currentVersion) > 0
  );
  const cacheHasSignedMeta = Boolean(cached?.zipSha256 && cached?.signatureRsaB64);

  if (
    !force &&
    cached?.latestVersion &&
    now - Number(cached.checkedAtMs || 0) < UPDATE_CACHE_TTL_MS &&
    (!cacheHasUpdate || cacheHasSignedMeta)
  ) {
    const resp = buildUpdateResponse(cached);
    await setUpdateActionBadge(resp.hasUpdate);
    if (allowSilentBgUpdate && resp.hasUpdate && !resp.isCrxManaged) {
      maybeRunSilentBackgroundAutoUpdate(resp).catch(() => {});
    }
    return resp;
  }

  let parsed = null;
  let versionAssetUrl = "";
  let lastErr = "";

  // 1. Prefer GitHub Pages CDN version.json first (zero GitHub API 60 req/hr rate-limit risk!)
  const cdnSigned = await fetchSignedVersionJson("", now);
  if (cdnSigned && cdnSigned.latestVersion && cdnSigned.zipSha256 && cdnSigned.signatureRsaB64) {
    parsed = cdnSigned;
  } else {
    // 2. Fallback to GitHub Releases API + hydrate signed version.json asset
    try {
      const res = await bgFetchWithTimeout(
        GITHUB_RELEASE_API_URL,
        {
          headers: { Accept: "application/vnd.github+json" },
          cache: "no-store"
        },
        GITHUB_FETCH_TIMEOUT_MS
      );
      if (res.ok) {
        const rel = await res.json();
        const assets = Array.isArray(rel?.assets) ? rel.assets : [];
        const unpackedAsset = assets.find((a) => /OmniVault-GiaiNen-.*\.zip$/i.test(String(a?.name || "")));
        const kitAsset = assets.find((a) => /OmniVault-TuDongCapNhat-Windows\.zip$/i.test(String(a?.name || "")));
        const verAsset = assets.find((a) => /^version\.json$/i.test(String(a?.name || "")));
        if (verAsset?.browser_download_url && OmniVaultCore.isAllowedGitHubUpdateUrl(verAsset.browser_download_url)) {
          versionAssetUrl = String(verAsset.browser_download_url).trim();
        }
        parsed = {
          latestVersion: String(rel?.tag_name || rel?.name || "").replace(/^v/i, "").trim(),
          changelog: String(rel?.body || "").trim(),
          unpackedZipUrl: sanitizeGitHubUpdateUrl(
            unpackedAsset?.browser_download_url,
            DEFAULT_UNPACKED_ZIP_URL
          ),
          unpackedLatestUrl: DEFAULT_UNPACKED_ZIP_URL,
          versionJsonUrl: versionAssetUrl || GITHUB_VERSION_JSON_URL,
          zipSha256: "",
          signatureRsaB64: "",
          autoUpdateKitUrl: sanitizeGitHubUpdateUrl(
            kitAsset?.browser_download_url,
            DEFAULT_AUTOUPDATE_KIT_URL
          ),
          releaseHtmlUrl: sanitizeGitHubUpdateUrl(rel?.html_url, DEFAULT_RELEASE_HTML_URL)
        };
      } else {
        lastErr = `GitHub API HTTP ${res.status}`;
      }
    } catch (e) {
      lastErr = String(e?.message || e || "Network error");
    }

    const signedMeta = versionAssetUrl
      ? await fetchSignedVersionJson(versionAssetUrl, now)
      : cdnSigned;
    if (signedMeta) {
      if (!parsed || !parsed.latestVersion) {
        parsed = signedMeta;
      } else if (compareVersions(signedMeta.latestVersion, parsed.latestVersion) >= 0) {
        parsed = {
          ...parsed,
          latestVersion: signedMeta.latestVersion,
          changelog: parsed.changelog || signedMeta.changelog,
          unpackedZipUrl:
            compareVersions(signedMeta.latestVersion, parsed.latestVersion) > 0
              ? signedMeta.unpackedZipUrl
              : parsed.unpackedZipUrl || signedMeta.unpackedZipUrl,
          unpackedLatestUrl: signedMeta.unpackedLatestUrl || DEFAULT_UNPACKED_ZIP_URL,
          versionJsonUrl: versionAssetUrl || signedMeta.versionJsonUrl || GITHUB_VERSION_JSON_URL,
          zipSha256: signedMeta.zipSha256,
          signatureRsaB64: signedMeta.signatureRsaB64,
          autoUpdateKitUrl: parsed.autoUpdateKitUrl || signedMeta.autoUpdateKitUrl,
          releaseHtmlUrl: parsed.releaseHtmlUrl || signedMeta.releaseHtmlUrl
        };
      }
    }
  }

  if (parsed && parsed.latestVersion) {
    let pendingCrx = String(cached?.pendingCrxReloadVersion || "").replace(/^v/i, "");
    if (pendingCrx && compareVersions(pendingCrx, currentVersion) <= 0) {
      pendingCrx = "";
    }
    const nextMeta = {
      ...parsed,
      pendingCrxReloadVersion: pendingCrx,
      checkedAtMs: now
    };
    await writeStoredUpdateMeta(nextMeta);
    const resp = buildUpdateResponse(nextMeta);
    await setUpdateActionBadge(resp.hasUpdate);
    if (allowSilentBgUpdate && resp.hasUpdate && !resp.isCrxManaged) {
      maybeRunSilentBackgroundAutoUpdate(resp).catch(() => {});
    }
    return resp;
  }

  const fallbackResp = buildUpdateResponse(cached, { ok: false, error: lastErr || "Không kiểm tra được GitHub" });
  await setUpdateActionBadge(fallbackResp.hasUpdate);
  return fallbackResp;
}

async function lockVaultAndClearCaches() {
  await clearEphemeralCaptureCaches();
  await OmniVaultCore.lockExtensionSession();
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create(SYNC_ALARM_NAME, { periodInMinutes: 5 });
  const storeManaged = isStoreDistributionBuild();
  if (!storeManaged) {
    chrome.alarms.create(UPDATE_CHECK_ALARM_NAME, { periodInMinutes: UPDATE_CHECK_INTERVAL_MINUTES });
  } else {
    chrome.alarms.clear(UPDATE_CHECK_ALARM_NAME).catch?.(() => {});
    chrome.alarms.clear(DEFERRED_AUTO_UPDATE_ALARM_NAME).catch?.(() => {});
  }
  reinjectContentScriptsOnOpenTabs();
  readStoredUpdateMeta().then((meta) => {
    const manifestVer = chrome?.runtime?.getManifest ? chrome.runtime.getManifest().version : "0.0.0";
    if (meta?.pendingCrxReloadVersion && compareVersions(meta.pendingCrxReloadVersion, manifestVer) <= 0) {
      meta.pendingCrxReloadVersion = "";
      writeStoredUpdateMeta(meta);
    }
  });
  if (!storeManaged) {
    checkGitHubExtensionUpdate(true, { allowSilentBgUpdate: true }).catch(() => {});
  }
});

chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create(SYNC_ALARM_NAME, { periodInMinutes: 5 });
  const storeManaged = isStoreDistributionBuild();
  if (!storeManaged) {
    chrome.alarms.create(UPDATE_CHECK_ALARM_NAME, { periodInMinutes: UPDATE_CHECK_INTERVAL_MINUTES });
  } else {
    chrome.alarms.clear(UPDATE_CHECK_ALARM_NAME).catch?.(() => {});
    chrome.alarms.clear(DEFERRED_AUTO_UPDATE_ALARM_NAME).catch?.(() => {});
  }
  // Always lock immediately on browser restart (even if OS/profile fast-restores session state)
  lockVaultAndClearCaches().catch(() => {});
  if (!storeManaged) {
    checkGitHubExtensionUpdate(true, { allowSilentBgUpdate: true }).catch(() => {});
  }
});

if (chrome?.runtime?.onConnect?.addListener) {
  chrome.runtime.onConnect.addListener((port) => {
    if (!port || port.name !== "omnivault_ui_open") return;
    if (port.sender && !isTrustedExtensionPageSender(port.sender)) return;
    openUiPortCount += 1;
    port.onDisconnect.addListener(() => {
      openUiPortCount = Math.max(0, openUiPortCount - 1);
      if (openUiPortCount === 0 && pendingSilentAutoUpdate) {
        setTimeout(() => {
          if (openUiPortCount === 0 && pendingSilentAutoUpdate) {
            checkGitHubExtensionUpdate(false, { allowSilentBgUpdate: true }).catch(() => {});
          }
        }, 800);
      }
    });
  });
}

if (chrome?.runtime?.onUpdateAvailable?.addListener) {
  chrome.runtime.onUpdateAvailable.addListener(async (details) => {
    const nextVer = String(details?.version || "").replace(/^v/i, "").trim();
    const meta = await readStoredUpdateMeta();
    meta.pendingCrxReloadVersion = nextVer || meta.latestVersion || "new";
    if (nextVer && (!meta.latestVersion || compareVersions(nextVer, meta.latestVersion) > 0)) {
      meta.latestVersion = nextVer;
    }
    await writeStoredUpdateMeta(meta);
    await setUpdateActionBadge(true);
    try {
      if (typeof chrome.runtime.getContexts === "function") {
        const openUi = await chrome.runtime.getContexts({ contextTypes: ["POPUP", "TAB"] });
        if (!Array.isArray(openUi) || openUi.length === 0) {
          chrome.runtime.reload();
        }
      }
    } catch (_) {}
  });
}

if (chrome?.idle?.setDetectionInterval && chrome?.idle?.onStateChanged?.addListener) {
  try {
    chrome.idle.setDetectionInterval(15 * 60);
    chrome.idle.onStateChanged.addListener(async (newState) => {
      if (newState === "idle" || newState === "locked") {
        await lockVaultAndClearCaches();
      } else if (newState === "active") {
        await OmniVaultCore.enforceSessionExpiryIfNeeded().catch(() => {});
      }
    });
  } catch (_) {}
}

if (chrome?.windows?.onFocusChanged?.addListener) {
  try {
    chrome.windows.onFocusChanged.addListener(async () => {
      const transitionedToLocked = await OmniVaultCore.enforceSessionExpiryIfNeeded().catch(() => false);
      if (transitionedToLocked) {
        await clearEphemeralCaptureCaches({ preserveLockedPrompts: true });
      }
    });
  } catch (_) {}
}

// Lock immediately whenever the last browser window is closed (covers Windows Chrome background mode & Edge Startup Boost!)
if (chrome?.windows?.onRemoved?.addListener) {
  try {
    chrome.windows.onRemoved.addListener(async () => {
      try {
        if (typeof chrome.windows.getAll !== "function") return;
        const remaining = await chrome.windows.getAll({ windowTypes: ["normal", "popup", "app"] });
        if (!Array.isArray(remaining) || remaining.length === 0) {
          await lockVaultAndClearCaches();
        }
      } catch (_) {}
    });
  } catch (_) {}
}

if (chrome?.storage?.onChanged?.addListener) {
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === "session" && changes && changes[OmniVaultCore.OMNIVAULT_SESSION_KEY]) {
      if (!changes[OmniVaultCore.OMNIVAULT_SESSION_KEY].newValue) {
        clearEphemeralCaptureCaches().catch(() => {});
      }
    }
  });
}

// Proactive push of pending tab capture notices ONLY for tabs that actually have a pending entry
if (chrome?.tabs?.onUpdated?.addListener) {
  chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (!changeInfo || changeInfo.status !== "complete") return;
    if (pendingTabNoticesHydrated && pendingTabNotices.size === 0) return;
    (async () => {
      try {
        await ensurePendingTabNoticesHydrated();
        const notice = pendingTabNotices.get(String(tabId));
        if (!notice) return;
        if (Date.now() - Number(notice.createdAt || 0) >= TAB_NOTICE_TTL_MS) {
          await removePendingTabNotice(tabId, notice.noticeId);
          return;
        }
        const tabUrl = tab?.url || "";
        if (!OmniVaultCore.isSafeAutofillUrl(tabUrl)) return;
        const tabHost = OmniVaultCore.extractCleanDomain(tabUrl);
        if (notice.host && tabHost && !isCompatibleRedirectHost(notice.host, tabHost)) {
          return;
        }
        pushTabNoticeToTab(tabId, notice, 0);
      } catch (_) {}
    })();
  });
}

if (chrome?.tabs?.onRemoved?.addListener) {
  chrome.tabs.onRemoved.addListener((tabId) => {
    removePendingTabNotice(tabId).catch(() => {});
    clearTabEphemeralMaps(tabId).catch(() => {});
  });
}

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === AUTOLOCK_ALARM_NAME) {
    await lockVaultAndClearCaches();
    return;
  }
  if (alarm.name === PENDING_UPDATES_CLEANUP_ALARM_NAME) {
    await OmniVaultCore.withVaultMutationLock(async () => {
      const raw = await getSessionJson(PENDING_UPDATES_KEY, {});
      const pruned = pruneMapByTtl(raw, PENDING_UPDATE_TTL_MS, PENDING_UPDATE_MAX);
      await setSessionJson(PENDING_UPDATES_KEY, pruned);
    }).catch(() => {});
    return;
  }
  if (alarm.name === UPDATE_CHECK_ALARM_NAME) {
    if (isStoreDistributionBuild()) return;
    await checkGitHubExtensionUpdate(true, { allowSilentBgUpdate: true }).catch(() => {});
    return;
  }
  if (alarm.name === DEFERRED_AUTO_UPDATE_ALARM_NAME) {
    if (isStoreDistributionBuild()) return;
    await checkGitHubExtensionUpdate(false, { allowSilentBgUpdate: true }).catch(() => {});
    return;
  }
  if (alarm.name === SYNC_ALARM_NAME) {
    try {
      const { state: st } = await OmniVaultCore.getCachedVaultStateAndIndex();
      if (!st.locked && st.pairing && !st.pairing.localOnly) {
        await OmniVaultCore.syncBrowserVaultBidirectional(false);
      }
    } catch (_) {
      // Silent retry on next cycle
    }
  }
});

function resolveVerifiedSenderHost(sender) {
  if (sender?.frameId && sender.frameId !== 0) {
    return "";
  }
  const tabUrl = sender?.tab?.url || "";
  const frameUrl = sender?.url || tabUrl;
  if (!OmniVaultCore.isSafeAutofillUrl(tabUrl) || !OmniVaultCore.isSafeAutofillUrl(frameUrl)) {
    return "";
  }
  const tabHost = OmniVaultCore.extractCleanDomain(tabUrl);
  const frameHost = OmniVaultCore.extractCleanDomain(frameUrl);
  if (!tabHost || !frameHost || tabHost !== frameHost) return "";
  return frameHost;
}

function resolveVerifiedWebAuthnSender(sender) {
  const cleanHost = resolveVerifiedSenderHost(sender);
  if (!cleanHost) return null;
  const tabUrl = sender?.tab?.url || "";
  const frameUrl = sender?.url || tabUrl;
  try {
    const tu = new URL(tabUrl);
    const fu = new URL(frameUrl);
    if (tu.origin !== fu.origin) return null;
    const rawHost = String(fu.hostname || "").toLowerCase().replace(/\.+$/, "");
    if (!rawHost) return null;
    return { origin: fu.origin, rawHost, cleanHost };
  } catch (_) {
    return null;
  }
}

function computeUsernameAffinity(itemUsername, preferredUserLc, host) {
  if (!preferredUserLc) return 0;
  const u = String(itemUsername || "").trim().toLowerCase();
  if (!u) return 0;
  if (u === preferredUserLc) return 4;
  if (host === "accounts.google.com" || host === "google.com" || host.endsWith(".google.com")) {
    const stripGmail = (s) => s.replace(/@(gmail|googlemail)\.com$/i, "");
    const uBase = stripGmail(u);
    const pBase = stripGmail(preferredUserLc);
    if (uBase && uBase === pBase) return 3;
  }
  if (OmniVaultCore.matchesUsernamePrefix(itemUsername, preferredUserLc)) {
    return 2;
  }
  return 0;
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || typeof msg !== "object") return false;

  if (msg.type === "PING_SW") {
    if (!isTrustedExtensionPageSender(sender)) {
      sendResponse({ ok: false });
      return false;
    }
    sendResponse({ ok: true });
    return false;
  }

  if (msg.type === "SET_STEP1_USERNAME") {
    (async () => {
      try {
        const host = resolveVerifiedSenderHost(sender);
        const tabId = sender?.tab?.id;
        if (!host || tabId == null) {
          sendResponse({ ok: false });
          return;
        }
        await setStep1UsernameForTabHost(tabId, host, msg.username || "");
        sendResponse({ ok: true });
      } catch (_) {
        sendResponse({ ok: false });
      }
    })();
    return true;
  }

  if (msg.type === "GET_STEP1_USERNAME") {
    (async () => {
      try {
        const host = resolveVerifiedSenderHost(sender);
        const tabId = sender?.tab?.id;
        if (!host || tabId == null) {
          sendResponse({ ok: false, username: "" });
          return;
        }
        const username = await getStep1UsernameForTabHost(tabId, host);
        sendResponse({ ok: true, username });
      } catch (_) {
        sendResponse({ ok: false, username: "" });
      }
    })();
    return true;
  }

  if (msg.type === "MARK_UNPAIRED_HINT_SHOWN") {
    (async () => {
      try {
        const host = resolveVerifiedSenderHost(sender);
        const tabId = sender?.tab?.id;
        if (!host || tabId == null) {
          sendResponse({ ok: false, alreadyShown: true });
          return;
        }
        const alreadyShown = await checkAndMarkUnpairedHint(tabId, host);
        sendResponse({ ok: true, alreadyShown });
      } catch (_) {
        sendResponse({ ok: false, alreadyShown: false });
      }
    })();
    return true;
  }

  if (msg.type === "GET_DOMAIN_MATCHES") {
    (async () => {
      try {
        const host = resolveVerifiedSenderHost(sender);
        if (!host) {
          sendResponse({ paired: false, matches: [] });
          return;
        }
        const tabId = sender?.tab?.id;
        const { state: st, byDomain } = await OmniVaultCore.getCachedVaultStateAndIndex();
        if (st.locked) {
          sendResponse({
            paired: true,
            locked: true,
            deviceNameHint: String(st.deviceNameHint || ""),
            matches: []
          });
          return;
        }
        if (!st.pairing) {
          sendResponse({ paired: false, matches: [] });
          return;
        }
        let step1Username = "";
        if (tabId != null) {
          step1Username = await getStep1UsernameForTabHost(tabId, host).catch(() => "");
        }
        const preferredUsername = (
          String(msg.preferredUsername || "").trim() || step1Username
        ).toLowerCase();
        // O(1) inverted domain index lookup (strict INV-07 subdomain isolation: only www. stripped)
        const domainHits = byDomain.get(host) || [];
        const ranked = new Array(domainHits.length);
        for (let i = 0; i < domainHits.length; i++) {
          const hit = domainHits[i];
          ranked[i] = {
            score: hit.score,
            userBoost: computeUsernameAffinity(hit.item.username, preferredUsername, host),
            item: hit.item
          };
        }
        ranked.sort((a, b) => {
          if (b.userBoost !== a.userBoost) return b.userBoost - a.userBoost;
          if (b.score !== a.score) return b.score - a.score;
          const favDiff = (b.item.is_favorite ? 1 : 0) - (a.item.is_favorite ? 1 : 0);
          if (favDiff !== 0) return favDiff;
          const timeDiff = (Number(b.item.last_autofilled_ms) || 0) - (Number(a.item.last_autofilled_ms) || 0);
          if (timeDiff !== 0) return timeDiff;
          return VI_COLLATOR.compare(
            String(a.item.username || a.item.service_name || ""),
            String(b.item.username || b.item.service_name || "")
          );
        });
        // EXT-02: Never send plaintext passwords on passive focus — return metadata only!
        sendResponse({
          paired: true,
          step1Username,
          matches: ranked.slice(0, 1000).map((r) => ({
            id: r.item.id,
            service_name: r.item.service_name,
            username: r.item.username,
            domain: (Array.isArray(r.item.web_domains) && r.item.web_domains[0]) || host,
            is_favorite: Boolean(r.item.is_favorite),
            step1_matched: r.userBoost >= 3
          }))
        });
      } catch (e) {
        sendResponse({ paired: false, matches: [], error: String(e.message || e) });
      }
    })();
    return true;
  }

  if (msg.type === "REQUEST_CREDENTIAL_FILL") {
    (async () => {
      try {
        const host = resolveVerifiedSenderHost(sender);
        if (!host) {
          sendResponse({ ok: false, error: "Trang không an toàn để tự động điền." });
          return;
        }
        const targetId = String(msg.itemId || "");
        const { state: st, byId } = await OmniVaultCore.getCachedVaultStateAndIndex();
        if (st.locked) {
          sendResponse({
            ok: false,
            error: "Kho OmniVault đang khóa. Hãy bấm biểu tượng tiện ích để nhập PIN."
          });
          return;
        }
        if (!st.pairing) {
          sendResponse({ ok: false, error: "Chưa kết nối OmniVault." });
          return;
        }
        const item = byId.get(targetId);
        if (!item || OmniVaultCore.itemMatchesDomain(item, host) < 2) {
          sendResponse({
            ok: false,
            error: "Tài khoản không khớp tên miền đã xác thực."
          });
          return;
        }
        // Update lightweight hot recency map + RAM cache WITHOUT re-encrypting the vault blob!
        await OmniVaultCore.recordItemAutofilled(item.id, Date.now());
        if (st.hasPinLock) {
          await OmniVaultCore.touchAutoLockAlarm();
        }
        sendResponse({
          ok: true,
          username: item.username || "",
          password: msg.step1Only ? "" : item.password || ""
        });
      } catch (e) {
        sendResponse({ ok: false, error: String(e.message || e) });
      }
    })();
    return true;
  }

  if (msg.type === "SUBMIT_LOGIN_CAPTURE") {
    (async () => {
      try {
        const host = resolveVerifiedSenderHost(sender);
        if (!host) {
          sendResponse({ ok: false, status: "unsafe_origin" });
          return;
        }
        const currentPassword = String(msg.currentPassword || "");
        const isChangePasswordForm = Boolean(msg.isChangePasswordForm);
        const tabId = sender?.tab?.id;
        let username = String(msg.username || "").trim();
        const password = String(msg.password || "");
        if (!password) {
          sendResponse({ ok: false, status: "empty_password" });
          return;
        }
        // Recover cross-page Step-1 username ONLY for normal login (never pollute change-password forms!)
        if (!username && !currentPassword && !isChangePasswordForm && tabId != null) {
          username = await getStep1UsernameForTabHost(tabId, host).catch(() => "");
        }
        if (tabId != null) {
          await clearStep1UsernameForTabHost(tabId, host).catch(() => {});
        }
        const now = Date.now();

        const outcome = await OmniVaultCore.mutateVaultState(async (st) => {
          if (st.locked) {
            // HIGH-EXT-04: Never store plaintext passwords in chrome.storage.session while locked!
            // Retain only non-secret origin/username hint so user can unlock first.
            const list = await getSessionJson(LOCKED_CAPTURES_KEY, []);
            const fresh = (Array.isArray(list) ? list : []).filter(
              (c) => c && now - Number(c.capturedAt || 0) < LOCKED_CAPTURE_TTL_MS
            );
            const dedupKey = `${host}|${username.toLowerCase()}`;
            const filtered = fresh.filter(
              (c) => `${c.host}|${String(c.username || "").toLowerCase()}` !== dedupKey
            );
            filtered.unshift({
              id: crypto.randomUUID(),
              host,
              serviceName: OmniVaultCore.prettifyDomainTitle(host) || host,
              username,
              capturedAt: now
            });
            await setSessionJson(LOCKED_CAPTURES_KEY, filtered.slice(0, LOCKED_CAPTURE_MAX));

            const notice = {
              noticeId: crypto.randomUUID(),
              kind: "locked_pending",
              host,
              username,
              createdAt: now
            };
            if (tabId != null) {
              await storePendingTabNotice(tabId, notice);
            }
            return {
              save: false,
              result: { response: { ok: true, status: "locked_pending", notice }, shouldSync: false }
            };
          }

          if (!st.pairing) {
            const notice = {
              noticeId: crypto.randomUUID(),
              kind: "unpaired",
              host,
              username,
              createdAt: now
            };
            if (tabId != null) {
              await storePendingTabNotice(tabId, notice);
            }
            return {
              save: false,
              result: { response: { ok: true, status: "unpaired", notice }, shouldSync: false }
            };
          }

          const res = upsertCapturedCredentialInState(st, {
            host,
            serviceName: msg.serviceName,
            username,
            password,
            currentPassword,
            now,
            allowOverwriteExistingPassword: false
          });
          if (res.status === "already_saved") {
            return {
              save: false,
              result: { response: { ok: true, status: "already_saved" }, shouldSync: false }
            };
          }

          if (res.status === "needs_confirm_update") {
            // HIGH-EXT-02: Require explicit user confirmation before overwriting an existing different password!
            const proposalId = crypto.randomUUID();
            const pendingMap = pruneMapByTtl(
              await getSessionJson(PENDING_UPDATES_KEY, {}),
              PENDING_UPDATE_TTL_MS,
              PENDING_UPDATE_MAX
            );
            // Replace any older pending proposal for the same vault item so Popup stays clean
            for (const [oldPid, oldP] of Object.entries(pendingMap)) {
              if (oldP && oldP.itemId === res.existingItem.id) {
                delete pendingMap[oldPid];
              }
            }
            const resolvedUsername = username || res.existingItem.username || "";
            pendingMap[proposalId] = {
              proposalId,
              itemId: res.existingItem.id,
              host,
              tabId: tabId ?? null,
              serviceName: res.existingItem.service_name,
              username: resolvedUsername,
              newPassword: password,
              createdAt: now
            };
            await setSessionJson(PENDING_UPDATES_KEY, pendingMap);
            try {
              chrome?.alarms?.create?.(PENDING_UPDATES_CLEANUP_ALARM_NAME, { delayInMinutes: 5 });
            } catch (_) {}

            const notice = {
              noticeId: proposalId,
              kind: "confirm_update",
              host,
              serviceName: res.existingItem.service_name,
              username: resolvedUsername,
              createdAt: now
            };
            if (tabId != null) {
              await storePendingTabNotice(tabId, notice);
            }
            if (st.hasPinLock) {
              await OmniVaultCore.touchAutoLockAlarm();
            }
            return {
              save: false,
              result: { response: { ok: true, status: "confirm_update", notice }, shouldSync: false }
            };
          }

          if (st.hasPinLock) {
            await OmniVaultCore.touchAutoLockAlarm();
          }

          const noticeId = crypto.randomUUID();
          const undos = pruneMapByTtl(
            await getSessionJson(UNDO_RECORDS_KEY, {}),
            UNDO_RECORD_TTL_MS,
            UNDO_RECORD_MAX
          );
          // Store metadata-only undo entry (zero plaintext passwords or TOTP secrets in session storage)
          undos[noticeId] = {
            noticeId,
            mode: res.mode,
            itemId: res.item.id,
            prevUsername: res.prevUsername || "",
            prevWasEmpty: Boolean(res.prevWasEmpty),
            prevPasswordHistoryChangedAt: Number(res.prevPasswordHistoryChangedAt) || 0,
            host,
            tabId: tabId ?? null,
            username: res.item.username,
            createdAt: now
          };
          await setSessionJson(UNDO_RECORDS_KEY, undos);

          const notice = {
            noticeId,
            kind: "auto_saved",
            mode: res.mode,
            host,
            serviceName: res.item.service_name,
            username: res.item.username,
            createdAt: now
          };
          if (tabId != null) {
            await storePendingTabNotice(tabId, notice);
          }

          return {
            save: true,
            result: {
              response: { ok: true, status: "auto_saved", mode: res.mode, notice },
              shouldSync: true
            }
          };
        });

        sendResponse(outcome.response);
        if (outcome.shouldSync) {
          try {
            await OmniVaultCore.syncBrowserVaultBidirectional(true);
          } catch (_) {}
        }
      } catch (e) {
        sendResponse({ ok: false, error: String(e.message || e) });
      }
    })();
    return true;
  }

  if (msg.type === "CONFIRM_PENDING_UPDATE") {
    (async () => {
      try {
        const host = resolveVerifiedSenderHost(sender);
        const senderTabId = sender?.tab?.id ?? null;
        const proposalId = String(msg.proposalId || "");
        if (!host || !proposalId) {
          sendResponse({ ok: false, error: "Yêu cầu xác nhận không hợp lệ" });
          return;
        }
        const now = Date.now();
        const outcome = await OmniVaultCore.mutateVaultState(async (st) => {
          if (st.locked || !st.pairing) {
            return {
              save: false,
              result: { response: { ok: false, error: "Kho đang khóa" }, shouldSync: false }
            };
          }
          const pendingMap = await getSessionJson(PENDING_UPDATES_KEY, {});
          const proposal = pendingMap && pendingMap[proposalId] ? pendingMap[proposalId] : null;
          const originAllowed =
            Boolean(proposal) &&
            (proposal.host === host ||
              (proposal.tabId != null &&
                senderTabId != null &&
                proposal.tabId === senderTabId &&
                isCompatibleRedirectHost(proposal.host, host)));
          if (!originAllowed) {
            return {
              save: false,
              result: {
                response: { ok: false, error: "Đề xuất cập nhật không tồn tại hoặc sai tên miền" },
                shouldSync: false
              }
            };
          }
          delete pendingMap[proposalId];
          await setSessionJson(
            PENDING_UPDATES_KEY,
            pruneMapByTtl(pendingMap, PENDING_UPDATE_TTL_MS, PENDING_UPDATE_MAX)
          );
          if (senderTabId != null) {
            await removePendingTabNotice(senderTabId, proposalId).catch(() => {});
          }
          if (now - Number(proposal.createdAt || 0) > PENDING_UPDATE_TTL_MS) {
            return {
              save: false,
              result: { response: { ok: false, error: "Hết thời gian xác nhận cập nhật" }, shouldSync: false }
            };
          }
          const res = upsertCapturedCredentialInState(st, {
            host: proposal.host,
            serviceName: proposal.serviceName,
            username: proposal.username,
            password: proposal.newPassword,
            targetItemId: proposal.itemId || "",
            now,
            allowOverwriteExistingPassword: true
          });
          if (res.status === "target_not_found") {
            return {
              save: false,
              result: {
                response: { ok: false, status: "target_not_found", error: "Tài khoản mục tiêu không còn tồn tại trong kho." },
                shouldSync: false
              }
            };
          }
          if (res.status !== "auto_saved") {
            return {
              save: false,
              result: { response: { ok: true, status: res.status }, shouldSync: false }
            };
          }
          if (st.hasPinLock) {
            await OmniVaultCore.touchAutoLockAlarm();
          }
          const noticeId = crypto.randomUUID();
          const undos = pruneMapByTtl(
            await getSessionJson(UNDO_RECORDS_KEY, {}),
            UNDO_RECORD_TTL_MS,
            UNDO_RECORD_MAX
          );
          undos[noticeId] = {
            noticeId,
            mode: res.mode,
            itemId: res.item.id,
            prevUsername: res.prevUsername || "",
            prevWasEmpty: Boolean(res.prevWasEmpty),
            prevPasswordHistoryChangedAt: Number(res.prevPasswordHistoryChangedAt) || 0,
            host: proposal.host,
            tabId: senderTabId,
            username: res.item.username,
            createdAt: now
          };
          await setSessionJson(UNDO_RECORDS_KEY, undos);
          return {
            save: true,
            result: {
              response: {
                ok: true,
                status: "updated",
                noticeId,
                host: proposal.host,
                username: res.item.username
              },
              shouldSync: true
            }
          };
        });
        sendResponse(outcome.response);
        if (outcome.shouldSync) {
          try {
            await OmniVaultCore.syncBrowserVaultBidirectional(true);
          } catch (_) {}
        }
      } catch (e) {
        sendResponse({ ok: false, error: String(e.message || e) });
      }
    })();
    return true;
  }

  if (msg.type === "DISMISS_PENDING_UPDATE") {
    (async () => {
      try {
        const host = resolveVerifiedSenderHost(sender);
        const senderTabId = sender?.tab?.id ?? null;
        const proposalId = String(msg.proposalId || "");
        if (host && proposalId) {
          await OmniVaultCore.withVaultMutationLock(async () => {
            const pendingMap = await getSessionJson(PENDING_UPDATES_KEY, {});
            const p = pendingMap && pendingMap[proposalId] ? pendingMap[proposalId] : null;
            const allowed =
              Boolean(p) &&
              (p.host === host ||
                (p.tabId != null &&
                  senderTabId != null &&
                  p.tabId === senderTabId &&
                  isCompatibleRedirectHost(p.host, host)));
            if (allowed) {
              delete pendingMap[proposalId];
              await setSessionJson(
                PENDING_UPDATES_KEY,
                pruneMapByTtl(pendingMap, PENDING_UPDATE_TTL_MS, PENDING_UPDATE_MAX)
              );
              if (senderTabId != null) {
                await removePendingTabNotice(senderTabId, proposalId).catch(() => {});
              }
            }
          });
        }
        sendResponse({ ok: true });
      } catch (_) {
        sendResponse({ ok: false });
      }
    })();
    return true;
  }

  if (msg.type === "GET_PENDING_UPDATES") {
    if (!isTrustedExtensionPageSender(sender)) {
      sendResponse({ ok: false, proposals: [] });
      return false;
    }
    (async () => {
      try {
        // L1: Short-circuit BEFORE loading/decrypting vault state when no pending proposals exist!
        const raw = await getSessionJson(PENDING_UPDATES_KEY, {});
        const pruned = pruneMapByTtl(raw, PENDING_UPDATE_TTL_MS, PENDING_UPDATE_MAX);
        const values = Object.values(pruned);
        if (values.length === 0) {
          sendResponse({ ok: true, proposals: [] });
          return;
        }
        const { state: st } = await OmniVaultCore.getCachedVaultStateAndIndex();
        if (st.locked || !st.pairing) {
          sendResponse({ ok: true, proposals: [] });
          return;
        }
        // Never leak plaintext newPassword to popup DOM — return metadata only!
        const proposals = values.map((p) => ({
          proposalId: p.proposalId,
          itemId: p.itemId || "",
          host: p.host || "",
          serviceName: p.serviceName || p.host || "Tài khoản Web",
          username: p.username || "",
          createdAt: Number(p.createdAt || 0)
        }));
        sendResponse({ ok: true, proposals });
      } catch (_) {
        sendResponse({ ok: false, proposals: [] });
      }
    })();
    return true;
  }

  if (msg.type === "CONFIRM_PENDING_UPDATE_BY_ID") {
    if (!isTrustedExtensionPageSender(sender)) {
      sendResponse({ ok: false, error: "Không được phép." });
      return false;
    }
    (async () => {
      try {
        const proposalId = String(msg.proposalId || "");
        if (!proposalId) {
          sendResponse({ ok: false, error: "Thiếu mã đề xuất cập nhật." });
          return;
        }
        const now = Date.now();
        const outcome = await OmniVaultCore.mutateVaultState(async (st) => {
          if (st.locked || !st.pairing) {
            return {
              save: false,
              result: { response: { ok: false, error: "Kho đang khóa" }, shouldSync: false }
            };
          }
          const pendingMap = await getSessionJson(PENDING_UPDATES_KEY, {});
          const proposal = pendingMap && pendingMap[proposalId] ? pendingMap[proposalId] : null;
          if (!proposal) {
            return {
              save: false,
              result: { response: { ok: false, error: "Đề xuất cập nhật đã hết hạn." }, shouldSync: false }
            };
          }
          delete pendingMap[proposalId];
          await setSessionJson(
            PENDING_UPDATES_KEY,
            pruneMapByTtl(pendingMap, PENDING_UPDATE_TTL_MS, PENDING_UPDATE_MAX)
          );
          if (proposal.tabId != null) {
            await removePendingTabNotice(proposal.tabId, proposalId).catch(() => {});
          }
          if (now - Number(proposal.createdAt || 0) > PENDING_UPDATE_TTL_MS) {
            return {
              save: false,
              result: { response: { ok: false, error: "Đề xuất cập nhật đã hết hạn." }, shouldSync: false }
            };
          }
          const res = upsertCapturedCredentialInState(st, {
            host: proposal.host,
            serviceName: proposal.serviceName,
            username: proposal.username,
            password: proposal.newPassword,
            targetItemId: proposal.itemId || "",
            now,
            allowOverwriteExistingPassword: true
          });
          if (res.status === "target_not_found") {
            return {
              save: false,
              result: {
                response: { ok: false, status: "target_not_found", error: "Tài khoản mục tiêu không còn tồn tại trong kho." },
                shouldSync: false
              }
            };
          }
          if (res.status !== "auto_saved") {
            return {
              save: false,
              result: { response: { ok: true, status: res.status }, shouldSync: false }
            };
          }
          if (st.hasPinLock) {
            await OmniVaultCore.touchAutoLockAlarm();
          }
          return {
            save: true,
            result: {
              response: {
                ok: true,
                status: "updated",
                host: proposal.host,
                username: res.item.username
              },
              shouldSync: true
            }
          };
        });
        if (outcome.shouldSync) {
          try {
            await OmniVaultCore.syncBrowserVaultBidirectional(true);
          } catch (_) {}
        }
        sendResponse(outcome.response);
      } catch (e) {
        sendResponse({ ok: false, error: String(e.message || e) });
      }
    })();
    return true;
  }

  if (msg.type === "DISMISS_PENDING_UPDATE_BY_ID") {
    if (!isTrustedExtensionPageSender(sender)) {
      sendResponse({ ok: false });
      return false;
    }
    (async () => {
      try {
        const proposalId = String(msg.proposalId || "");
        if (proposalId) {
          await OmniVaultCore.withVaultMutationLock(async () => {
            const pendingMap = await getSessionJson(PENDING_UPDATES_KEY, {});
            const proposal = pendingMap && pendingMap[proposalId] ? pendingMap[proposalId] : null;
            if (proposal) {
              delete pendingMap[proposalId];
              await setSessionJson(
                PENDING_UPDATES_KEY,
                pruneMapByTtl(pendingMap, PENDING_UPDATE_TTL_MS, PENDING_UPDATE_MAX)
              );
              if (proposal.tabId != null) {
                await removePendingTabNotice(proposal.tabId, proposalId).catch(() => {});
              }
            }
          });
        }
        sendResponse({ ok: true });
      } catch (_) {
        sendResponse({ ok: false });
      }
    })();
    return true;
  }

  if (msg.type === "DISMISS_PENDING_UPDATES_FOR_ITEM") {
    if (!isTrustedExtensionPageSender(sender)) {
      sendResponse({ ok: false });
      return false;
    }
    (async () => {
      try {
        const itemId = String(msg.itemId || "").trim();
        const username = String(msg.username || "").trim();
        const domains = Array.isArray(msg.domains)
          ? msg.domains.map((d) => OmniVaultCore.extractCleanDomain(d)).filter(Boolean)
          : [];
        await OmniVaultCore.withVaultMutationLock(async () => {
          const pendingMap = await getSessionJson(PENDING_UPDATES_KEY, {});
          if (!pendingMap || typeof pendingMap !== "object") return;
          let changed = false;
          for (const [pid, p] of Object.entries(pendingMap)) {
            if (!p) continue;
            const idHit = Boolean(itemId && p.itemId && p.itemId === itemId);
            const domUserHit = Boolean(
              !idHit &&
                domains.length > 0 &&
                p.host &&
                domains.includes(OmniVaultCore.extractCleanDomain(p.host)) &&
                username &&
                usernamesMatchForAccount(p.username, username, p.host)
            );
            if (idHit || domUserHit) {
              delete pendingMap[pid];
              changed = true;
              if (p.tabId != null) {
                await removePendingTabNotice(p.tabId, pid).catch(() => {});
              }
            }
          }
          if (changed) {
            await setSessionJson(
              PENDING_UPDATES_KEY,
              pruneMapByTtl(pendingMap, PENDING_UPDATE_TTL_MS, PENDING_UPDATE_MAX)
            );
          }
        });
        sendResponse({ ok: true });
      } catch (_) {
        sendResponse({ ok: false });
      }
    })();
    return true;
  }

  if (msg.type === "ACK_TAB_CAPTURE_NOTICE") {
    if (sender?.frameId !== 0) {
      sendResponse({ ok: false });
      return false;
    }
    (async () => {
      try {
        const tabId = sender?.tab?.id;
        const noticeId = String(msg.noticeId || "");
        if (tabId != null && noticeId) {
          await removePendingTabNotice(tabId, noticeId);
        }
        sendResponse({ ok: true });
      } catch (_) {
        sendResponse({ ok: false });
      }
    })();
    return true;
  }

  if (msg.type === "UNDO_AUTO_SAVED_LOGIN") {
    (async () => {
      try {
        const host = resolveVerifiedSenderHost(sender);
        const noticeId = String(msg.noticeId || "");
        if (!host || !noticeId) {
          sendResponse({ ok: false, error: "Yêu cầu hoàn tác không hợp lệ" });
          return;
        }
        const outcome = await OmniVaultCore.mutateVaultState(async (st) => {
          if (st.locked || !st.pairing) {
            return {
              save: false,
              result: { response: { ok: false, error: "Kho đang khóa" }, shouldSync: false }
            };
          }
          const undos = await getSessionJson(UNDO_RECORDS_KEY, {});
          const undo = undos && undos[noticeId] ? undos[noticeId] : null;
          const undoTabId = sender?.tab?.id ?? null;
          const undoAllowed =
            Boolean(undo) &&
            (undo.host === host ||
              (undo.tabId != null &&
                undoTabId != null &&
                undo.tabId === undoTabId &&
                isCompatibleRedirectHost(undo.host, host)));
          if (!undoAllowed) {
            return {
              save: false,
              result: { response: { ok: false, error: "Yêu cầu hoàn tác không hợp lệ" }, shouldSync: false }
            };
          }
          delete undos[noticeId];
          await setSessionJson(
            UNDO_RECORDS_KEY,
            pruneMapByTtl(undos, UNDO_RECORD_TTL_MS, UNDO_RECORD_MAX)
          );
          if (Date.now() - Number(undo.createdAt || 0) > UNDO_RECORD_TTL_MS) {
            return {
              save: false,
              result: { response: { ok: false, error: "Hết thời gian hoàn tác" }, shouldSync: false }
            };
          }
          const now = Date.now();
          if (!st.deletedIds || typeof st.deletedIds !== "object") {
            st.deletedIds = {};
          }
          if (undo.mode === "created") {
            st.items = (st.items || []).filter((x) => x.id !== undo.itemId);
            st.deletedIds[undo.itemId] = now;
          } else if (undo.mode === "updated") {
            const idx = (st.items || []).findIndex((x) => x.id === undo.itemId);
            if (idx >= 0) {
              const cur = { ...st.items[idx] };
              cur.username = undo.prevUsername || "";
              if (undo.prevWasEmpty) {
                cur.password = "";
              } else if (
                Array.isArray(cur.password_history) &&
                cur.password_history.length > 0
              ) {
                const histIdx = undo.prevPasswordHistoryChangedAt
                  ? cur.password_history.findIndex(
                      (h) => Number(h.changed_at_ms) === Number(undo.prevPasswordHistoryChangedAt)
                    )
                  : 0;
                const pickIdx = histIdx >= 0 ? histIdx : 0;
                const prevEntry = cur.password_history[pickIdx];
                if (prevEntry && typeof prevEntry.password === "string") {
                  cur.password = prevEntry.password;
                  cur.password_history = cur.password_history.filter((_, i) => i !== pickIdx);
                }
              }
              cur.updated_at_ms = now;
              st.items[idx] = OmniVaultCore.normalizeVaultItem(cur);
              delete st.deletedIds[undo.itemId];
            }
          }
          if (st.hasPinLock) {
            await OmniVaultCore.touchAutoLockAlarm();
          }
          return {
            save: true,
            result: { response: { ok: true, mode: undo.mode }, shouldSync: true }
          };
        });
        sendResponse(outcome.response);
        if (outcome.shouldSync) {
          try {
            await OmniVaultCore.syncBrowserVaultBidirectional(true);
          } catch (_) {}
        }
      } catch (e) {
        sendResponse({ ok: false, error: String(e.message || e) });
      }
    })();
    return true;
  }

  if (msg.type === "FLUSH_LOCKED_CAPTURES") {
    (async () => {
      try {
        if (sender?.tab || !isTrustedExtensionPageSender(sender)) {
          sendResponse({ ok: false, savedCount: 0, pendingHosts: [] });
          return;
        }
        const outcome = await OmniVaultCore.withVaultMutationLock(async () => {
          // HIGH-EXT-04: Always check locked status BEFORE clearing the session hint queue!
          const st = await OmniVaultCore.loadExtensionState();
          if (st.locked || !st.pairing) {
            return { ok: false, savedCount: 0, pendingHosts: [] };
          }
          const list = await getSessionJson(LOCKED_CAPTURES_KEY, []);
          await setSessionJson(LOCKED_CAPTURES_KEY, []);
          const now = Date.now();
          const pendingHosts = [];
          for (const c of Array.isArray(list) ? list : []) {
            if (!c || now - Number(c.capturedAt || 0) >= LOCKED_CAPTURE_TTL_MS) {
              continue;
            }
            if (c.host && !pendingHosts.includes(c.host)) {
              pendingHosts.push(c.host);
            }
          }
          return { ok: true, savedCount: 0, pendingHosts };
        });
        sendResponse(outcome);
      } catch (_) {
        sendResponse({ ok: false, savedCount: 0, pendingHosts: [] });
      }
    })();
    return true;
  }

  if (msg.type === "GET_EXTENSION_UPDATE_STATUS") {
    if (!isTrustedExtensionPageSender(sender)) {
      sendResponse({ ok: false });
      return false;
    }
    checkGitHubExtensionUpdate(Boolean(msg.force), {
      allowSilentBgUpdate: !msg.skipSilentAutoUpdate
    })
      .then((res) => sendResponse(res))
      .catch((e) => sendResponse({ ok: false, error: String(e?.message || e) }));
    return true;
  }

  if (msg.type === "ONE_CLICK_CHECK_AND_UPDATE") {
    if (!isTrustedExtensionPageSender(sender)) {
      sendResponse({ ok: false, error: "Không được phép." });
      return false;
    }
    (async () => {
      try {
        if (isStoreDistributionBuild()) {
          const updateStatus = await checkGitHubExtensionUpdate(true, { allowSilentBgUpdate: false });
          if (updateStatus.pendingCrxReloadVersion) {
            sendResponse({
              ok: true,
              mode: "store",
              updated: true,
              reloading: true,
              version: updateStatus.pendingCrxReloadVersion,
              updateStatus
            });
            setTimeout(() => chrome.runtime.reload(), 200);
            return;
          }
          if (typeof chrome?.runtime?.requestUpdateCheck === "function") {
            chrome.runtime.requestUpdateCheck((status, details) => {
              const reloading = status === "update_available";
              sendResponse({
                ok: true,
                mode: "store",
                updated: reloading,
                reloading,
                alreadyUpToDate: !reloading,
                status: status || "no_update",
                version: details?.version || updateStatus.currentVersion,
                updateStatus
              });
              if (reloading) setTimeout(() => chrome.runtime.reload(), 200);
            });
            return;
          }
          sendResponse({
            ok: true,
            mode: "store",
            updated: false,
            alreadyUpToDate: true,
            version: updateStatus.currentVersion,
            updateStatus
          });
          return;
        }
        const [updateStatus, nativeStatus] = await Promise.all([
          checkGitHubExtensionUpdate(true, { allowSilentBgUpdate: false }),
          probeNativeUpdaterHost()
        ]);
        if (!updateStatus || !updateStatus.ok) {
          sendResponse({
            ok: false,
            mode: nativeStatus?.available ? "native" : "browser_fs",
            updateStatus,
            nativeStatus,
            error: updateStatus?.error || "Không kết nối được GitHub để kiểm tra bản mới."
          });
          return;
        }
        if (updateStatus.isCrxManaged) {
          if (!updateStatus.hasUpdate) {
            sendResponse({
              ok: true,
              mode: "crx",
              updated: false,
              alreadyUpToDate: true,
              version: updateStatus.currentVersion,
              updateStatus,
              nativeStatus
            });
            return;
          }
          if (updateStatus.pendingCrxReloadVersion) {
            sendResponse({
              ok: true,
              mode: "crx",
              updated: true,
              reloading: true,
              version: updateStatus.pendingCrxReloadVersion,
              updateStatus,
              nativeStatus
            });
            setTimeout(() => chrome.runtime.reload(), 200);
            return;
          }
          if (typeof chrome?.runtime?.requestUpdateCheck === "function") {
            chrome.runtime.requestUpdateCheck((status, details) => {
              const reloading = status === "update_available";
              sendResponse({
                ok: true,
                mode: "crx",
                updated: reloading,
                reloading,
                status: status || "no_update",
                version: details?.version || updateStatus.latestVersion,
                updateStatus,
                nativeStatus
              });
              if (reloading) setTimeout(() => chrome.runtime.reload(), 200);
            });
            return;
          }
        }
        if (nativeStatus?.available) {
          const diskAheadOfRam = Boolean(
            nativeStatus.currentVersion &&
              compareVersions(nativeStatus.currentVersion, updateStatus.currentVersion) > 0
          );
          if (!updateStatus.hasUpdate && !diskAheadOfRam && !msg.force) {
            sendResponse({
              ok: true,
              mode: "native",
              updated: false,
              alreadyUpToDate: true,
              version: updateStatus.currentVersion,
              dirName: nativeStatus.dirName,
              dirPath: nativeStatus.dirPath,
              updateStatus,
              nativeStatus
            });
            return;
          }
          const runRes = await runNativeSelfUpdate({
            allowSilentReload: msg.allowSilentReload !== false,
            force: Boolean(msg.force)
          });
          sendResponse({
            ...runRes,
            mode: "native",
            updated: Boolean(runRes.ok && !runRes.alreadyUpToDate),
            updateStatus,
            nativeStatus
          });
          return;
        }
        sendResponse({
          ok: true,
          mode: "browser_fs",
          updated: false,
          alreadyUpToDate: !updateStatus.hasUpdate,
          version: updateStatus.hasUpdate ? updateStatus.latestVersion : updateStatus.currentVersion,
          updateStatus,
          nativeStatus
        });
      } catch (e) {
        sendResponse({ ok: false, error: String(e?.message || e) });
      }
    })();
    return true;
  }

  if (msg.type === "OPEN_EXTENSION_UPDATER") {
    if (!isTrustedExtensionPageSender(sender) || isStoreDistributionBuild()) {
      sendResponse({ ok: false, storeManaged: isStoreDistributionBuild() });
      return false;
    }
    openExtensionUpdaterWindow(Boolean(msg.autoStart))
      .then((res) => sendResponse(res))
      .catch((e) => sendResponse({ ok: false, error: String(e?.message || e) }));
    return true;
  }

  if (msg.type === "GET_NATIVE_UPDATER_STATUS") {
    if (!isTrustedExtensionPageSender(sender) || isStoreDistributionBuild()) {
      sendResponse({ ok: false, available: false, storeManaged: isStoreDistributionBuild() });
      return false;
    }
    probeNativeUpdaterHost()
      .then((res) => sendResponse(res))
      .catch((e) => sendResponse({ ok: false, available: false, error: String(e?.message || e) }));
    return true;
  }

  if (msg.type === "SET_AUTO_UPDATE_BG") {
    if (!isTrustedExtensionPageSender(sender)) {
      sendResponse({ ok: false });
      return false;
    }
    writeAutoUpdateBgEnabled(Boolean(msg.enabled))
      .then((enabled) => sendResponse({ ok: true, autoUpdateBgEnabled: enabled }))
      .catch((e) => sendResponse({ ok: false, error: String(e?.message || e) }));
    return true;
  }

  if (msg.type === "RUN_NATIVE_SELF_UPDATE") {
    if (!isTrustedExtensionPageSender(sender) || isStoreDistributionBuild()) {
      sendResponse({ ok: false, storeManaged: isStoreDistributionBuild(), error: "Không được phép." });
      return false;
    }
    runNativeSelfUpdate({
      allowSilentReload: msg.allowSilentReload !== false,
      force: Boolean(msg.force)
    })
      .then((res) => sendResponse(res))
      .catch((e) => sendResponse({ ok: false, error: String(e?.message || e) }));
    return true;
  }

  if (msg.type === "APPLY_EXTENSION_UPDATE_NOW") {
    if (!isTrustedExtensionPageSender(sender)) {
      sendResponse({ ok: false });
      return false;
    }
    (async () => {
      try {
        const manifest = chrome?.runtime?.getManifest ? chrome.runtime.getManifest() : {};
        const isCrxManaged = Boolean(manifest.update_url);
        const stored = await readStoredUpdateMeta();
        if (isCrxManaged && typeof chrome?.runtime?.requestUpdateCheck === "function") {
          if (stored?.pendingCrxReloadVersion) {
            sendResponse({
              ok: true,
              reloading: true,
              status: "update_available",
              version: stored.pendingCrxReloadVersion
            });
            setTimeout(() => chrome.runtime.reload(), 200);
            return;
          }
          chrome.runtime.requestUpdateCheck((status, details) => {
            if (status === "update_available") {
              sendResponse({
                ok: true,
                reloading: true,
                status,
                version: details?.version || stored?.latestVersion || ""
              });
              setTimeout(() => chrome.runtime.reload(), 200);
            } else {
              sendResponse({ ok: true, reloading: false, status: status || "no_update" });
            }
          });
          return;
        }
        sendResponse({ ok: true, reloading: true, status: "reload_unpacked" });
        setTimeout(() => chrome.runtime.reload(), 150);
      } catch (e) {
        sendResponse({ ok: false, reloading: false, error: String(e?.message || e) });
      }
    })();
    return true;
  }

  if (msg.type === "CLEAR_EPHEMERAL_CAPTURES") {
    if (sender?.tab || !isTrustedExtensionPageSender(sender)) {
      sendResponse({ ok: false });
      return false;
    }
    clearEphemeralCaptureCaches()
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (msg.type === "OPEN_INLINE_UNLOCK_PROMPT") {
    (async () => {
      try {
        const host = resolveVerifiedSenderHost(sender);
        if (!host) {
          sendResponse({ ok: false, error: "Trang không an toàn để mở khóa tự động điền." });
          return;
        }
        const { state: st } = await OmniVaultCore.getCachedVaultStateAndIndex();
        if (!st.locked) {
          sendResponse({ ok: true, alreadyUnlocked: true });
          return;
        }
        const openRes = await openInlineUnlockWindow({
          tabId: sender?.tab?.id ?? null,
          origWindowId: sender?.tab?.windowId ?? null,
          host,
          deviceNameHint: String(st.deviceNameHint || ""),
          anchorRect: msg.anchorRect || null
        });
        sendResponse(openRes);
      } catch (e) {
        sendResponse({ ok: false, error: String(e?.message || e) });
      }
    })();
    return true;
  }

  if (msg.type === "READ_LATEST_PASSWORD_EXPORT") {
    if (!isTrustedExtensionPageSender(sender)) {
      sendResponse({ ok: false, error: "Không được phép." });
      return false;
    }
    if (isStoreDistributionBuild()) {
      sendResponse({ ok: false, nativeAvailable: false, storeManaged: true, found: false });
      return false;
    }
    readLatestPasswordExportViaNative(msg.maxAgeMinutes)
      .then((res) => sendResponse(res))
      .catch((e) => sendResponse({ ok: false, nativeAvailable: false, found: false, error: String(e?.message || e) }));
    return true;
  }

  if (msg.type === "DELETE_IMPORTED_PASSWORD_EXPORT") {
    if (!isTrustedExtensionPageSender(sender)) {
      sendResponse({ ok: false, error: "Không được phép." });
      return false;
    }
    if (isStoreDistributionBuild()) {
      sendResponse({ ok: false, nativeAvailable: false, storeManaged: true, deleted: false });
      return false;
    }
    deleteVerifiedPasswordExportViaNative({
      fileName: msg.fileName,
      sha256: msg.sha256,
      sizeBytes: msg.sizeBytes
    })
      .then((res) => sendResponse(res))
      .catch((e) => sendResponse({ ok: false, deleted: false, error: String(e?.message || e) }));
    return true;
  }

  if (msg.type === "UNLOCK_EXTENSION_WITH_PIN") {
    if (!isTrustedExtensionPageSender(sender)) {
      sendResponse({ ok: false, error: "Không được phép." });
      return false;
    }
    (async () => {
      try {
        // Executed inside Service Worker so closing Popup/Unlock window mid-unlock cannot abort 310k->600k upgrade!
        const state = await OmniVaultCore.unlockExtensionWithPin(msg.pin);
        if (msg.notifyPendingTab) {
          await notifyPendingUnlockTabIfAny();
        }
        if (msg.includeState === false) {
          sendResponse({ ok: true });
        } else {
          sendResponse({ ok: true, state });
        }
      } catch (e) {
        sendResponse({ ok: false, error: String(e?.message || e) });
      }
    })();
    return true;
  }

  if (msg.type === "SET_EXTENSION_PIN") {
    if (sender?.tab || !isTrustedExtensionPageSender(sender)) {
      sendResponse({ ok: false, error: "Không được phép." });
      return false;
    }
    (async () => {
      try {
        await OmniVaultCore.setExtensionPin(msg.newPin, msg.currentPin ?? null);
        const state = await OmniVaultCore.loadExtensionState();
        sendResponse({ ok: true, state });
      } catch (e) {
        sendResponse({ ok: false, error: String(e?.message || e) });
      }
    })();
    return true;
  }

  if (msg.type === "CLEAR_EXTENSION_PIN") {
    if (sender?.tab || !isTrustedExtensionPageSender(sender)) {
      sendResponse({ ok: false, error: "Không được phép." });
      return false;
    }
    (async () => {
      try {
        await OmniVaultCore.clearExtensionPin(msg.currentPin);
        const state = await OmniVaultCore.loadExtensionState();
        sendResponse({ ok: true, state });
      } catch (e) {
        sendResponse({ ok: false, error: String(e?.message || e) });
      }
    })();
    return true;
  }

  if (msg.type === "WEBAUTHN_CHECK_AVAILABLE") {
    (async () => {
      try {
        const ctx = resolveVerifiedWebAuthnSender(sender);
        if (!ctx) {
          sendResponse({ handled: false });
          return;
        }
        const rawRpId = String(msg.rpId || "").trim().toLowerCase().replace(/\.+$/, "");
        if (rawRpId && !OmniVaultCore.isValidPasskeyRpMatch(rawRpId, ctx.rawHost)) {
          sendResponse({ handled: false });
          return;
        }
        const { state: st } = await OmniVaultCore.getCachedVaultStateAndIndex();
        // Zero-leak guard: never reveal lock/pairing status to untrusted web pages
        if (st.locked || !st.pairing) {
          sendResponse({ handled: false });
          return;
        }
        const mode = msg.mode === "create" ? "create" : "get";
        if (mode === "create") {
          const effectiveRpId = rawRpId || ctx.rawHost;
          if (!OmniVaultCore.isValidPasskeyRpMatch(effectiveRpId, ctx.rawHost)) {
            sendResponse({ handled: false });
            return;
          }
          const excludeIds = Array.isArray(msg.excludeCredentialIds) ? msg.excludeCredentialIds : [];
          if (excludeIds.length > 0) {
            const dupes = OmniVaultCore.findMatchingPasskeysForHost(
              st.items,
              ctx.rawHost,
              effectiveRpId,
              excludeIds
            );
            if (dupes.length > 0) {
              sendResponse({ handled: false });
              return;
            }
          }
          sendResponse({ handled: true, mode: "create", rpId: effectiveRpId });
          return;
        }
        const allowIds = Array.isArray(msg.allowCredentialIds) ? msg.allowCredentialIds : [];
        const matches = OmniVaultCore.findMatchingPasskeysForHost(
          st.items,
          ctx.rawHost,
          rawRpId,
          allowIds
        );
        if (matches.length === 0) {
          sendResponse({ handled: false });
          return;
        }
        sendResponse({
          handled: true,
          mode: "get",
          passkeys: matches.slice(0, 20).map(({ item, passkey }) => ({
            itemId: item.id,
            serviceName: item.service_name || passkey.rp_name || passkey.rp_id,
            credentialIdB64Url: passkey.credential_id_b64url,
            rpId: passkey.rp_id,
            rpName: passkey.rp_name || passkey.rp_id,
            userName: passkey.user_name || item.username || "",
            userDisplayName: passkey.user_display_name || passkey.user_name || item.username || "",
            lastUsedAtMs: passkey.last_used_at_ms || null
          }))
        });
      } catch (_) {
        sendResponse({ handled: false });
      }
    })();
    return true;
  }

  if (msg.type === "WEBAUTHN_ASSERT_PASSKEY") {
    (async () => {
      try {
        const ctx = resolveVerifiedWebAuthnSender(sender);
        if (!ctx) {
          sendResponse({ ok: false, error: "Trang không an toàn cho Passkey." });
          return;
        }
        const credentialIdB64Url = String(msg.credentialIdB64Url || "").trim();
        const challengeB64Url = String(msg.challengeB64Url || "").trim();
        const rawRpId = String(msg.rpId || "").trim().toLowerCase().replace(/\.+$/, "");
        if (!credentialIdB64Url || !challengeB64Url) {
          sendResponse({ ok: false, error: "Thiếu thông tin xác thực Passkey." });
          return;
        }
        if (rawRpId && !OmniVaultCore.isValidPasskeyRpMatch(rawRpId, ctx.rawHost)) {
          sendResponse({ ok: false, error: "RP ID không khớp với tên miền hiện tại." });
          return;
        }
        const outcome = await OmniVaultCore.mutateVaultState(async (st) => {
          if (st.locked || !st.pairing) {
            return {
              save: false,
              result: { response: { ok: false, error: "Kho OmniVault đang khóa." }, shouldSync: false }
            };
          }
          const matches = OmniVaultCore.findMatchingPasskeysForHost(
            st.items,
            ctx.rawHost,
            rawRpId,
            [credentialIdB64Url]
          );
          if (matches.length === 0) {
            return {
              save: false,
              result: { response: { ok: false, error: "Không tìm thấy Passkey khớp tên miền." }, shouldSync: false }
            };
          }
          const { item, passkey } = matches[0];
          const now = Date.now();
          const nextSignCount = (Number(passkey.sign_count) || 0) + 1;
          const assertion = await OmniVaultCore.signPasskeyAssertionP256({
            passkey,
            challengeB64Url,
            origin: ctx.origin,
            signCount: nextSignCount
          });
          passkey.sign_count = nextSignCount;
          passkey.last_used_at_ms = now;
          item.updated_at_ms = now;
          item.last_autofilled_ms = now;
          if (st.deletedIds && typeof st.deletedIds === "object") {
            delete st.deletedIds[item.id];
          }
          if (st.hasPinLock) {
            await OmniVaultCore.touchAutoLockAlarm();
          }
          return {
            save: true,
            result: {
              response: { ok: true, response: assertion },
              shouldSync: true
            }
          };
        });
        sendResponse(outcome.response);
        if (outcome.shouldSync) {
          OmniVaultCore.syncBrowserVaultBidirectional(true).catch(() => {});
        }
      } catch (e) {
        sendResponse({ ok: false, error: String(e?.message || e) });
      }
    })();
    return true;
  }

  if (msg.type === "WEBAUTHN_CREATE_PASSKEY") {
    (async () => {
      try {
        const ctx = resolveVerifiedWebAuthnSender(sender);
        if (!ctx) {
          sendResponse({ ok: false, error: "Trang không an toàn để tạo Passkey." });
          return;
        }
        const rawRpId = String(msg.rpId || "").trim().toLowerCase().replace(/\.+$/, "");
        const effectiveRpId = rawRpId || ctx.rawHost;
        if (!OmniVaultCore.isValidPasskeyRpMatch(effectiveRpId, ctx.rawHost)) {
          sendResponse({ ok: false, error: "RP ID không khớp với tên miền hiện tại." });
          return;
        }
        const challengeB64Url = String(msg.challengeB64Url || "").trim();
        if (!challengeB64Url) {
          sendResponse({ ok: false, error: "Thiếu WebAuthn challenge." });
          return;
        }
        if (Array.isArray(msg.pubKeyCredParams) && msg.pubKeyCredParams.length > 0) {
          const supportsEs256 = msg.pubKeyCredParams.some(
            (p) => p && Number(p.alg) === -7 && (!p.type || p.type === "public-key")
          );
          if (!supportsEs256) {
            sendResponse({ ok: false, unsupportedAlg: true, error: "Trang không hỗ trợ thuật toán ES256." });
            return;
          }
        }
        const pre = await OmniVaultCore.getCachedVaultStateAndIndex();
        if (pre.state.locked || !pre.state.pairing) {
          sendResponse({ ok: false, error: "Kho OmniVault đang khóa hoặc chưa kết nối." });
          return;
        }

        const cleanRpName =
          String(msg.rpName || "").trim() ||
          OmniVaultCore.prettifyDomainTitle(effectiveRpId) ||
          effectiveRpId;
        const cleanUserName = String(msg.userName || "").trim();
        const cleanUserDisplayName = String(msg.userDisplayName || cleanUserName).trim();

        const generated = await OmniVaultCore.generatePasskeyP256({
          rpId: effectiveRpId,
          rpName: cleanRpName,
          userIdB64Url: String(msg.userIdB64Url || "").trim(),
          userName: cleanUserName,
          userDisplayName: cleanUserDisplayName,
          challengeB64Url,
          origin: ctx.origin
        });

        const outcome = await OmniVaultCore.mutateVaultState(async (st) => {
          if (st.locked || !st.pairing) {
            return {
              save: false,
              result: { response: { ok: false, error: "Kho OmniVault đang khóa." }, shouldSync: false }
            };
          }
          const now = Date.now();
          const items = Array.isArray(st.items) ? st.items : [];
          st.items = items;
          if (!st.deletedIds || typeof st.deletedIds !== "object") {
            st.deletedIds = {};
          }
          const cleanRpDomain = OmniVaultCore.extractCleanDomain(effectiveRpId);
          let matchIdx = -1;
          if (cleanUserName) {
            matchIdx = items.findIndex(
              (it) =>
                (OmniVaultCore.itemMatchesDomain(it, ctx.cleanHost) >= 2 ||
                  (cleanRpDomain && OmniVaultCore.itemMatchesDomain(it, cleanRpDomain) >= 3)) &&
                usernamesMatchForAccount(it.username, cleanUserName, ctx.cleanHost)
            );
          } else {
            matchIdx = items.findIndex(
              (it) =>
                OmniVaultCore.itemMatchesDomain(it, ctx.cleanHost) >= 3 &&
                !String(it.username || "").trim()
            );
          }

          if (matchIdx >= 0) {
            const existing = items[matchIdx];
            const prevPasskeys = Array.isArray(existing.passkeys) ? existing.passkeys : [];
            const prevDomains = Array.isArray(existing.web_domains) ? existing.web_domains : [];
            const nextDomains = Array.from(new Set([...prevDomains, ctx.cleanHost].filter(Boolean)));
            const updated = OmniVaultCore.normalizeVaultItem({
              ...existing,
              web_domains: nextDomains,
              passkeys: [...prevPasskeys, generated.passkey],
              updated_at_ms: now
            });
            items[matchIdx] = updated;
            delete st.deletedIds[updated.id];
          } else {
            const newDomains = Array.from(new Set([ctx.cleanHost, cleanRpDomain].filter(Boolean)));
            const created = OmniVaultCore.normalizeVaultItem({
              id: crypto.randomUUID(),
              service_name: cleanRpName,
              username: cleanUserName,
              password: "",
              web_domains: newDomains,
              passkeys: [generated.passkey],
              created_at_ms: now,
              updated_at_ms: now
            });
            items.push(created);
          }

          if (st.hasPinLock) {
            await OmniVaultCore.touchAutoLockAlarm();
          }
          return {
            save: true,
            result: {
              response: { ok: true, response: generated.responseJson },
              shouldSync: true
            }
          };
        });
        sendResponse(outcome.response);
        if (outcome.shouldSync) {
          OmniVaultCore.syncBrowserVaultBidirectional(true).catch(() => {});
        }
      } catch (e) {
        sendResponse({ ok: false, error: String(e?.message || e) });
      }
    })();
    return true;
  }

  if (msg.type === "DELETE_ITEM_PASSKEY") {
    if (!isTrustedExtensionPageSender(sender)) {
      sendResponse({ ok: false, error: "Không được phép." });
      return false;
    }
    (async () => {
      try {
        const itemId = String(msg.itemId || "").trim();
        const credentialIdB64Url = String(msg.credentialIdB64Url || "").trim();
        if (!itemId || !credentialIdB64Url) {
          sendResponse({ ok: false, error: "Thiếu mã Passkey cần xóa." });
          return;
        }
        const outcome = await OmniVaultCore.mutateVaultState(async (st) => {
          if (st.locked) {
            return {
              save: false,
              result: { response: { ok: false, error: "Kho OmniVault đang khóa." }, shouldSync: false }
            };
          }
          const idx = (st.items || []).findIndex((x) => x && x.id === itemId);
          if (idx < 0) {
            return {
              save: false,
              result: { response: { ok: false, error: "Không tìm thấy tài khoản." }, shouldSync: false }
            };
          }
          const item = st.items[idx];
          const prevList = Array.isArray(item.passkeys) ? item.passkeys : [];
          const nextList = prevList.filter((pk) => pk && pk.credential_id_b64url !== credentialIdB64Url);
          if (nextList.length === prevList.length) {
            return {
              save: false,
              result: { response: { ok: false, error: "Không tìm thấy Passkey cần xóa." }, shouldSync: false }
            };
          }
          const updated = OmniVaultCore.normalizeVaultItem({
            ...item,
            passkeys: nextList,
            updated_at_ms: Date.now()
          });
          st.items[idx] = updated;
          if (st.deletedIds && typeof st.deletedIds === "object") {
            delete st.deletedIds[item.id];
          }
          if (st.hasPinLock) {
            await OmniVaultCore.touchAutoLockAlarm();
          }
          return {
            save: true,
            result: { response: { ok: true, item: updated }, shouldSync: true }
          };
        });
        if (outcome.shouldSync) {
          await OmniVaultCore.syncBrowserVaultBidirectional(true).catch(() => {});
        }
        const finalState = outcome.response.ok ? await OmniVaultCore.loadExtensionState() : null;
        sendResponse(finalState ? { ...outcome.response, state: finalState } : outcome.response);
      } catch (e) {
        sendResponse({ ok: false, error: String(e?.message || e) });
      }
    })();
    return true;
  }

  if (msg.type === "RESET_EXTENSION_VAULT") {
    if (sender?.tab || !isTrustedExtensionPageSender(sender)) {
      sendResponse({ ok: false });
      return false;
    }
    (async () => {
      await clearEphemeralCaptureCaches();
      await OmniVaultCore.resetExtensionVault();
    })()
      .then(() => sendResponse({ ok: true }))
      .catch((e) => sendResponse({ ok: false, error: String(e?.message || e) }));
    return true;
  }

  return false;
});
