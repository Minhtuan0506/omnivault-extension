@echo off
setlocal EnableExtensions
chcp 65001 >nul
set "BAT_SELF=%~f0"
set "EXT_DIR=%~dp0"
setlocal EnableDelayedExpansion
(
  "%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $raw=[IO.File]::ReadAllText($env:BAT_SELF,[Text.Encoding]::UTF8); $m='###POWERSHELL_BELOW###'; $i=$raw.LastIndexOf($m); if($i -lt 0){exit 1}; & ([ScriptBlock]::Create($raw.Substring($i+$m.Length)))"
  set "ERR=!ERRORLEVEL!"
  echo.
  pause
  exit /b !ERR!
)

###POWERSHELL_BELOW###
$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType](3072 -bor 12288)
} catch {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
}
$MaxZipBytes = 10 * 1024 * 1024
$MaxEntries = 100

function Test-AllowedGitHubUrl {
    param([string]$Url)
    if ([string]::IsNullOrWhiteSpace($Url)) { return $false }
    try {
        $u = [Uri]$Url.Trim()
        if ($u.Scheme -ne "https") { return $false }
        if (-not [string]::IsNullOrEmpty($u.UserInfo)) { return $false }
        $h = $u.Host.ToLowerInvariant()
        if ($h -eq "github.com") {
            return ($u.AbsolutePath -match '^/Minhtuan0506/omnivault-extension(?:/|$)')
        }
        if ($h -eq "minhtuan0506.github.io") {
            return ($u.AbsolutePath -match '^/omnivault-extension(?:/|$)')
        }
        return $false
    } catch {
        return $false
    }
}

function Download-AllowedZipWithLimit {
    param([string]$Url, [string]$DestPath, [int]$LimitBytes)
    if (-not (Test-AllowedGitHubUrl $Url)) {
        throw "URL tai goi cap nhat khong thuoc kho GitHub chinh thuc: $Url"
    }
    $req = [System.Net.HttpWebRequest]::Create($Url)
    $req.UserAgent = "OmniVault-Updater"
    $req.Timeout = 30000
    $req.ReadWriteTimeout = 30000
    $req.AllowAutoRedirect = $true
    $req.MaximumAutomaticRedirections = 5
    $resp = $req.GetResponse()
    try {
        if ($resp.ResponseUri -and $resp.ResponseUri.Scheme -ne "https") {
            throw "Tu choi chuyen huong khong dung HTTPS: $($resp.ResponseUri.AbsoluteUri)"
        }
        if ($resp.ContentLength -gt $LimitBytes) {
            throw "Goi tai ve vuot gioi han an toan 10 MB."
        }
        $inS = $resp.GetResponseStream()
        $outS = [System.IO.File]::Open($DestPath, [System.IO.FileMode]::Create, [System.IO.FileAccess]::Write)
        try {
            $buf = New-Object byte[] 16384
            $total = 0
            while ($true) {
                $n = $inS.Read($buf, 0, $buf.Length)
                if ($n -le 0) { break }
                $total += $n
                if ($total -gt $LimitBytes) {
                    throw "Dong du lieu tai ve vuot gioi han an toan 10 MB."
                }
                $outS.Write($buf, 0, $n)
            }
        } finally {
            $outS.Dispose()
            $inS.Dispose()
        }
    } finally {
        $resp.Dispose()
    }
}

$ExtDir = $env:EXT_DIR.TrimEnd('\')
$ManifestPath = Join-Path $ExtDir "manifest.json"
if (-not (Test-Path $ManifestPath)) {
    Write-Host "[!] Khong tim thay manifest.json trong thu muc: $ExtDir" -ForegroundColor Red
    Write-Host "    Vui long dat file nay trong thu muc tien ich OmniVault roi chay lai." -ForegroundColor Yellow
    exit 1
}

function Compare-SemVer {
    param([string]$A, [string]$B)
    $pa = ($A -replace '^v', '') -split '\.' | ForEach-Object { [int]($_ -replace '[^0-9].*$', '') }
    $pb = ($B -replace '^v', '') -split '\.' | ForEach-Object { [int]($_ -replace '[^0-9].*$', '') }
    $len = [Math]::Max($pa.Count, $pb.Count)
    for ($i = 0; $i -lt $len; $i++) {
        $va = if ($i -lt $pa.Count) { $pa[$i] } else { 0 }
        $vb = if ($i -lt $pb.Count) { $pb[$i] } else { 0 }
        if ($va -ne $vb) { return ($va - $vb) }
    }
    return 0
}

$curManifest = Get-Content -Raw -Encoding UTF8 $ManifestPath | ConvertFrom-Json
$curVer = [string]$curManifest.version
$pinnedPubKeyB64 = ([string]$curManifest.key).Trim()
if ([string]::IsNullOrWhiteSpace($pinnedPubKeyB64)) {
    Write-Host "[!] manifest.json thieu khoa cong khai RSA (key) de xac thuc ban cap nhat." -ForegroundColor Red
    exit 1
}

$spki = [Convert]::FromBase64String($pinnedPubKeyB64)
if ($spki.Length -ne 294 -or $spki[32] -ne 0) {
    Write-Host "[!] Khoa cong khai RSA-2048 SPKI trong manifest.json khong hop le." -ForegroundColor Red
    exit 1
}

Write-Host "=========================================================" -ForegroundColor Cyan
Write-Host "  OMNIVAULT EXTENSION - CAP NHAT TRUC TIEP TU GITHUB     " -ForegroundColor Cyan
Write-Host "=========================================================" -ForegroundColor Cyan
Write-Host "[*] Thu muc hien tai  : $ExtDir" -ForegroundColor Gray
Write-Host "[*] Phien ban hien tai: v$curVer" -ForegroundColor White
Write-Host "[*] Dang kiem tra ban moi nhat tren GitHub..." -ForegroundColor Yellow

$latestVer = ""
$zipUrl = ""
$changelog = ""
$vj = $null
$ts = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()

try {
    $vj = Invoke-RestMethod -Uri "https://minhtuan0506.github.io/omnivault-extension/version.json?t=$ts" -Headers @{ "User-Agent" = "OmniVault-Updater" } -TimeoutSec 20
    $latestVer = ([string]$vj.version) -replace '^v', ''
    $changelog = [string]$vj.changelog
    $zipUrl = [string]$vj.unpacked_zip_url
} catch {
    $rel = Invoke-RestMethod -Uri "https://api.github.com/repos/Minhtuan0506/omnivault-extension/releases/latest" -Headers @{ "User-Agent" = "OmniVault-Updater"; "Accept" = "application/vnd.github+json" } -TimeoutSec 20
    $latestVer = ([string]$rel.tag_name) -replace '^v', ''
    $changelog = [string]$rel.body
    $asset = $rel.assets | Where-Object { $_.name -match '^OmniVault-GiaiNen-.*\.zip$' } | Select-Object -First 1
    if ($asset) {
        $zipUrl = [string]$asset.browser_download_url
    }
    $vjAsset = $rel.assets | Where-Object { $_.name -eq 'version.json' } | Select-Object -First 1
    if ($vjAsset -and (Test-AllowedGitHubUrl ([string]$vjAsset.browser_download_url))) {
        $vj = Invoke-RestMethod -Uri ([string]$vjAsset.browser_download_url) -Headers @{ "User-Agent" = "OmniVault-Updater" } -TimeoutSec 20
    } else {
        $vj = Invoke-RestMethod -Uri "https://minhtuan0506.github.io/omnivault-extension/version.json?t=$ts" -Headers @{ "User-Agent" = "OmniVault-Updater" } -TimeoutSec 20
    }
}

if (-not $zipUrl) {
    $zipUrl = "https://minhtuan0506.github.io/omnivault-extension/OmniVault-GiaiNen-latest.zip"
}
if (-not (Test-AllowedGitHubUrl $zipUrl)) {
    throw "URL tai goi cap nhat khong thuoc kho GitHub chinh thuc: $zipUrl"
}

Write-Host "[*] Ban moi nhat GitHub : v$latestVer" -ForegroundColor Green
if ((Compare-SemVer $latestVer $curVer) -le 0) {
    Write-Host "[+] Ban dang su dung phien ban moi nhat (v$curVer). Khong can cap nhat them!" -ForegroundColor Green
    exit 0
}

if (-not $vj) {
    throw "Thieu metadata version.json da ky de xac thuc tinh toan ven ban cap nhat!"
}
$vjVer = ([string]$vj.version) -replace '^v', ''
if ((Compare-SemVer $vjVer $latestVer) -ne 0) {
    throw "Phien ban trong version.json (v$vjVer) khong khop Release (v$latestVer)!"
}
$zipSha256Expected = ([string]$vj.zip_sha256).Trim().ToLowerInvariant()
$zipSigRsaB64 = ([string]$vj.signature_rsa_b64).Trim()
if ([string]::IsNullOrWhiteSpace($zipSha256Expected) -or [string]::IsNullOrWhiteSpace($zipSigRsaB64)) {
    throw "Thieu zip_sha256 hoac signature_rsa_b64 trong version.json - tu choi cai dat ban chua ky!"
}

if ($changelog) {
    Write-Host "[*] Thay doi moi:" -ForegroundColor Cyan
    Write-Host "    $changelog" -ForegroundColor White
}

$tmpRoot = Join-Path $env:TEMP ("omnivault_ext_dl_" + [Guid]::NewGuid().ToString("N"))
$zipFile = Join-Path $tmpRoot "update.zip"
$unpackDir = Join-Path $tmpRoot "unpack"
New-Item -ItemType Directory -Force -Path $unpackDir | Out-Null

try {
    Write-Host "[*] Dang tai goi v$latestVer tu GitHub..." -ForegroundColor Yellow
    Download-AllowedZipWithLimit -Url $zipUrl -DestPath $zipFile -LimitBytes $MaxZipBytes

    Write-Host "[*] Dang kiem tra SHA-256 & chu ky so RSA-2048..." -ForegroundColor Yellow
    $zipBytes = [System.IO.File]::ReadAllBytes($zipFile)
    $sha256Alg = [System.Security.Cryptography.SHA256]::Create()
    try {
        $hashBytes = $sha256Alg.ComputeHash($zipBytes)
    } finally {
        $sha256Alg.Dispose()
    }
    $actualZipSha256 = ([BitConverter]::ToString($hashBytes) -replace '-', '').ToLowerInvariant()
    if ($actualZipSha256 -ne $zipSha256Expected) {
        throw "SHA-256 goi cap nhat KHONG KHOP! Ky vong=$zipSha256Expected, Thuc te=$actualZipSha256"
    }

    $rsaParams = New-Object System.Security.Cryptography.RSAParameters
    $rsaParams.Modulus = [byte[]]$spki[33..288]
    $rsaParams.Exponent = [byte[]]$spki[291..293]
    $rsa = New-Object System.Security.Cryptography.RSACryptoServiceProvider
    try {
        $rsa.ImportParameters($rsaParams)
        $canonical = "omnivault-ext-zip-v1|$latestVer|$actualZipSha256"
        $canonicalBytes = [System.Text.Encoding]::UTF8.GetBytes($canonical)
        $sigBytes = [Convert]::FromBase64String($zipSigRsaB64)
        $sigOk = $rsa.VerifyData(
            $canonicalBytes,
            [System.Security.Cryptography.CryptoConfig]::MapNameToOID("SHA256"),
            $sigBytes
        )
        if (-not $sigOk) {
            throw "Chu ky RSA-2048 KHONG HOP LE! Goi cap nhat da bi sua doi hoac gia mao."
        }
    } finally {
        $rsa.Dispose()
    }
    Write-Host "[+] Chu ky RSA-2048 & SHA-256 hop le ($actualZipSha256)." -ForegroundColor Green

    Add-Type -AssemblyName System.IO.Compression
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $unpackFullRoot = [System.IO.Path]::GetFullPath($unpackDir).TrimEnd('\') + '\'
    $stagedFiles = New-Object System.Collections.Generic.List[string]
    $seenLower = New-Object System.Collections.Generic.HashSet[string]
    $totalUncomp = [long]0
    $arch = [System.IO.Compression.ZipFile]::OpenRead($zipFile)
    try {
        if ($arch.Entries.Count -eq 0 -or $arch.Entries.Count -gt $MaxEntries) {
            throw "So luong tep trong ZIP khong hop le ($($arch.Entries.Count))."
        }
        foreach ($entry in $arch.Entries) {
            $rawName = [string]$entry.FullName
            if ([string]::IsNullOrWhiteSpace($rawName) -or $rawName.EndsWith("/")) { continue }
            if ($rawName.Contains([char]0) -or $rawName.Contains("\") -or $rawName.Contains(":") -or $rawName.StartsWith("/")) {
                throw "Phat hien duong dan nguy hiem (Zip-Slip): $rawName"
            }
            foreach ($seg in $rawName.Split("/")) {
                if ([string]::IsNullOrEmpty($seg) -or $seg -eq "." -or $seg -eq "..") {
                    throw "Phat hien duong dan vuot cap (Zip-Slip): $rawName"
                }
            }
            if (-not $seenLower.Add($rawName.ToLowerInvariant())) {
                throw "Phat hien tep trung lap trong ZIP: $rawName"
            }
            $outPath = [System.IO.Path]::GetFullPath((Join-Path $unpackDir ($rawName -replace '/', '\')))
            if (-not $outPath.StartsWith($unpackFullRoot, [System.StringComparison]::OrdinalIgnoreCase)) {
                throw "Chan ghi tep ngoai thu muc tam (Zip-Slip): $rawName"
            }
            $outParent = Split-Path -Parent $outPath
            if (-not (Test-Path $outParent)) {
                New-Item -ItemType Directory -Force -Path $outParent | Out-Null
            }
            $inS = $entry.Open()
            $outS = [System.IO.File]::Open($outPath, [System.IO.FileMode]::Create, [System.IO.FileAccess]::Write)
            try {
                $buf = New-Object byte[] 16384
                while ($true) {
                    $n = $inS.Read($buf, 0, $buf.Length)
                    if ($n -le 0) { break }
                    $totalUncomp += $n
                    if ($totalUncomp -gt $MaxZipBytes) {
                        throw "Goi ZIP vuot gioi han giai nen an toan 10 MB."
                    }
                    $outS.Write($buf, 0, $n)
                }
            } finally {
                $outS.Dispose()
                $inS.Dispose()
            }
            $stagedFiles.Add($rawName)
        }
    } finally {
        $arch.Dispose()
    }

    $checkManifest = Join-Path $unpackDir "manifest.json"
    if (-not (Test-Path $checkManifest)) {
        throw "Goi tai ve khong hop le (thieu manifest.json)"
    }
    $newManifest = Get-Content -Raw -Encoding UTF8 $checkManifest | ConvertFrom-Json
    if (([string]$newManifest.key).Trim() -ne $pinnedPubKeyB64) {
        throw "manifest.json trong goi moi co khoa cong khai (key) khong khop voi ban hien tai!"
    }
    if ((Compare-SemVer ([string]$newManifest.version) $latestVer) -ne 0) {
        throw "manifest.json phien ban ($($newManifest.version)) khong khop voi v$latestVer!"
    }

    # Copy all regular files FIRST and manifest.json strictly LAST (never overwrite native_updater_host.json)
    $orderedCopy = New-Object System.Collections.Generic.List[string]
    foreach ($rel in $stagedFiles) {
        $rl = $rel.ToLowerInvariant()
        if ($rl -eq "manifest.json" -or $rl -eq "native_updater_host.json") { continue }
        $orderedCopy.Add($rel)
    }
    $orderedCopy.Add("manifest.json")

    $extFullRoot = [System.IO.Path]::GetFullPath($ExtDir).TrimEnd('\') + '\'
    Write-Host "[*] Dang chep de cac tep cap nhat vao thu muc hien tai (manifest.json sau cung)..." -ForegroundColor Yellow
    foreach ($rel in $orderedCopy) {
        $srcPath = Join-Path $unpackDir ($rel -replace '/', '\')
        $destPath = [System.IO.Path]::GetFullPath((Join-Path $ExtDir ($rel -replace '/', '\')))
        if (-not $destPath.StartsWith($extFullRoot, [System.StringComparison]::OrdinalIgnoreCase)) {
            throw "Phat hien duong dan nguy hiem ngoai thu muc extension: $rel"
        }
        $destParent = Split-Path -Parent $destPath
        if (-not (Test-Path $destParent)) {
            New-Item -ItemType Directory -Force -Path $destParent | Out-Null
        }
        Copy-Item -Force -Path $srcPath -Destination $destPath
    }

    Write-Host ""
    Write-Host "=========================================================" -ForegroundColor Green
    Write-Host "  DA CAP NHAT OMNIVAULT EXTENSION LEN v$latestVer!       " -ForegroundColor Green
    Write-Host "  - Toan bo mat khau & ket noi duoc giu nguyen 100%.     " -ForegroundColor White
    Write-Host "  - Hay mo bieu tuong OmniVault tren trinh duyet ->       " -ForegroundColor Yellow
    Write-Host "    bam nut [Ap dung ngay] (hoac Tai lai trong extensions)." -ForegroundColor Yellow
    Write-Host "=========================================================" -ForegroundColor Green
} finally {
    Remove-Item -Recurse -Force -Path $tmpRoot -ErrorAction SilentlyContinue
}
