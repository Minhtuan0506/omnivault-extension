(() => {
  const viewPairing = document.getElementById("viewPairing");
  const viewVault = document.getElementById("viewVault");
  const viewEditor = document.getElementById("viewEditor");
  const viewAudit = document.getElementById("viewAudit");
  const pairedBottomActions = document.getElementById("pairedBottomActions");
  const popupScrollArea = document.getElementById("popupScrollArea");
  const deviceLabel = document.getElementById("deviceLabel");
  const toastBanner = document.getElementById("toastBanner");

  const pairingInput = document.getElementById("pairingInput");
  const btnConnectCode = document.getElementById("btnConnectCode");
  const btnStartLocalMode = document.getElementById("btnStartLocalMode");
  const btnCancelPairUpgrade = document.getElementById("btnCancelPairUpgrade");
  const btnUpgradeToPhoneSync = document.getElementById("btnUpgradeToPhoneSync");
  const btnSecurityAudit = document.getElementById("btnSecurityAudit");
  const btnOpenBulkImportTop = document.getElementById("btnOpenBulkImportTop");
  const btnOpenBulkImportVault = document.getElementById("btnOpenBulkImportVault");
  const btnOpenBulkImportUnpaired = document.getElementById("btnOpenBulkImportUnpaired");
  const btnSyncNow = document.getElementById("btnSyncNow");
  const btnOpenAdd = document.getElementById("btnOpenAdd");
  const btnUnpair = document.getElementById("btnUnpair");

  const searchInput = document.getElementById("searchInput");
  const currentSiteSection = document.getElementById("currentSiteSection");
  const currentSiteLabel = document.getElementById("currentSiteLabel");
  const currentSiteList = document.getElementById("currentSiteList");
  const allItemsCaption = document.getElementById("allItemsCaption");
  const allVaultList = document.getElementById("allVaultList");

  const editorTitle = document.getElementById("editorTitle");
  const editId = document.getElementById("editId");
  const editService = document.getElementById("editService");
  const editUsername = document.getElementById("editUsername");
  const editPassword = document.getElementById("editPassword");
  const editDomains = document.getElementById("editDomains");
  const editTotpSecret = document.getElementById("editTotpSecret");
  const editNotes = document.getElementById("editNotes");
  const editPasskeysSection = document.getElementById("editPasskeysSection");
  const editPasskeysList = document.getElementById("editPasskeysList");
  const btnGenPw = document.getElementById("btnGenPw");
  const btnCancelEdit = document.getElementById("btnCancelEdit");
  const btnSaveItem = document.getElementById("btnSaveItem");
  const btnDeleteItem = document.getElementById("btnDeleteItem");

  const btnAuditBack = document.getElementById("btnAuditBack");
  const auditScoreSummary = document.getElementById("auditScoreSummary");
  const auditStatsGrid = document.getElementById("auditStatsGrid");
  const btnRunHibpAudit = document.getElementById("btnRunHibpAudit");
  const auditHibpStatus = document.getElementById("auditHibpStatus");
  const auditResultsList = document.getElementById("auditResultsList");

  const VI_COLLATOR = new Intl.Collator("vi");

  let currentState = null;
  let activeTab = null;
  let activeHost = "";
  let indexedItems = [];
  let itemsById = new Map();
  let domainIndex = new Map();
  let liveTotpMap = new Map();
  let virtualItems = [];
  let siteMatchedItems = [];
  let toastTimer = null;
  let searchDebounceTimer = null;
  let showingPairUpgrade = false;
  let pinInputsRef = [];
  let lastHibpResult = null;
  let hibpCheckRunning = false;
  let editorReturnView = "vault";

  function clearEditorInputs() {
    if (editId) editId.value = "";
    if (editService) editService.value = "";
    if (editUsername) editUsername.value = "";
    if (editPassword) editPassword.value = "";
    if (editDomains) editDomains.value = "";
    if (editTotpSecret) editTotpSecret.value = "";
    if (editNotes) editNotes.value = "";
    if (editPasskeysList) editPasskeysList.textContent = "";
    if (editPasskeysSection) editPasskeysSection.hidden = true;
  }

  function clearPinInputs() {
    for (const inp of pinInputsRef) {
      if (inp) inp.value = "";
    }
    if (pairingInput) pairingInput.value = "";
  }

  function clearSensitivePopupCaches() {
    indexedItems = [];
    itemsById.clear();
    domainIndex = new Map();
    liveTotpMap.clear();
    virtualItems = [];
    siteMatchedItems = [];
    lastHibpResult = null;
    hibpCheckRunning = false;
    editorReturnView = "vault";
    if (allVaultList) allVaultList.textContent = "";
    if (currentSiteList) currentSiteList.textContent = "";
    if (auditScoreSummary) auditScoreSummary.textContent = "";
    if (auditStatsGrid) auditStatsGrid.textContent = "";
    if (auditResultsList) auditResultsList.textContent = "";
    if (auditHibpStatus) {
      auditHibpStatus.textContent = "";
      auditHibpStatus.hidden = true;
    }
    const pendingBox = document.getElementById("pendingUpdatesBox");
    if (pendingBox) {
      pendingBox.textContent = "";
      pendingBox.hidden = true;
    }
    clearEditorInputs();
    clearPinInputs();
    if (typeof OmniVaultCore.clearTotpKeyCache === "function") {
      OmniVaultCore.clearTotpKeyCache();
    }
  }

  function setVaultState(nextState) {
    currentState = nextState;
    if (!currentState || currentState.locked || !Array.isArray(currentState.items)) {
      clearSensitivePopupCaches();
      return;
    }
    const items = currentState.items;
    indexedItems = new Array(items.length);
    itemsById = new Map();
    for (let i = 0; i < items.length; i++) {
      const it = items[i];
      indexedItems[i] = OmniVaultCore.buildItemSearchIndex(it);
      itemsById.set(it.id, it);
    }
    domainIndex = OmniVaultCore.buildVaultDomainIndex(items).byDomain;
    // Prune stale TOTP cache entries for removed items or changed secrets
    for (const [id, entry] of Array.from(liveTotpMap.entries())) {
      const it = itemsById.get(id);
      if (!it || !it.totp_secret || entry.secret !== it.totp_secret) {
        liveTotpMap.delete(id);
      }
    }
  }

  function showToast(msg, isError = false) {
    toastBanner.textContent = msg;
    toastBanner.className = isError ? "toast error" : "toast";
    toastBanner.hidden = false;
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      toastBanner.hidden = true;
    }, 3500);
  }

  function showView(which) {
    viewPairing.hidden = which !== "pairing";
    viewVault.hidden = which !== "vault";
    viewEditor.hidden = which !== "editor";
    if (viewAudit) viewAudit.hidden = which !== "audit";
    if (pairedBottomActions) {
      pairedBottomActions.hidden = which !== "vault";
    }
  }

  async function detectActiveTab() {
    try {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      activeTab = tabs && tabs[0] ? tabs[0] : null;
      const url = activeTab?.url || "";
      if (OmniVaultCore.isSafeAutofillUrl(url)) {
        activeHost = OmniVaultCore.extractCleanDomain(url);
      } else {
        activeHost = "";
      }
    } catch (_) {
      activeTab = null;
      activeHost = "";
    }
  }

  function formatTotpDisplay(code) {
    const s = String(code || "");
    const half = Math.ceil(s.length / 2);
    return `2FA: ${s.slice(0, half)} ${s.slice(half)}`;
  }

  async function getOrComputeTotpForItem(item, nowMs = Date.now()) {
    if (!item || !item.totp_secret) return null;
    const { step, remainingSeconds, period } = OmniVaultCore.computeTotpStep(item.totp_period, nowMs);
    const cached = liveTotpMap.get(item.id);
    if (cached && cached.step === step && cached.secret === item.totp_secret && cached.code) {
      cached.remainingSeconds = remainingSeconds;
      return cached;
    }
    try {
      const live = await OmniVaultCore.computeTotpCode(
        item.totp_secret,
        item.totp_digits,
        period,
        item.totp_algorithm,
        nowMs
      );
      if (live && live.code) {
        const entry = {
          code: live.code,
          remainingSeconds: live.remainingSeconds,
          period: live.period,
          step: live.step,
          secret: item.totp_secret
        };
        liveTotpMap.set(item.id, entry);
        return entry;
      }
    } catch (_) {
      // Ignore malformed secret
    }
    return null;
  }

  // Smart TOTP Scheduler: runs WebCrypto HMAC ONLY for currently mounted/visible cards
  // and ONLY when their TOTP step rolls over (29/30 seconds update ONLY countdown integer!)
  async function updateVisibleTotpPills(forceRecompute = false) {
    if (!currentState || currentState.locked || viewVault.hidden) return;
    const pills = document.querySelectorAll(".totp-pill[data-item-id]");
    if (pills.length === 0) return;

    const nowMs = Date.now();
    const pendingJobs = [];

    for (let i = 0; i < pills.length; i++) {
      const pill = pills[i];
      const id = pill.dataset.itemId;
      const item = id ? itemsById.get(id) : null;
      if (!item || !item.totp_secret) continue;

      const { step, remainingSeconds, period } = OmniVaultCore.computeTotpStep(item.totp_period, nowMs);
      const cached = liveTotpMap.get(id);
      const remEl = pill.querySelector(".totp-rem");

      if (!forceRecompute && cached && cached.step === step && cached.secret === item.totp_secret && cached.code) {
        cached.remainingSeconds = remainingSeconds;
        if (pill.dataset.totpCode !== cached.code) {
          pill.dataset.totpCode = cached.code;
          const codeEl = pill.querySelector(".totp-code");
          if (codeEl) codeEl.textContent = formatTotpDisplay(cached.code);
        }
        if (remEl) remEl.textContent = `${remainingSeconds}s`;
        continue;
      }

      if (remEl) remEl.textContent = `${remainingSeconds}s`;
      pendingJobs.push(
        getOrComputeTotpForItem(item, nowMs).then((live) => {
          if (!live || !live.code || !pill.isConnected) return;
          pill.dataset.totpCode = live.code;
          const codeEl = pill.querySelector(".totp-code");
          if (codeEl) codeEl.textContent = formatTotpDisplay(live.code);
          if (remEl) remEl.textContent = `${live.remainingSeconds}s`;
        })
      );
    }

    if (pendingJobs.length > 0) {
      await Promise.all(pendingJobs);
    }
  }

  async function copyText(text, label) {
    if (!text) {
      showToast(`Chưa lưu ${label}`, true);
      return false;
    }
    try {
      await navigator.clipboard.writeText(text);
      if (currentState && currentState.hasPinLock) {
        await OmniVaultCore.touchAutoLockAlarm();
      }
      showToast(`Đã sao chép ${label}`);
      return true;
    } catch (_) {
      showToast(`Không thể sao chép ${label}`, true);
      return false;
    }
  }

  async function safeClipboardWrite(text) {
    if (!text) return false;
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch (_) {
      return false;
    }
  }

  async function fillIntoActiveTab(item) {
    if (!currentState || currentState.locked) {
      showToast("Kho OmniVault đang khóa. Vui lòng nhập PIN trước.", true);
      return;
    }
    let liveTab = null;
    try {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      liveTab = tabs && tabs[0] ? tabs[0] : null;
    } catch (_) {
      liveTab = null;
    }
    if (!liveTab || !liveTab.id) {
      showToast("Không tìm thấy trang web đang mở", true);
      return;
    }
    const liveUrl = liveTab.url || "";
    if (!OmniVaultCore.isSafeAutofillUrl(liveUrl)) {
      activeTab = liveTab;
      activeHost = "";
      renderVaultList();
      showToast("Trang hiện tại không phải HTTPS an toàn để tự động điền", true);
      return;
    }
    const liveHost = OmniVaultCore.extractCleanDomain(liveUrl);
    if (!liveHost || OmniVaultCore.itemMatchesDomain(item, liveHost) < 2) {
      activeTab = liveTab;
      activeHost = liveHost;
      renderVaultList();
      showToast("Tên miền trang hiện tại không khớp với tài khoản này!", true);
      return;
    }
    activeTab = liveTab;
    activeHost = liveHost;

    if (currentState.hasPinLock) {
      await OmniVaultCore.touchAutoLockAlarm();
    }

    const handleFilledResponse = async (mode) => {
      try {
        await OmniVaultCore.recordItemAutofilled(item.id);
      } catch (_) {}
      if (mode === "username_only" && item.password) {
        const copied = await safeClipboardWrite(item.password);
        showToast(
          copied
            ? "Đã điền Tài khoản & chép sẵn Mật khẩu cho bước 2!"
            : "Đã điền Tài khoản (không sao chép được mật khẩu sang clipboard)"
        );
        return;
      }
      // If account also has 2FA, auto-copy 2FA code to clipboard (compute on-demand if needed)!
      const live = item.totp_secret ? await getOrComputeTotpForItem(item) : null;
      if (live && live.code) {
        const copied = await safeClipboardWrite(live.code);
        showToast(
          copied
            ? "Đã điền mật khẩu & sao chép sẵn mã 2FA"
            : `Đã tự động điền '${item.service_name}'`
        );
      } else {
        showToast(`Đã tự động điền '${item.service_name}'`);
      }
    };

    try {
      chrome.tabs.sendMessage(
        activeTab.id,
        {
          type: "FILL_LOGIN_NOW",
          username: item.username,
          password: item.password
        },
        async (resp) => {
          if (chrome.runtime.lastError || !resp || !resp.filled) {
            // Fallback via chrome.scripting.executeScript (top frame only: allFrames: false)
            try {
              await chrome.scripting.executeScript({
                target: { tabId: activeTab.id, allFrames: false },
                files: ["content.js"]
              });
              chrome.tabs.sendMessage(
                activeTab.id,
                {
                  type: "FILL_LOGIN_NOW",
                  username: item.username,
                  password: item.password
                },
                async (r2) => {
                  void chrome.runtime.lastError;
                  if (r2 && r2.filled) {
                    await handleFilledResponse(r2.mode);
                  } else {
                    const copied = await safeClipboardWrite(item.password || "");
                    showToast(
                      copied
                        ? "Không thấy ô đăng nhập trên trang — đã sao chép mật khẩu!"
                        : "Không thấy ô đăng nhập trên trang.",
                      !copied
                    );
                  }
                }
              );
            } catch (_) {
              await copyText(item.password, "mật khẩu");
            }
          } else {
            await handleFilledResponse(resp.mode);
          }
        }
      );
    } catch (_) {
      await copyText(item.password, "mật khẩu");
    }
  }

  const COPY_ICON_SVG =
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' +
    '<rect x="9" y="9" width="11" height="11" rx="2.2"></rect>' +
    '<path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>' +
    "</svg>";

  const CHECK_ICON_SVG =
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' +
    '<polyline points="20 6 9 17 4 12"></polyline>' +
    "</svg>";

  // Parse SVG icons ONCE into <template> elements and clone nodes instead of re-parsing HTML 2*N times
  const copyIconTemplate = document.createElement("template");
  copyIconTemplate.innerHTML = COPY_ICON_SVG;
  const checkIconTemplate = document.createElement("template");
  checkIconTemplate.innerHTML = CHECK_ICON_SVG;

  function cloneCopyIconNode() {
    return copyIconTemplate.content.firstElementChild.cloneNode(true);
  }

  function cloneCheckIconNode() {
    return checkIconTemplate.content.firstElementChild.cloneNode(true);
  }

  function buildCredentialRow({ value, emptyText, isSecret, copyTitle, copyLabel }) {
    const row = document.createElement("div");
    row.className = "cred-row";

    const copyBtn = document.createElement("button");
    copyBtn.type = "button";
    copyBtn.className = "copy-icon-btn";
    copyBtn.title = copyTitle;
    copyBtn.setAttribute("aria-label", copyTitle);
    copyBtn.appendChild(cloneCopyIconNode());
    let feedbackTimer = null;
    copyBtn.onclick = async () => {
      const ok = await copyText(value, copyLabel);
      if (ok) {
        copyBtn.replaceChildren(cloneCheckIconNode());
        copyBtn.classList.add("copied");
        if (feedbackTimer) clearTimeout(feedbackTimer);
        feedbackTimer = setTimeout(() => {
          copyBtn.replaceChildren(cloneCopyIconNode());
          copyBtn.classList.remove("copied");
        }, 900);
      }
    };

    const valEl = document.createElement("span");
    const hasVal = Boolean(value);
    valEl.className = "cred-value" + (isSecret ? " cred-secret" : "") + (hasVal ? "" : " cred-empty");
    if (hasVal) {
      valEl.textContent = isSecret ? "••••••••••••" : value;
      if (!isSecret) {
        valEl.title = value;
      }
    } else {
      valEl.textContent = emptyText;
    }

    row.appendChild(copyBtn);
    row.appendChild(valEl);
    return row;
  }

  function buildVaultCard(item, isMatched = false) {
    const card = document.createElement("div");
    card.className = isMatched ? "vault-item matched" : "vault-item";

    const head = document.createElement("div");
    head.className = "item-head";

    const left = document.createElement("div");
    left.style.minWidth = "0";
    left.style.flex = "1";

    const domList = Array.isArray(item.web_domains) ? item.web_domains.filter(Boolean) : [];
    const serviceTitle = String(item.service_name || "").trim() || domList[0] || "Tài khoản";

    const title = document.createElement("div");
    title.className = "item-title";
    title.textContent = serviceTitle;
    left.appendChild(title);

    const hasExtraDomains =
      domList.length > 1 ||
      (domList.length === 1 && domList[0].trim().toLowerCase() !== serviceTitle.toLowerCase());
    if (hasExtraDomains) {
      const domEl = document.createElement("div");
      domEl.className = "item-domain";
      domEl.textContent = domList.join(", ");
      left.appendChild(domEl);
    }

    const pkList = Array.isArray(item.passkeys) ? item.passkeys : [];
    if (pkList.length > 0) {
      const pkBadge = document.createElement("span");
      pkBadge.className = "passkey-badge";
      pkBadge.textContent = pkList.length === 1 ? "🔑 Passkey" : `🔑 ${pkList.length} Passkey`;
      pkBadge.title = pkList
        .map((pk) => `${pk.rp_id}${pk.user_name ? " (" + pk.user_name + ")" : ""}`)
        .join(", ");
      left.appendChild(pkBadge);
    }

    const headActions = document.createElement("div");
    headActions.className = "item-head-actions";

    const canFillActiveTab = Boolean(
      activeHost && OmniVaultCore.itemMatchesDomain(item, activeHost) >= 2
    );
    if (canFillActiveTab) {
      const fillBtn = document.createElement("button");
      fillBtn.type = "button";
      fillBtn.className = "chip-btn fill chip-btn-compact";
      fillBtn.textContent = "Điền";
      fillBtn.title = "Điền tự động vào trang đang mở";
      fillBtn.onclick = () => fillIntoActiveTab(item);
      headActions.appendChild(fillBtn);
    }

    const editBtn = document.createElement("button");
    editBtn.type = "button";
    editBtn.className = "icon-btn";
    editBtn.title = "Sửa tài khoản";
    editBtn.textContent = "✎";
    editBtn.onclick = () => openEditor(item);
    headActions.appendChild(editBtn);

    head.appendChild(left);
    head.appendChild(headActions);
    card.appendChild(head);

    const credRows = document.createElement("div");
    credRows.className = "cred-rows";
    credRows.appendChild(
      buildCredentialRow({
        value: item.username || "",
        emptyText: "Chưa nhập tên đăng nhập",
        isSecret: false,
        copyTitle: "Sao chép tài khoản",
        copyLabel: "tài khoản"
      })
    );
    credRows.appendChild(
      buildCredentialRow({
        value: item.password || "",
        emptyText: "Chưa lưu mật khẩu",
        isSecret: true,
        copyTitle: "Sao chép mật khẩu",
        copyLabel: "mật khẩu"
      })
    );
    card.appendChild(credRows);

    if (item.totp_secret) {
      const nowMs = Date.now();
      const { step, remainingSeconds } = OmniVaultCore.computeTotpStep(item.totp_period, nowMs);
      const cached = liveTotpMap.get(item.id);
      const hasValidCode = Boolean(
        cached && cached.step === step && cached.secret === item.totp_secret && cached.code
      );

      const pill = document.createElement("div");
      pill.className = "totp-pill";
      pill.dataset.itemId = item.id;
      pill.dataset.totpCode = hasValidCode ? cached.code : "";
      pill.title = "Bấm để sao chép mã 2FA";

      const codeSpan = document.createElement("span");
      codeSpan.className = "totp-code";
      codeSpan.textContent = hasValidCode ? formatTotpDisplay(cached.code) : "2FA: ••• •••";

      const remSpan = document.createElement("span");
      remSpan.className = "totp-rem";
      remSpan.textContent = `${remainingSeconds}s`;

      pill.appendChild(codeSpan);
      pill.appendChild(remSpan);
      pill.onclick = async () => {
        let curCode = pill.dataset.totpCode;
        if (!curCode) {
          const live = await getOrComputeTotpForItem(item);
          curCode = live && live.code ? live.code : "";
          if (curCode) {
            pill.dataset.totpCode = curCode;
            codeSpan.textContent = formatTotpDisplay(curCode);
          }
        }
        copyText(curCode, "mã 2FA");
      };
      card.appendChild(pill);
    }

    return card;
  }

  let pinSettingsOpen = false;
  let latestUpdateStatus = null;
  let cachedNativeStatus = null;
  let cachedNativeStatusAt = 0;
  let updateBannerManualOpen = false;
  let inlineUpdateRunning = false;

  async function getCachedNativeUpdaterStatus(force = false) {
    if (!force && cachedNativeStatus?.available && Date.now() - cachedNativeStatusAt < 5000) {
      return cachedNativeStatus;
    }
    const resp = await sendRuntimeMsg({ type: "GET_NATIVE_UPDATER_STATUS" });
    if (resp && resp.ok && resp.available) {
      cachedNativeStatus = resp;
      cachedNativeStatusAt = Date.now();
    } else if (resp && resp.ok && !resp.available) {
      cachedNativeStatus = null;
      cachedNativeStatusAt = 0;
    }
    return resp;
  }

  const verEl = document.getElementById("extVersionLabel");
  const extUpdateBanner = document.getElementById("extUpdateBanner");
  const extUpdateTitle = document.getElementById("extUpdateTitle");
  const extUpdateDesc = document.getElementById("extUpdateDesc");
  const extUpdateProgressWrap = document.getElementById("extUpdateProgressWrap");
  const extUpdateProgressFill = document.getElementById("extUpdateProgressFill");
  const extUpdateProgressLabel = document.getElementById("extUpdateProgressLabel");
  const extUpdateAutoRow = document.getElementById("extUpdateAutoRow");
  const chkPopupAutoUpdateBg = document.getElementById("chkPopupAutoUpdateBg");
  const btnUpdatePrimary = document.getElementById("btnUpdatePrimary");
  const btnReloadUnpacked = document.getElementById("btnReloadUnpacked");
  const btnManualZipDownload = document.getElementById("btnManualZipDownload");
  const btnDismissUpdateBanner = document.getElementById("btnDismissUpdateBanner");
  const pendingUpdatesBox = document.getElementById("pendingUpdatesBox");

  function setInlineUpdateProgress(percent, label, isError = false) {
    if (extUpdateBanner) {
      extUpdateBanner.hidden = false;
      extUpdateBanner.classList.toggle("has-error", Boolean(isError));
    }
    if (extUpdateProgressWrap) {
      extUpdateProgressWrap.hidden = !label;
    }
    if (extUpdateProgressFill && typeof percent === "number") {
      extUpdateProgressFill.style.width = `${Math.max(0, Math.min(100, Math.round(percent)))}%`;
    }
    if (extUpdateProgressLabel) {
      extUpdateProgressLabel.textContent = label || "";
    }
  }

  function clearInlineUpdateProgress() {
    if (extUpdateBanner) extUpdateBanner.classList.remove("has-error");
    if (extUpdateProgressWrap) extUpdateProgressWrap.hidden = true;
    if (extUpdateProgressFill) extUpdateProgressFill.style.width = "0%";
    if (extUpdateProgressLabel) extUpdateProgressLabel.textContent = "";
  }

  function applyFsProgressInline(ev) {
    if (!ev) return;
    if (ev.stage === "metadata" || ev.stage === "downloading") {
      setInlineUpdateProgress(22, ev.message || "1/4 Đang tải gói cập nhật từ GitHub...");
    } else if (ev.stage === "verifying") {
      setInlineUpdateProgress(48, ev.message || "2/4 Đang xác thực SHA-256 & RSA-2048...");
    } else if (ev.stage === "extracting") {
      setInlineUpdateProgress(62, ev.message || "3/4 Đang giải nén an toàn...");
    } else if (ev.stage === "writing") {
      const pct =
        typeof ev.current === "number" && typeof ev.total === "number" && ev.total > 0
          ? 62 + Math.round((ev.current / ev.total) * 32)
          : 78;
      const text =
        typeof ev.current === "number" && typeof ev.total === "number" && ev.total > 0
          ? `3/4 Đang ghi tệp (${ev.current}/${ev.total}): ${ev.file || ""}`
          : ev.message || "3/4 Đang ghi tệp an toàn...";
      setInlineUpdateProgress(pct, text);
    } else if (ev.stage === "reloading") {
      setInlineUpdateProgress(100, ev.message || "4/4 Hoàn tất — đang nạp lại tiện ích...");
    }
  }

  if (chkPopupAutoUpdateBg) {
    chkPopupAutoUpdateBg.addEventListener("change", async () => {
      const enabled = Boolean(chkPopupAutoUpdateBg.checked);
      const res = await sendRuntimeMsg({ type: "SET_AUTO_UPDATE_BG", enabled });
      if (res && res.ok) {
        if (cachedNativeStatus) cachedNativeStatus.autoUpdateBgEnabled = res.autoUpdateBgEnabled;
        showToast(
          res.autoUpdateBgEnabled
            ? "✓ Đã bật tự động cập nhật ngầm 100%"
            : "Đã tắt tự động cập nhật ngầm"
        );
      }
    });
  }

  function isStoreManagedUi() {
    const manifest = chrome?.runtime?.getManifest ? chrome.runtime.getManifest() : {};
    const updateUrl = String(manifest.update_url || "").toLowerCase();
    if (
      updateUrl.includes("clients2.google.com") ||
      updateUrl.includes("edge.microsoft.com")
    ) {
      return true;
    }
    const perms = Array.isArray(manifest.permissions) ? manifest.permissions : [];
    return (!manifest.key && !perms.includes("nativeMessaging")) || typeof globalThis.OmniVaultUpdater === "undefined";
  }

  const storeManagedUi = isStoreManagedUi();

  if (verEl && chrome?.runtime?.getManifest) {
    const verStr = chrome.runtime.getManifest().version;
    verEl.textContent = storeManagedUi ? `v${verStr}` : `v${verStr} ↻`;
    verEl.title = storeManagedUi
      ? "Kiểm tra cập nhật tiện ích từ cửa hàng trình duyệt"
      : "1 click: Kiểm tra bản mới từ GitHub & tự động cập nhật ngay";
  }

  // Notify service worker while popup is open so deferred silent auto-update runs right after popup closes
  try {
    if (typeof chrome?.runtime?.connect === "function") {
      chrome.runtime.connect({ name: "omnivault_ui_open" });
    }
  } catch (_) {}

  function sendRuntimeMsg(payload) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(payload, (resp) => {
          void chrome.runtime.lastError;
          resolve(resp || null);
        });
      } catch (_) {
        resolve(null);
      }
    });
  }

  async function renderUpdateBanner(status, showUpToDateCard = false, preloadedNativeStatus = null) {
    if (!extUpdateBanner) return;
    if (status) {
      latestUpdateStatus = status;
    }
    if (preloadedNativeStatus && preloadedNativeStatus.ok) {
      cachedNativeStatus = preloadedNativeStatus;
      cachedNativeStatusAt = Date.now();
    }
    if (!status || !status.hasUpdate) {
      if (verEl) verEl.classList.remove("has-update");
      if (!showUpToDateCard) {
        updateBannerManualOpen = false;
        clearInlineUpdateProgress();
        if (extUpdateAutoRow) extUpdateAutoRow.hidden = true;
        extUpdateBanner.hidden = true;
        extUpdateBanner.classList.remove("up-to-date");
        return;
      }
      updateBannerManualOpen = true;
      clearInlineUpdateProgress();
      extUpdateBanner.classList.add("up-to-date");
      const curVer = status?.currentVersion || (chrome?.runtime?.getManifest ? chrome.runtime.getManifest().version : "");
      if (extUpdateTitle) {
        extUpdateTitle.textContent = `✓ Đang dùng bản mới nhất (v${curVer})`;
      }
      let folderHint = storeManagedUi || status?.isStoreManaged
        ? "Tiện ích được tự động cập nhật an toàn qua Chrome Web Store / Microsoft Edge Add-ons."
        : "Cập nhật 1 chạm trực tiếp ngay trên giao diện tiện ích (xác thực SHA-256 & RSA-2048).";
      let hasNative = false;
      if (!status?.isCrxManaged && !storeManagedUi) {
        const nativeStatus = preloadedNativeStatus || (await getCachedNativeUpdaterStatus(false));
        if (nativeStatus?.available) {
          hasNative = true;
          const folderDisplay = nativeStatus.dirPath || nativeStatus.dirName || "OmniVault";
          folderHint = `🤖 Đã kích hoạt tự động 100% (${folderDisplay}) — cập nhật thẳng ngay tại đây, không mở cửa sổ phụ.`;
          if (extUpdateAutoRow) extUpdateAutoRow.hidden = false;
          if (chkPopupAutoUpdateBg) chkPopupAutoUpdateBg.checked = Boolean(nativeStatus.autoUpdateBgEnabled);
        } else {
          if (extUpdateAutoRow) extUpdateAutoRow.hidden = true;
          if (globalThis.OmniVaultUpdater?.isFileSystemAccessSupported?.()) {
            const savedDir = await globalThis.OmniVaultUpdater.getStoredDirectoryHandle().catch(() => null);
            folderHint = savedDir
              ? `Đã liên kết "${savedDir.name}". Chạy Bat-TuDongCapNhat-100.bat 1 lần để cập nhật thẳng tại đây không cần mở cửa sổ chọn quyền.`
              : "Chạy Bat-TuDongCapNhat-100.bat (1 lần duy nhất, không cần Admin) để cập nhật thẳng ngay trên giao diện chính.";
          }
        }
      } else if (extUpdateAutoRow) {
        extUpdateAutoRow.hidden = true;
      }
      if (extUpdateDesc) extUpdateDesc.textContent = folderHint;
      if (btnUpdatePrimary) {
        btnUpdatePrimary.textContent = hasNative ? "🔄 Kiểm tra lại" : "📂 Chọn thư mục";
        btnUpdatePrimary.hidden = Boolean(status?.isCrxManaged || storeManagedUi);
      }
      if (btnReloadUnpacked) btnReloadUnpacked.hidden = true;
      if (btnManualZipDownload) btnManualZipDownload.hidden = true;
      if (btnDismissUpdateBanner) btnDismissUpdateBanner.hidden = false;
      extUpdateBanner.hidden = false;
      return;
    }

    updateBannerManualOpen = false;
    if (!inlineUpdateRunning) clearInlineUpdateProgress();
    if (extUpdateAutoRow) extUpdateAutoRow.hidden = true;
    extUpdateBanner.classList.remove("up-to-date");
    const targetVer = status.pendingCrxReloadVersion || status.latestVersion || "";
    if (verEl) verEl.classList.add("has-update");
    if (extUpdateTitle) {
      extUpdateTitle.textContent = storeManagedUi || status?.isStoreManaged
        ? (targetVer ? `🚀 Đã có bản cập nhật mới v${targetVer}` : "🚀 Đã có bản cập nhật mới")
        : (targetVer ? `🚀 Đã có bản mới v${targetVer} trên GitHub` : "🚀 Đã có bản mới trên GitHub");
    }
    let canUpdateInlineNow = Boolean(status.isCrxManaged || storeManagedUi);
    let hasSavedFsDir = false;
    if (!status.isCrxManaged && !storeManagedUi) {
      const nativeSt = preloadedNativeStatus || (await getCachedNativeUpdaterStatus(false));
      if (nativeSt?.available) {
        canUpdateInlineNow = true;
      } else if (globalThis.OmniVaultUpdater?.isFileSystemAccessSupported?.()) {
        const savedDir = await globalThis.OmniVaultUpdater.getStoredDirectoryHandle().catch(() => null);
        hasSavedFsDir = Boolean(savedDir);
        if (savedDir) {
          const perm = await globalThis.OmniVaultUpdater.queryDirectoryPermission(savedDir).catch(() => "prompt");
          if (perm === "granted") canUpdateInlineNow = true;
        }
      }
    }
    if (extUpdateDesc) {
      if (status.isCrxManaged || storeManagedUi) {
        extUpdateDesc.textContent =
          status.changelog || "Bấm nút bên dưới để trình duyệt tải và áp dụng tự động (giữ nguyên 100% mật khẩu).";
      } else if (canUpdateInlineNow) {
        extUpdateDesc.textContent =
          status.changelog || "Bấm '⚡ Cập nhật ngay' để tự tải, xác thực RSA-2048 & cập nhật thẳng tại đây (không mở cửa sổ phụ).";
      } else {
        extUpdateDesc.textContent =
          "Chưa bật Tự động 100%: chạy Bat-TuDongCapNhat-100.bat (1 lần) để cập nhật thẳng tại đây, hoặc bấm nút dưới để cấp quyền thư mục.";
      }
    }
    if (btnUpdatePrimary) {
      btnUpdatePrimary.textContent = status.isCrxManaged || storeManagedUi
        ? "⚡ Cập nhật tự động ngay"
        : canUpdateInlineNow
          ? "⚡ Cập nhật ngay"
          : hasSavedFsDir
            ? "🔓 Cấp quyền & Cập nhật"
            : "📂 Chọn thư mục & Cập nhật";
      btnUpdatePrimary.hidden = false;
    }
    if (btnReloadUnpacked) {
      btnReloadUnpacked.hidden = Boolean(status.isCrxManaged || storeManagedUi);
      btnReloadUnpacked.textContent = "🔄 Nạp lại";
    }
    if (btnManualZipDownload) {
      btnManualZipDownload.hidden = Boolean(status.isCrxManaged || storeManagedUi);
    }
    if (btnDismissUpdateBanner) {
      btnDismissUpdateBanner.hidden = true;
    }
    extUpdateBanner.hidden = false;
  }

  async function refreshGitHubUpdateStatus(force = false, showUpToDateCard = false) {
    const resp = await sendRuntimeMsg({ type: "GET_EXTENSION_UPDATE_STATUS", force });
    if (resp) {
      await renderUpdateBanner(resp, showUpToDateCard);
    }
    return resp;
  }

  if (verEl) {
    verEl.onclick = async () => {
      if (inlineUpdateRunning) return;
      verEl.disabled = true;
      const curVer = chrome?.runtime?.getManifest ? String(chrome.runtime.getManifest().version || "") : "";
      verEl.textContent = curVer ? `v${curVer} ...` : "...";
      try {
        // True 1-click inline inside popup: check update via Store channel (or GitHub on unpacked builds)
        setInlineUpdateProgress(18, storeManagedUi ? "Đang kiểm tra bản cập nhật..." : "Đang kiểm tra bản mới từ GitHub...");
        const res = await sendRuntimeMsg({ type: "ONE_CLICK_CHECK_AND_UPDATE", allowSilentReload: true });
        if (!res || !res.ok) {
          if (res?.updateStatus) {
            await renderUpdateBanner(res.updateStatus, true, res.nativeStatus || null);
          }
          setInlineUpdateProgress(100, res?.error || "Không kiểm tra được bản cập nhật.", true);
          showToast(res?.error || "Không kiểm tra được bản cập nhật mới", true);
          return;
        }
        if (res.updated) {
          setInlineUpdateProgress(100, `✓ Đã cập nhật v${res.version} — đang tự nạp lại...`);
          showToast(`🚀 Đã tự tải & cập nhật lên v${res.version} — đang tự nạp lại!`);
          return;
        }
        if (res.updateStatus) {
          await renderUpdateBanner(res.updateStatus, true, res.nativeStatus || null);
        }
        if (res.alreadyUpToDate || !res.updateStatus?.hasUpdate) {
          clearInlineUpdateProgress();
          showToast(
            res.mode === "native"
              ? `✓ Đang dùng bản mới nhất (v${res.version || curVer}) • Tự động 100% sẵn sàng`
              : `✓ Đang dùng bản mới nhất (v${res.version || curVer})`
          );
          return;
        }
        // New update found on browser_fs tier -> execute inline right inside popup if folder already granted!
        const updater = globalThis.OmniVaultUpdater;
        const manifestKey = chrome?.runtime?.getManifest ? String(chrome.runtime.getManifest().key || "").trim() : "";
        if (updater?.isFileSystemAccessSupported?.() && manifestKey) {
          const savedDir = await updater.getStoredDirectoryHandle().catch(() => null);
          const perm = savedDir ? await updater.queryDirectoryPermission(savedDir).catch(() => "prompt") : "prompt";
          if (savedDir && perm === "granted") {
            inlineUpdateRunning = true;
            try {
              const fsRes = await updater.performSelfUpdate({
                dirHandle: savedDir,
                updateInfo: res.updateStatus,
                pinnedSpkiB64: manifestKey,
                onProgress: applyFsProgressInline
              });
              setInlineUpdateProgress(100, `✓ Hoàn tất v${fsRes.version} — đang nạp lại tiện ích...`);
              showToast(`✓ Đã tự tải & cập nhật lên v${fsRes.version} — đang nạp lại!`);
              await sendRuntimeMsg({ type: "APPLY_EXTENSION_UPDATE_NOW" });
              return;
            } finally {
              inlineUpdateRunning = false;
            }
          }
        }
        clearInlineUpdateProgress();
        showToast(`Đã có bản mới v${res.updateStatus.latestVersion} — bấm '⚡ Cập nhật ngay'!`);
      } catch (err) {
        const msg = String(err?.message || err || "Lỗi cập nhật tiện ích");
        setInlineUpdateProgress(100, msg, true);
        showToast(msg, true);
      } finally {
        verEl.disabled = false;
        verEl.textContent = curVer ? (storeManagedUi ? `v${curVer}` : `v${curVer} ↻`) : (storeManagedUi ? "" : "↻");
      }
    };
  }

  if (btnDismissUpdateBanner) {
    btnDismissUpdateBanner.onclick = () => {
      updateBannerManualOpen = false;
      if (extUpdateBanner) {
        extUpdateBanner.hidden = true;
        extUpdateBanner.classList.remove("up-to-date");
      }
    };
  }

  if (btnManualZipDownload) {
    btnManualZipDownload.onclick = () => {
      const candidateUrl =
        latestUpdateStatus?.unpackedZipUrl ||
        latestUpdateStatus?.unpackedLatestUrl ||
        latestUpdateStatus?.releaseHtmlUrl;
      const targetUrl = OmniVaultCore.isAllowedGitHubUpdateUrl(candidateUrl)
        ? candidateUrl
        : "https://github.com/Minhtuan0506/omnivault-extension/releases/latest";
      chrome.tabs.create({ url: targetUrl, active: true });
      showToast("Đã mở tải tệp .zip thủ công từ GitHub!");
    };
  }

  if (btnUpdatePrimary) {
    btnUpdatePrimary.onclick = async () => {
      if (inlineUpdateRunning) return;

      // When user manually opened up-to-date panel:
      // - If Native Host is active -> re-check & update inline directly inside popup (no extra window!)
      // - Otherwise open folder-linker window once so Chrome OS directory picker won't auto-close popup
      if (updateBannerManualOpen && !latestUpdateStatus?.hasUpdate) {
        const nativeSt = await getCachedNativeUpdaterStatus(true);
        if (nativeSt?.available) {
          if (verEl) verEl.click();
          return;
        }
        await sendRuntimeMsg({ type: "OPEN_EXTENSION_UPDATER", autoStart: false });
        return;
      }

      if (!latestUpdateStatus) {
        await refreshGitHubUpdateStatus(true);
      }
      if (latestUpdateStatus?.isCrxManaged) {
        btnUpdatePrimary.disabled = true;
        btnUpdatePrimary.textContent = "Đang cập nhật...";
        setInlineUpdateProgress(45, "Đang yêu cầu trình duyệt tải bản cập nhật CRX...");
        try {
          const res = await sendRuntimeMsg({ type: "APPLY_EXTENSION_UPDATE_NOW" });
          if (res?.reloading) {
            setInlineUpdateProgress(100, "Hoàn tất — đang áp dụng bản mới...");
            showToast("Đang áp dụng bản cập nhật mới...");
          } else {
            clearInlineUpdateProgress();
            showToast(
              res?.status === "throttled"
                ? "Trình duyệt đang chờ chu kỳ kiểm tra, thử lại sau ít phút hoặc mở trang Release."
                : "Trình duyệt sẽ tự tải bản mới trong nền — kiểm tra lại sau giây lát."
            );
          }
        } finally {
          btnUpdatePrimary.disabled = false;
          btnUpdatePrimary.textContent = "⚡ Cập nhật tự động ngay";
        }
        return;
      }

      // Unpacked 1-click in-popup self-update (NO separate popup window when Native Host or FS grant is ready!):
      // 1) Tier 2 (Native Messaging 100% Auto): ALWAYS fresh-probe on click so newly activated Bat-TuDongCapNhat-100.bat works immediately!
      const prevBtnLabel = btnUpdatePrimary.textContent;
      setInlineUpdateProgress(12, "Đang kiểm tra kênh cập nhật tự động...");
      const nativeStatus = await getCachedNativeUpdaterStatus(true);
      if (nativeStatus?.available) {
        inlineUpdateRunning = true;
        btnUpdatePrimary.disabled = true;
        if (btnReloadUnpacked) btnReloadUnpacked.disabled = true;
        if (btnManualZipDownload) btnManualZipDownload.disabled = true;
        btnUpdatePrimary.textContent = "⏳ Đang cập nhật...";
        setInlineUpdateProgress(35, "Đang tải từ GitHub, xác thực SHA-256 & RSA-2048...");
        const progressMidTimer = setTimeout(() => {
          if (inlineUpdateRunning) {
            setInlineUpdateProgress(72, "Đang giải nén & ghi tệp an toàn vào thư mục tiện ích...");
          }
        }, 1200);
        try {
          const res = await sendRuntimeMsg({ type: "RUN_NATIVE_SELF_UPDATE", allowSilentReload: true });
          clearTimeout(progressMidTimer);
          if (res?.ok) {
            setInlineUpdateProgress(100, `✓ Hoàn tất v${res.version} — đang tự nạp lại tiện ích...`);
            showToast(`✓ Đã cập nhật lên v${res.version} — đang tự nạp lại!`);
            return;
          }
          const errMsg = res?.error || "Lỗi cập nhật qua Native Host";
          setInlineUpdateProgress(100, errMsg, true);
          showToast(errMsg, true);
          return;
        } finally {
          clearTimeout(progressMidTimer);
          inlineUpdateRunning = false;
          btnUpdatePrimary.disabled = false;
          if (btnReloadUnpacked) btnReloadUnpacked.disabled = false;
          if (btnManualZipDownload) btnManualZipDownload.disabled = false;
          btnUpdatePrimary.textContent = prevBtnLabel || "⚡ Cập nhật ngay";
        }
      }
      clearInlineUpdateProgress();

      // 2) Tier 3 (File System Access API fallback):
      //    If folder handle is already stored AND readwrite permission is already granted in this session,
      //    execute download -> SHA-256 + RSA-2048 verify -> extract -> write -> reload RIGHT INSIDE POPUP!
      //    Only open the dedicated updater.html window when Chrome requires an OS folder/permission dialog
      //    (which forcibly dismisses toolbar popups on focus loss).
      const updater = globalThis.OmniVaultUpdater;
      const manifestKey = chrome?.runtime?.getManifest ? String(chrome.runtime.getManifest().key || "").trim() : "";
      if (updater?.isFileSystemAccessSupported?.() && manifestKey) {
        const savedDir = await updater.getStoredDirectoryHandle().catch(() => null);
        const perm = savedDir ? await updater.queryDirectoryPermission(savedDir).catch(() => "prompt") : "prompt";
        if (savedDir && perm === "granted") {
          inlineUpdateRunning = true;
          btnUpdatePrimary.disabled = true;
          if (btnReloadUnpacked) btnReloadUnpacked.disabled = true;
          if (btnManualZipDownload) btnManualZipDownload.disabled = true;
          btnUpdatePrimary.textContent = "⏳ Đang cập nhật...";
          setInlineUpdateProgress(15, "1/4 Đang tải gói cập nhật từ GitHub...");
          try {
            const res = await updater.performSelfUpdate({
              dirHandle: savedDir,
              updateInfo: latestUpdateStatus,
              pinnedSpkiB64: manifestKey,
              onProgress: applyFsProgressInline
            });
            setInlineUpdateProgress(100, `✓ Hoàn tất v${res.version} — đang nạp lại tiện ích...`);
            showToast(`✓ Đã cập nhật lên v${res.version} — đang nạp lại tiện ích!`);
            await sendRuntimeMsg({ type: "APPLY_EXTENSION_UPDATE_NOW" });
            return;
          } catch (err) {
            const errMsg = String(err?.message || err || "Lỗi ghi tệp cập nhật");
            setInlineUpdateProgress(100, errMsg, true);
            showToast(errMsg, true);
            return;
          } finally {
            inlineUpdateRunning = false;
            btnUpdatePrimary.disabled = false;
            if (btnReloadUnpacked) btnReloadUnpacked.disabled = false;
            if (btnManualZipDownload) btnManualZipDownload.disabled = false;
            btnUpdatePrimary.textContent = "⚡ Cập nhật ngay";
          }
        }
      }

      // Chromium forcibly closes toolbar popups when OS folder/permission dialogs open -> fallback window only when needed
      await sendRuntimeMsg({ type: "OPEN_EXTENSION_UPDATER", autoStart: true });
    };
  }

  if (btnReloadUnpacked) {
    btnReloadUnpacked.onclick = async () => {
      btnReloadUnpacked.disabled = true;
      await sendRuntimeMsg({ type: "APPLY_EXTENSION_UPDATE_NOW" });
      showToast("Đang nạp lại tiện ích...");
    };
  }

  async function refreshPendingUpdatesBox() {
    if (!pendingUpdatesBox) return;
    if (!currentState || currentState.locked || !currentState.pairing) {
      pendingUpdatesBox.hidden = true;
      pendingUpdatesBox.textContent = "";
      return;
    }
    const resp = await sendRuntimeMsg({ type: "GET_PENDING_UPDATES" });
    const list = resp && resp.ok && Array.isArray(resp.proposals) ? resp.proposals : [];
    pendingUpdatesBox.textContent = "";
    if (list.length === 0) {
      pendingUpdatesBox.hidden = true;
      return;
    }
    for (const p of list) {
      const card = document.createElement("div");
      card.className = "pending-update-card";

      const title = document.createElement("div");
      title.className = "pending-update-title";
      title.textContent = "🔑 Cập nhật mật khẩu mới cho tài khoản đã lưu?";

      const meta = document.createElement("div");
      meta.className = "pending-update-meta";
      meta.textContent = `${p.host || p.serviceName}${p.username ? " • " + p.username : ""}`;

      const actions = document.createElement("div");
      actions.className = "pending-update-actions";

      const btnApply = document.createElement("button");
      btnApply.type = "button";
      btnApply.className = "btn btn-primary btn-sm";
      btnApply.textContent = "✓ Cập nhật mật khẩu";

      const btnKeepOld = document.createElement("button");
      btnKeepOld.type = "button";
      btnKeepOld.className = "btn btn-outline btn-sm";
      btnKeepOld.textContent = "Giữ bản cũ";

      btnApply.onclick = async () => {
        btnApply.disabled = true;
        btnKeepOld.disabled = true;
        btnApply.textContent = "Đang cập nhật...";
        const res = await sendRuntimeMsg({
          type: "CONFIRM_PENDING_UPDATE_BY_ID",
          proposalId: p.proposalId
        });
        if (res && res.ok) {
          setVaultState(await OmniVaultCore.loadExtensionState());
          renderVaultList();
          await refreshPendingUpdatesBox();
          showToast(`✓ Đã cập nhật mật khẩu mới${p.username ? " (" + p.username + ")" : ""} & đồng bộ!`);
        } else {
          await refreshPendingUpdatesBox();
          showToast(res?.error || "Không thể cập nhật mật khẩu", true);
        }
      };

      btnKeepOld.onclick = async () => {
        btnApply.disabled = true;
        btnKeepOld.disabled = true;
        await sendRuntimeMsg({
          type: "DISMISS_PENDING_UPDATE_BY_ID",
          proposalId: p.proposalId
        });
        await refreshPendingUpdatesBox();
      };

      actions.appendChild(btnApply);
      actions.appendChild(btnKeepOld);
      card.appendChild(title);
      card.appendChild(meta);
      card.appendChild(actions);
      pendingUpdatesBox.appendChild(card);
    }
    pendingUpdatesBox.hidden = false;
  }

  const btnPinConfig = document.getElementById("btnPinConfig");
  const btnLockNow = document.getElementById("btnLockNow");

  const sessionLockCard = document.createElement("div");
  sessionLockCard.className = "pin-card";
  sessionLockCard.hidden = true;
  sessionLockCard.innerHTML = `
    <h3>🔒 Kho tiện ích đang khóa</h3>
    <p id="sessionLockHint">Nhập mã PIN để mở khóa phiên trình duyệt (tự khóa sau 15 phút không dùng).</p>
    <input id="sessionPinInput" class="pin-input" type="password" inputmode="numeric" autocomplete="off" spellcheck="false" placeholder="Nhập mã PIN mở khóa">
    <div id="sessionPinErr" class="pin-err" hidden></div>
    <button id="btnUnlockSession" class="btn btn-primary full-width" type="button">Mở khóa phiên</button>
    <button id="btnResetVaultLock" class="btn btn-outline full-width" type="button" style="margin-top:8px;color:#b91c1c;border-color:#fca5a5;">Quên PIN? Xóa kho cục bộ &amp; kết nối lại</button>
  `;

  const pinSettingsCard = document.createElement("div");
  pinSettingsCard.className = "pin-card";
  pinSettingsCard.hidden = true;
  pinSettingsCard.innerHTML = `
    <h3 id="pinSettingsTitle">🔑 Khóa phiên bằng mã PIN</h3>
    <p>Bảo vệ dữ liệu Extension trên Chrome bằng AES-256-GCM (PBKDF2 600.000 vòng) — tự động khóa khi đóng trình duyệt hoặc sau 15 phút rảnh.</p>
    <input id="pinOldInput" class="pin-input" type="password" inputmode="numeric" autocomplete="off" spellcheck="false" placeholder="Mã PIN hiện tại" hidden>
    <input id="pinNewInput" class="pin-input" type="password" inputmode="numeric" autocomplete="off" spellcheck="false" placeholder="Mã PIN mới (4–64 ký tự)">
    <input id="pinConfirmInput" class="pin-input" type="password" inputmode="numeric" autocomplete="off" spellcheck="false" placeholder="Nhập lại mã PIN mới">
    <div id="pinConfigErr" class="pin-err" hidden></div>
    <div style="display:flex;gap:8px;">
      <button id="btnSavePin" class="btn btn-primary" style="flex:1;" type="button">Lưu mã PIN</button>
      <button id="btnClosePin" class="btn btn-outline" type="button">Đóng</button>
    </div>
    <button id="btnRemovePin" class="btn btn-danger full-width" type="button" hidden>Gỡ mã PIN khóa phiên</button>
  `;

  if (popupScrollArea) {
    popupScrollArea.prepend(pinSettingsCard);
    popupScrollArea.prepend(sessionLockCard);
  }

  const sessionLockHint = sessionLockCard.querySelector("#sessionLockHint");
  const sessionPinInput = sessionLockCard.querySelector("#sessionPinInput");
  const sessionPinErr = sessionLockCard.querySelector("#sessionPinErr");
  const btnUnlockSession = sessionLockCard.querySelector("#btnUnlockSession");
  const btnResetVaultLock = sessionLockCard.querySelector("#btnResetVaultLock");

  const pinSettingsTitle = pinSettingsCard.querySelector("#pinSettingsTitle");
  const pinOldInput = pinSettingsCard.querySelector("#pinOldInput");
  const pinNewInput = pinSettingsCard.querySelector("#pinNewInput");
  const pinConfirmInput = pinSettingsCard.querySelector("#pinConfirmInput");
  const pinConfigErr = pinSettingsCard.querySelector("#pinConfigErr");
  const btnSavePin = pinSettingsCard.querySelector("#btnSavePin");
  const btnClosePin = pinSettingsCard.querySelector("#btnClosePin");
  const btnRemovePin = pinSettingsCard.querySelector("#btnRemovePin");

  pinInputsRef = [sessionPinInput, pinOldInput, pinNewInput, pinConfirmInput];

  function hideAllPopupViews() {
    for (const el of document.querySelectorAll(".view")) {
      el.hidden = true;
    }
    if (pairedBottomActions) {
      pairedBottomActions.hidden = true;
    }
    if (pendingUpdatesBox && (!currentState || currentState.locked)) {
      pendingUpdatesBox.hidden = true;
    }
  }

  function syncSessionLockButtons() {
    const isLocked = Boolean(currentState && currentState.locked);
    const hasPin = Boolean(currentState && currentState.hasPinLock);
    if (btnLockNow) {
      btnLockNow.hidden = isLocked || !hasPin;
    }
    if (btnPinConfig) {
      btnPinConfig.hidden = isLocked;
      btnPinConfig.title = hasPin ? "Đổi hoặc gỡ mã PIN khóa phiên" : "Bật khóa phiên bằng mã PIN";
    }
  }

  async function submitSessionUnlock() {
    sessionPinErr.hidden = true;
    btnUnlockSession.disabled = true;
    btnUnlockSession.textContent = "Đang kiểm tra...";
    try {
      const enteredPin = sessionPinInput.value;
      // Delegate PBKDF2 600k + 310k->600k re-wrap upgrade to Service Worker so closing Popup cannot abort upgrade
      let unlockedState = null;
      const swRes = await sendRuntimeMsg({ type: "UNLOCK_EXTENSION_WITH_PIN", pin: enteredPin });
      if (swRes && swRes.ok && swRes.state) {
        unlockedState = swRes.state;
      } else if (swRes && swRes.ok === false && swRes.error) {
        throw new Error(swRes.error);
      } else {
        unlockedState = await OmniVaultCore.unlockExtensionWithPin(enteredPin);
      }
      setVaultState(unlockedState);
      sessionPinInput.value = "";
      let pendingHosts = [];
      try {
        const flushRes = await sendRuntimeMsg({ type: "FLUSH_LOCKED_CAPTURES" });
        if (flushRes && Array.isArray(flushRes.pendingHosts) && flushRes.pendingHosts.length > 0) {
          pendingHosts = flushRes.pendingHosts;
        }
      } catch (_) {}
      renderVaultList();
      refreshPendingUpdatesBox().catch(() => {});
      showToast(
        pendingHosts.length > 0
          ? `Đã mở khóa! Các đăng nhập lúc khóa (${pendingHosts.join(", ")}) chưa lưu tạm vì bảo mật.`
          : "Đã mở khóa OmniVault"
      );
      if (currentState.pairing && !currentState.pairing.localOnly) {
        OmniVaultCore.syncBrowserVaultBidirectional(false)
          .then((syncRes) => {
            if (syncRes && syncRes.pulledCount > 0 && syncRes.state) {
              setVaultState(syncRes.state);
              renderVaultList();
            }
          })
          .catch(() => {});
      }
    } catch (e) {
      sessionPinErr.textContent = String(e.message || e);
      sessionPinErr.hidden = false;
    } finally {
      btnUnlockSession.disabled = false;
      btnUnlockSession.textContent = "Mở khóa phiên";
    }
  }

  btnUnlockSession.onclick = submitSessionUnlock;
  sessionPinInput.addEventListener("keydown", (ev) => {
    if (ev.key === "Enter") {
      ev.preventDefault();
      submitSessionUnlock();
    }
  });

  if (btnResetVaultLock) {
    btnResetVaultLock.onclick = async () => {
      if (
        !window.confirm(
          "Xóa toàn bộ dữ liệu kho cục bộ trên tiện ích và ngắt kết nối hiện tại?\n\nDữ liệu trên điện thoại và đám mây vẫn được giữ nguyên."
        )
      ) {
        return;
      }
      btnResetVaultLock.disabled = true;
      try {
        await sendRuntimeMsg({ type: "RESET_EXTENSION_VAULT" });
        await OmniVaultCore.resetExtensionVault();
        setVaultState(await OmniVaultCore.loadExtensionState());
        renderVaultList();
        showToast("Đã đặt lại kho tiện ích cục bộ");
      } catch (e) {
        showToast(String(e?.message || e), true);
      } finally {
        btnResetVaultLock.disabled = false;
      }
    };
  }

  btnLockNow.onclick = async () => {
    pinSettingsOpen = false;
    try {
      await sendRuntimeMsg({ type: "CLEAR_EPHEMERAL_CAPTURES" });
    } catch (_) {}
    await OmniVaultCore.lockExtensionSession();
    setVaultState(await OmniVaultCore.loadExtensionState());
    renderVaultList();
    showToast("Đã khóa phiên OmniVault");
  };

  btnPinConfig.onclick = () => {
    if (currentState && currentState.locked) return;
    pinSettingsOpen = !pinSettingsOpen;
    clearPinInputs();
    if (pinSettingsOpen) {
      const hasPin = Boolean(currentState && currentState.hasPinLock);
      pinSettingsTitle.textContent = hasPin
        ? "🔑 Đổi hoặc gỡ mã PIN khóa phiên"
        : "🔑 Bật khóa phiên bằng mã PIN";
      pinOldInput.hidden = !hasPin;
      pinConfigErr.hidden = true;
      btnRemovePin.hidden = !hasPin;
    }
    renderVaultList();
  };

  btnClosePin.onclick = () => {
    pinSettingsOpen = false;
    clearPinInputs();
    renderVaultList();
  };

  btnSavePin.onclick = async () => {
    pinConfigErr.hidden = true;
    const p1 = pinNewInput.value.trim();
    const p2 = pinConfirmInput.value.trim();
    if (p1.length < 4 || p1.length > 64) {
      pinConfigErr.textContent = "Mã PIN phải từ 4 đến 64 ký tự.";
      pinConfigErr.hidden = false;
      return;
    }
    if (p1 !== p2) {
      pinConfigErr.textContent = "Hai lần nhập mã PIN mới không khớp.";
      pinConfigErr.hidden = false;
      return;
    }
    btnSavePin.disabled = true;
    try {
      const hasPin = Boolean(currentState && currentState.hasPinLock);
      const oldPin = hasPin ? pinOldInput.value : null;
      const swRes = await sendRuntimeMsg({ type: "SET_EXTENSION_PIN", newPin: p1, currentPin: oldPin });
      if (swRes && swRes.ok && swRes.state) {
        setVaultState(swRes.state);
      } else if (swRes && swRes.ok === false && swRes.error) {
        throw new Error(swRes.error);
      } else {
        await OmniVaultCore.setExtensionPin(p1, oldPin);
        setVaultState(await OmniVaultCore.loadExtensionState());
      }
      pinSettingsOpen = false;
      clearPinInputs();
      renderVaultList();
      refreshPendingUpdatesBox().catch(() => {});
      showToast("Đã bật khóa phiên AES-256 (tự khóa sau 15 phút)");
    } catch (e) {
      pinConfigErr.textContent = String(e.message || e);
      pinConfigErr.hidden = false;
    } finally {
      btnSavePin.disabled = false;
    }
  };

  btnRemovePin.onclick = async () => {
    pinConfigErr.hidden = true;
    btnRemovePin.disabled = true;
    try {
      const oldPin = pinOldInput.value;
      const swRes = await sendRuntimeMsg({ type: "CLEAR_EXTENSION_PIN", currentPin: oldPin });
      if (swRes && swRes.ok && swRes.state) {
        setVaultState(swRes.state);
      } else if (swRes && swRes.ok === false && swRes.error) {
        throw new Error(swRes.error);
      } else {
        await OmniVaultCore.clearExtensionPin(oldPin);
        setVaultState(await OmniVaultCore.loadExtensionState());
      }
      pinSettingsOpen = false;
      clearPinInputs();
      renderVaultList();
      refreshPendingUpdatesBox().catch(() => {});
      showToast("Đã gỡ mã PIN khóa phiên");
    } catch (e) {
      pinConfigErr.textContent = String(e.message || e);
      pinConfigErr.hidden = false;
    } finally {
      btnRemovePin.disabled = false;
    }
  };

  // --- Virtualized List Renderer for #allVaultList & Windowed #currentSiteList ---
  const VIRTUAL_LIST_THRESHOLD = 24;
  const VIRTUAL_OVERSCAN = 4;
  const CARD_GAP_PX = 6;
  const SITE_LIST_PAGE_SIZE = 40;

  let virtualHeights = [];
  let virtualOffsets = [0];
  let virtualEnabled = false;
  let virtualStart = -1;
  let virtualEnd = -1;
  let virtualTopSpacer = null;
  let virtualSliceContainer = null;
  let virtualBottomSpacer = null;
  let virtualScrollRaf = 0;

  let siteRenderedCount = 0;

  function estimateVaultCardHeight(item) {
    const domList = Array.isArray(item.web_domains) ? item.web_domains.filter(Boolean) : [];
    const serviceTitle = String(item.service_name || "").trim() || domList[0] || "Tài khoản";
    const hasExtraDomains =
      domList.length > 1 ||
      (domList.length === 1 && domList[0].trim().toLowerCase() !== serviceTitle.toLowerCase());
    let h = 88;
    if (hasExtraDomains) h += 13;
    if (Array.isArray(item.passkeys) && item.passkeys.length > 0) h += 18;
    if (item.totp_secret) h += 32;
    return h + CARD_GAP_PX;
  }

  function rebuildVirtualOffsetsFrom(startIdx = 0) {
    const n = virtualHeights.length;
    if (virtualOffsets.length !== n + 1) {
      virtualOffsets = new Array(n + 1);
      virtualOffsets[0] = 0;
      startIdx = 0;
    }
    let acc = virtualOffsets[startIdx] || 0;
    for (let i = startIdx; i < n; i++) {
      acc += virtualHeights[i];
      virtualOffsets[i + 1] = acc;
    }
  }

  function findFirstIndexAtOffset(y) {
    const n = virtualItems.length;
    if (n === 0 || y <= 0) return 0;
    let lo = 0;
    let hi = n - 1;
    while (lo < hi) {
      const mid = (lo + hi) >>> 1;
      if (virtualOffsets[mid + 1] <= y) {
        lo = mid + 1;
      } else {
        hi = mid;
      }
    }
    return lo;
  }

  function renderVirtualSlice(force = false) {
    if (!virtualEnabled || !virtualSliceContainer || !popupScrollArea || viewVault.hidden) return;
    const n = virtualItems.length;
    if (n === 0) return;

    const scrollTop = popupScrollArea.scrollTop || 0;
    const viewportH = popupScrollArea.clientHeight || 460;
    const listOffsetTop = allVaultList.offsetTop || 0;
    const localTop = Math.max(0, scrollTop - listOffsetTop);
    const localBottom = Math.max(viewportH, scrollTop + viewportH - listOffsetTop);

    const nextStart = Math.max(0, findFirstIndexAtOffset(localTop) - VIRTUAL_OVERSCAN);
    const nextEnd = Math.min(n, findFirstIndexAtOffset(localBottom) + 1 + VIRTUAL_OVERSCAN);

    if (!force && nextStart === virtualStart && nextEnd === virtualEnd) {
      return;
    }

    virtualStart = nextStart;
    virtualEnd = nextEnd;

    const totalHeight = virtualOffsets[n] || 0;
    const topH = virtualOffsets[nextStart] || 0;
    const botH = Math.max(0, totalHeight - (virtualOffsets[nextEnd] || totalHeight));

    virtualTopSpacer.style.height = `${topH}px`;
    virtualBottomSpacer.style.height = `${botH}px`;

    const frag = document.createDocumentFragment();
    for (let i = nextStart; i < nextEnd; i++) {
      frag.appendChild(buildVaultCard(virtualItems[i], false));
    }
    virtualSliceContainer.replaceChildren(frag);

    // Refine height estimates from actual measured card heights
    const children = virtualSliceContainer.children;
    let firstChanged = -1;
    for (let i = 0; i < children.length; i++) {
      const itemIdx = nextStart + i;
      const measured = children[i].offsetHeight;
      if (measured > 0) {
        const withGap = measured + CARD_GAP_PX;
        if (Math.abs(virtualHeights[itemIdx] - withGap) >= 2) {
          virtualHeights[itemIdx] = withGap;
          if (firstChanged < 0) firstChanged = itemIdx;
        }
      }
    }
    if (firstChanged >= 0) {
      rebuildVirtualOffsetsFrom(firstChanged);
      const updatedTotal = virtualOffsets[n] || 0;
      virtualTopSpacer.style.height = `${virtualOffsets[nextStart] || 0}px`;
      virtualBottomSpacer.style.height = `${Math.max(0, updatedTotal - (virtualOffsets[nextEnd] || updatedTotal))}px`;
    }

    updateVisibleTotpPills(false).catch(() => {});
  }

  function scheduleVirtualSliceRender() {
    if (!virtualEnabled || virtualScrollRaf) return;
    virtualScrollRaf = requestAnimationFrame(() => {
      virtualScrollRaf = 0;
      renderVirtualSlice(false);
    });
  }

  function attachControlledWheelScroll(el, { maxStepPx = 56, discreteScale = 0.44, touchpadScale = 0.65, chainAtEdge = false } = {}) {
    if (!el || typeof el.addEventListener !== "function") return;
    let wheelRem = 0;
    let lastWheelAt = 0;
    el.addEventListener(
      "wheel",
      (ev) => {
        if (ev.ctrlKey) return; // Allow browser zoom
        if (ev.target && ev.target.tagName === "TEXTAREA" && ev.target.scrollHeight > ev.target.clientHeight) {
          return;
        }
        let raw = Number(ev.deltaY) || 0;
        if (!Number.isFinite(raw) || raw === 0) return;
        if (ev.deltaMode === 1) raw *= 16;
        else if (ev.deltaMode === 2) raw *= 120;
        const maxScroll = Math.max(0, el.scrollHeight - el.clientHeight);
        if (maxScroll <= 0) return;
        if (chainAtEdge) {
          if (raw < 0 && el.scrollTop <= 0) return;
          if (raw > 0 && el.scrollTop >= maxScroll - 1) return;
        }
        const absRaw = Math.abs(raw);
        // Smooth monotonic transfer curve (zero speed drop cliff at 35px) + sub-pixel remainder accumulation
        const knee = 35;
        const kneeOut = knee * touchpadScale;
        const target120 = Math.min(maxStepPx, 120 * discreteScale);
        const tailSlope = target120 > kneeOut ? (target120 - kneeOut) / (120 - knee) : discreteScale;
        const mag = absRaw <= knee ? absRaw * touchpadScale : kneeOut + (absRaw - knee) * tailSlope;
        const clamped = Math.min(maxStepPx, mag);
        const scaledDelta = raw < 0 ? -clamped : clamped;
        ev.preventDefault();
        ev.stopPropagation();
        const now = Date.now();
        if (now - lastWheelAt > 150 || (scaledDelta > 0 && wheelRem < 0) || (scaledDelta < 0 && wheelRem > 0)) {
          wheelRem = 0;
        }
        lastWheelAt = now;
        wheelRem += scaledDelta;
        const step = Math.trunc(wheelRem + (wheelRem >= 0 ? 1e-9 : -1e-9));
        wheelRem -= step;
        if (Math.abs(wheelRem) < 1e-9) wheelRem = 0;
        if (step !== 0) {
          el.scrollTop += step;
        }
      },
      { passive: false }
    );
  }

  if (popupScrollArea) {
    popupScrollArea.addEventListener("scroll", scheduleVirtualSliceRender, { passive: true });
    attachControlledWheelScroll(popupScrollArea, { maxStepPx: 56, discreteScale: 0.44, touchpadScale: 0.65, chainAtEdge: false });
  }

  function appendCurrentSiteBatch() {
    if (siteRenderedCount >= siteMatchedItems.length) return;
    const end = Math.min(siteMatchedItems.length, siteRenderedCount + SITE_LIST_PAGE_SIZE);
    const frag = document.createDocumentFragment();
    for (let i = siteRenderedCount; i < end; i++) {
      frag.appendChild(buildVaultCard(siteMatchedItems[i].it, true));
    }
    currentSiteList.appendChild(frag);
    siteRenderedCount = end;
    updateVisibleTotpPills(false).catch(() => {});
  }

  if (currentSiteList) {
    attachControlledWheelScroll(currentSiteList, { maxStepPx: 48, discreteScale: 0.4, touchpadScale: 0.6, chainAtEdge: true });
    currentSiteList.addEventListener(
      "scroll",
      () => {
        if (
          siteRenderedCount < siteMatchedItems.length &&
          currentSiteList.scrollTop + currentSiteList.clientHeight >= currentSiteList.scrollHeight - 40
        ) {
          appendCurrentSiteBatch();
        }
      },
      { passive: true }
    );
  }

  function renderVaultList() {
    syncSessionLockButtons();
    if (currentState && currentState.locked) {
      pinSettingsOpen = false;
      pinSettingsCard.hidden = true;
      virtualEnabled = false;
      deviceLabel.textContent = currentState.deviceNameHint
        ? `${currentState.deviceNameHint} • Đang khóa`
        : "Đang khóa phiên";
      sessionLockHint.textContent = currentState.deviceNameHint
        ? `Nhập mã PIN để mở khóa thiết bị "${currentState.deviceNameHint}" (tự khóa sau 15 phút không dùng).`
        : "Nhập mã PIN để mở khóa phiên trình duyệt (tự khóa sau 15 phút không dùng).";
      hideAllPopupViews();
      sessionLockCard.hidden = false;
      setTimeout(() => sessionPinInput.focus(), 40);
      return;
    }
    sessionLockCard.hidden = true;

    if (pinSettingsOpen) {
      virtualEnabled = false;
      hideAllPopupViews();
      pinSettingsCard.hidden = false;
      return;
    }
    pinSettingsCard.hidden = true;

    if (!currentState || !currentState.pairing) {
      virtualEnabled = false;
      deviceLabel.textContent = "Chưa kết nối điện thoại";
      if (btnStartLocalMode) btnStartLocalMode.hidden = false;
      if (btnCancelPairUpgrade) btnCancelPairUpgrade.hidden = true;
      showView("pairing");
      return;
    }

    if (showingPairUpgrade && currentState.pairing.localOnly) {
      virtualEnabled = false;
      deviceLabel.textContent = "Kết nối App Điện thoại";
      if (btnStartLocalMode) btnStartLocalMode.hidden = true;
      if (btnCancelPairUpgrade) btnCancelPairUpgrade.hidden = false;
      showView("pairing");
      return;
    }

    if (btnStartLocalMode) btnStartLocalMode.hidden = false;
    if (btnCancelPairUpgrade) btnCancelPairUpgrade.hidden = true;
    if (btnUpgradeToPhoneSync) btnUpgradeToPhoneSync.hidden = !Boolean(currentState.pairing.localOnly);

    deviceLabel.textContent = currentState.pairing.localOnly
      ? "Chế độ: Lưu cục bộ trên trình duyệt"
      : `Thiết bị: ${currentState.pairing.deviceName}`;
    showView("vault");

    const rawQ = (searchInput.value || "").trim();
    const foldedQ = OmniVaultCore.foldSearchText(rawQ);

    // Pre-indexed zero-allocation scoring
    let filtered;
    if (!foldedQ) {
      filtered = currentState.items || [];
    } else {
      const scoredAll = [];
      for (let i = 0; i < indexedItems.length; i++) {
        const entry = indexedItems[i];
        const qScore = OmniVaultCore.scoreIndexedItem(entry, foldedQ);
        if (qScore > 0) {
          scoredAll.push({ it: entry.item, qScore });
        }
      }
      scoredAll.sort((a, b) => {
        if (b.qScore !== a.qScore) return b.qScore - a.qScore;
        const favDiff = (b.it.is_favorite ? 1 : 0) - (a.it.is_favorite ? 1 : 0);
        if (favDiff !== 0) return favDiff;
        return VI_COLLATOR.compare(
          String(a.it.username || a.it.service_name || ""),
          String(b.it.username || b.it.service_name || "")
        );
      });
      filtered = scoredAll.map((x) => x.it);
    }

    // Matching current tab domain filters strictly left-to-right on username (O(1) domain index lookup)!
    currentSiteList.textContent = "";
    siteMatchedItems = [];
    siteRenderedCount = 0;
    if (activeHost) {
      const domainHits = domainIndex.get(activeHost) || [];
      const matched = [];
      for (let i = 0; i < domainHits.length; i++) {
        const hit = domainHits[i];
        if (!foldedQ || OmniVaultCore.foldSearchText(hit.item.username).startsWith(foldedQ)) {
          matched.push({ it: hit.item, score: hit.score });
        }
      }
      matched.sort((a, b) => {
        if (b.score !== a.score) return b.score - a.score;
        const favDiff = (b.it.is_favorite ? 1 : 0) - (a.it.is_favorite ? 1 : 0);
        if (favDiff !== 0) return favDiff;
        const timeDiff = (Number(b.it.last_autofilled_ms) || 0) - (Number(a.it.last_autofilled_ms) || 0);
        if (timeDiff !== 0) return timeDiff;
        return VI_COLLATOR.compare(String(a.it.username || ""), String(b.it.username || ""));
      });

      if (matched.length > 0) {
        currentSiteSection.hidden = false;
        currentSiteLabel.textContent = `Khớp với ${activeHost} (${matched.length})`;
        siteMatchedItems = matched;
        appendCurrentSiteBatch();
      } else {
        currentSiteSection.hidden = true;
      }
    } else {
      currentSiteSection.hidden = true;
    }

    allItemsCaption.textContent = `Tất cả tài khoản (${filtered.length})`;
    allVaultList.textContent = "";
    virtualStart = -1;
    virtualEnd = -1;

    if (filtered.length === 0) {
      virtualEnabled = false;
      allVaultList.style.gap = "";
      const empty = document.createElement("div");
      empty.className = "empty-box";
      empty.textContent = rawQ
        ? "Không tìm thấy tài khoản phù hợp."
        : "Kho mật khẩu đang trống. Bấm ↻ để đồng bộ hoặc ＋ để thêm mới.";
      allVaultList.appendChild(empty);
      return;
    }

    if (filtered.length <= VIRTUAL_LIST_THRESHOLD) {
      virtualEnabled = false;
      allVaultList.style.gap = "";
      const frag = document.createDocumentFragment();
      for (let i = 0; i < filtered.length; i++) {
        frag.appendChild(buildVaultCard(filtered[i], false));
      }
      allVaultList.appendChild(frag);
      updateVisibleTotpPills(false).catch(() => {});
      return;
    }

    // Virtualized rendering for large vaults (renders only visible viewport slice + overscan buffer!)
    virtualEnabled = true;
    virtualItems = filtered;
    virtualHeights = new Array(filtered.length);
    for (let i = 0; i < filtered.length; i++) {
      virtualHeights[i] = estimateVaultCardHeight(filtered[i]);
    }
    rebuildVirtualOffsetsFrom(0);

    allVaultList.style.gap = "0px";
    virtualTopSpacer = document.createElement("div");
    virtualTopSpacer.style.cssText = "flex-shrink: 0; pointer-events: none;";
    virtualSliceContainer = document.createElement("div");
    virtualSliceContainer.className = "vault-list";
    virtualBottomSpacer = document.createElement("div");
    virtualBottomSpacer.style.cssText = "flex-shrink: 0; pointer-events: none;";

    allVaultList.appendChild(virtualTopSpacer);
    allVaultList.appendChild(virtualSliceContainer);
    allVaultList.appendChild(virtualBottomSpacer);

    renderVirtualSlice(true);
  }

  function renderEditorPasskeys(item) {
    if (!editPasskeysSection || !editPasskeysList) return;
    editPasskeysList.textContent = "";
    const pks = item && Array.isArray(item.passkeys) ? item.passkeys : [];
    if (pks.length === 0) {
      editPasskeysSection.hidden = true;
      return;
    }
    for (const pk of pks) {
      const row = document.createElement("div");
      row.className = "passkey-editor-row";

      const meta = document.createElement("div");
      meta.className = "passkey-editor-meta";
      const label = pk.user_name ? `${pk.rp_id} • ${pk.user_name}` : pk.rp_id;
      meta.textContent = label;
      meta.title = label;

      const delBtn = document.createElement("button");
      delBtn.type = "button";
      delBtn.className = "passkey-del-btn";
      delBtn.title = "Xóa Passkey này";
      delBtn.textContent = "✕";
      delBtn.onclick = async () => {
        if (!confirm(`Xóa Passkey "${label}" khỏi tài khoản này?`)) return;
        delBtn.disabled = true;
        try {
          const res = await sendRuntimeMsg({
            type: "DELETE_ITEM_PASSKEY",
            itemId: item.id,
            credentialIdB64Url: pk.credential_id_b64url
          });
          if (res && res.ok) {
            if (res.state) {
              setVaultState(res.state);
            } else {
              setVaultState(await OmniVaultCore.loadExtensionState());
            }
            const refreshed = itemsById.get(item.id) || res.item || null;
            renderEditorPasskeys(refreshed);
            showToast("Đã xóa Passkey & đồng bộ");
          } else {
            showToast(res?.error || "Không thể xóa Passkey", true);
          }
        } catch (e) {
          showToast(String(e?.message || e), true);
        } finally {
          delBtn.disabled = false;
        }
      };

      row.appendChild(meta);
      row.appendChild(delBtn);
      editPasskeysList.appendChild(row);
    }
    editPasskeysSection.hidden = false;
  }

  function renderAuditView() {
    if (!viewAudit || !currentState || currentState.locked || !currentState.pairing) return;
    const items = Array.isArray(currentState.items) ? currentState.items : [];
    const summary = OmniVaultCore.auditVaultSecurity(items);

    if (auditScoreSummary) {
      auditScoreSummary.textContent = "";
      const left = document.createElement("div");
      const num = document.createElement("div");
      num.className =
        "audit-score-num" + (summary.score < 60 ? " danger" : summary.score < 85 ? " warn" : "");
      num.textContent = `${summary.score}/100`;
      const lbl = document.createElement("div");
      lbl.className = "audit-score-label";
      lbl.textContent = `Điểm bảo mật (${summary.totalItems} tài khoản)`;
      left.appendChild(num);
      left.appendChild(lbl);
      auditScoreSummary.appendChild(left);
    }

    if (auditStatsGrid) {
      auditStatsGrid.textContent = "";
      const stats = [
        { label: "Mật khẩu yếu", val: summary.weakCount, cls: summary.weakCount > 0 ? "danger" : "" },
        { label: "Trùng lặp", val: summary.reusedCount, cls: summary.reusedCount > 0 ? "warn" : "" },
        { label: "Thiếu 2FA", val: summary.missing2faCount, cls: "" },
        { label: "🔑 Passkey", val: summary.passkeyCount, cls: "passkey" }
      ];
      for (const s of stats) {
        const pill = document.createElement("div");
        pill.className = "audit-stat-pill" + (s.cls ? " " + s.cls : "");
        const k = document.createElement("span");
        k.textContent = s.label;
        const v = document.createElement("span");
        v.textContent = String(s.val);
        pill.appendChild(k);
        pill.appendChild(v);
        auditStatsGrid.appendChild(pill);
      }
    }

    if (auditResultsList) {
      auditResultsList.textContent = "";
      const rows = [];
      const seenBreached = new Set();

      if (lastHibpResult && Array.isArray(lastHibpResult.breachedItems)) {
        for (const b of lastHibpResult.breachedItems) {
          if (!itemsById.has(b.id)) continue;
          seenBreached.add(b.id);
          rows.push({
            id: b.id,
            title: `${b.service_name}${b.username ? " • " + b.username : ""}`,
            meta: `⚠️ Lộ mật khẩu (${Number(b.breachCount || 0).toLocaleString("vi-VN")} lần trong dữ liệu rò rỉ) — Bấm để sửa`,
            breached: true,
            warn: false
          });
        }
      }

      for (const w of summary.weakItems) {
        if (seenBreached.has(w.id)) continue;
        rows.push({
          id: w.id,
          title: `${w.service_name}${w.username ? " • " + w.username : ""}`,
          meta: `Yếu: ${w.reason} — Bấm để đổi mật khẩu`,
          breached: false,
          warn: true
        });
      }

      for (const r of summary.reusedItems) {
        if (seenBreached.has(r.id) || rows.some((x) => x.id === r.id)) continue;
        rows.push({
          id: r.id,
          title: `${r.service_name}${r.username ? " • " + r.username : ""}`,
          meta: `Trùng mật khẩu với ${r.reuseCount} tài khoản — Bấm để sửa`,
          breached: false,
          warn: true
        });
      }

      if (rows.length === 0) {
        const okBox = document.createElement("div");
        okBox.className = "empty-box";
        okBox.textContent = "✓ Không phát hiện mật khẩu yếu hoặc trùng lặp trong kho.";
        auditResultsList.appendChild(okBox);
      } else {
        for (const entry of rows.slice(0, 60)) {
          const btn = document.createElement("button");
          btn.type = "button";
          btn.className = "audit-result-item" + (entry.breached ? " breached" : "");

          const t = document.createElement("div");
          t.className = "audit-result-title";
          t.textContent = entry.title;

          const m = document.createElement("div");
          m.className = "audit-result-meta" + (entry.warn ? " warn" : "");
          m.textContent = entry.meta;

          btn.appendChild(t);
          btn.appendChild(m);
          btn.onclick = () => {
            const target = itemsById.get(entry.id);
            if (target) openEditor(target, "audit");
          };
          auditResultsList.appendChild(btn);
        }
      }
    }
  }

  function openSecurityAuditView() {
    if (!currentState || currentState.locked || !currentState.pairing) return;
    virtualEnabled = false;
    if (popupScrollArea) popupScrollArea.scrollTop = 0;
    showView("audit");
    renderAuditView();
  }

  function openEditor(existing = null, returnView = "vault") {
    editorReturnView = returnView === "audit" ? "audit" : "vault";
    if (existing) {
      editorTitle.textContent = "Sửa tài khoản";
      editId.value = existing.id;
      editService.value = existing.service_name || "";
      editUsername.value = existing.username || "";
      editPassword.value = existing.password || "";
      editDomains.value = (existing.web_domains || []).join(", ");
      editTotpSecret.value = existing.totp_secret || "";
      editNotes.value = existing.notes || "";
      btnDeleteItem.hidden = false;
      renderEditorPasskeys(existing);
    } else {
      editorTitle.textContent = "Thêm tài khoản mới";
      editId.value = "";
      editService.value = activeHost ? OmniVaultCore.prettifyDomainTitle(activeHost) : "";
      editUsername.value = "";
      editPassword.value = "";
      editDomains.value = activeHost || "";
      editTotpSecret.value = "";
      editNotes.value = "";
      btnDeleteItem.hidden = true;
      renderEditorPasskeys(null);
    }
    showView("editor");
  }

  // --- Event Handlers ---
  if (btnStartLocalMode) {
    btnStartLocalMode.onclick = async () => {
      try {
        const nextSt = await OmniVaultCore.enableLocalStandaloneMode();
        setVaultState(nextSt);
        showingPairUpgrade = false;
        renderVaultList();
        showToast("Đã bật Kho mật khẩu cục bộ trên trình duyệt!");
      } catch (e) {
        showToast(String(e.message || e), true);
      }
    };
  }

  if (btnUpgradeToPhoneSync) {
    btnUpgradeToPhoneSync.onclick = () => {
      showingPairUpgrade = true;
      renderVaultList();
    };
  }

  if (btnCancelPairUpgrade) {
    btnCancelPairUpgrade.onclick = () => {
      showingPairUpgrade = false;
      renderVaultList();
    };
  }

  btnConnectCode.onclick = async () => {
    const raw = pairingInput.value.trim();
    if (!raw) {
      showToast("Vui lòng dán Mã Kết Nối (OVB2-... hoặc OVB1-...) từ điện thoại", true);
      return;
    }
    btnConnectCode.disabled = true;
    btnConnectCode.textContent = "Đang kết nối & giải mã...";
    try {
      // HIGH-EXT-05: Authenticate & verify cloud handshake BEFORE modifying any local items!
      const pairRes = await OmniVaultCore.pairWithCloudCode(raw);
      showingPairUpgrade = false;
      setVaultState(await OmniVaultCore.loadExtensionState());
      pairingInput.value = "";
      renderVaultList();
      refreshPendingUpdatesBox().catch(() => {});
      showToast(
        pairRes.mergedLocalCount > 0
          ? `Đã kết nối & gộp ${pairRes.mergedLocalCount} tài khoản cục bộ (${pairRes.itemCount} tổng)!`
          : `Đã kết nối! Đồng bộ ${pairRes.itemCount} tài khoản.`
      );
    } catch (e) {
      showToast(String(e.message || e), true);
    } finally {
      btnConnectCode.disabled = false;
      btnConnectCode.textContent = "Kết nối & Tải mật khẩu";
    }
  };

  btnSyncNow.onclick = async () => {
    if (currentState && currentState.pairing && currentState.pairing.localOnly) {
      showingPairUpgrade = true;
      renderVaultList();
      refreshPendingUpdatesBox().catch(() => {});
      showToast("Dán Mã Kết Nối OVB2-... (hoặc OVB1-...) để đồng bộ với Điện thoại");
      return;
    }
    btnSyncNow.disabled = true;
    try {
      const res = await OmniVaultCore.syncBrowserVaultBidirectional(false);
      setVaultState(res.state || (await OmniVaultCore.loadExtensionState()));
      if (currentState.hasPinLock) {
        await OmniVaultCore.touchAutoLockAlarm();
      }
      renderVaultList();
      refreshPendingUpdatesBox().catch(() => {});
      showToast(`Đã đồng bộ (${res.itemCount} tài khoản)`);
    } catch (e) {
      showToast(String(e.message || e), true);
    } finally {
      btnSyncNow.disabled = false;
    }
  };

  function openBulkImporterTab() {
    chrome.tabs.create({ url: chrome.runtime.getURL("import.html"), active: true });
  }

  if (btnOpenBulkImportTop) btnOpenBulkImportTop.onclick = openBulkImporterTab;
  if (btnOpenBulkImportVault) btnOpenBulkImportVault.onclick = openBulkImporterTab;
  if (btnOpenBulkImportUnpaired) btnOpenBulkImportUnpaired.onclick = openBulkImporterTab;

  if (btnSecurityAudit) {
    btnSecurityAudit.onclick = () => openSecurityAuditView();
  }
  if (btnAuditBack) {
    btnAuditBack.onclick = () => renderVaultList();
  }
  if (btnRunHibpAudit) {
    btnRunHibpAudit.onclick = async () => {
      if (hibpCheckRunning || !currentState || currentState.locked) return;
      hibpCheckRunning = true;
      btnRunHibpAudit.disabled = true;
      btnRunHibpAudit.textContent = "⏳ Đang kiểm tra ẩn danh...";
      if (auditHibpStatus) {
        auditHibpStatus.className = "audit-hibp-status info";
        auditHibpStatus.textContent = "Đang tính SHA-1 cục bộ & truy vấn tiền tố 5 ký tự...";
        auditHibpStatus.hidden = false;
      }
      try {
        const res = await OmniVaultCore.checkPasswordsHibpKAnonymity(currentState.items || [], {
          onProgress: (done, total) => {
            if (auditHibpStatus && total > 0) {
              auditHibpStatus.textContent = `Đang kiểm tra ẩn danh (${done}/${total} nhóm tiền tố)...`;
            }
          }
        });
        lastHibpResult = res;
        if (auditHibpStatus) {
          if (res.breachedCount > 0) {
            auditHibpStatus.className = "audit-hibp-status danger";
            auditHibpStatus.textContent = `⚠️ Phát hiện ${res.breachedCount}/${res.checkedCount} tài khoản có mật khẩu từng bị lộ!`;
          } else if (res.failedPrefixes.length > 0) {
            auditHibpStatus.className = "audit-hibp-status info";
            auditHibpStatus.textContent = `Đã kiểm ${res.checkedCount} tài khoản (${res.failedPrefixes.length} nhóm lỗi mạng, không lộ).`;
          } else {
            auditHibpStatus.className = "audit-hibp-status";
            auditHibpStatus.textContent = `✓ An toàn: 0/${res.checkedCount} mật khẩu xuất hiện trong dữ liệu rò rỉ.`;
          }
          auditHibpStatus.hidden = false;
        }
        renderAuditView();
      } catch (e) {
        if (auditHibpStatus) {
          auditHibpStatus.className = "audit-hibp-status danger";
          auditHibpStatus.textContent = `Lỗi kiểm tra HIBP: ${String(e?.message || e)}`;
          auditHibpStatus.hidden = false;
        }
      } finally {
        hibpCheckRunning = false;
        btnRunHibpAudit.disabled = false;
        btnRunHibpAudit.textContent = "🛡️ Kiểm tra lộ mật khẩu (Ẩn danh)";
      }
    };
  }

  btnOpenAdd.onclick = () => openEditor(null, "vault");
  btnCancelEdit.onclick = () => {
    const ret = editorReturnView;
    clearEditorInputs();
    if (ret === "audit") {
      openSecurityAuditView();
    } else {
      renderVaultList();
    }
  };

  btnGenPw.onclick = () => {
    editPassword.value = OmniVaultCore.generateStrongPassword(18);
  };

  btnSaveItem.onclick = async () => {
    const srv = editService.value.trim();
    const usr = editUsername.value.trim();
    const pw = editPassword.value;
    const doms = editDomains.value
      .split(",")
      .map((s) => OmniVaultCore.extractCleanDomain(s))
      .filter(Boolean);
    const rawSecret = editTotpSecret.value.trim();
    const notes = editNotes.value.trim();

    if (!srv && !pw && doms.length === 0) {
      showToast("Vui lòng nhập Tên dịch vụ hoặc Mật khẩu", true);
      return;
    }

    let secret = null;
    let parsedTotpMeta = null;
    if (rawSecret) {
      if (/^otpauth:\/\//i.test(rawSecret)) {
        try {
          parsedTotpMeta = OmniVaultCore.parseOtpAuthUri(rawSecret);
          secret = parsedTotpMeta.secret;
        } catch (e) {
          showToast(String(e?.message || e), true);
          return;
        }
      } else {
        const cleanB32 = OmniVaultCore.parseTotpSecretField(rawSecret);
        if (!cleanB32) {
          showToast("Mã bí mật 2FA TOTP (Base32) không hợp lệ", true);
          return;
        }
        secret = cleanB32;
      }
    }

    btnSaveItem.disabled = true;
    btnSaveItem.textContent = "Đang lưu...";
    try {
      const record = await OmniVaultCore.mutateVaultState((st) => {
        if (st.locked) {
          throw new Error("Kho tiện ích đang khóa — vui lòng nhập PIN trước khi lưu.");
        }
        const now = Date.now();
        let existing = editId.value ? st.items.find((x) => x.id === editId.value) : null;
        let mergedExistingAccount = false;

        // When adding a new entry with the exact same (domain, username), update the existing account in place
        // instead of creating a duplicate card with the old password still lingering in Autofill!
        if (!existing && usr && doms.length > 0) {
          const usrLc = usr.toLowerCase();
          existing =
            st.items.find(
              (x) =>
                String(x.username || "").trim().toLowerCase() === usrLc &&
                doms.some((d) => OmniVaultCore.itemMatchesDomain(x, d) >= 3)
            ) ||
            st.items.find(
              (x) =>
                String(x.username || "").trim().toLowerCase() === usrLc &&
                doms.some((d) => OmniVaultCore.itemMatchesDomain(x, d) >= 2)
            ) ||
            null;
          if (existing) {
            mergedExistingAccount = true;
          }
        }

        const id = existing ? existing.id : editId.value || crypto.randomUUID();
        let passwordHistory = Array.isArray(existing?.password_history)
          ? [...existing.password_history]
          : [];
        if (existing && existing.password && existing.password !== pw) {
          passwordHistory = [
            { password: existing.password, changed_at_ms: now },
            ...passwordHistory
          ].slice(0, 10);
        }

        const mergedDomains = mergedExistingAccount
          ? Array.from(new Set([...(Array.isArray(existing.web_domains) ? existing.web_domains : []), ...doms]))
          : doms;
        const resolvedTotpSecret = mergedExistingAccount ? secret || existing.totp_secret || null : secret;
        const resolvedNotes = mergedExistingAccount ? notes || existing.notes || "" : notes;

        const nextRecord = OmniVaultCore.normalizeVaultItem({
          ...(existing || {}),
          id,
          service_name:
            srv ||
            (mergedExistingAccount ? existing.service_name : "") ||
            (mergedDomains[0] ? OmniVaultCore.prettifyDomainTitle(mergedDomains[0]) : "") ||
            usr ||
            "Tài khoản Web",
          username: usr,
          password: pw,
          password_history: passwordHistory,
          totp_secret: resolvedTotpSecret,
          totp_algorithm: parsedTotpMeta ? parsedTotpMeta.algorithm : existing?.totp_algorithm || "SHA1",
          totp_digits: parsedTotpMeta ? parsedTotpMeta.digits : existing?.totp_digits || 6,
          totp_period: parsedTotpMeta ? parsedTotpMeta.period : existing?.totp_period || 30,
          web_domains: mergedDomains,
          notes: resolvedNotes,
          created_at_ms: existing ? existing.created_at_ms : now,
          updated_at_ms: now
        });

        const idx = st.items.findIndex((x) => x.id === id);
        if (idx >= 0) {
          st.items[idx] = nextRecord;
        } else {
          st.items.push(nextRecord);
        }
        if (!st.deletedIds || typeof st.deletedIds !== "object") {
          st.deletedIds = {};
        }
        delete st.deletedIds[id];
        return { save: true, result: { record: nextRecord, updatedExisting: Boolean(existing) } };
      });

      const syncRes = await OmniVaultCore.syncBrowserVaultBidirectional(true);
      setVaultState(syncRes.state || (await OmniVaultCore.loadExtensionState()));
      if (currentState.hasPinLock) {
        await OmniVaultCore.touchAutoLockAlarm();
      }
      await sendRuntimeMsg({
        type: "DISMISS_PENDING_UPDATES_FOR_ITEM",
        itemId: record.record.id,
        domains: record.record.web_domains,
        username: record.record.username
      });
      clearEditorInputs();
      if (editorReturnView === "audit") {
        // Refresh HIBP breached list if edited item's password changed
        if (lastHibpResult && Array.isArray(lastHibpResult.breachedItems)) {
          lastHibpResult = {
            ...lastHibpResult,
            breachedItems: lastHibpResult.breachedItems.filter((b) => b.id !== record.record.id)
          };
        }
        openSecurityAuditView();
      } else {
        renderVaultList();
      }
      refreshPendingUpdatesBox().catch(() => {});
      showToast(
        record.updatedExisting
          ? `✓ Đã cập nhật mật khẩu mới & đồng bộ '${record.record.service_name}'`
          : `Đã lưu & đồng bộ '${record.record.service_name}'`
      );
    } catch (e) {
      showToast(String(e.message || e), true);
    } finally {
      btnSaveItem.disabled = false;
      btnSaveItem.textContent = "Lưu & Đồng bộ";
    }
  };

  btnDeleteItem.onclick = async () => {
    const id = editId.value;
    if (!id) return;
    if (!confirm("Xóa tài khoản này khỏi Trình duyệt và chuyển vào Thùng rác trên Điện thoại?")) {
      return;
    }
    btnDeleteItem.disabled = true;
    try {
      await OmniVaultCore.mutateVaultState((st) => {
        if (st.locked) {
          throw new Error("Kho tiện ích đang khóa — vui lòng nhập PIN trước khi xóa.");
        }
        st.items = st.items.filter((x) => x.id !== id);
        if (!st.deletedIds || typeof st.deletedIds !== "object") {
          st.deletedIds = {};
        }
        st.deletedIds[id] = Date.now();
        return { save: true, result: true };
      });
      const syncRes = await OmniVaultCore.syncBrowserVaultBidirectional(true);
      setVaultState(syncRes.state || (await OmniVaultCore.loadExtensionState()));
      if (currentState.hasPinLock) {
        await OmniVaultCore.touchAutoLockAlarm();
      }
      await sendRuntimeMsg({ type: "DISMISS_PENDING_UPDATES_FOR_ITEM", itemId: id });
      clearEditorInputs();
      if (editorReturnView === "audit") {
        if (lastHibpResult && Array.isArray(lastHibpResult.breachedItems)) {
          lastHibpResult = {
            ...lastHibpResult,
            breachedItems: lastHibpResult.breachedItems.filter((b) => b.id !== id)
          };
        }
        openSecurityAuditView();
      } else {
        renderVaultList();
      }
      refreshPendingUpdatesBox().catch(() => {});
      showToast("Đã xóa và đồng bộ");
    } catch (e) {
      showToast(String(e.message || e), true);
    } finally {
      btnDeleteItem.disabled = false;
    }
  };

  btnUnpair.onclick = async () => {
    if (!confirm("Ngắt kết nối kho mật khẩu trên trình duyệt này? (Dữ liệu trên điện thoại vẫn giữ nguyên)")) {
      return;
    }
    try {
      await sendRuntimeMsg({ type: "CLEAR_EPHEMERAL_CAPTURES" });
      setVaultState(await OmniVaultCore.unpairExtensionVault());
      renderVaultList();
      refreshPendingUpdatesBox().catch(() => {});
      showToast("Đã ngắt kết nối trình duyệt");
    } catch (e) {
      showToast(String(e.message || e), true);
    }
  };

  searchInput.addEventListener("input", () => {
    if (searchDebounceTimer) {
      clearTimeout(searchDebounceTimer);
      searchDebounceTimer = null;
    }
    if (!searchInput.value) {
      if (popupScrollArea) popupScrollArea.scrollTop = 0;
      renderVaultList();
      return;
    }
    searchDebounceTimer = setTimeout(() => {
      searchDebounceTimer = null;
      if (popupScrollArea) popupScrollArea.scrollTop = 0;
      renderVaultList();
    }, 60);
  });

  // React immediately when session locks externally (e.g. 15-min idle alarm) to clear sensitive popup DOM & RAM
  if (chrome?.storage?.onChanged?.addListener) {
    chrome.storage.onChanged.addListener((changes, areaName) => {
      if (areaName === "session" && changes && changes[OmniVaultCore.OMNIVAULT_SESSION_KEY]) {
        if (!changes[OmniVaultCore.OMNIVAULT_SESSION_KEY].newValue) {
          clearSensitivePopupCaches();
          OmniVaultCore.loadExtensionState()
            .then((st) => {
              setVaultState(st);
              renderVaultList();
            })
            .catch(() => {});
        }
      }
    });
  }

  // Smart 1s TOTP tick: updates countdown text only during 29/30s and runs WebCrypto HMAC
  // ONLY on visible cards when their TOTP step rolls over!
  setInterval(() => {
    if (!viewVault.hidden && currentState && !currentState.locked && currentState.pairing) {
      updateVisibleTotpPills(false).catch(() => {});
    }
  }, 1000);

  // Wipe cached TOTP keys and decrypted search index on popup close (INV-03)
  window.addEventListener("pagehide", () => {
    clearSensitivePopupCaches();
  });

  // Coalesced single-pass popup startup: 1 decrypt + 1 virtualized DOM paint!
  (async () => {
    const [, loadedState] = await Promise.all([
      detectActiveTab(),
      OmniVaultCore.loadExtensionState()
    ]);
    setVaultState(loadedState);
    renderVaultList();
    refreshPendingUpdatesBox().catch(() => {});
    refreshGitHubUpdateStatus(false).catch(() => {});

    if (currentState && !currentState.locked && currentState.pairing && !currentState.pairing.localOnly) {
      try {
        const syncRes = await OmniVaultCore.syncBrowserVaultBidirectional(false);
        // Only re-index & re-paint if remote actually delivered new/updated items!
        if (syncRes && syncRes.pulledCount > 0 && syncRes.state) {
          setVaultState(syncRes.state);
          renderVaultList();
        }
      } catch (_) {
        // Offline cached vault remains usable
      }
    }
  })();
})();
