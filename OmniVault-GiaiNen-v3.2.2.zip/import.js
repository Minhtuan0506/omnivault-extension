(() => {
  const deviceBadge = document.getElementById("deviceBadge");
  const pinUnlockCard = document.getElementById("pinUnlockCard");
  const importPinInput = document.getElementById("importPinInput");
  const btnUnlockInline = document.getElementById("btnUnlockInline");

  const pairingCard = document.getElementById("pairingCard");
  const pairingCodeInput = document.getElementById("pairingCodeInput");
  const btnPairInline = document.getElementById("btnPairInline");
  const btnStartLocalInline = document.getElementById("btnStartLocalInline");

  const browserChipRow = document.getElementById("browserChipRow");
  const exportUrlLabel = document.getElementById("exportUrlLabel");
  const btnOpenBrowserExport = document.getElementById("btnOpenBrowserExport");
  const btnCopyExportUrl = document.getElementById("btnCopyExportUrl");

  const csvFileInput = document.getElementById("csvFileInput");
  const dropZone = document.getElementById("dropZone");
  const btnAutoDetectExport = document.getElementById("btnAutoDetectExport");
  const btnSelectFile = document.getElementById("btnSelectFile");
  const btnPasteClipboard = document.getElementById("btnPasteClipboard");
  const btnExportBackupCsv = document.getElementById("btnExportBackupCsv");

  const previewCard = document.getElementById("previewCard");
  const previewHeading = document.getElementById("previewHeading");
  const btnClearPreview = document.getElementById("btnClearPreview");
  const diffNewCount = document.getElementById("diffNewCount");
  const diffUpdateCount = document.getElementById("diffUpdateCount");
  const diffSameCount = document.getElementById("diffSameCount");
  const diffWeakCount = document.getElementById("diffWeakCount");
  const chkSkipPwOverwrite = document.getElementById("chkSkipPwOverwrite");
  const autoShredWrap = document.getElementById("autoShredWrap");
  const chkAutoShredExport = document.getElementById("chkAutoShredExport");
  const autoShredLabel = document.getElementById("autoShredLabel");
  const previewFilterRow = document.getElementById("previewFilterRow");
  const btnSelectActionable = document.getElementById("btnSelectActionable");
  const btnUnselectAll = document.getElementById("btnUnselectAll");
  const previewSearchInput = document.getElementById("previewSearchInput");
  const previewList = document.getElementById("previewList");
  const btnPushSelected = document.getElementById("btnPushSelected");

  const statusBox = document.getElementById("statusBox");

  const MAX_IMPORT_FILE_BYTES = 16 * 1024 * 1024; // 16 MiB safety guard
  let currentState = null;
  let stagedRawItems = [];
  let stagedSourceLabels = [];
  let pendingAutoShredFiles = [];
  let openedExportAtMs = 0;
  let autoProbeInFlight = false;
  let currentDiff = null;
  let activePreviewFilter = "actionable";
  let previewRenderLimit = 100;

  // H2: Notify service worker while import tab is open so silent background auto-update won't interrupt import
  try {
    if (typeof chrome?.runtime?.connect === "function") {
      chrome.runtime.connect({ name: "omnivault_ui_open" });
    }
  } catch (_) {}

  function syncAutoShredUi() {
    if (!autoShredWrap) return;
    if (pendingAutoShredFiles.length === 0) {
      autoShredWrap.hidden = true;
      return;
    }
    autoShredWrap.hidden = false;
    if (autoShredLabel) {
      const names = pendingAutoShredFiles.map((f) => f.fileName).join(", ");
      autoShredLabel.textContent = `🧹 Tự xóa sạch file mật khẩu thô "${names}" khỏi Downloads ngay sau khi đẩy lên Máy chủ (an toàn tuyệt đối)`;
    }
  }

  function clearSensitiveImportState() {
    stagedRawItems = [];
    stagedSourceLabels = [];
    pendingAutoShredFiles = [];
    currentDiff = null;
    syncAutoShredUi();
    if (previewList) previewList.textContent = "";
    if (previewCard) previewCard.hidden = true;
    if (importPinInput) importPinInput.value = "";
    if (pairingCodeInput) pairingCodeInput.value = "";
    if (previewSearchInput) previewSearchInput.value = "";
    if (typeof OmniVaultCore?.clearTotpKeyCache === "function") {
      OmniVaultCore.clearTotpKeyCache();
    }
  }

  function detectBrowserProfile() {
    const ua = navigator.userAgent || "";
    if (ua.includes("Edg/")) {
      return { id: "edge", url: "edge://wallet/passwords" };
    }
    if (ua.includes("coc_coc_browser")) {
      return { id: "coccoc", url: "coccoc://password-manager/settings" };
    }
    if (navigator.brave) {
      return { id: "brave", url: "brave://password-manager/settings" };
    }
    return { id: "chrome", url: "chrome://password-manager/settings" };
  }

  let activeBrowserExportUrl = detectBrowserProfile().url;
  const detectedId = detectBrowserProfile().id;

  function syncBrowserChipUi() {
    exportUrlLabel.textContent = activeBrowserExportUrl;
    if (!browserChipRow) return;
    for (const chip of browserChipRow.querySelectorAll(".browser-chip")) {
      chip.classList.toggle("active", chip.dataset.url === activeBrowserExportUrl);
    }
  }

  if (browserChipRow) {
    const defaultChip = browserChipRow.querySelector(`.browser-chip[data-browser="${detectedId}"]`);
    if (defaultChip && defaultChip.dataset.url) {
      activeBrowserExportUrl = defaultChip.dataset.url;
    }
    browserChipRow.addEventListener("click", (ev) => {
      const btn = ev.target instanceof Element ? ev.target.closest(".browser-chip") : null;
      if (!btn || !btn.dataset.url) return;
      activeBrowserExportUrl = btn.dataset.url;
      syncBrowserChipUi();
    });
  }
  syncBrowserChipUi();

  function sendRuntimeMsg(payload) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(payload, (resp) => {
          void chrome.runtime.lastError;
          resolve(resp || null);
        });
      } catch (_) {
        resolve(null);
      }
    });
  }

  function showInfo(msg) {
    statusBox.hidden = false;
    statusBox.className = "banner info";
    statusBox.textContent = msg;
  }

  function showError(msg) {
    statusBox.hidden = false;
    statusBox.className = "banner error";
    statusBox.textContent = msg;
  }

  function showSuccessSummary(sourceSummary, res, shreddedFiles = []) {
    statusBox.hidden = false;
    statusBox.className = "banner success";
    statusBox.textContent = "";

    const isLocal = Boolean(currentState && currentState.pairing && currentState.pairing.localOnly);
    const heading = document.createElement("div");
    heading.style.fontWeight = "800";
    heading.style.fontSize = "14px";
    heading.textContent = isLocal
      ? `✅ Đã nhập mật khẩu từ ${sourceSummary} vào Kho cục bộ Trình duyệt!`
      : `✅ Đã mã hóa AES-256 & đẩy mật khẩu từ ${sourceSummary} lên Máy chủ thành công!`;
    statusBox.appendChild(heading);

    const grid = document.createElement("div");
    grid.className = "metrics-grid";

    const cells = [
      { val: String(res.addedCount), lbl: "Tài khoản thêm mới" },
      { val: String(res.updatedCount), lbl: "Cập nhật / Gộp trùng" },
      { val: String(res.totalServerCount), lbl: isLocal ? "Tổng trong Kho cục bộ" : "Tổng trên Máy chủ App" }
    ];
    for (const c of cells) {
      const well = document.createElement("div");
      well.className = "metric-well";
      const v = document.createElement("div");
      v.className = "metric-val";
      v.textContent = c.val;
      const l = document.createElement("div");
      l.className = "metric-lbl";
      l.textContent = c.lbl;
      well.appendChild(v);
      well.appendChild(l);
      grid.appendChild(well);
    }
    statusBox.appendChild(grid);

    const note = document.createElement("div");
    note.className = "security-note";
    if (Array.isArray(shreddedFiles) && shreddedFiles.length > 0) {
      note.textContent = `🧹 Đã tự ghi đè 0x00 và xóa sạch file mật khẩu thô (${shreddedFiles.join(", ")}) khỏi Downloads! Điện thoại sẽ tự đồng bộ đầy đủ danh sách này từ Máy chủ.`;
    } else {
      note.textContent =
        "🔒 Điện thoại của anh sẽ tự đồng bộ đầy đủ danh sách này từ Máy chủ. Hãy xóa ngay file .csv/.json tạm trong thư mục Downloads để bảo mật tuyệt đối!";
    }
    statusBox.appendChild(note);
  }

  async function refreshPairingUi() {
    currentState = await OmniVaultCore.loadExtensionState();
    if (currentState && currentState.locked) {
      deviceBadge.textContent = "🔒 Đang khóa PIN";
      deviceBadge.className = "status-pill unpaired";
      pinUnlockCard.hidden = false;
      pairingCard.hidden = true;
      btnExportBackupCsv.hidden = true;
      return;
    }
    pinUnlockCard.hidden = true;

    if (currentState && currentState.pairing) {
      deviceBadge.textContent = currentState.pairing.localOnly
        ? "Kho cục bộ Trình duyệt"
        : `Đã kết nối: ${currentState.pairing.deviceName}`;
      deviceBadge.className = "status-pill";
      pairingCard.hidden = true;
      btnExportBackupCsv.hidden = !(currentState.items && currentState.items.length > 0);
    } else {
      deviceBadge.textContent = "Chưa kết nối điện thoại";
      deviceBadge.className = "status-pill unpaired";
      pairingCard.hidden = false;
      btnExportBackupCsv.hidden = true;
    }
  }

  async function submitInlineUnlock() {
    const pin = String(importPinInput?.value || "");
    if (!pin) {
      showError("Vui lòng nhập mã PIN để mở khóa.");
      importPinInput?.focus();
      return;
    }
    btnUnlockInline.disabled = true;
    btnUnlockInline.textContent = "Đang mở khóa...";
    try {
      const resp = await sendRuntimeMsg({ type: "UNLOCK_EXTENSION_WITH_PIN", pin, includeState: false });
      if (!resp || !resp.ok) {
        showError(resp?.error || "Mã PIN không đúng.");
        importPinInput.value = "";
        importPinInput.focus();
        return;
      }
      importPinInput.value = "";
      await refreshPairingUi();
      showInfo("✓ Đã mở khóa phiên OmniVault! Anh có thể chọn file hoặc đẩy danh sách mật khẩu ngay.");
      if (stagedRawItems.length > 0) {
        rebuildDiffAndRender();
      }
    } finally {
      btnUnlockInline.disabled = false;
      btnUnlockInline.textContent = "🔓 Mở khóa ngay";
    }
  }

  if (btnUnlockInline) btnUnlockInline.onclick = submitInlineUnlock;
  if (importPinInput) {
    importPinInput.addEventListener("keydown", (ev) => {
      if (ev.key === "Enter") {
        ev.preventDefault();
        submitInlineUnlock();
      }
    });
  }

  if (btnStartLocalInline) {
    btnStartLocalInline.onclick = async () => {
      try {
        await OmniVaultCore.enableLocalStandaloneMode();
        await refreshPairingUi();
        showInfo("Đã bật Kho cục bộ trên trình duyệt! Anh có thể nạp file .CSV / .JSON ngay.");
        if (stagedRawItems.length > 0) rebuildDiffAndRender();
      } catch (e) {
        showError(String(e.message || e));
      }
    };
  }

  btnPairInline.onclick = async () => {
    const raw = (pairingCodeInput.value || "").trim();
    if (!raw) {
      showError("Vui lòng dán Mã Kết Nối (bắt đầu bằng OVB2- hoặc OVB1-) từ ứng dụng OmniVault trên điện thoại.");
      return;
    }
    btnPairInline.disabled = true;
    btnPairInline.textContent = "Đang kết nối...";
    try {
      const pairRes = await OmniVaultCore.pairWithCloudCode(raw);
      pairingCodeInput.value = "";
      await refreshPairingUi();
      showInfo(
        `Đã kết nối với thiết bị "${pairRes.pairing.deviceName}" (hiện có ${pairRes.itemCount} mật khẩu trên Máy chủ).`
      );
      if (stagedRawItems.length > 0) rebuildDiffAndRender();
    } catch (e) {
      showError(String(e.message || e));
    } finally {
      btnPairInline.disabled = false;
      btnPairInline.textContent = "Kết nối thiết bị ngay";
    }
  };

  btnOpenBrowserExport.onclick = async () => {
    openedExportAtMs = Date.now();
    try {
      await chrome.tabs.create({ url: activeBrowserExportUrl, active: true });
    } catch (_) {
      await navigator.clipboard.writeText(activeBrowserExportUrl);
      showInfo(
        `Đã chép "${activeBrowserExportUrl}" — anh mở tab mới và dán lên thanh địa chỉ để xuất file .CSV nhé.`
      );
    }
  };

  btnCopyExportUrl.onclick = async () => {
    try {
      await navigator.clipboard.writeText(activeBrowserExportUrl);
      showInfo(`Đã sao chép đường dẫn: ${activeBrowserExportUrl}`);
    } catch (_) {
      showError("Không thể sao chép tự động, anh hãy bôi đen đường dẫn ở Bước 1.");
    }
  };

  const yieldToBrowser = () =>
    typeof scheduler !== "undefined" && typeof scheduler.yield === "function"
      ? scheduler.yield()
      : new Promise((resolve) => setTimeout(resolve, 0));

  function updatePushButtonLabel() {
    if (!currentDiff) {
      btnPushSelected.disabled = true;
      return;
    }
    const selectedCount = currentDiff.entries.filter((e) => e.selected).length;
    btnPushSelected.disabled = selectedCount === 0;
    const isLocal = Boolean(currentState && currentState.pairing && currentState.pairing.localOnly);
    btnPushSelected.textContent =
      selectedCount > 0
        ? isLocal
          ? `🚀 Lưu ${selectedCount} tài khoản vào Kho cục bộ`
          : `🚀 Mã hóa AES-256 & Đẩy ${selectedCount} tài khoản lên Máy chủ`
        : "Chọn ít nhất 1 tài khoản để đẩy lên Máy chủ";
  }

  function renderPreviewList() {
    if (!currentDiff) {
      previewCard.hidden = true;
      return;
    }
    previewCard.hidden = false;
    diffNewCount.textContent = String(currentDiff.newCount);
    diffUpdateCount.textContent = String(currentDiff.updateCount);
    diffSameCount.textContent = String(currentDiff.unchangedCount);
    diffWeakCount.textContent = String(currentDiff.weakCount);

    const dupNote =
      currentDiff.intraBatchDupCount > 0 ? ` • Đã gộp ${currentDiff.intraBatchDupCount} dòng trùng trong file` : "";
    previewHeading.textContent = `Xem trước ${currentDiff.totalUnique} tài khoản (${stagedSourceLabels.length} nguồn${dupNote})`;

    const rawQ = String(previewSearchInput?.value || "").trim();
    const foldedQ = OmniVaultCore.foldSearchText(rawQ);

    const filtered = [];
    for (let i = 0; i < currentDiff.entries.length; i++) {
      const entry = currentDiff.entries[i];
      if (activePreviewFilter === "actionable" && entry.status === "unchanged") continue;
      if (activePreviewFilter === "new" && entry.status !== "new") continue;
      if (activePreviewFilter === "update" && entry.status !== "update") continue;
      if (foldedQ) {
        const hay = OmniVaultCore.foldSearchText(
          `${entry.item.service_name} ${entry.item.username} ${(entry.item.web_domains || []).join(" ")}`
        );
        if (!hay.includes(foldedQ)) continue;
      }
      filtered.push({ entry, idx: i });
    }

    previewList.textContent = "";
    if (filtered.length === 0) {
      const empty = document.createElement("div");
      empty.className = "preview-row";
      empty.style.justifyContent = "center";
      empty.style.color = "#64748b";
      empty.textContent =
        activePreviewFilter === "actionable" && currentDiff.unchangedCount > 0
          ? "Tất cả tài khoản trong file đều đã có y hệt trên OmniVault!"
          : "Không có tài khoản phù hợp bộ lọc này.";
      previewList.appendChild(empty);
      updatePushButtonLabel();
      return;
    }

    const slice = filtered.slice(0, previewRenderLimit);
    const frag = document.createDocumentFragment();
    for (const { entry, idx } of slice) {
      const row = document.createElement("label");
      row.className = "preview-row";

      const cb = document.createElement("input");
      cb.type = "checkbox";
      cb.checked = Boolean(entry.selected);
      cb.dataset.diffIdx = String(idx);
      row.appendChild(cb);

      const main = document.createElement("div");
      main.className = "preview-main";
      const title = document.createElement("div");
      title.className = "preview-title";
      title.textContent = entry.item.service_name || entry.item.web_domains?.[0] || "Tài khoản Web";
      const sub = document.createElement("div");
      sub.className = "preview-sub";
      const dom = entry.item.web_domains?.[0] || entry.item.android_packages?.[0] || "";
      sub.textContent = [entry.item.username || "(Chưa có TK)", dom].filter(Boolean).join(" • ");
      main.appendChild(title);
      main.appendChild(sub);
      row.appendChild(main);

      if (entry.item.totp_secret) {
        const totpTag = document.createElement("span");
        totpTag.className = "row-tag totp";
        totpTag.textContent = "2FA";
        row.appendChild(totpTag);
      }

      const tag = document.createElement("span");
      tag.className = `row-tag ${entry.status}`;
      tag.textContent = entry.reason;
      row.appendChild(tag);

      frag.appendChild(row);
    }

    if (filtered.length > slice.length) {
      const moreRow = document.createElement("div");
      moreRow.className = "preview-row";
      moreRow.style.justifyContent = "center";
      const moreBtn = document.createElement("button");
      moreBtn.type = "button";
      moreBtn.className = "btn btn-outline btn-sm";
      moreBtn.textContent = `Hiển thị thêm (${filtered.length - slice.length} tài khoản còn lại)`;
      moreBtn.onclick = () => {
        previewRenderLimit += 150;
        renderPreviewList();
      };
      moreRow.appendChild(moreBtn);
      frag.appendChild(moreRow);
    }

    previewList.appendChild(frag);
    updatePushButtonLabel();
  }

  function rebuildDiffAndRender() {
    if (stagedRawItems.length === 0) {
      currentDiff = null;
      previewCard.hidden = true;
      return;
    }
    const existingItems = currentState && !currentState.locked && Array.isArray(currentState.items)
      ? currentState.items
      : [];
    currentDiff = OmniVaultCore.analyzeImportDiff(existingItems, stagedRawItems, {
      skipPasswordOverwrite: Boolean(chkSkipPwOverwrite?.checked)
    });
    previewRenderLimit = 100;
    activePreviewFilter =
      currentDiff.newCount + currentDiff.updateCount > 0 ? "actionable" : "all";
    for (const pill of previewFilterRow.querySelectorAll(".filter-pill")) {
      pill.classList.toggle("active", pill.dataset.filter === activePreviewFilter);
    }
    renderPreviewList();
  }

  async function ingestTextSources(sources) {
    if (!Array.isArray(sources) || sources.length === 0) return;
    await refreshPairingUi();

    btnSelectFile.disabled = true;
    btnPasteClipboard.disabled = true;
    showInfo(`⏳ Đang đọc & phân tích ${sources.length} nguồn dữ liệu mật khẩu...`);
    try {
      const allParsed = [];
      const labels = [];
      let lastProgressUiMs = 0;

      for (const src of sources) {
        if (typeof src.text === "string" && src.text.length > MAX_IMPORT_FILE_BYTES) {
          throw new Error(`Nguồn "${src.label}" vượt quá giới hạn an toàn 16 MB.`);
        }
        const parsed =
          typeof OmniVaultCore.parseBrowserPasswordsTextAsync === "function"
            ? await OmniVaultCore.parseBrowserPasswordsTextAsync(src.text, {
                yieldEvery: 100,
                yieldFn: yieldToBrowser,
                onProgress: (done, total) => {
                  const now = Date.now();
                  if (total > 200 && (done === total || now - lastProgressUiMs >= 120)) {
                    lastProgressUiMs = now;
                    showInfo(`⏳ Đang phân tích "${src.label}": ${done}/${total} dòng...`);
                  }
                }
              })
            : OmniVaultCore.parseBrowserPasswordsText(src.text);
        for (const it of parsed) allParsed.push(it);
        labels.push(src.label);
      }

      if (allParsed.length === 0) {
        throw new Error("Không tìm thấy tài khoản hợp lệ nào trong dữ liệu đã nạp.");
      }

      stagedRawItems = [...stagedRawItems, ...allParsed];
      stagedSourceLabels = [...stagedSourceLabels, ...labels];
      rebuildDiffAndRender();

      const actionable = currentDiff.newCount + currentDiff.updateCount;
      showInfo(
        actionable > 0
          ? `✓ Đã phân tích ${currentDiff.totalUnique} tài khoản (${currentDiff.newCount} mới, ${currentDiff.updateCount} cập nhật, ${currentDiff.unchangedCount} trùng). Bấm nút xanh ở Bước 3 để đẩy lên Máy chủ!`
          : `✓ Đã kiểm tra ${currentDiff.totalUnique} tài khoản — toàn bộ đều đã tồn tại y hệt trên OmniVault.`
      );
      previewCard.scrollIntoView({ behavior: "smooth", block: "nearest" });
    } catch (e) {
      showError(String(e.message || e));
    } finally {
      btnSelectFile.disabled = false;
      btnPasteClipboard.disabled = false;
      csvFileInput.value = "";
    }
  }

  async function ingestFileList(fileList) {
    const files = Array.from(fileList || []).filter(Boolean);
    if (files.length === 0) return;
    const sources = [];
    for (const f of files) {
      if (Number(f.size) > MAX_IMPORT_FILE_BYTES) {
        showError(`Tệp "${f.name}" quá lớn (${(f.size / (1024 * 1024)).toFixed(1)} MB — giới hạn tối đa 16 MB).`);
        return;
      }
      const text = await f.text();
      sources.push({ label: f.name, text });
    }
    await ingestTextSources(sources);
  }

  async function openDownloadsFilePicker() {
    if (typeof window.showOpenFilePicker === "function") {
      try {
        const handles = await window.showOpenFilePicker({
          id: "omnivault-csv-import",
          startIn: "downloads",
          multiple: true,
          types: [
            {
              description: "File mật khẩu trình duyệt (.csv / .json)",
              accept: {
                "text/csv": [".csv"],
                "application/json": [".json"]
              }
            }
          ]
        });
        const files = [];
        for (const h of handles) {
          files.push(await h.getFile());
        }
        await ingestFileList(files);
        return;
      } catch (e) {
        if (e && e.name === "AbortError") return;
      }
    }
    csvFileInput.click();
  }

  function isStoreDistributionBuild() {
    const manifest = chrome?.runtime?.getManifest ? chrome.runtime.getManifest() : {};
    const updateUrl = String(manifest.update_url || "").toLowerCase();
    if (
      updateUrl.includes("clients2.google.com") ||
      updateUrl.includes("edge.microsoft.com")
    ) {
      return true;
    }
    const perms = Array.isArray(manifest.permissions) ? manifest.permissions : [];
    return !manifest.key && !perms.includes("nativeMessaging");
  }

  const storeDistribution = isStoreDistributionBuild();

  if (storeDistribution && btnAutoDetectExport) {
    btnAutoDetectExport.textContent = "📂 Mở thư mục Downloads (1 chạm)";
  }

  async function autoDetectLatestExportFromDownloads({ silentIfMissing = false, minWriteMs = 0 } = {}) {
    if (storeDistribution) {
      if (!silentIfMissing) {
        await openDownloadsFilePicker();
      }
      return false;
    }
    if (autoProbeInFlight) return false;
    autoProbeInFlight = true;
    if (btnAutoDetectExport && !silentIfMissing) {
      btnAutoDetectExport.disabled = true;
      btnAutoDetectExport.textContent = "⏳ Đang quét file mới xuất trong Downloads...";
    }
    try {
      const res = await sendRuntimeMsg({
        type: "READ_LATEST_PASSWORD_EXPORT",
        maxAgeMinutes: minWriteMs > 0 ? 15 : 1440
      });
      if (!res || res.nativeAvailable === false) {
        if (!silentIfMissing) {
          showInfo(
            "Chưa bật Native Host (Bat-TuDongCapNhat-100.bat) — đang mở thẳng thư mục Downloads để anh chọn file nhanh (1 chạm)."
          );
          await openDownloadsFilePicker();
        }
        return false;
      }
      if (!res.ok) {
        if (!silentIfMissing) showError(res.error || "Không đọc được file xuất mật khẩu trong Downloads.");
        return false;
      }
      if (!res.found || !res.text) {
        if (!silentIfMissing) {
          showInfo(
            "Chưa thấy file xuất mật khẩu (.csv / .json) mới trong Downloads. Bấm nút ở Bước 1 để xuất mật khẩu từ trình duyệt, rồi quay lại đây!"
          );
        }
        return false;
      }
      if (minWriteMs > 0 && Number(res.lastWriteMs || 0) < minWriteMs) {
        return false;
      }
      const alreadyStaged = pendingAutoShredFiles.some((f) => f.sha256 === res.sha256 && f.fileName === res.fileName);
      if (alreadyStaged) {
        if (!silentIfMissing) {
          showInfo(`File "${res.fileName}" đã được nạp sẵn ở Bước 3 bên dưới.`);
        }
        return true;
      }
      await ingestTextSources([{ label: res.fileName, text: res.text }]);
      if (stagedRawItems.length > 0) {
        pendingAutoShredFiles.push({
          fileName: res.fileName,
          sha256: res.sha256,
          sizeBytes: res.sizeBytes
        });
        syncAutoShredUi();
      }
      openedExportAtMs = 0;
      return true;
    } finally {
      autoProbeInFlight = false;
      if (btnAutoDetectExport) {
        btnAutoDetectExport.disabled = false;
        btnAutoDetectExport.textContent = "⚡ Tự lấy file vừa xuất trong Downloads (1 chạm)";
      }
    }
  }

  if (btnAutoDetectExport) {
    btnAutoDetectExport.onclick = () => {
      autoDetectLatestExportFromDownloads({ silentIfMissing: false }).catch(() => {});
    };
  }

  // Seamless return-to-tab magic: after clicking Step 1 "Mở trang Xuất mật khẩu",
  // returning to this tab automatically detects the freshly exported CSV/CXF in Downloads!
  function tryAutoDetectAfterReturn() {
    if (!openedExportAtMs || stagedRawItems.length > 0 || document.visibilityState === "hidden") return;
    if (Date.now() - openedExportAtMs > 15 * 60 * 1000) {
      openedExportAtMs = 0;
      return;
    }
    autoDetectLatestExportFromDownloads({
      silentIfMissing: true,
      minWriteMs: openedExportAtMs - 5000
    }).catch(() => {});
  }
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible") tryAutoDetectAfterReturn();
  });
  window.addEventListener("focus", tryAutoDetectAfterReturn);

  btnSelectFile.onclick = openDownloadsFilePicker;
  dropZone.onclick = openDownloadsFilePicker;

  csvFileInput.onchange = () => {
    if (csvFileInput.files && csvFileInput.files.length > 0) {
      ingestFileList(csvFileInput.files);
    }
  };

  btnPasteClipboard.onclick = async () => {
    try {
      const clipText = await navigator.clipboard.readText();
      if (!clipText || !clipText.trim()) {
        showError("Clipboard đang trống. Hãy sao chép nội dung file CSV/JSON rồi bấm lại.");
        return;
      }
      await ingestTextSources([{ label: "Clipboard", text: clipText }]);
    } catch (_) {
      showInfo("Anh có thể nhấn trực tiếp Ctrl+V bất kỳ đâu trên trang này để dán nội dung CSV/JSON!");
    }
  };

  document.addEventListener("paste", (ev) => {
    const active = document.activeElement;
    if (active && (active.tagName === "INPUT" || active.tagName === "TEXTAREA")) return;
    const txt = ev.clipboardData?.getData("text/plain") || "";
    if (txt.trim().length > 10) {
      ev.preventDefault();
      ingestTextSources([{ label: "Clipboard (Ctrl+V)", text: txt }]);
    }
  });

  dropZone.addEventListener("dragover", (ev) => {
    ev.preventDefault();
    dropZone.classList.add("dragover");
  });

  dropZone.addEventListener("dragleave", () => {
    dropZone.classList.remove("dragover");
  });

  dropZone.addEventListener("drop", (ev) => {
    ev.preventDefault();
    dropZone.classList.remove("dragover");
    if (ev.dataTransfer && ev.dataTransfer.files && ev.dataTransfer.files.length > 0) {
      ingestFileList(ev.dataTransfer.files);
    }
  });

  previewList.addEventListener("change", (ev) => {
    const t = ev.target;
    if (!(t instanceof HTMLInputElement) || t.type !== "checkbox" || !currentDiff) return;
    const idx = Number(t.dataset.diffIdx);
    if (Number.isInteger(idx) && currentDiff.entries[idx]) {
      currentDiff.entries[idx].selected = t.checked;
      updatePushButtonLabel();
    }
  });

  previewFilterRow.addEventListener("click", (ev) => {
    const btn = ev.target instanceof Element ? ev.target.closest(".filter-pill") : null;
    if (!btn || !btn.dataset.filter) return;
    activePreviewFilter = btn.dataset.filter;
    previewRenderLimit = 100;
    for (const pill of previewFilterRow.querySelectorAll(".filter-pill")) {
      pill.classList.toggle("active", pill.dataset.filter === activePreviewFilter);
    }
    renderPreviewList();
  });

  previewSearchInput.addEventListener("input", () => {
    previewRenderLimit = 100;
    renderPreviewList();
  });

  chkSkipPwOverwrite.addEventListener("change", () => {
    rebuildDiffAndRender();
  });

  btnSelectActionable.onclick = () => {
    if (!currentDiff) return;
    for (const e of currentDiff.entries) {
      e.selected = e.status !== "unchanged";
    }
    renderPreviewList();
  };

  btnUnselectAll.onclick = () => {
    if (!currentDiff) return;
    for (const e of currentDiff.entries) {
      e.selected = false;
    }
    renderPreviewList();
  };

  btnClearPreview.onclick = () => {
    clearSensitiveImportState();
    statusBox.hidden = true;
  };

  btnPushSelected.onclick = async () => {
    if (!currentDiff) return;
    await refreshPairingUi();
    if (currentState && currentState.locked) {
      pinUnlockCard.hidden = false;
      importPinInput?.focus();
      showError("Vui lòng nhập mã PIN ở khung trên để mở khóa trước khi đẩy lên Máy chủ.");
      return;
    }
    if (!currentState || !currentState.pairing) {
      pairingCard.hidden = false;
      pairingCodeInput?.focus();
      showError("Vui lòng dán Mã Kết Nối (OVB2-/OVB1-) hoặc bật Kho cục bộ trước khi đẩy.");
      return;
    }

    const chosenItems = currentDiff.entries.filter((e) => e.selected).map((e) => e.item);
    if (chosenItems.length === 0) {
      showError("Chưa chọn tài khoản nào để đẩy lên Máy chủ.");
      return;
    }

    btnPushSelected.disabled = true;
    btnPushSelected.textContent = "⏳ Đang mã hóa AES-256 & đẩy lên Máy chủ...";
    showInfo(`⏳ Đang mã hóa AES-256-GCM và đồng bộ ${chosenItems.length} tài khoản lên Máy chủ App...`);
    try {
      const res = await OmniVaultCore.importAndPushAllToServer(chosenItems, {
        skipPasswordOverwrite: Boolean(chkSkipPwOverwrite?.checked)
      });
      const labelSummary =
        stagedSourceLabels.length === 1
          ? `"${stagedSourceLabels[0]}"`
          : `${stagedSourceLabels.length} nguồn (${stagedSourceLabels.slice(0, 2).join(", ")}${stagedSourceLabels.length > 2 ? "..." : ""})`;

      const filesToShred = chkAutoShredExport?.checked ? [...pendingAutoShredFiles] : [];
      const shreddedNames = [];
      for (const f of filesToShred) {
        const delRes = await sendRuntimeMsg({
          type: "DELETE_IMPORTED_PASSWORD_EXPORT",
          fileName: f.fileName,
          sha256: f.sha256,
          sizeBytes: f.sizeBytes
        });
        if (delRes && delRes.ok && delRes.deleted) {
          shreddedNames.push(f.fileName);
        }
      }

      stagedRawItems = [];
      stagedSourceLabels = [];
      pendingAutoShredFiles = [];
      currentDiff = null;
      syncAutoShredUi();
      previewCard.hidden = true;
      await refreshPairingUi();
      showSuccessSummary(labelSummary, res, shreddedNames);
    } catch (e) {
      showError(String(e.message || e));
      updatePushButtonLabel();
    }
  };

  btnExportBackupCsv.onclick = async () => {
    const st = await OmniVaultCore.loadExtensionState();
    if (st.locked) {
      showError("Tiện ích đang khóa bằng PIN! Hãy mở khóa trước khi xuất CSV.");
      return;
    }
    const csv = OmniVaultCore.exportVaultToChromeCsv(st.items || []);
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "omnivault_matkhau_trinhduyet.csv";
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  };

  // H7: Wipe staged plaintext import items & preview DOM immediately on session lock or tab close (INV-03)
  if (chrome?.storage?.onChanged?.addListener) {
    chrome.storage.onChanged.addListener((changes, areaName) => {
      if (areaName === "session" && changes && changes[OmniVaultCore.OMNIVAULT_SESSION_KEY]) {
        if (!changes[OmniVaultCore.OMNIVAULT_SESSION_KEY].newValue) {
          clearSensitiveImportState();
          refreshPairingUi().catch(() => {});
        }
      }
    });
  }
  window.addEventListener("pagehide", () => {
    clearSensitiveImportState();
  });

  refreshPairingUi();
})();
