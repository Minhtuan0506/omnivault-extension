// ============================================================================
// OmniVault Browser Sync & Crypto Core (100% Byte-Compatible with Rust Core)
// Encryption: AES-256-GCM (12-byte IV + Ciphertext || 16-byte GCM Tag)
// TOTP: RFC 6238 (SHA1 / SHA256 / SHA512)
// ============================================================================

((globalScope) => {
"use strict";

const OMNIVAULT_STORAGE_KEY = "omnivault_state_v1";
const OMNIVAULT_META_FLAGS_KEY = "omnivault_meta_flags_v1";
const OMNIVAULT_HOT_RECENCY_KEY = "omnivault_hot_recency_v1";
const OMNIVAULT_JWT_CACHE_KEY = "omnivault_jwt_cache_v1";
const OMNIVAULT_SESSION_KEY = "omnivault_session_wrap_key_b64";
const OMNIVAULT_SESSION_EXPIRES_KEY = "omnivault_session_expires_at_ms";
const OMNIVAULT_PIN_FAILS_KEY = "omnivault_pin_fails_v1";
const OMNIVAULT_AUTOLOCK_ALARM = "omnivault_autolock";
const OMNIVAULT_PENDING_UPDATES_KEY = "omnivault_pending_updates_v1";
const OMNIVAULT_PENDING_INLINE_UNLOCK_KEY = "omnivault_pending_inline_unlock_v1";
const OMNIVAULT_STEP1_USERS_KEY = "omnivault_step1_users_v1";
const OMNIVAULT_UNPAIRED_HINTS_KEY = "omnivault_unpaired_hints_v1";
const VAULT_MUTATION_LOCK_NAME = "omnivault_vault_mutation_lock";
const SESSION_KEY_IDB_NAME = "omnivault_ephemeral_keys_v1";
const SESSION_KEY_IDB_STORE = "session_keys";
const SESSION_KEY_IDB_RECORD_ID = "active_wrap_key";
const _knownIdbHandleIds = new Set();
const SESSION_AUTOLOCK_MS = 15 * 60 * 1000;
const LEGACY_PIN_PBKDF2_ITERS = 310000;
const PIN_PBKDF2_ITERS = 600000;
const MAX_HOT_RECENCY_ENTRIES = 2000;
const DEFAULT_FETCH_TIMEOUT_MS = 20000;

const TEXT_ENCODER = new TextEncoder();
const TEXT_DECODER = new TextDecoder("utf-8");
const VI_COLLATOR = new Intl.Collator("vi");

async function fetchWithTimeout(url, options = {}, timeoutMs = DEFAULT_FETCH_TIMEOUT_MS, fetchImpl = null) {
  const doFetch =
    typeof fetchImpl === "function"
      ? fetchImpl
      : typeof globalScope.fetch === "function"
      ? globalScope.fetch.bind(globalScope)
      : fetch;
  const ms = Math.max(1000, Number(timeoutMs) || DEFAULT_FETCH_TIMEOUT_MS);
  const opts = options && typeof options === "object" ? { ...options } : {};
  let timer = null;
  if (!opts.signal) {
    if (typeof AbortSignal !== "undefined" && typeof AbortSignal.timeout === "function") {
      opts.signal = AbortSignal.timeout(ms);
    } else if (typeof AbortController !== "undefined") {
      const controller = new AbortController();
      opts.signal = controller.signal;
      timer = setTimeout(() => {
        try {
          controller.abort(new DOMException("Request timed out", "TimeoutError"));
        } catch (_) {
          controller.abort();
        }
      }, ms);
    }
  }
  try {
    return await doFetch(url, opts);
  } finally {
    if (timer !== null) clearTimeout(timer);
  }
}

function bytesToBase64Chunked(u8) {
  const CHUNK = 0x8000;
  if (u8.length <= CHUNK) {
    return btoa(String.fromCharCode.apply(null, u8));
  }
  const parts = [];
  for (let i = 0; i < u8.length; i += CHUNK) {
    parts.push(String.fromCharCode.apply(null, u8.subarray(i, i + CHUNK)));
  }
  return btoa(parts.join(""));
}

function bytesToBase64(bytes) {
  const u8 = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  if (u8.length === 0) return "";
  if (typeof u8.toBase64 === "function") {
    return u8.toBase64();
  }
  return bytesToBase64Chunked(u8);
}

function base64ToBytes(b64) {
  const clean = (b64 || "").trim().replace(/\s+/g, "");
  if (!clean) return new Uint8Array(0);
  if (typeof Uint8Array.fromBase64 === "function") {
    return Uint8Array.fromBase64(clean);
  }
  const bin = atob(clean);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) {
    out[i] = bin.charCodeAt(i);
  }
  return out;
}

function bytesToBase64Url(bytes) {
  return bytesToBase64(bytes).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

function base64UrlToBytes(b64url) {
  let s = (b64url || "").trim().replace(/-/g, "+").replace(/_/g, "/");
  while (s.length % 4 !== 0) s += "=";
  return base64ToBytes(s);
}

function normalizeStandardBase64(raw) {
  const clean = String(raw || "").trim().replace(/\s+/g, "");
  if (!clean) return "";
  try {
    return bytesToBase64(base64UrlToBytes(clean));
  } catch (_) {
    return clean;
  }
}

const BROWSER_VAULT_HKDF_SALT = TEXT_ENCODER.encode("OMNIVAULT_HKDF_SALT_V2");
const BROWSER_VAULT_HKDF_INFO = TEXT_ENCODER.encode("omnivault-browser-vault-v2");
const BROWSER_VAULT_AAD = TEXT_ENCODER.encode("omnivault-browser-vault");
const MAX_BROWSER_TOMBSTONES = 2000;
let _vaultMutationLockTail = Promise.resolve();

function isAllowedGitHubUpdateUrl(rawUrl) {
  if (!rawUrl) return false;
  try {
    const u = new URL(String(rawUrl).trim());
    if (u.protocol !== "https:") return false;
    if (u.username || u.password) return false;
    const host = u.hostname.toLowerCase();
    const pathname = u.pathname || "";
    if (host === "github.com") {
      return /^\/Minhtuan0506\/omnivault-extension(?:\/|$)/i.test(pathname);
    }
    if (host === "minhtuan0506.github.io") {
      return /^\/omnivault-extension(?:\/|$)/i.test(pathname);
    }
    return false;
  } catch (_) {
    return false;
  }
}

function parsePairingCode(raw) {
  const trimmed = (raw || "").trim();
  const prefix = trimmed.startsWith("OVB2-")
    ? "OVB2-"
    : trimmed.startsWith("OVB1-")
    ? "OVB1-"
    : "";
  if (!prefix) {
    throw new Error("Mã kết nối không hợp lệ (phải bắt đầu bằng OVB2- hoặc OVB1-).");
  }
  const encoded = trimmed.slice(prefix.length);
  let jsonStr;
  try {
    jsonStr = new TextDecoder("utf-8").decode(base64UrlToBytes(encoded));
  } catch (_) {
    throw new Error("Không giải mã được Mã Kết Nối. Vui lòng sao chép lại từ điện thoại.");
  }
  let parsed;
  try {
    parsed = JSON.parse(jsonStr);
  } catch (_) {
    throw new Error("Cấu trúc Mã Kết Nối không hợp lệ.");
  }
  if (!parsed.u || !parsed.k || !parsed.e || !parsed.p || !parsed.d || !parsed.s) {
    throw new Error("Mã Kết Nối thiếu thông tin máy chủ hoặc khóa giải mã.");
  }
  let parsedUrl;
  try {
    parsedUrl = new URL(String(parsed.u).trim());
  } catch (_) {
    throw new Error("Địa chỉ máy chủ trong Mã Kết Nối không hợp lệ.");
  }
  const host = parsedUrl.hostname.toLowerCase();
  const isLoopback = host === "localhost" || host === "127.0.0.1" || host === "::1" || host === "[::1]";
  if (parsedUrl.protocol !== "https:" && !(parsedUrl.protocol === "http:" && isLoopback)) {
    throw new Error("Máy chủ đồng bộ bắt buộc phải sử dụng HTTPS (chỉ cho phép HTTP với localhost).");
  }
  const keyBytes = base64ToBytes(parsed.s);
  if (keyBytes.length !== 32) {
    throw new Error("Khóa mã hóa trình duyệt không đúng chuẩn AES-256 (32 byte).");
  }
  return {
    version: parsed.v || (prefix === "OVB2-" ? 2 : 1),
    supabaseUrl: String(parsed.u).trim().replace(/\/+$/, ""),
    supabaseAnonKey: String(parsed.k).trim(),
    syncEmail: String(parsed.e).trim(),
    syncPassword: String(parsed.p).trim(),
    deviceId: String(parsed.d).trim(),
    deviceName: String(parsed.n || parsed.d).trim(),
    syncKeyB64: String(parsed.s).trim()
  };
}

async function importAesKey(syncKeyB64) {
  const rawKey = base64ToBytes(syncKeyB64);
  return crypto.subtle.importKey("raw", rawKey, { name: "AES-GCM" }, false, [
    "encrypt",
    "decrypt"
  ]);
}

async function deriveBrowserVaultV2Key(syncKeyB64, usage) {
  const rawKey = base64ToBytes(syncKeyB64);
  if (rawKey.length !== 32) {
    throw new Error("Khóa mã hóa trình duyệt không đúng chuẩn 32 byte.");
  }
  const ikm = await crypto.subtle.importKey("raw", rawKey, "HKDF", false, ["deriveKey"]);
  return crypto.subtle.deriveKey(
    {
      name: "HKDF",
      hash: "SHA-256",
      salt: BROWSER_VAULT_HKDF_SALT,
      info: BROWSER_VAULT_HKDF_INFO
    },
    ikm,
    { name: "AES-GCM", length: 256 },
    false,
    [usage]
  );
}

async function encryptBrowserVaultPayload(syncKeyB64, obj) {
  const key = await deriveBrowserVaultV2Key(syncKeyB64, "encrypt");
  const nonce = crypto.getRandomValues(new Uint8Array(12));
  const plainBytes = TEXT_ENCODER.encode(JSON.stringify(obj));
  const ctBuf = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv: nonce, additionalData: BROWSER_VAULT_AAD, tagLength: 128 },
    key,
    plainBytes
  );
  return {
    nonceB64: bytesToBase64(nonce),
    ciphertextB64: bytesToBase64(new Uint8Array(ctBuf))
  };
}

async function decryptBrowserVaultPayload(syncKeyB64, nonceB64, ciphertextB64) {
  const nonce = base64ToBytes(nonceB64);
  const ct = base64ToBytes(ciphertextB64);
  try {
    const v2Key = await deriveBrowserVaultV2Key(syncKeyB64, "decrypt");
    const plainBuf = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv: nonce, additionalData: BROWSER_VAULT_AAD, tagLength: 128 },
      v2Key,
      ct
    );
    const text = TEXT_DECODER.decode(plainBuf);
    return JSON.parse(text);
  } catch (_) {
    // Backward compatibility fallback for v1 un-HKDF browser_vault payloads
    return aes256DecryptJson(syncKeyB64, nonceB64, ciphertextB64);
  }
}

async function aes256EncryptJsonWithKey(cryptoKey, obj) {
  const nonce = crypto.getRandomValues(new Uint8Array(12));
  const plainBytes = TEXT_ENCODER.encode(JSON.stringify(obj));
  const ctBuf = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv: nonce, tagLength: 128 },
    cryptoKey,
    plainBytes
  );
  return {
    nonceB64: bytesToBase64(nonce),
    ciphertextB64: bytesToBase64(new Uint8Array(ctBuf))
  };
}

async function aes256DecryptJsonWithKey(cryptoKey, nonceB64, ciphertextB64) {
  const nonce = base64ToBytes(nonceB64);
  const ct = base64ToBytes(ciphertextB64);
  const plainBuf = await crypto.subtle.decrypt(
    { name: "AES-GCM", iv: nonce, tagLength: 128 },
    cryptoKey,
    ct
  );
  const text = TEXT_DECODER.decode(plainBuf);
  return JSON.parse(text);
}

async function aes256EncryptJson(syncKeyB64, obj) {
  const key = await importAesKey(syncKeyB64);
  return aes256EncryptJsonWithKey(key, obj);
}

async function aes256DecryptJson(syncKeyB64, nonceB64, ciphertextB64) {
  const key = await importAesKey(syncKeyB64);
  return aes256DecryptJsonWithKey(key, nonceB64, ciphertextB64);
}

// --- RFC 6238 TOTP Generator (with Non-Extractable HMAC CryptoKey Cache) ---
const _totpHmacKeyCache = new Map();
const MAX_TOTP_KEY_CACHE_SIZE = 512;

function clearTotpKeyCache() {
  _totpHmacKeyCache.clear();
}

function getTotpKeyCacheSize() {
  return _totpHmacKeyCache.size;
}

function computeTotpStep(period = 30, nowMs = Date.now()) {
  const p = Math.max(1, Number(period) || 30);
  const epochSec = Math.floor(nowMs / 1000);
  return {
    step: Math.floor(epochSec / p),
    remainingSeconds: p - (epochSec % p),
    period: p
  };
}

function decodeBase32(secret) {
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
  const clean = (secret || "")
    .toUpperCase()
    .replace(/[\s\-=]+/g, "");
  if (!clean) return new Uint8Array(0);
  let bits = 0;
  let value = 0;
  const out = [];
  for (let i = 0; i < clean.length; i++) {
    const idx = alphabet.indexOf(clean[i]);
    if (idx === -1) continue;
    value = (value << 5) | idx;
    bits += 5;
    if (bits >= 8) {
      out.push((value >>> (bits - 8)) & 0xff);
      bits -= 8;
    }
  }
  return new Uint8Array(out);
}

async function getOrImportTotpHmacKey(secret, hashName) {
  const cleanSec = String(secret || "")
    .toUpperCase()
    .replace(/[\s\-=]+/g, "");
  if (!cleanSec) return null;
  const cacheKey = `${hashName}:${cleanSec}`;
  const cached = _totpHmacKeyCache.get(cacheKey);
  if (cached) return cached;

  const keyBytes = decodeBase32(cleanSec);
  if (!keyBytes.length) return null;

  const hmacKey = await crypto.subtle.importKey(
    "raw",
    keyBytes,
    { name: "HMAC", hash: { name: hashName } },
    false,
    ["sign"]
  );
  if (_totpHmacKeyCache.size >= MAX_TOTP_KEY_CACHE_SIZE) {
    // Evict oldest entry to keep RAM bounded
    const oldestKey = _totpHmacKeyCache.keys().next().value;
    if (oldestKey !== undefined) _totpHmacKeyCache.delete(oldestKey);
  }
  _totpHmacKeyCache.set(cacheKey, hmacKey);
  return hmacKey;
}

async function computeTotpCode(secret, digits = 6, period = 30, algorithm = "SHA1", nowMs = Date.now()) {
  const algUpper = String(algorithm || "SHA1").toUpperCase();
  const hashName =
    algUpper === "SHA256"
      ? "SHA-256"
      : algUpper === "SHA512"
      ? "SHA-512"
      : "SHA-1";
  const hmacKey = await getOrImportTotpHmacKey(secret, hashName);
  if (!hmacKey) return null;

  const { step: counter, remainingSeconds: remaining, period: p } = computeTotpStep(period, nowMs);
  const d = Math.min(10, Math.max(6, Number(digits) || 6));

  const counterBytes = new Uint8Array(8);
  let tmp = counter;
  for (let i = 7; i >= 0; i--) {
    counterBytes[i] = tmp & 0xff;
    tmp = Math.floor(tmp / 256);
  }

  const sig = new Uint8Array(await crypto.subtle.sign("HMAC", hmacKey, counterBytes));
  const offset = sig[sig.length - 1] & 0x0f;
  const binary =
    ((sig[offset] & 0x7f) << 24) |
    ((sig[offset + 1] & 0xff) << 16) |
    ((sig[offset + 2] & 0xff) << 8) |
    (sig[offset + 3] & 0xff);
  const otp = String(binary % Math.pow(10, d)).padStart(d, "0");
  return { code: otp, remainingSeconds: remaining, period: p, step: counter };
}

// --- Clean Domain & Android Package Matching ---
function extractAndroidPackageFromUri(rawUrl) {
  if (!rawUrl) return "";
  const trimmed = String(rawUrl).trim();
  let rest = "";
  if (/^android:\/\//i.test(trimmed)) {
    const afterScheme = trimmed.slice(10);
    const atIdx = afterScheme.lastIndexOf("@");
    rest = atIdx >= 0 ? afterScheme.slice(atIdx + 1) : afterScheme;
  } else if (/^androidapp:\/\//i.test(trimmed)) {
    rest = trimmed.slice(13);
  } else {
    return "";
  }
  const pkg = rest.split(/[/?#]/)[0].trim();
  if (pkg && pkg.includes(".") && !pkg.includes(" ")) {
    return pkg;
  }
  return "";
}

function friendlyServiceNameFromPackage(pkg) {
  const stop = new Set([
    "com", "vn", "org", "net", "io", "app", "apps", "android",
    "mobile", "client", "bb", "mb", "gprsandroid", "production", "release", "global", "gp"
  ]);
  const parts = String(pkg || "").split(".").filter(Boolean);
  for (let i = parts.length - 1; i >= 0; i--) {
    const seg = parts[i];
    if (seg.length >= 2 && !stop.has(seg.toLowerCase())) {
      if (/[A-Z]/.test(seg)) return seg;
      return seg.charAt(0).toUpperCase() + seg.slice(1);
    }
  }
  return String(pkg || "Ứng dụng Android");
}

function isLoopbackHost(hostname) {
  const h = String(hostname || "").toLowerCase().replace(/^\[|\]$/g, "");
  return h === "localhost" || h === "127.0.0.1" || h === "::1";
}

function isSafeAutofillUrl(rawUrl) {
  if (!rawUrl) return false;
  try {
    const u = new URL(String(rawUrl).trim());
    if (u.protocol === "https:") return Boolean(u.hostname);
    if (u.protocol === "http:" && isLoopbackHost(u.hostname)) {
      return true;
    }
    return false;
  } catch (_) {
    return false;
  }
}

const DISALLOWED_DOMAIN_SCHEMES =
  /^(javascript|data|about|blob|mailto|tel|vbscript|file|chrome|chrome-extension|edge|brave|coccoc|opera|moz-extension|view-source|filesystem|android|androidapp|otpauth|ws|wss|ftp|sftp):/i;
const FAST_CLEAN_DOMAIN_RE =
  /^(?!www\.)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,62}$/;

function extractCleanDomain(urlOrHost) {
  if (!urlOrHost) return "";
  const trimmed = String(urlOrHost).trim();
  if (!trimmed) return "";
  // Ultra-fast path for already-clean lowercase domains (avoids WHATWG URL allocation)
  if (trimmed === "localhost" || FAST_CLEAN_DOMAIN_RE.test(trimmed)) {
    return trimmed;
  }
  if (DISALLOWED_DOMAIN_SCHEMES.test(trimmed)) return "";
  const raw = trimmed.toLowerCase();
  if (raw === "localhost" || FAST_CLEAN_DOMAIN_RE.test(raw)) {
    return raw;
  }
  if (/\s/.test(raw)) return "";
  try {
    let u;
    if (raw.includes("://")) {
      u = new URL(raw);
      if (u.protocol !== "http:" && u.protocol !== "https:") return "";
    } else {
      // Reject non-http pseudo-schemes like "custom:payload" while still allowing "host:port" and "[::1]:port"
      if (
        raw.includes(":") &&
        !/^\[[0-9a-f:]+\](?::\d+)?(?:[/?#]|$)/.test(raw) &&
        !/^[a-z0-9.-]+:\d+(?:[/?#]|$)/.test(raw)
      ) {
        return "";
      }
      u = new URL("https://" + raw);
    }
    const cleanHost = u.hostname.replace(/\.+$/, "").replace(/^www\./, "");
    if (!cleanHost) return "";
    return cleanHost;
  } catch (_) {
    return "";
  }
}

const MULTI_PART_TLDS = new Set([
  "com.vn", "net.vn", "org.vn", "edu.vn", "gov.vn", "ac.vn", "info.vn",
  "health.vn", "int.vn", "biz.vn", "name.vn", "pro.vn",
  "co.uk", "org.uk", "ac.uk", "gov.uk", "me.uk", "net.uk",
  "com.au", "net.au", "org.au", "edu.au", "gov.au", "asn.au", "id.au",
  "co.jp", "ne.jp", "or.jp", "go.jp", "ac.jp", "ed.jp", "gr.jp", "lg.jp",
  "co.kr", "or.kr", "go.kr", "ac.kr", "ne.kr", "re.kr",
  "com.sg", "edu.sg", "gov.sg", "org.sg", "net.sg", "per.sg",
  "com.tw", "edu.tw", "gov.tw", "org.tw", "net.tw", "idv.tw",
  "com.hk", "org.hk", "edu.hk", "gov.hk", "net.hk", "idv.hk",
  "com.cn", "org.cn", "net.cn", "gov.cn", "edu.cn", "ac.cn",
  "com.br", "net.br", "org.br", "gov.br", "edu.br",
  "com.my", "net.my", "org.my", "edu.my", "gov.my",
  "co.in", "net.in", "org.in", "gov.in", "ac.in", "edu.in",
  "co.id", "or.id", "ac.id", "go.id", "web.id", "sch.id",
  "co.th", "ac.th", "go.th", "or.th", "in.th",
  "com.mx", "org.mx", "gob.mx", "edu.mx", "net.mx",
  "co.nz", "net.nz", "org.nz", "govt.nz", "ac.nz",
  "co.za", "org.za", "gov.za", "ac.za", "net.za",
  "com.ph", "org.ph", "gov.ph", "edu.ph", "net.ph",
  "com.tr", "org.tr", "gov.tr", "edu.tr", "net.tr",
  "com.ar", "org.ar", "gob.ar", "edu.ar", "net.ar",
  "com.ua", "org.ua", "gov.ua", "edu.ua", "net.ua",
  "co.il", "org.il", "ac.il", "gov.il",
  "com.co", "org.co", "gov.co", "edu.co",
  "eu.org"
]);

const SHARED_HOSTING_SUFFIXES = new Set([
  "github.io", "gitlab.io", "github.dev", "pages.dev", "workers.dev", "r2.dev",
  "vercel.app", "vercel.dev", "netlify.app", "netlify.com",
  "web.app", "firebaseapp.com", "herokuapp.com",
  "onrender.com", "railway.app", "fly.dev", "surge.sh",
  "ngrok-free.app", "ngrok.app", "ngrok.io", "trycloudflare.com",
  "blogspot.com", "wordpress.com", "myshopify.com",
  "azurewebsites.net", "azurestaticapps.net", "blob.core.windows.net",
  "cloudfront.net", "amplifyapp.com", "b-cdn.net",
  "duckdns.org", "ddns.net", "wixsite.com", "appspot.com",
  "run.app", "cloudfunctions.net", "storage.googleapis.com",
  "supabase.co", "s3.amazonaws.com", "replit.dev", "glitch.me",
  "googleusercontent.com", "hf.space", "ondigitalocean.app",
  "deno.dev", "val.run", "pythonanywhere.com"
]);

function baseRegistrableDomain(host) {
  const h = extractCleanDomain(host);
  if (!h) return "";
  if (h === "localhost" || h.includes(":") || /^\d{1,3}(\.\d{1,3}){3}$/.test(h)) return h;
  const parts = h.split(".").filter(Boolean);
  if (parts.length < 2) return "";
  const last3 = parts.length >= 3 ? parts.slice(-3).join(".") : "";
  if (last3 && (MULTI_PART_TLDS.has(last3) || SHARED_HOSTING_SUFFIXES.has(last3))) {
    if (parts.length < 4) return "";
    return parts.slice(-4).join(".");
  }
  const last2 = parts.slice(-2).join(".");
  if (MULTI_PART_TLDS.has(last2) || SHARED_HOSTING_SUFFIXES.has(last2)) {
    if (parts.length < 3) return "";
    return parts.slice(-3).join(".");
  }
  return last2;
}

const KNOWN_PACKAGE_TO_DOMAINS = {
  "com.vcb": ["vietcombank.com.vn", "vcbdigibank.vietcombank.com.vn"],
  "com.mbmobile": ["mbbank.com.vn"],
  "vn.com.techcombank.bb.app": ["techcombank.com", "techcombank.com.vn"],
  "com.vnpay.bidv": ["bidv.com.vn", "smartbanking.bidv.com.vn"],
  "com.vietinbank.ipay": ["vietinbank.vn", "ipay.vietinbank.vn"],
  "com.vnpay.agribank": ["agribank.com.vn"],
  "mobile.acb.com.vn": ["acb.com.vn", "online.acb.com.vn"],
  "com.vnpay.vpbankonline": ["vpbank.com.vn", "neo.vpbank.com.vn"],
  "com.tpb.mb.gprsandroid": ["tpb.vn", "ebank.tpb.vn"],
  "com.zing.zalo": ["zalo.me", "id.zalo.me", "chat.zalo.me"],
  "com.facebook.katana": ["facebook.com", "messenger.com"],
  "com.google.android.gm": ["google.com", "accounts.google.com"],
  "com.shopee.vn": ["shopee.vn"]
};

function prettifyDomainTitle(urlOrHost) {
  const clean = extractCleanDomain(urlOrHost);
  if (!clean) return "";
  const base = baseRegistrableDomain(clean);
  // Keep distinct subdomain hosts visible (e.g. 1.domain.vn vs 2.domain.vn vs domain.vn)
  if (base && clean !== base) {
    return clean;
  }
  const head = (base || clean).split(".")[0] || clean;
  return head ? head.charAt(0).toUpperCase() + head.slice(1) : clean;
}

function itemMatchesDomain(item, tabHost) {
  const cleanTab = extractCleanDomain(tabHost);
  if (!cleanTab) return 0;

  const explicitDomains = new Set();
  if (Array.isArray(item.web_domains)) {
    for (const rawD of item.web_domains) {
      const d = extractCleanDomain(rawD);
      if (d) explicitDomains.add(d);
    }
  }

  for (const d of explicitDomains) {
    if (d === cleanTab) return 3; // Strict exact hostname match (after stripping www.)
  }

  // Only bridge native Android-package items that do NOT have explicit web_domains yet
  if (explicitDomains.size === 0 && Array.isArray(item.android_packages)) {
    for (const rawPkg of item.android_packages) {
      const mapped = KNOWN_PACKAGE_TO_DOMAINS[String(rawPkg || "").trim().toLowerCase()];
      if (Array.isArray(mapped)) {
        for (const md of mapped) {
          if (extractCleanDomain(md) === cleanTab) return 2;
        }
      }
    }
  }

  return 0;
}

function normalizePasskeyRecord(raw, now = Date.now()) {
  if (!raw || typeof raw !== "object") return null;
  const credentialId = String(raw.credential_id_b64url || raw.credentialIdB64Url || raw.credentialId || "").trim();
  const rpId = String(raw.rp_id || raw.rpId || "").trim().toLowerCase().replace(/\.+$/, "");
  if (!credentialId || !rpId) return null;
  const algRaw = Number(raw.alg);
  const alg = Number.isFinite(algRaw) && algRaw !== 0 ? Math.trunc(algRaw) : -7;
  const signCountRaw = Number(raw.sign_count ?? raw.signCount);
  const signCount = Number.isFinite(signCountRaw) && signCountRaw >= 0 ? Math.floor(signCountRaw) : 0;
  const createdMs = Number(raw.created_at_ms ?? raw.createdAtMs) || now;
  const lastUsedRaw = raw.last_used_at_ms ?? raw.lastUsedAtMs;
  const lastUsedMs = lastUsedRaw != null && Number(lastUsedRaw) > 0 ? Number(lastUsedRaw) : null;
  const userName = String(raw.user_name ?? raw.userName ?? "").trim();
  const userDisplayName = String(raw.user_display_name ?? raw.userDisplayName ?? userName).trim();
  return {
    credential_id_b64url: credentialId,
    rp_id: rpId,
    rp_name: String(raw.rp_name ?? raw.rpName ?? rpId).trim() || rpId,
    user_handle_b64url: String(raw.user_handle_b64url ?? raw.userHandleB64Url ?? raw.userHandle ?? "").trim(),
    user_name: userName,
    user_display_name: userDisplayName,
    private_key_pkcs8_b64: String(raw.private_key_pkcs8_b64 ?? raw.privateKeyPkcs8B64 ?? "").trim(),
    public_key_spki_b64: String(raw.public_key_spki_b64 ?? raw.publicKeySpkiB64 ?? "").trim(),
    alg,
    sign_count: signCount,
    created_at_ms: createdMs,
    last_used_at_ms: lastUsedMs
  };
}

function normalizePasskeysArray(rawList, now = Date.now()) {
  if (!Array.isArray(rawList) || rawList.length === 0) return [];
  const byId = new Map();
  for (const entry of rawList) {
    const pk = normalizePasskeyRecord(entry, now);
    if (!pk) continue;
    const prev = byId.get(pk.credential_id_b64url);
    if (
      !prev ||
      pk.sign_count > prev.sign_count ||
      (Number(pk.last_used_at_ms) || 0) > (Number(prev.last_used_at_ms) || 0)
    ) {
      byId.set(pk.credential_id_b64url, pk);
    }
  }
  return Array.from(byId.values());
}

function normalizeVaultItem(raw) {
  const now = Date.now();
  const updatedAtMs = Number(raw.updated_at_ms) || now;
  const createdAtMs = Number(raw.created_at_ms) || updatedAtMs;
  return {
    id: raw.id || crypto.randomUUID(),
    service_name: String(raw.service_name || "Tài khoản Web").trim(),
    username: String(raw.username || "").trim(),
    password: String(raw.password || ""),
    totp_secret: raw.totp_secret && String(raw.totp_secret).trim() && raw.totp_secret !== "null"
      ? String(raw.totp_secret).trim()
      : null,
    totp_algorithm: raw.totp_algorithm || "SHA1",
    totp_digits: Number(raw.totp_digits) || 6,
    totp_period: Number(raw.totp_period) || 30,
    web_domains: Array.isArray(raw.web_domains)
      ? raw.web_domains.map(extractCleanDomain).filter(Boolean)
      : [],
    android_packages: Array.isArray(raw.android_packages) ? raw.android_packages : [],
    recovery_codes: Array.isArray(raw.recovery_codes) ? raw.recovery_codes : [],
    pin_code: raw.pin_code || null,
    notes: String(raw.notes || ""),
    folder: String(raw.folder || "Chung"),
    is_favorite: Boolean(raw.is_favorite),
    localOnly: Boolean(raw.localOnly),
    pin_totp_to_dashboard: raw.pin_totp_to_dashboard !== false,
    password_history: Array.isArray(raw.password_history) ? raw.password_history : [],
    passkeys: normalizePasskeysArray(raw.passkeys, now),
    created_at_ms: createdAtMs,
    updated_at_ms: updatedAtMs,
    last_autofilled_ms: raw.last_autofilled_ms ? Number(raw.last_autofilled_ms) : null
  };
}

function buildVaultDomainIndex(items) {
  const byDomain = new Map();
  const byId = new Map();
  for (const item of Array.isArray(items) ? items : []) {
    if (!item || !item.id) continue;
    byId.set(item.id, item);
    const explicitDomains = new Set();
    if (Array.isArray(item.web_domains)) {
      for (const rawD of item.web_domains) {
        const d = extractCleanDomain(rawD);
        if (d) explicitDomains.add(d);
      }
    }
    if (explicitDomains.size > 0) {
      for (const d of explicitDomains) {
        let bucket = byDomain.get(d);
        if (!bucket) {
          bucket = [];
          byDomain.set(d, bucket);
        }
        bucket.push({ item, score: 3 });
      }
    } else if (Array.isArray(item.android_packages)) {
      const mappedSet = new Set();
      for (const rawPkg of item.android_packages) {
        const mapped = KNOWN_PACKAGE_TO_DOMAINS[String(rawPkg || "").trim().toLowerCase()];
        if (Array.isArray(mapped)) {
          for (const md of mapped) {
            const d = extractCleanDomain(md);
            if (d) mappedSet.add(d);
          }
        }
      }
      for (const d of mappedSet) {
        let bucket = byDomain.get(d);
        if (!bucket) {
          bucket = [];
          byDomain.set(d, bucket);
        }
        bucket.push({ item, score: 2 });
      }
    }
  }
  return { byDomain, byId };
}

// --- In-Memory Cache & Non-Extractable CryptoKey IDB Session Store (2027 Standard) ---
let _memCacheStorageLocal = null;
let _memCacheStorageSession = null;
let _memVaultCache = null; // { state, byDomain, byId, sessionHandleId, expiresAtMs }
let _memMetaFlagsCache = null;
let _memRecencyCache = null;
let _memJwtCache = null;
const _memSessionKeys = new Map(); // handleId -> non-extractable CryptoKey
const _ownStorageWriteIds = new Set();
let _ownStorageWriteSeq = 0;
let _idbPromise = null;
let _idbFactoryRef = null;

function nextOwnStorageWriteId() {
  _ownStorageWriteSeq += 1;
  const id = `${Date.now().toString(36)}-${_ownStorageWriteSeq}-${Math.random().toString(36).slice(2, 8)}`;
  if (_ownStorageWriteIds.size > 32) {
    const first = _ownStorageWriteIds.values().next().value;
    if (first !== undefined) _ownStorageWriteIds.delete(first);
  }
  _ownStorageWriteIds.add(id);
  return id;
}

function invalidateMemoryCaches() {
  _memVaultCache = null;
  _memMetaFlagsCache = null;
  _memRecencyCache = null;
  _memJwtCache = null;
  clearTotpKeyCache();
}

function ensureStorageEpoch() {
  const curLocal = chrome?.storage?.local || null;
  const curSession = chrome?.storage?.session || null;
  if (curLocal !== _memCacheStorageLocal || curSession !== _memCacheStorageSession) {
    _memCacheStorageLocal = curLocal;
    _memCacheStorageSession = curSession;
    invalidateMemoryCaches();
    _memSessionKeys.clear();
    _ownStorageWriteIds.clear();
  }
}

function applyRecencyMapToItems(items, recencyMap) {
  if (!Array.isArray(items) || !recencyMap || typeof recencyMap !== "object") return;
  for (const item of items) {
    if (!item || !item.id) continue;
    const hotTs = Number(recencyMap[item.id] || 0);
    if (hotTs > 0 && hotTs > (Number(item.last_autofilled_ms) || 0)) {
      item.last_autofilled_ms = hotTs;
    }
  }
}

function handleStorageChanged(changes, areaName) {
  ensureStorageEpoch();
  if (!changes || typeof changes !== "object") return;
  if (areaName === "local") {
    if (OMNIVAULT_STORAGE_KEY in changes) {
      const incomingWriteId = changes[OMNIVAULT_META_FLAGS_KEY]?.newValue?.writeId;
      if (incomingWriteId && _ownStorageWriteIds.has(incomingWriteId)) {
        _ownStorageWriteIds.delete(incomingWriteId);
      } else {
        _memVaultCache = null;
        _memMetaFlagsCache = null;
      }
    }
    if (OMNIVAULT_META_FLAGS_KEY in changes) {
      _memMetaFlagsCache = changes[OMNIVAULT_META_FLAGS_KEY]?.newValue || null;
      if (_memVaultCache && _memMetaFlagsCache && _memMetaFlagsCache.lastSyncedAtMs) {
        _memVaultCache.state.lastSyncedAtMs = Math.max(
          Number(_memVaultCache.state.lastSyncedAtMs) || 0,
          Number(_memMetaFlagsCache.lastSyncedAtMs) || 0
        );
      }
    }
    if (OMNIVAULT_HOT_RECENCY_KEY in changes) {
      const nextRec = changes[OMNIVAULT_HOT_RECENCY_KEY]?.newValue || null;
      _memRecencyCache = nextRec && typeof nextRec === "object" ? { ...nextRec } : null;
      if (_memVaultCache && !_memVaultCache.state.locked && _memRecencyCache) {
        applyRecencyMapToItems(_memVaultCache.state.items, _memRecencyCache);
      }
    }
  } else if (areaName === "session") {
    if (OMNIVAULT_SESSION_KEY in changes) {
      const nextSess = changes[OMNIVAULT_SESSION_KEY]?.newValue;
      const nextHandle = nextSess && typeof nextSess === "object" ? nextSess.handleId : null;
      if (!_memVaultCache || !nextHandle || _memVaultCache.sessionHandleId !== nextHandle) {
        _memVaultCache = null;
      }
      if (!nextSess) {
        _memJwtCache = null;
        _memSessionKeys.clear();
        clearTotpKeyCache();
      }
    }
    if (OMNIVAULT_SESSION_EXPIRES_KEY in changes) {
      const nextExp = Number(changes[OMNIVAULT_SESSION_EXPIRES_KEY]?.newValue || 0);
      if (_memVaultCache) {
        if (!nextExp || nextExp <= Date.now()) {
          _memVaultCache = null;
        } else {
          _memVaultCache.expiresAtMs = nextExp;
        }
      }
    }
    if (OMNIVAULT_JWT_CACHE_KEY in changes) {
      _memJwtCache = changes[OMNIVAULT_JWT_CACHE_KEY]?.newValue || null;
    }
  }
}

if (typeof chrome !== "undefined" && chrome?.storage?.onChanged?.addListener) {
  try {
    chrome.storage.onChanged.addListener(handleStorageChanged);
  } catch (_) {}
}

function isIdbInvalidStateError(err) {
  if (!err) return false;
  if (String(err.name || "") === "InvalidStateError") return true;
  return /InvalidStateError|connection is closing|database connection is closing/i.test(
    String(err.message || "")
  );
}

function openSessionKeyIdb() {
  if (typeof indexedDB === "undefined" || !indexedDB || typeof indexedDB.open !== "function") {
    _idbPromise = null;
    _idbFactoryRef = null;
    return Promise.resolve(null);
  }
  if (_idbFactoryRef !== indexedDB) {
    _idbPromise = null;
    _idbFactoryRef = indexedDB;
  }
  if (_idbPromise) return _idbPromise;
  _idbPromise = new Promise((resolve) => {
    try {
      const req = indexedDB.open(SESSION_KEY_IDB_NAME, 1);
      req.onupgradeneeded = () => {
        try {
          const db = req.result;
          if (!db.objectStoreNames.contains(SESSION_KEY_IDB_STORE)) {
            db.createObjectStore(SESSION_KEY_IDB_STORE);
          }
        } catch (_) {}
      };
      req.onsuccess = () => {
        const db = req.result;
        db.onclose = () => {
          _idbPromise = null;
        };
        db.onversionchange = () => {
          try {
            db.close();
          } catch (_) {}
          _idbPromise = null;
        };
        resolve(db);
      };
      req.onerror = () => {
        _idbPromise = null;
        resolve(null);
      };
      req.onblocked = () => {
        _idbPromise = null;
        resolve(null);
      };
    } catch (_) {
      _idbPromise = null;
      resolve(null);
    }
  });
  return _idbPromise;
}

async function putSessionKeyInIdb(handleId, cryptoKey, _retried = false) {
  const db = await openSessionKeyIdb();
  if (!db) return false;
  let retryInvalidState = false;
  const ok = await new Promise((resolve) => {
    try {
      const tx = db.transaction(SESSION_KEY_IDB_STORE, "readwrite");
      const store = tx.objectStore(SESSION_KEY_IDB_STORE);
      // Key by handleId so concurrent PIN change / re-unlock never clobbers an in-flight reader's handle.
      store.put({ handleId, key: cryptoKey, createdAt: Date.now() }, handleId);
      _knownIdbHandleIds.add(handleId);
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => {
        _idbPromise = null;
        if (!_retried && isIdbInvalidStateError(tx.error)) retryInvalidState = true;
        resolve(false);
      };
      tx.onabort = () => {
        _idbPromise = null;
        if (!_retried && isIdbInvalidStateError(tx.error)) retryInvalidState = true;
        resolve(false);
      };
    } catch (err) {
      _idbPromise = null;
      if (!_retried && isIdbInvalidStateError(err)) retryInvalidState = true;
      resolve(false);
    }
  });
  if (!ok && retryInvalidState && !_retried) {
    return putSessionKeyInIdb(handleId, cryptoKey, true);
  }
  return ok;
}

async function pruneOldSessionKeysInIdb(activeHandleId) {
  const db = await openSessionKeyIdb();
  if (!db) return;
  const cutoff = Date.now() - 10_000;
  await new Promise((resolve) => {
    try {
      const tx = db.transaction(SESSION_KEY_IDB_STORE, "readwrite");
      const store = tx.objectStore(SESSION_KEY_IDB_STORE);
      if (typeof store.openCursor === "function") {
        const req = store.openCursor();
        req.onsuccess = () => {
          const cursor = req.result;
          if (!cursor) return;
          const k = cursor.key;
          const v = cursor.value;
          const isLegacy = k === SESSION_KEY_IDB_RECORD_ID;
          const isStaleOther = k !== activeHandleId && (Number(v?.createdAt) || 0) < cutoff;
          if (isLegacy || isStaleOther) {
            try {
              cursor.delete();
            } catch (_) {}
          }
          cursor.continue();
        };
      }
      tx.oncomplete = () => resolve();
      tx.onerror = () => resolve();
      tx.onabort = () => resolve();
    } catch (_) {
      resolve();
    }
  });
}

async function getSessionKeyFromIdb(expectedHandleId, _retried = false) {
  const db = await openSessionKeyIdb();
  if (!db) return null;
  let retryInvalidState = false;
  const key = await new Promise((resolve) => {
    try {
      const tx = db.transaction(SESSION_KEY_IDB_STORE, "readonly");
      const store = tx.objectStore(SESSION_KEY_IDB_STORE);
      const req = store.get(expectedHandleId);
      req.onsuccess = () => {
        const rec = req.result;
        if (rec && rec.handleId === expectedHandleId && rec.key) {
          resolve(rec.key);
          return;
        }
        // Backward-read fallback for pre-upgrade single-slot record
        try {
          const legacyReq = store.get(SESSION_KEY_IDB_RECORD_ID);
          legacyReq.onsuccess = () => {
            const lrec = legacyReq.result;
            if (lrec && lrec.handleId === expectedHandleId && lrec.key) {
              resolve(lrec.key);
            } else {
              resolve(null);
            }
          };
          legacyReq.onerror = () => resolve(null);
        } catch (_) {
          resolve(null);
        }
      };
      req.onerror = () => {
        _idbPromise = null;
        if (!_retried && isIdbInvalidStateError(req.error || tx.error)) retryInvalidState = true;
        resolve(null);
      };
      tx.onabort = () => {
        _idbPromise = null;
        if (!_retried && isIdbInvalidStateError(tx.error)) retryInvalidState = true;
        resolve(null);
      };
    } catch (err) {
      _idbPromise = null;
      if (!_retried && isIdbInvalidStateError(err)) retryInvalidState = true;
      resolve(null);
    }
  });
  if (!key && retryInvalidState && !_retried) {
    return getSessionKeyFromIdb(expectedHandleId, true);
  }
  return key;
}

async function deleteSessionKeyFromIdb(_retried = false) {
  const db = await openSessionKeyIdb();
  if (!db) return;
  let retryInvalidState = false;
  await new Promise((resolve) => {
    try {
      const tx = db.transaction(SESSION_KEY_IDB_STORE, "readwrite");
      const store = tx.objectStore(SESSION_KEY_IDB_STORE);
      if (typeof store.clear === "function") {
        store.clear();
      } else {
        store.delete(SESSION_KEY_IDB_RECORD_ID);
        for (const hid of _knownIdbHandleIds) {
          store.delete(hid);
        }
      }
      tx.oncomplete = () => {
        _knownIdbHandleIds.clear();
        resolve();
      };
      tx.onerror = () => {
        _idbPromise = null;
        if (!_retried && isIdbInvalidStateError(tx.error)) retryInvalidState = true;
        resolve();
      };
      tx.onabort = () => {
        _idbPromise = null;
        if (!_retried && isIdbInvalidStateError(tx.error)) retryInvalidState = true;
        resolve();
      };
    } catch (err) {
      _idbPromise = null;
      if (!_retried && isIdbInvalidStateError(err)) retryInvalidState = true;
      resolve();
    }
  });
  if (retryInvalidState && !_retried) {
    return deleteSessionKeyFromIdb(true);
  }
}

// --- Storage & KDF Helpers ---
async function derivePinWrapCryptoKey(pin, saltBytes, iterations = PIN_PBKDF2_ITERS) {
  const passBytes = TEXT_ENCODER.encode(String(pin || ""));
  const baseKey = await crypto.subtle.importKey(
    "raw",
    passBytes,
    { name: "PBKDF2" },
    false,
    ["deriveKey"]
  );
  // Non-extractable AES-256-GCM CryptoKey — raw key material NEVER enters JS heap!
  return crypto.subtle.deriveKey(
    { name: "PBKDF2", salt: saltBytes, iterations, hash: "SHA-256" },
    baseKey,
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt", "decrypt"]
  );
}

async function clearEphemeralSessionItemsOnly() {
  ensureStorageEpoch();
  _memJwtCache = null;
  try {
    if (chrome?.storage?.session) {
      await chrome.storage.session.remove([
        OMNIVAULT_JWT_CACHE_KEY,
        "omnivault_tab_notices_v1",
        "omnivault_undo_records_v1",
        "omnivault_locked_captures_v1",
        OMNIVAULT_PENDING_UPDATES_KEY,
        OMNIVAULT_PENDING_INLINE_UNLOCK_KEY,
        OMNIVAULT_STEP1_USERS_KEY,
        OMNIVAULT_UNPAIRED_HINTS_KEY
      ]);
    }
  } catch (_) {}
}

async function setSessionWrapCryptoKey(cryptoKey, ttlMs = SESSION_AUTOLOCK_MS) {
  ensureStorageEpoch();
  if (!chrome?.storage?.session || !cryptoKey) return null;
  const safeTtl = Math.max(1000, Number(ttlMs) || SESSION_AUTOLOCK_MS);
  const handleId = crypto.randomUUID();
  const expiresAtMs = Date.now() + safeTtl;

  _memSessionKeys.set(handleId, cryptoKey);
  if (_memSessionKeys.size > 4) {
    const oldestKey = _memSessionKeys.keys().next().value;
    if (oldestKey && oldestKey !== handleId) _memSessionKeys.delete(oldestKey);
  }
  const storedInIdb = await putSessionKeyInIdb(handleId, cryptoKey);

  await chrome.storage.session.set({
    [OMNIVAULT_SESSION_KEY]: {
      type: storedInIdb ? "idb_handle" : "mem_handle",
      handleId
    },
    [OMNIVAULT_SESSION_EXPIRES_KEY]: expiresAtMs
  });
  if (storedInIdb) {
    pruneOldSessionKeysInIdb(handleId).catch(() => {});
  }
  return { handleId, expiresAtMs };
}

async function getSessionWrapCryptoKeyInfo(_retryRotated = false) {
  ensureStorageEpoch();
  if (!chrome?.storage?.session) return null;
  const data = await chrome.storage.session.get([
    OMNIVAULT_SESSION_KEY,
    OMNIVAULT_SESSION_EXPIRES_KEY
  ]);
  const raw = data[OMNIVAULT_SESSION_KEY];
  if (!raw) return null;

  let expiresAtMs = Number(data[OMNIVAULT_SESSION_EXPIRES_KEY] || 0);
  if (raw && typeof raw === "object" && raw.expiresAtMs && !expiresAtMs) {
    expiresAtMs = Number(raw.expiresAtMs);
  }
  if (!Number.isFinite(expiresAtMs) || expiresAtMs <= 0 || Date.now() >= expiresAtMs) {
    await lockExtensionSession();
    return null;
  }

  // Modern 2027 path: random handle paired with non-extractable CryptoKey in IndexedDB (or RAM fallback)
  if (raw && typeof raw === "object" && raw.handleId && (raw.type === "idb_handle" || raw.type === "mem_handle")) {
    let key = _memSessionKeys.get(raw.handleId) || null;
    if (!key && raw.type === "idb_handle") {
      key = await getSessionKeyFromIdb(raw.handleId);
      if (key) {
        _memSessionKeys.set(raw.handleId, key);
      }
    }
    if (!key) {
      if (raw.type === "idb_handle") {
        // Re-check chrome.storage.session once in case a concurrent PIN change / re-unlock rotated handleId
        if (!_retryRotated) {
          const latestData = await chrome.storage.session.get(OMNIVAULT_SESSION_KEY);
          const latestRaw = latestData[OMNIVAULT_SESSION_KEY];
          if (latestRaw && latestRaw.handleId && latestRaw.handleId !== raw.handleId) {
            return getSessionWrapCryptoKeyInfo(true);
          }
        }
        await lockExtensionSession();
      }
      return null;
    }
    return { key, handleId: raw.handleId, expiresAtMs };
  }

  // Backward-read compatibility (INV-02): upgrade legacy raw Base64 session key to non-extractable IDB handle
  let legacyB64 = null;
  if (typeof raw === "string") {
    legacyB64 = raw;
  } else if (raw && typeof raw === "object" && raw.wrapKeyB64) {
    legacyB64 = String(raw.wrapKeyB64);
  }
  if (!legacyB64) return null;
  try {
    const key = await importAesKey(legacyB64);
    const remainingTtl = Math.max(1000, expiresAtMs - Date.now());
    const upgraded = await setSessionWrapCryptoKey(key, remainingTtl);
    return { key, handleId: upgraded ? upgraded.handleId : "legacy", expiresAtMs };
  } catch (_) {
    await lockExtensionSession();
    return null;
  }
}

async function touchAutoLockAlarm(ttlMs = SESSION_AUTOLOCK_MS) {
  ensureStorageEpoch();
  try {
    const safeTtl = Math.max(1000, Number(ttlMs) || SESSION_AUTOLOCK_MS);
    if (chrome?.storage?.session) {
      const existing = await getSessionWrapCryptoKeyInfo();
      if (existing) {
        const nextExpires = Date.now() + safeTtl;
        await chrome.storage.session.set({
          [OMNIVAULT_SESSION_EXPIRES_KEY]: nextExpires
        });
        if (_memVaultCache) {
          _memVaultCache.expiresAtMs = nextExpires;
        }
      }
    }
    if (chrome?.alarms?.create) {
      await chrome.alarms.create(OMNIVAULT_AUTOLOCK_ALARM, {
        delayInMinutes: Math.max(1, safeTtl / 60_000)
      });
    }
  } catch (_) {}
}

async function lockExtensionSession() {
  ensureStorageEpoch();
  _memVaultCache = null;
  _memJwtCache = null;
  _memSessionKeys.clear();
  clearTotpKeyCache();
  try {
    await deleteSessionKeyFromIdb();
  } catch (_) {}
  try {
    if (chrome?.storage?.session) {
      await chrome.storage.session.remove([
        OMNIVAULT_SESSION_KEY,
        OMNIVAULT_SESSION_EXPIRES_KEY,
        OMNIVAULT_JWT_CACHE_KEY,
        "omnivault_tab_notices_v1",
        "omnivault_undo_records_v1",
        "omnivault_locked_captures_v1",
        OMNIVAULT_PENDING_UPDATES_KEY,
        OMNIVAULT_PENDING_INLINE_UNLOCK_KEY,
        OMNIVAULT_STEP1_USERS_KEY,
        OMNIVAULT_UNPAIRED_HINTS_KEY
      ]);
    }
    if (chrome?.alarms?.clear) {
      await chrome.alarms.clear(OMNIVAULT_AUTOLOCK_ALARM);
    }
  } catch (_) {}
}

async function readHotMetaFlags() {
  ensureStorageEpoch();
  if (_memMetaFlagsCache !== null) {
    return _memMetaFlagsCache;
  }
  if (!chrome?.storage?.local) return null;
  const data = await chrome.storage.local.get(OMNIVAULT_META_FLAGS_KEY);
  const flags = data[OMNIVAULT_META_FLAGS_KEY];
  if (flags && typeof flags === "object" && typeof flags.hasPinLock === "boolean") {
    _memMetaFlagsCache = flags;
    return flags;
  }
  // Backward-read fallback for pre-upgrade state blobs lacking omnivault_meta_flags_v1
  const legacyData = await chrome.storage.local.get(OMNIVAULT_STORAGE_KEY);
  const st = legacyData[OMNIVAULT_STORAGE_KEY];
  if (!st || typeof st !== "object") {
    return null;
  }
  const hasPinLock = Boolean(st.encryptedVault && st.encryptedVault.ciphertextB64);
  const derived = {
    hasPinLock,
    paired: hasPinLock ? Boolean(st.deviceNameHint || st.encryptedVault) : Boolean(st.pairing),
    localOnly: Boolean(st.pairing && st.pairing.localOnly),
    deviceNameHint: st.pairing?.deviceName || st.deviceNameHint || null,
    lockTimeoutMin: Math.round(SESSION_AUTOLOCK_MS / 60_000),
    lastSyncedAtMs: Number(st.lastSyncedAtMs) || 0
  };
  _memMetaFlagsCache = derived;
  try {
    await chrome.storage.local.set({ [OMNIVAULT_META_FLAGS_KEY]: derived });
  } catch (_) {}
  return derived;
}

async function hasExtensionPinLock() {
  const flags = await readHotMetaFlags();
  return Boolean(flags && flags.hasPinLock);
}

async function enforceSessionExpiryIfNeeded() {
  // Fast hot-metadata path: reads ONLY tiny omnivault_meta_flags_v1 (never the 1-3 MB vault blob!)
  const hasPin = await hasExtensionPinLock();
  if (!hasPin) return false;
  if (!chrome?.storage?.session) return false;
  const pre = await chrome.storage.session.get(OMNIVAULT_SESSION_KEY);
  const hadActiveSession = Boolean(pre && pre[OMNIVAULT_SESSION_KEY]);
  if (!hadActiveSession) {
    // Already locked — did NOT transition from unlocked -> locked!
    return false;
  }
  const info = await getSessionWrapCryptoKeyInfo();
  // Return true ONLY when an active unlocked session actually expired and transitioned to locked
  return !info;
}

async function readHotRecencyMap() {
  ensureStorageEpoch();
  if (_memRecencyCache !== null) return _memRecencyCache;
  if (!chrome?.storage?.local) return {};
  try {
    const data = await chrome.storage.local.get(OMNIVAULT_HOT_RECENCY_KEY);
    const map = data[OMNIVAULT_HOT_RECENCY_KEY];
    _memRecencyCache = map && typeof map === "object" ? { ...map } : {};
    return _memRecencyCache;
  } catch (_) {
    return {};
  }
}

let _recencyWriteChain = Promise.resolve();

async function recordItemAutofilled(itemId, ts = Date.now()) {
  ensureStorageEpoch();
  if (!itemId) return;
  const nextTs = Number(ts) || Date.now();
  const run = async () => {
    const recMap = { ...(await readHotRecencyMap()) };
    recMap[itemId] = nextTs;
    const keys = Object.keys(recMap);
    if (keys.length > MAX_HOT_RECENCY_ENTRIES) {
      const entries = Object.entries(recMap)
        .sort((a, b) => Number(b[1] || 0) - Number(a[1] || 0))
        .slice(0, MAX_HOT_RECENCY_ENTRIES);
      const pruned = Object.fromEntries(entries);
      _memRecencyCache = pruned;
      if (chrome?.storage?.local) {
        await chrome.storage.local.set({ [OMNIVAULT_HOT_RECENCY_KEY]: pruned });
      }
    } else {
      _memRecencyCache = recMap;
      if (chrome?.storage?.local) {
        await chrome.storage.local.set({ [OMNIVAULT_HOT_RECENCY_KEY]: recMap });
      }
    }
    if (_memVaultCache && _memVaultCache.byId) {
      const cachedItem = _memVaultCache.byId.get(itemId);
      if (cachedItem) {
        cachedItem.last_autofilled_ms = nextTs;
      }
    }
  };
  const nextPromise = _recencyWriteChain.then(run, run);
  _recencyWriteChain = nextPromise.catch(() => {});
  return nextPromise;
}

async function readHotJwtCache(expectedDeviceId) {
  ensureStorageEpoch();
  if (!expectedDeviceId) return null;
  if (_memJwtCache && _memJwtCache.deviceId === expectedDeviceId) {
    return _memJwtCache;
  }
  if (!chrome?.storage?.session) return null;
  try {
    const data = await chrome.storage.session.get(OMNIVAULT_JWT_CACHE_KEY);
    const rec = data[OMNIVAULT_JWT_CACHE_KEY];
    if (rec && rec.deviceId === expectedDeviceId && rec.jwt) {
      _memJwtCache = rec;
      return rec;
    }
  } catch (_) {}
  return null;
}

async function writeHotJwtCache(deviceId, jwt, jwtExpiresAtMs) {
  ensureStorageEpoch();
  if (!deviceId || !jwt) {
    _memJwtCache = null;
    try {
      if (chrome?.storage?.session) {
        await chrome.storage.session.remove(OMNIVAULT_JWT_CACHE_KEY);
      }
    } catch (_) {}
    return;
  }
  const rec = { deviceId, jwt, jwtExpiresAtMs: Number(jwtExpiresAtMs) || 0 };
  _memJwtCache = rec;
  if (_memVaultCache && _memVaultCache.state && _memVaultCache.state.pairing?.deviceId === deviceId) {
    _memVaultCache.state.jwt = jwt;
    _memVaultCache.state.jwtExpiresAtMs = rec.jwtExpiresAtMs;
  }
  try {
    if (chrome?.storage?.session) {
      await chrome.storage.session.set({ [OMNIVAULT_JWT_CACHE_KEY]: rec });
    }
  } catch (_) {}
}

async function withVaultMutationLock(fn) {
  if (
    typeof navigator !== "undefined" &&
    navigator.locks &&
    typeof navigator.locks.request === "function"
  ) {
    return navigator.locks.request(VAULT_MUTATION_LOCK_NAME, async () => await fn());
  }
  const run = _vaultMutationLockTail.then(fn, fn);
  _vaultMutationLockTail = run.then(
    () => undefined,
    () => undefined
  );
  return run;
}

async function _resetExtensionVaultRaw() {
  ensureStorageEpoch();
  invalidateMemoryCaches();
  try {
    if (chrome?.storage?.local) {
      await chrome.storage.local.remove([
        OMNIVAULT_STORAGE_KEY,
        OMNIVAULT_PIN_FAILS_KEY,
        OMNIVAULT_META_FLAGS_KEY,
        OMNIVAULT_HOT_RECENCY_KEY
      ]);
    }
  } catch (_) {}
  await lockExtensionSession();
}

async function resetExtensionVault() {
  return withVaultMutationLock(() => _resetExtensionVaultRaw());
}

async function checkPinLockoutWindow() {
  if (!chrome?.storage?.local) return;
  const fails = await chrome.storage.local.get(OMNIVAULT_PIN_FAILS_KEY);
  const info = fails[OMNIVAULT_PIN_FAILS_KEY];
  if (info && info.lockedUntilMs && Date.now() < info.lockedUntilMs) {
    const secs = Math.max(1, Math.ceil((info.lockedUntilMs - Date.now()) / 1000));
    throw new Error(`Thử sai quá nhiều lần. Đợi ${secs}s.`);
  }
}

async function recordPinFailureLocked(wrongMessage) {
  if (chrome?.storage?.local) {
    const fails = await chrome.storage.local.get(OMNIVAULT_PIN_FAILS_KEY);
    const prevCount = Number(fails[OMNIVAULT_PIN_FAILS_KEY]?.count || 0) + 1;
    if (prevCount >= 10) {
      await _resetExtensionVaultRaw();
      throw new Error(
        "Nhập sai PIN 10 lần — kho cục bộ trên tiện ích đã tự động xóa để bảo vệ dữ liệu. Vui lòng ghép nối lại."
      );
    }
    const lockedUntilMs =
      prevCount >= 7
        ? Date.now() + 300_000
        : prevCount >= 5
        ? Date.now() + 30_000
        : 0;
    await chrome.storage.local.set({
      [OMNIVAULT_PIN_FAILS_KEY]: { count: prevCount, lockedUntilMs }
    });
  }
  throw new Error(wrongMessage || "Mã PIN không đúng.");
}

async function verifyExistingPinWithLockout(
  st,
  rawPin,
  emptyMessage,
  wrongMessage,
  preDerived = null
) {
  const cleanPin = String(rawPin || "").trim();
  if (!cleanPin) {
    throw new Error(emptyMessage || "Vui lòng nhập mã PIN.");
  }
  await checkPinLockoutWindow();

  const saltB64 = st.encryptedVault.saltB64;
  const iterations = Number(st.encryptedVault.iterations) || LEGACY_PIN_PBKDF2_ITERS;
  let wrapCryptoKey =
    preDerived &&
    preDerived.saltB64 === saltB64 &&
    preDerived.iterations === iterations &&
    preDerived.key
      ? preDerived.key
      : null;
  if (!wrapCryptoKey) {
    const salt = base64ToBytes(saltB64);
    wrapCryptoKey = await derivePinWrapCryptoKey(cleanPin, salt, iterations);
  }

  let bundle;
  try {
    bundle = await aes256DecryptJsonWithKey(
      wrapCryptoKey,
      st.encryptedVault.nonceB64,
      st.encryptedVault.ciphertextB64
    );
  } catch (_) {
    await recordPinFailureLocked(wrongMessage);
  }
  if (chrome?.storage?.local) {
    await chrome.storage.local.remove(OMNIVAULT_PIN_FAILS_KEY);
  }
  return { bundle, wrapCryptoKey, iterations, cleanPin };
}

function buildMetaFlagsObject(hasPinLock, pairing, deviceNameHint, lastSyncedAtMs, markOwnWrite = false) {
  const out = {
    hasPinLock: Boolean(hasPinLock),
    paired: Boolean(pairing),
    localOnly: Boolean(pairing && pairing.localOnly),
    deviceNameHint: pairing?.deviceName || deviceNameHint || null,
    lockTimeoutMin: Math.round(SESSION_AUTOLOCK_MS / 60_000),
    lastSyncedAtMs: Number(lastSyncedAtMs) || 0
  };
  if (markOwnWrite) {
    out.writeId = nextOwnStorageWriteId();
  }
  return out;
}

function updateMemVaultCache(state, sessionHandleId = null, expiresAtMs = 0) {
  if (!state || state.locked) {
    _memVaultCache = null;
    return;
  }
  const { byDomain, byId } = buildVaultDomainIndex(state.items);
  _memVaultCache = {
    state,
    byDomain,
    byId,
    sessionHandleId,
    expiresAtMs
  };
}

async function setExtensionPin(newPin, currentPin = null) {
  ensureStorageEpoch();
  const cleanPin = String(newPin || "").trim();
  if (cleanPin.length < 4 || cleanPin.length > 64) {
    throw new Error("Mã PIN phải từ 4 đến 64 ký tự.");
  }

  // Step 1: Run heavy PBKDF2 600,000-iter derivation OUTSIDE navigator.locks!
  const preData = await chrome.storage.local.get(OMNIVAULT_STORAGE_KEY);
  const preSt = preData[OMNIVAULT_STORAGE_KEY] || {};
  let preCurrentDerived = null;
  let shouldPreDeriveNew = true;

  if (preSt.encryptedVault && preSt.encryptedVault.ciphertextB64) {
    const cleanCur = String(currentPin || "").trim();
    if (!cleanCur) {
      throw new Error("Vui lòng nhập mã PIN hiện tại để đổi PIN mới.");
    }
    await checkPinLockoutWindow();
    const curSaltB64 = preSt.encryptedVault.saltB64;
    const curIters = Number(preSt.encryptedVault.iterations) || LEGACY_PIN_PBKDF2_ITERS;
    const curKey = await derivePinWrapCryptoKey(cleanCur, base64ToBytes(curSaltB64), curIters);
    preCurrentDerived = { saltB64: curSaltB64, iterations: curIters, key: curKey };
    try {
      await aes256DecryptJsonWithKey(
        curKey,
        preSt.encryptedVault.nonceB64,
        preSt.encryptedVault.ciphertextB64
      );
    } catch (_) {
      // Do not waste 600k iterations on newPin when currentPin is wrong; lockout will increment inside lock
      shouldPreDeriveNew = false;
    }
  }

  let newSalt = null;
  let newWrapCryptoKey = null;
  if (shouldPreDeriveNew) {
    newSalt = crypto.getRandomValues(new Uint8Array(16));
    newWrapCryptoKey = await derivePinWrapCryptoKey(cleanPin, newSalt, PIN_PBKDF2_ITERS);
  }

  // Step 2: Acquire vault mutation lock ONLY for fast atomic verification + AES-GCM write!
  return withVaultMutationLock(async () => {
    const data = await chrome.storage.local.get(OMNIVAULT_STORAGE_KEY);
    const st = data[OMNIVAULT_STORAGE_KEY] || {};
    let bundle;
    let preservedJwt = null;
    let preservedJwtExp = 0;

    if (st.encryptedVault && st.encryptedVault.ciphertextB64) {
      const verified = await verifyExistingPinWithLockout(
        st,
        currentPin,
        "Vui lòng nhập mã PIN hiện tại để đổi PIN mới.",
        "Mã PIN hiện tại không đúng.",
        preCurrentDerived
      );
      bundle = { ...verified.bundle, jwt: null, jwtExpiresAtMs: 0 };
      preservedJwt = verified.bundle.jwt || null;
      preservedJwtExp = Number(verified.bundle.jwtExpiresAtMs) || 0;
    } else {
      preservedJwt = st.jwt || null;
      preservedJwtExp = Number(st.jwtExpiresAtMs) || 0;
      bundle = {
        pairing: st.pairing || null,
        jwt: null,
        jwtExpiresAtMs: 0,
        items: Array.isArray(st.items) ? st.items.map(normalizeVaultItem) : [],
        pendingCapture: st.pendingCapture || null
      };
    }

    if (!newSalt || !newWrapCryptoKey) {
      newSalt = crypto.getRandomValues(new Uint8Array(16));
      newWrapCryptoKey = await derivePinWrapCryptoKey(cleanPin, newSalt, PIN_PBKDF2_ITERS);
    }

    const enc = await aes256EncryptJsonWithKey(newWrapCryptoKey, bundle);
    const metaFlags = buildMetaFlagsObject(
      true,
      bundle?.pairing || null,
      bundle?.pairing?.deviceName || st.deviceNameHint || null,
      st.lastSyncedAtMs || 0,
      true
    );

    await chrome.storage.local.set({
      [OMNIVAULT_STORAGE_KEY]: {
        hasPinLock: true,
        deviceNameHint: metaFlags.deviceNameHint,
        deletedIds: st.deletedIds && typeof st.deletedIds === "object" ? st.deletedIds : {},
        tombstoneFloorMs: Number(st.tombstoneFloorMs) || 0,
        lastSyncedAtMs: st.lastSyncedAtMs || 0,
        encryptedVault: {
          saltB64: bytesToBase64(newSalt),
          iterations: PIN_PBKDF2_ITERS,
          nonceB64: enc.nonceB64,
          ciphertextB64: enc.ciphertextB64
        }
      },
      [OMNIVAULT_META_FLAGS_KEY]: metaFlags
    });
    _memMetaFlagsCache = metaFlags;
    if (bundle.pairing?.deviceId && preservedJwt) {
      await writeHotJwtCache(bundle.pairing.deviceId, preservedJwt, preservedJwtExp);
    }
    const sess = await setSessionWrapCryptoKey(newWrapCryptoKey);
    await touchAutoLockAlarm();
    _memVaultCache = null;
    if (sess) {
      const recMap = await readHotRecencyMap();
      const normItems = Array.isArray(bundle.items) ? bundle.items.map(normalizeVaultItem) : [];
      applyRecencyMapToItems(normItems, recMap);
      const hotJwt = bundle.pairing?.deviceId ? await readHotJwtCache(bundle.pairing.deviceId) : null;
      updateMemVaultCache(
        {
          locked: false,
          hasPinLock: true,
          deviceNameHint: metaFlags.deviceNameHint,
          pairing: bundle.pairing || null,
          jwt: hotJwt?.jwt || preservedJwt || null,
          jwtExpiresAtMs: hotJwt?.jwtExpiresAtMs || preservedJwtExp || 0,
          items: normItems,
          deletedIds: st.deletedIds && typeof st.deletedIds === "object" ? st.deletedIds : {},
          tombstoneFloorMs: Number(st.tombstoneFloorMs) || 0,
          lastSyncedAtMs: st.lastSyncedAtMs || 0,
          pendingCapture: bundle.pendingCapture || null
        },
        sess.handleId,
        sess.expiresAtMs
      );
    }
  });
}

async function unlockExtensionWithPin(pin) {
  ensureStorageEpoch();
  const cleanPin = String(pin || "").trim();
  if (!cleanPin) {
    throw new Error("Vui lòng nhập mã PIN.");
  }

  // Step 1: Perform heavy PBKDF2 derivation (and 310k -> 600k upgrade derivation) OUTSIDE navigator.locks!
  const preData = await chrome.storage.local.get(OMNIVAULT_STORAGE_KEY);
  const preSt = preData[OMNIVAULT_STORAGE_KEY] || {};
  if (!preSt.encryptedVault || !preSt.encryptedVault.ciphertextB64) {
    return _loadExtensionStateRaw();
  }
  await checkPinLockoutWindow();

  const preSaltB64 = preSt.encryptedVault.saltB64;
  const preIters = Number(preSt.encryptedVault.iterations) || LEGACY_PIN_PBKDF2_ITERS;
  const preKey = await derivePinWrapCryptoKey(cleanPin, base64ToBytes(preSaltB64), preIters);
  const preDerived = { saltB64: preSaltB64, iterations: preIters, key: preKey };

  let upgradeSalt = null;
  let upgradeKey = null;
  if (preIters < PIN_PBKDF2_ITERS) {
    try {
      await aes256DecryptJsonWithKey(
        preKey,
        preSt.encryptedVault.nonceB64,
        preSt.encryptedVault.ciphertextB64
      );
      // Pre-derive upgraded 600k key outside the lock so lock hold time is < 2ms
      upgradeSalt = crypto.getRandomValues(new Uint8Array(16));
      upgradeKey = await derivePinWrapCryptoKey(cleanPin, upgradeSalt, PIN_PBKDF2_ITERS);
    } catch (_) {
      // Wrong PIN — failure count & lockout will be applied atomically inside lock
    }
  }

  // Step 2: Acquire vault mutation lock for atomic decrypt, optional 310k->600k re-wrap, and session key write
  return withVaultMutationLock(async () => {
    const data = await chrome.storage.local.get(OMNIVAULT_STORAGE_KEY);
    const st = data[OMNIVAULT_STORAGE_KEY] || {};
    if (!st.encryptedVault || !st.encryptedVault.ciphertextB64) {
      return _loadExtensionStateRaw();
    }
    const verified = await verifyExistingPinWithLockout(
      st,
      cleanPin,
      "Vui lòng nhập mã PIN.",
      "Mã PIN không đúng.",
      preDerived
    );
    let activeKey = verified.wrapCryptoKey;
    const metaFlags = buildMetaFlagsObject(
      true,
      verified.bundle?.pairing || null,
      verified.bundle?.pairing?.deviceName || st.deviceNameHint || null,
      st.lastSyncedAtMs || 0,
      verified.iterations < PIN_PBKDF2_ITERS
    );

    if (chrome?.storage?.local && verified.iterations < PIN_PBKDF2_ITERS) {
      // Transparently upgrade legacy 310k PBKDF2 PIN wrappers to 600k (2027 standard) on successful unlock.
      if (!upgradeSalt || !upgradeKey) {
        upgradeSalt = crypto.getRandomValues(new Uint8Array(16));
        upgradeKey = await derivePinWrapCryptoKey(verified.cleanPin, upgradeSalt, PIN_PBKDF2_ITERS);
      }
      const reEnc = await aes256EncryptJsonWithKey(upgradeKey, verified.bundle);
      await chrome.storage.local.set({
        [OMNIVAULT_STORAGE_KEY]: {
          ...st,
          hasPinLock: true,
          deviceNameHint: metaFlags.deviceNameHint,
          encryptedVault: {
            saltB64: bytesToBase64(upgradeSalt),
            iterations: PIN_PBKDF2_ITERS,
            nonceB64: reEnc.nonceB64,
            ciphertextB64: reEnc.ciphertextB64
          }
        },
        [OMNIVAULT_META_FLAGS_KEY]: metaFlags
      });
      activeKey = upgradeKey;
    } else if (chrome?.storage?.local) {
      await chrome.storage.local.set({ [OMNIVAULT_META_FLAGS_KEY]: metaFlags });
    }

    _memMetaFlagsCache = metaFlags;
    const sess = await setSessionWrapCryptoKey(activeKey);
    await touchAutoLockAlarm();

    const recMap = await readHotRecencyMap();
    const items = Array.isArray(verified.bundle.items)
      ? verified.bundle.items.map(normalizeVaultItem)
      : [];
    applyRecencyMapToItems(items, recMap);
    const unlockedState = {
      locked: false,
      hasPinLock: true,
      deviceNameHint: metaFlags.deviceNameHint,
      pairing: verified.bundle.pairing || null,
      jwt: verified.bundle.jwt || null,
      jwtExpiresAtMs: verified.bundle.jwtExpiresAtMs || 0,
      items,
      deletedIds: st.deletedIds && typeof st.deletedIds === "object" ? st.deletedIds : {},
      tombstoneFloorMs: Number(st.tombstoneFloorMs) || 0,
      lastSyncedAtMs: st.lastSyncedAtMs || 0,
      pendingCapture: verified.bundle.pendingCapture || null
    };
    if (unlockedState.pairing?.deviceId) {
      const hotJwt = await readHotJwtCache(unlockedState.pairing.deviceId);
      if (hotJwt && hotJwt.jwt && hotJwt.jwtExpiresAtMs > (unlockedState.jwtExpiresAtMs || 0)) {
        unlockedState.jwt = hotJwt.jwt;
        unlockedState.jwtExpiresAtMs = hotJwt.jwtExpiresAtMs;
      }
    }
    updateMemVaultCache(unlockedState, sess ? sess.handleId : null, sess ? sess.expiresAtMs : 0);
    return cloneVaultStateForCaller(unlockedState);
  });
}

async function clearExtensionPin(currentPin) {
  ensureStorageEpoch();
  const preData = await chrome.storage.local.get(OMNIVAULT_STORAGE_KEY);
  const preSt = preData[OMNIVAULT_STORAGE_KEY] || {};
  let preCurrentDerived = null;
  if (preSt.encryptedVault && preSt.encryptedVault.ciphertextB64) {
    const cleanCur = String(currentPin || "").trim();
    if (!cleanCur) {
      throw new Error("Vui lòng nhập mã PIN hiện tại để gỡ khóa.");
    }
    await checkPinLockoutWindow();
    const curSaltB64 = preSt.encryptedVault.saltB64;
    const curIters = Number(preSt.encryptedVault.iterations) || LEGACY_PIN_PBKDF2_ITERS;
    const curKey = await derivePinWrapCryptoKey(cleanCur, base64ToBytes(curSaltB64), curIters);
    preCurrentDerived = { saltB64: curSaltB64, iterations: curIters, key: curKey };
  }

  return withVaultMutationLock(async () => {
    const data = await chrome.storage.local.get(OMNIVAULT_STORAGE_KEY);
    const st = data[OMNIVAULT_STORAGE_KEY] || {};
    if (!st.encryptedVault || !st.encryptedVault.ciphertextB64) {
      await lockExtensionSession();
      return;
    }
    const verified = await verifyExistingPinWithLockout(
      st,
      currentPin,
      "Vui lòng nhập mã PIN hiện tại để gỡ khóa.",
      "Mã PIN hiện tại không đúng.",
      preCurrentDerived
    );
    const bundle = verified.bundle;
    const normItems = Array.isArray(bundle.items) ? bundle.items.map(normalizeVaultItem) : [];
    const recMap = await readHotRecencyMap();
    applyRecencyMapToItems(normItems, recMap);
    const metaFlags = buildMetaFlagsObject(
      false,
      bundle.pairing || null,
      bundle.pairing?.deviceName || null,
      st.lastSyncedAtMs || 0,
      true
    );

    await chrome.storage.local.set({
      [OMNIVAULT_STORAGE_KEY]: {
        hasPinLock: false,
        pairing: bundle.pairing || null,
        jwt: null,
        jwtExpiresAtMs: 0,
        items: normItems,
        deletedIds: st.deletedIds && typeof st.deletedIds === "object" ? st.deletedIds : {},
        tombstoneFloorMs: Number(st.tombstoneFloorMs) || 0,
        lastSyncedAtMs: st.lastSyncedAtMs || 0,
        pendingCapture: bundle.pendingCapture || null
      },
      [OMNIVAULT_META_FLAGS_KEY]: metaFlags
    });
    _memMetaFlagsCache = metaFlags;
    await lockExtensionSession();
  });
}

function cloneVaultStateForCaller(state) {
  if (!state) return state;
  if (typeof structuredClone === "function") {
    return structuredClone(state);
  }
  return {
    ...state,
    items: Array.isArray(state.items)
      ? state.items.map((it) => ({
          ...it,
          web_domains: Array.isArray(it.web_domains) ? it.web_domains.slice() : [],
          android_packages: Array.isArray(it.android_packages) ? it.android_packages.slice() : [],
          recovery_codes: Array.isArray(it.recovery_codes) ? it.recovery_codes.slice() : [],
          password_history: Array.isArray(it.password_history)
            ? it.password_history.map((h) => ({ ...h }))
            : [],
          passkeys: Array.isArray(it.passkeys) ? it.passkeys.map((pk) => ({ ...pk })) : []
        }))
      : [],
    deletedIds: state.deletedIds ? { ...state.deletedIds } : {}
  };
}

async function _loadExtensionStateRaw() {
  ensureStorageEpoch();
  const data = await chrome.storage.local.get([
    OMNIVAULT_STORAGE_KEY,
    OMNIVAULT_META_FLAGS_KEY,
    OMNIVAULT_HOT_RECENCY_KEY
  ]);
  const st = data[OMNIVAULT_STORAGE_KEY] || {};
  const hotFlags = data[OMNIVAULT_META_FLAGS_KEY] || null;
  const recMap =
    data[OMNIVAULT_HOT_RECENCY_KEY] && typeof data[OMNIVAULT_HOT_RECENCY_KEY] === "object"
      ? data[OMNIVAULT_HOT_RECENCY_KEY]
      : {};
  _memRecencyCache = { ...recMap };

  const effectiveLastSyncedAtMs = Math.max(
    Number(st.lastSyncedAtMs) || 0,
    Number(hotFlags?.lastSyncedAtMs) || 0
  );

  if (st.encryptedVault && st.encryptedVault.ciphertextB64) {
    const sessInfo = await getSessionWrapCryptoKeyInfo();
    if (!sessInfo) {
      _memVaultCache = null;
      return {
        locked: true,
        hasPinLock: true,
        deviceNameHint: st.deviceNameHint || hotFlags?.deviceNameHint || null,
        pairing: null,
        jwt: null,
        jwtExpiresAtMs: 0,
        items: [],
        deletedIds: st.deletedIds && typeof st.deletedIds === "object" ? st.deletedIds : {},
        tombstoneFloorMs: Number(st.tombstoneFloorMs) || 0,
        lastSyncedAtMs: effectiveLastSyncedAtMs,
        pendingCapture: null
      };
    }
    try {
      const bundle = await aes256DecryptJsonWithKey(
        sessInfo.key,
        st.encryptedVault.nonceB64,
        st.encryptedVault.ciphertextB64
      );
      const items = Array.isArray(bundle.items) ? bundle.items.map(normalizeVaultItem) : [];
      applyRecencyMapToItems(items, recMap);
      let jwt = bundle.jwt || null;
      let jwtExpiresAtMs = Number(bundle.jwtExpiresAtMs) || 0;
      if (bundle.pairing?.deviceId) {
        const hotJwt = await readHotJwtCache(bundle.pairing.deviceId);
        if (hotJwt && hotJwt.jwt && hotJwt.jwtExpiresAtMs >= jwtExpiresAtMs) {
          jwt = hotJwt.jwt;
          jwtExpiresAtMs = hotJwt.jwtExpiresAtMs;
        }
      }
      const loaded = {
        locked: false,
        hasPinLock: true,
        deviceNameHint: bundle?.pairing?.deviceName || st.deviceNameHint || null,
        pairing: bundle.pairing || null,
        jwt,
        jwtExpiresAtMs,
        items,
        deletedIds: st.deletedIds && typeof st.deletedIds === "object" ? st.deletedIds : {},
        tombstoneFloorMs: Number(st.tombstoneFloorMs) || 0,
        lastSyncedAtMs: effectiveLastSyncedAtMs,
        pendingCapture: bundle.pendingCapture || null
      };
      updateMemVaultCache(loaded, sessInfo.handleId, sessInfo.expiresAtMs);
      return loaded;
    } catch (_) {
      await lockExtensionSession();
      return {
        locked: true,
        hasPinLock: true,
        deviceNameHint: st.deviceNameHint || null,
        pairing: null,
        jwt: null,
        jwtExpiresAtMs: 0,
        items: [],
        deletedIds: st.deletedIds && typeof st.deletedIds === "object" ? st.deletedIds : {},
        tombstoneFloorMs: Number(st.tombstoneFloorMs) || 0,
        lastSyncedAtMs: effectiveLastSyncedAtMs,
        pendingCapture: null
      };
    }
  }

  const items = Array.isArray(st.items) ? st.items.map(normalizeVaultItem) : [];
  applyRecencyMapToItems(items, recMap);
  let jwt = st.jwt || null;
  let jwtExpiresAtMs = Number(st.jwtExpiresAtMs) || 0;
  if (st.pairing?.deviceId) {
    const hotJwt = await readHotJwtCache(st.pairing.deviceId);
    if (hotJwt && hotJwt.jwt && hotJwt.jwtExpiresAtMs >= jwtExpiresAtMs) {
      jwt = hotJwt.jwt;
      jwtExpiresAtMs = hotJwt.jwtExpiresAtMs;
    }
  }
  const loaded = {
    locked: false,
    hasPinLock: false,
    deviceNameHint: st.pairing?.deviceName || null,
    pairing: st.pairing || null,
    jwt,
    jwtExpiresAtMs,
    items,
    deletedIds: st.deletedIds && typeof st.deletedIds === "object" ? st.deletedIds : {},
    tombstoneFloorMs: Number(st.tombstoneFloorMs) || 0,
    lastSyncedAtMs: effectiveLastSyncedAtMs,
    pendingCapture: st.pendingCapture || null
  };
  updateMemVaultCache(loaded, null, 0);
  return loaded;
}

async function getCachedVaultStateAndIndex() {
  ensureStorageEpoch();
  if (_memVaultCache && _memVaultCache.state) {
    if (_memVaultCache.state.hasPinLock) {
      const sessInfo = await getSessionWrapCryptoKeyInfo();
      if (!sessInfo || sessInfo.handleId !== _memVaultCache.sessionHandleId) {
        _memVaultCache = null;
        const freshLocked = await _loadExtensionStateRaw();
        return {
          state: freshLocked,
          byDomain: _memVaultCache ? _memVaultCache.byDomain : new Map(),
          byId: _memVaultCache ? _memVaultCache.byId : new Map()
        };
      }
      _memVaultCache.expiresAtMs = sessInfo.expiresAtMs;
    }
    return {
      state: _memVaultCache.state,
      byDomain: _memVaultCache.byDomain,
      byId: _memVaultCache.byId
    };
  }
  const loaded = await _loadExtensionStateRaw();
  if (_memVaultCache && !loaded.locked) {
    return {
      state: _memVaultCache.state,
      byDomain: _memVaultCache.byDomain,
      byId: _memVaultCache.byId
    };
  }
  return { state: loaded, byDomain: new Map(), byId: new Map() };
}

async function loadExtensionState() {
  ensureStorageEpoch();
  // When chrome.storage.onChanged is available (real Chrome MV3), serve unlocked reads from RAM cache
  // after verifying session expiry, avoiding redundant AES-GCM decryption.
  if (chrome?.storage?.onChanged?.addListener && _memVaultCache && _memVaultCache.state) {
    const cached = await getCachedVaultStateAndIndex();
    return cloneVaultStateForCaller(cached.state);
  }
  const loaded = await _loadExtensionStateRaw();
  return cloneVaultStateForCaller(loaded);
}

async function _saveExtensionStateRaw(nextState, options = {}) {
  ensureStorageEpoch();
  const data = await chrome.storage.local.get(OMNIVAULT_STORAGE_KEY);
  const prev = data[OMNIVAULT_STORAGE_KEY] || {};
  const normalizedItems = options.alreadyNormalized
    ? Array.isArray(nextState.items)
      ? nextState.items
      : []
    : Array.isArray(nextState.items)
    ? nextState.items.map(normalizeVaultItem)
    : [];
  const deletedIds =
    nextState.deletedIds && typeof nextState.deletedIds === "object" ? nextState.deletedIds : {};
  const tombstoneFloorMs = Number(nextState.tombstoneFloorMs) || 0;
  const lastSyncedAtMs = Number(nextState.lastSyncedAtMs) || 0;

  // Keep session JWT cache coherent with saved state
  if (nextState.pairing?.deviceId && nextState.jwt) {
    await writeHotJwtCache(nextState.pairing.deviceId, nextState.jwt, nextState.jwtExpiresAtMs || 0);
  } else if (!nextState.pairing || !nextState.jwt) {
    await writeHotJwtCache("", null, 0);
  }

  if (prev.encryptedVault && prev.encryptedVault.ciphertextB64) {
    const sessInfo = await getSessionWrapCryptoKeyInfo();
    if (!sessInfo) {
      throw new Error("Kho tiện ích đang khóa — vui lòng mở khóa bằng PIN trước khi lưu.");
    }
    const bundle = {
      pairing: nextState.pairing || null,
      jwt: null,
      jwtExpiresAtMs: 0,
      items: normalizedItems,
      pendingCapture: nextState.pendingCapture || null
    };
    const enc = await aes256EncryptJsonWithKey(sessInfo.key, bundle);
    const metaFlags = buildMetaFlagsObject(
      true,
      nextState.pairing || null,
      nextState.pairing?.deviceName || null,
      lastSyncedAtMs,
      true
    );
    await chrome.storage.local.set({
      [OMNIVAULT_STORAGE_KEY]: {
        hasPinLock: true,
        deviceNameHint: metaFlags.deviceNameHint,
        deletedIds,
        tombstoneFloorMs,
        lastSyncedAtMs,
        encryptedVault: {
          saltB64: prev.encryptedVault.saltB64,
          iterations: prev.encryptedVault.iterations || PIN_PBKDF2_ITERS,
          nonceB64: enc.nonceB64,
          ciphertextB64: enc.ciphertextB64
        }
      },
      [OMNIVAULT_META_FLAGS_KEY]: metaFlags
    });
    _memMetaFlagsCache = metaFlags;
    updateMemVaultCache(
      {
        locked: false,
        hasPinLock: true,
        deviceNameHint: metaFlags.deviceNameHint,
        pairing: bundle.pairing,
        jwt: nextState.jwt || null,
        jwtExpiresAtMs: nextState.jwtExpiresAtMs || 0,
        items: normalizedItems,
        deletedIds,
        tombstoneFloorMs,
        lastSyncedAtMs,
        pendingCapture: bundle.pendingCapture
      },
      sessInfo.handleId,
      sessInfo.expiresAtMs
    );
    return;
  }

  const metaFlags = buildMetaFlagsObject(
    false,
    nextState.pairing || null,
    nextState.pairing?.deviceName || null,
    lastSyncedAtMs,
    true
  );
  await chrome.storage.local.set({
    [OMNIVAULT_STORAGE_KEY]: {
      hasPinLock: false,
      pairing: nextState.pairing || null,
      jwt: null,
      jwtExpiresAtMs: 0,
      items: normalizedItems,
      deletedIds,
      tombstoneFloorMs,
      lastSyncedAtMs,
      pendingCapture: nextState.pendingCapture || null
    },
    [OMNIVAULT_META_FLAGS_KEY]: metaFlags
  });
  _memMetaFlagsCache = metaFlags;
  updateMemVaultCache(
    {
      locked: false,
      hasPinLock: false,
      deviceNameHint: metaFlags.deviceNameHint,
      pairing: nextState.pairing || null,
      jwt: nextState.jwt || null,
      jwtExpiresAtMs: nextState.jwtExpiresAtMs || 0,
      items: normalizedItems,
      deletedIds,
      tombstoneFloorMs,
      lastSyncedAtMs,
      pendingCapture: nextState.pendingCapture || null
    },
    null,
    0
  );
}

async function saveExtensionState(nextState) {
  return withVaultMutationLock(() => _saveExtensionStateRaw(nextState));
}

async function mutateVaultState(mutatorFn) {
  return withVaultMutationLock(async () => {
    const st = cloneVaultStateForCaller(await _loadExtensionStateRaw());
    const out = await mutatorFn(st);
    if (out && out.save) {
      await _saveExtensionStateRaw(st);
    }
    return out && "result" in out ? out.result : out;
  });
}

async function unpairExtensionVault() {
  return withVaultMutationLock(async () => {
    const st = await _loadExtensionStateRaw();
    if (st.locked) {
      throw new Error("Kho tiện ích đang khóa — vui lòng nhập PIN trước khi ngắt kết nối.");
    }
    _memRecencyCache = {};
    try {
      if (chrome?.storage?.local) {
        await chrome.storage.local.remove(OMNIVAULT_HOT_RECENCY_KEY);
      }
    } catch (_) {}
    await _saveExtensionStateRaw({
      pairing: null,
      jwt: null,
      jwtExpiresAtMs: 0,
      items: [],
      deletedIds: {},
      tombstoneFloorMs: 0,
      lastSyncedAtMs: 0,
      pendingCapture: null
    });
    clearTotpKeyCache();
    await clearEphemeralSessionItemsOnly();
    return cloneVaultStateForCaller(await _loadExtensionStateRaw());
  });
}

// --- Supabase Auth + Bidirectional E2EE Sync ---
async function _fetchSupabaseJwtOnly(pairing) {
  if (!pairing) throw new Error("Chưa kết nối với ứng dụng OmniVault.");
  const resp = await fetchWithTimeout(
    `${pairing.supabaseUrl}/auth/v1/token?grant_type=password`,
    {
      method: "POST",
      headers: {
        apikey: pairing.supabaseAnonKey,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        email: pairing.syncEmail,
        password: pairing.syncPassword
      })
    },
    DEFAULT_FETCH_TIMEOUT_MS
  );
  if (!resp.ok) {
    throw new Error(`Lỗi xác thực Máy chủ Đám mây (${resp.status}).`);
  }
  const tok = await resp.json();
  if (!tok || !tok.access_token) {
    throw new Error("Máy chủ Đám mây không trả về mã phiên hợp lệ.");
  }
  return {
    jwt: tok.access_token,
    jwtExpiresAtMs: Date.now() + Number(tok.expires_in || 3600) * 1000
  };
}

async function _getSupabaseJwtRaw(state, forceRefresh = false) {
  const p = state.pairing;
  if (!p) throw new Error("Chưa kết nối với ứng dụng OmniVault.");
  if (!forceRefresh && state.jwt && state.jwtExpiresAtMs > Date.now() + 60_000) {
    return state.jwt;
  }
  if (!forceRefresh && p.deviceId) {
    const hot = await readHotJwtCache(p.deviceId);
    if (hot && hot.jwt && hot.jwtExpiresAtMs > Date.now() + 60_000) {
      state.jwt = hot.jwt;
      state.jwtExpiresAtMs = hot.jwtExpiresAtMs;
      return state.jwt;
    }
  }
  const auth = await _fetchSupabaseJwtOnly(p);
  state.jwt = auth.jwt;
  state.jwtExpiresAtMs = auth.jwtExpiresAtMs;
  // Store refreshed JWT strictly in ephemeral session/RAM cache — NEVER re-encrypt entire vault blob!
  await writeHotJwtCache(p.deviceId || "", auth.jwt, auth.jwtExpiresAtMs);
  return state.jwt;
}

function isTransientSupaStatus(status) {
  return status === 429 || status === 500 || status === 502 || status === 503 || status === 504;
}

function fullJitterBackoffMs(attempt, baseMs = 200, maxMs = 2000) {
  const cap = Math.min(maxMs, baseMs * Math.pow(2, Math.max(0, attempt)));
  return Math.floor(Math.random() * (cap + 1));
}

function sleepMs(ms) {
  return new Promise((resolve) => setTimeout(resolve, Math.max(0, Number(ms) || 0)));
}

async function _supaFetchWithAuthRetry(state, url, buildOptions) {
  let jwt = await _getSupabaseJwtRaw(state, false);
  let refreshedAuth = false;
  let lastResp = null;
  let lastErr = null;
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      const resp = await fetchWithTimeout(url, buildOptions(jwt), DEFAULT_FETCH_TIMEOUT_MS);
      if (resp.status === 401 && !refreshedAuth) {
        refreshedAuth = true;
        state.jwt = null;
        state.jwtExpiresAtMs = 0;
        await writeHotJwtCache("", null, 0);
        jwt = await _getSupabaseJwtRaw(state, true);
        continue;
      }
      if (isTransientSupaStatus(resp.status) && attempt < 2) {
        lastResp = resp;
        await sleepMs(fullJitterBackoffMs(attempt, 180, 1500));
        continue;
      }
      return resp;
    } catch (err) {
      lastErr = err;
      if (attempt < 2) {
        await sleepMs(fullJitterBackoffMs(attempt, 180, 1500));
        continue;
      }
      throw err;
    }
  }
  if (lastResp) return lastResp;
  throw lastErr || new Error("Lỗi kết nối Máy chủ.");
}

async function enableLocalStandaloneMode() {
  return withVaultMutationLock(async () => {
    const st = cloneVaultStateForCaller(await _loadExtensionStateRaw());
    if (st.locked) {
      throw new Error("Kho tiện ích đang khóa — vui lòng nhập PIN trước.");
    }
    if (!st.pairing) {
      st.pairing = {
        version: 1,
        localOnly: true,
        deviceName: "Trình duyệt cục bộ"
      };
      await _saveExtensionStateRaw(st);
    }
    return st;
  });
}

const PASSKEY_TOMB_PREFIX = "passkey:";

function passkeyTombKey(credentialIdB64Url) {
  return PASSKEY_TOMB_PREFIX + String(credentialIdB64Url || "").trim();
}

function isPasskeyTombKey(key) {
  return typeof key === "string" && key.startsWith(PASSKEY_TOMB_PREFIX);
}

function pruneBrowserTombstonesWithFloor(
  tombstones,
  limit = MAX_BROWSER_TOMBSTONES,
  prevFloorMs = 0
) {
  const entries = Object.entries(tombstones || {})
    .map(([id, ts]) => [id, Number(ts) || 0])
    .filter(([, ts]) => ts > 0)
    .sort((a, b) => b[1] - a[1]);
  let floorMs = Number(prevFloorMs) || 0;
  if (entries.length <= limit) {
    return { tombstones: Object.fromEntries(entries), tombstoneFloorMs: floorMs };
  }
  const kept = entries.slice(0, limit);
  const pruned = entries.slice(limit);
  // Advance vault-item tombstone floor strictly from pruned vault-item IDs (NEVER from passkey:* tombstones).
  for (const [id, ts] of pruned) {
    if (!isPasskeyTombKey(id) && ts > floorMs) {
      floorMs = ts;
      break;
    }
  }
  return { tombstones: Object.fromEntries(kept), tombstoneFloorMs: floorMs };
}

function filterPasskeysByTombstones(list, tombstones) {
  const arr = Array.isArray(list) ? list : [];
  if (!tombstones || typeof tombstones !== "object") return arr;
  return arr.filter((pk) => {
    if (!pk || !pk.credential_id_b64url) return false;
    const delTs = Number(tombstones[passkeyTombKey(pk.credential_id_b64url)]) || 0;
    if (delTs <= 0) return true;
    const createdTs = Number(pk.created_at_ms) || 0;
    return createdTs > delTs;
  });
}

function mergePasskeyListsUnion(primaryList, secondaryList, tombstones = null) {
  const map = new Map();
  for (const rawList of [primaryList, secondaryList]) {
    for (const pk of Array.isArray(rawList) ? rawList : []) {
      if (!pk || !pk.credential_id_b64url) continue;
      const cid = pk.credential_id_b64url;
      if (tombstones && typeof tombstones === "object") {
        const delTs = Number(tombstones[passkeyTombKey(cid)]) || 0;
        if (delTs > 0 && delTs >= (Number(pk.created_at_ms) || 0)) {
          continue;
        }
      }
      const prev = map.get(cid);
      if (
        !prev ||
        (Number(pk.last_used_at_ms) || 0) > (Number(prev.last_used_at_ms) || 0) ||
        ((Number(pk.last_used_at_ms) || 0) === (Number(prev.last_used_at_ms) || 0) &&
          (Number(pk.sign_count) || 0) > (Number(prev.sign_count) || 0))
      ) {
        map.set(cid, pk);
      }
    }
  }
  return Array.from(map.values());
}

function canonicalCoreFieldsJson(item) {
  return JSON.stringify({
    service_name: item.service_name || "",
    username: item.username || "",
    password: item.password || "",
    totp_secret: item.totp_secret || null,
    totp_algorithm: item.totp_algorithm || "SHA1",
    totp_digits: Number(item.totp_digits) || 6,
    totp_period: Number(item.totp_period) || 30,
    web_domains: Array.isArray(item.web_domains) ? item.web_domains : [],
    android_packages: Array.isArray(item.android_packages) ? item.android_packages : [],
    recovery_codes: Array.isArray(item.recovery_codes) ? item.recovery_codes : [],
    pin_code: item.pin_code || null,
    notes: item.notes || "",
    folder: item.folder || "Chung",
    is_favorite: Boolean(item.is_favorite),
    pin_totp_to_dashboard: Boolean(item.pin_totp_to_dashboard)
  });
}

function mergePasswordHistoryUnion(primaryList, secondaryList) {
  const byEntry = new Map();
  for (const rawList of [primaryList, secondaryList]) {
    for (const h of Array.isArray(rawList) ? rawList : []) {
      if (!h || !h.password) continue;
      const ts = Number(h.changed_at_ms) || 0;
      const key = `${String(h.password)}\0${ts}`;
      if (!byEntry.has(key)) {
        byEntry.set(key, { password: String(h.password), changed_at_ms: ts });
      }
    }
  }
  return Array.from(byEntry.values())
    .sort((a, b) => b.changed_at_ms - a.changed_at_ms)
    .slice(0, 10);
}

function passkeyListsEqual(a, b) {
  const la = Array.isArray(a) ? a : [];
  const lb = Array.isArray(b) ? b : [];
  if (la.length !== lb.length) return false;
  const bMap = new Map(lb.map((x) => [x.credential_id_b64url, x]));
  for (const x of la) {
    const y = bMap.get(x.credential_id_b64url);
    if (
      !y ||
      (Number(x.last_used_at_ms) || 0) !== (Number(y.last_used_at_ms) || 0) ||
      (Number(x.sign_count) || 0) !== (Number(y.sign_count) || 0)
    ) {
      return false;
    }
  }
  return true;
}

function historyListsEqual(a, b) {
  const la = Array.isArray(a) ? a : [];
  const lb = Array.isArray(b) ? b : [];
  if (la.length !== lb.length) return false;
  for (let i = 0; i < la.length; i++) {
    if (la[i].password !== lb[i].password || (Number(la[i].changed_at_ms) || 0) !== (Number(lb[i].changed_at_ms) || 0)) {
      return false;
    }
  }
  return true;
}

async function _syncBrowserVaultBidirectionalRaw(forcePush = false, options = {}) {
  const state = await _loadExtensionStateRaw();
  if (state.locked) {
    throw new Error("Kho tiện ích đang khóa — vui lòng nhập PIN trước khi đồng bộ.");
  }
  const p = state.pairing;
  if (!p) throw new Error("Chưa kết nối thiết bị.");
  if (p.localOnly) {
    const sortedLocal = (Array.isArray(state.items) ? state.items : [])
      .slice()
      .sort((a, b) => {
        if (a.is_favorite !== b.is_favorite) return a.is_favorite ? -1 : 1;
        return VI_COLLATOR.compare(a.service_name, b.service_name);
      });
    state.items = sortedLocal;
    await _saveExtensionStateRaw(state, { alreadyNormalized: true });
    return {
      itemCount: sortedLocal.length,
      pulledCount: 0,
      pushed: false,
      localOnly: true,
      state: cloneVaultStateForCaller(state)
    };
  }

  const qDev = encodeURIComponent(p.deviceId);
  const getUrl = `${p.supabaseUrl}/rest/v1/omnivault_browser_vault?device_id=eq.${qDev}&select=*&limit=1`;

  const baseLocalItems = Array.isArray(state.items)
    ? options.alreadyNormalized
      ? state.items
      : state.items.map(normalizeVaultItem)
    : [];
  const baseTombstones = { ...(state.deletedIds || {}) };
  const baseTombstoneFloorMs = Number(state.tombstoneFloorMs) || 0;
  const hadPriorSync = Number(state.lastSyncedAtMs || 0) > 0;

  let finalMergedAll = [];
  let finalTombstones = pruneBrowserTombstonesWithFloor(
    baseTombstones,
    MAX_BROWSER_TOMBSTONES,
    baseTombstoneFloorMs
  ).tombstones;
  let finalTombstoneFloorMs = baseTombstoneFloorMs;
  let finalPulledCount = 0;
  let finalPushed = false;
  let casCommitted = false;

  for (let attempt = 0; attempt < 3; attempt++) {
    const getResp = await _supaFetchWithAuthRetry(state, getUrl, (jwt) => ({
      method: "GET",
      headers: {
        apikey: p.supabaseAnonKey,
        Authorization: `Bearer ${jwt}`
      }
    }));
    if (!getResp.ok) {
      throw new Error(`Không tải được Kho Trình duyệt (${getResp.status}).`);
    }
    const rows = await getResp.json();
    const remoteRow = Array.isArray(rows) && rows.length > 0 ? rows[0] : null;
    const expectedRevision = Number(remoteRow?.revision || 0);

    const tombstones = { ...baseTombstones };
    let tombstoneFloorMs = baseTombstoneFloorMs;
    const localMap = new Map();
    const localOnlyMap = new Map();
    for (const it of baseLocalItems) {
      if (it.localOnly) {
        localOnlyMap.set(it.id, it);
      } else {
        localMap.set(it.id, it);
      }
    }

    let needPush = forcePush || !remoteRow;
    let pulledCount = 0;

    if (remoteRow && remoteRow.enc_nonce_b64 && remoteRow.enc_ciphertext_b64) {
      const remotePayload = await decryptBrowserVaultPayload(
        p.syncKeyB64,
        remoteRow.enc_nonce_b64,
        remoteRow.enc_ciphertext_b64
      );
      const localFloorMs = baseTombstoneFloorMs;
      const remoteFloorMs = Number(
        remotePayload.tombstone_floor_ms || remotePayload.tombstoneFloorMs || 0
      );
      if (remoteFloorMs > tombstoneFloorMs) {
        tombstoneFloorMs = remoteFloorMs;
      } else if (localFloorMs > remoteFloorMs) {
        needPush = true;
      }

      const remoteDeleted = remotePayload.deleted_ids || {};
      for (const [delId, delTs] of Object.entries(remoteDeleted)) {
        if (localOnlyMap.has(delId)) continue;
        const ts = Number(delTs) || 0;
        if (!tombstones[delId] || ts > tombstones[delId]) {
          tombstones[delId] = ts;
        }
      }

      const remoteItems = Array.isArray(remotePayload.items) ? remotePayload.items : [];
      // Purge stale tombstones if an item was restored from Trash on Android or re-saved with a newer timestamp
      for (const rawRemote of remoteItems) {
        const rTs = Number(rawRemote?.updated_at_ms) || 0;
        const rId = rawRemote?.id;
        if (rId && tombstones[rId] && rTs > tombstones[rId]) {
          delete tombstones[rId];
        }
        for (const pk of Array.isArray(rawRemote?.passkeys) ? rawRemote.passkeys : []) {
          const pkKey = pk?.credential_id_b64url ? passkeyTombKey(pk.credential_id_b64url) : "";
          const pkCreated = Number(pk?.created_at_ms) || 0;
          if (pkKey && tombstones[pkKey] && pkCreated > tombstones[pkKey]) {
            delete tombstones[pkKey];
          }
        }
      }
      for (const [id, item] of localMap.entries()) {
        if (tombstones[id] && item.updated_at_ms > tombstones[id]) {
          delete tombstones[id];
        }
        for (const pk of Array.isArray(item.passkeys) ? item.passkeys : []) {
          const pkKey = pk?.credential_id_b64url ? passkeyTombKey(pk.credential_id_b64url) : "";
          const pkCreated = Number(pk?.created_at_ms) || 0;
          if (pkKey && tombstones[pkKey] && pkCreated > tombstones[pkKey]) {
            delete tombstones[pkKey];
          }
        }
      }

      for (const [locDelId, locDelTs] of Object.entries(tombstones)) {
        if ((Number(remoteDeleted[locDelId]) || 0) < locDelTs) {
          needPush = true;
        }
      }

      // Apply tombstones to syncable local items only (never delete localOnly items via remote tombstones)
      for (const [id, item] of Array.from(localMap.entries())) {
        if (tombstones[id] && tombstones[id] >= item.updated_at_ms) {
          localMap.delete(id);
          pulledCount++;
          continue;
        }
        if (Array.isArray(item.passkeys) && item.passkeys.length > 0) {
          const filteredPks = filterPasskeysByTombstones(item.passkeys, tombstones);
          if (filteredPks.length !== item.passkeys.length) {
            localMap.set(id, { ...item, passkeys: filteredPks });
            pulledCount++;
          }
        }
      }

      const remoteIds = new Set();
      for (const rawRemote of remoteItems) {
        const rItemRaw = normalizeVaultItem(rawRemote);
        if (localOnlyMap.has(rItemRaw.id)) {
          continue;
        }
        if (tombstones[rItemRaw.id] && tombstones[rItemRaw.id] >= rItemRaw.updated_at_ms) {
          needPush = true;
          continue;
        }
        // S-05 + P0-1: Check remote-only items strictly against localFloorMs AND require created_at_ms <= localFloorMs
        // so freshly created or newly imported records with historical updated_at_ms are never silently dropped.
        const rCreated = Number(rItemRaw.created_at_ms) || 0;
        if (
          !localMap.has(rItemRaw.id) &&
          localFloorMs > 0 &&
          rCreated > 0 &&
          rCreated <= localFloorMs &&
          rItemRaw.updated_at_ms <= localFloorMs
        ) {
          needPush = true;
          continue;
        }
        const filteredRemotePks = filterPasskeysByTombstones(rItemRaw.passkeys, tombstones);
        const rItem =
          filteredRemotePks.length !== (rItemRaw.passkeys || []).length
            ? { ...rItemRaw, passkeys: filteredRemotePks }
            : rItemRaw;
        if (filteredRemotePks.length !== (rItemRaw.passkeys || []).length) {
          needPush = true;
        }
        remoteIds.add(rItem.id);
        const lItem = localMap.get(rItem.id);
        if (!lItem) {
          localMap.set(rItem.id, rItem);
          pulledCount++;
        } else {
          let remoteWins = rItem.updated_at_ms > lItem.updated_at_ms;
          let localWins = lItem.updated_at_ms > rItem.updated_at_ms;
          let equalTsDiff = false;
          if (!remoteWins && !localWins) {
            const lCore = canonicalCoreFieldsJson(lItem);
            const rCore = canonicalCoreFieldsJson(rItem);
            if (lCore !== rCore) {
              equalTsDiff = true;
              // Deterministic lexicographic tie-breaker ensures all devices converge on identical winner
              if (rCore > lCore) {
                remoteWins = true;
              } else {
                localWins = true;
              }
            }
          }
          const winner = remoteWins ? rItem : lItem;
          const loser = remoteWins ? lItem : rItem;
          const mergedPasskeys = mergePasskeyListsUnion(winner.passkeys, loser.passkeys, tombstones);
          const mergedHistory = mergePasswordHistoryUnion(winner.password_history, loser.password_history);
          const merged = {
            ...winner,
            passkeys: mergedPasskeys,
            password_history: mergedHistory
          };
          const localChanged =
            remoteWins ||
            !passkeyListsEqual(mergedPasskeys, lItem.passkeys) ||
            !historyListsEqual(mergedHistory, lItem.password_history);
          const remoteNeedsPush =
            localWins ||
            equalTsDiff ||
            !passkeyListsEqual(mergedPasskeys, rItemRaw.passkeys) ||
            !historyListsEqual(mergedHistory, rItemRaw.password_history);
          localMap.set(rItem.id, merged);
          if (localChanged) pulledCount++;
          if (remoteNeedsPush) needPush = true;
        }
      }

      for (const [k, lItem] of Array.from(localMap.entries())) {
        if (!remoteIds.has(k)) {
          const lCreated = Number(lItem.created_at_ms) || 0;
          if (
            remoteFloorMs > 0 &&
            hadPriorSync &&
            lCreated > 0 &&
            lCreated <= remoteFloorMs &&
            lItem.updated_at_ms <= remoteFloorMs
          ) {
            // Remote pruned a deletion tombstone newer than this stale local copy -> remove instead of resurrecting
            localMap.delete(k);
            pulledCount++;
          } else {
            needPush = true;
          }
        }
      }
    }

    const prunedResult = pruneBrowserTombstonesWithFloor(
      tombstones,
      MAX_BROWSER_TOMBSTONES,
      tombstoneFloorMs
    );
    const cappedTombstones = prunedResult.tombstones;
    const nextFloorMs = prunedResult.tombstoneFloorMs;

    const syncableMerged = Array.from(localMap.values()).sort((a, b) => {
      if (a.is_favorite !== b.is_favorite) return a.is_favorite ? -1 : 1;
      return VI_COLLATOR.compare(a.service_name, b.service_name);
    });
    const combinedAll = Array.from([...syncableMerged, ...localOnlyMap.values()]).sort((a, b) => {
      if (a.is_favorite !== b.is_favorite) return a.is_favorite ? -1 : 1;
      return VI_COLLATOR.compare(a.service_name, b.service_name);
    });

    finalMergedAll = combinedAll;
    finalTombstones = cappedTombstones;
    finalTombstoneFloorMs = nextFloorMs;
    finalPulledCount = pulledCount;
    finalPushed = needPush;

    if (!needPush) {
      casCommitted = true;
      break;
    }

    const now = Date.now();
    const payload = {
      items: syncableMerged,
      deleted_ids: cappedTombstones,
      tombstone_floor_ms: nextFloorMs,
      updated_at_ms: now
    };
    const enc = await encryptBrowserVaultPayload(p.syncKeyB64, payload);

    let pushResp;
    if (expectedRevision <= 0) {
      const postUrl = `${p.supabaseUrl}/rest/v1/omnivault_browser_vault?on_conflict=user_id,device_id`;
      pushResp = await _supaFetchWithAuthRetry(state, postUrl, (jwt) => ({
        method: "POST",
        headers: {
          apikey: p.supabaseAnonKey,
          Authorization: `Bearer ${jwt}`,
          Prefer: "resolution=ignore-duplicates,return=representation",
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          device_id: p.deviceId,
          device_name: p.deviceName,
          enc_nonce_b64: enc.nonceB64,
          enc_ciphertext_b64: enc.ciphertextB64,
          item_count: syncableMerged.length,
          updated_at_ms: now
        })
      }));
    } else {
      const patchUrl = `${p.supabaseUrl}/rest/v1/omnivault_browser_vault?device_id=eq.${qDev}&revision=eq.${expectedRevision}`;
      pushResp = await _supaFetchWithAuthRetry(state, patchUrl, (jwt) => ({
        method: "PATCH",
        headers: {
          apikey: p.supabaseAnonKey,
          Authorization: `Bearer ${jwt}`,
          Prefer: "return=representation",
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          device_name: p.deviceName,
          enc_nonce_b64: enc.nonceB64,
          enc_ciphertext_b64: enc.ciphertextB64,
          item_count: syncableMerged.length,
          updated_at_ms: now
        })
      }));
    }

    if (pushResp.status === 409) {
      if (attempt < 2) {
        await sleepMs(fullJitterBackoffMs(attempt, 200, 2000));
      }
      continue;
    }
    if (!pushResp.ok) {
      throw new Error(`Lỗi đẩy dữ liệu lên Máy chủ (${pushResp.status}).`);
    }

    const respText = await pushResp.text();
    let appliedRows = [];
    try {
      appliedRows = respText ? JSON.parse(respText) : [];
    } catch (_) {
      appliedRows = [];
    }
    if (Array.isArray(appliedRows) && appliedRows.length > 0) {
      casCommitted = true;
      break;
    }
    // Empty representation means a concurrent revision won the race -> Full-Jitter backoff then re-pull & retry
    if (attempt < 2) {
      await sleepMs(fullJitterBackoffMs(attempt, 200, 2000));
    }
  }

  if (!casCommitted) {
    throw new Error("Xung đột đồng bộ đồng thời (CAS). Vui lòng thử đồng bộ lại.");
  }

  const syncNow = Date.now();
  let tombstonesChanged = Object.keys(finalTombstones).length !== Object.keys(baseTombstones).length;
  if (!tombstonesChanged) {
    for (const [tid, tts] of Object.entries(finalTombstones)) {
      if (baseTombstones[tid] !== tts) {
        tombstonesChanged = true;
        break;
      }
    }
  }
  const vaultDataChanged =
    finalPulledCount > 0 ||
    finalPushed ||
    finalTombstoneFloorMs !== baseTombstoneFloorMs ||
    tombstonesChanged;

  state.items = finalMergedAll;
  state.deletedIds = finalTombstones;
  state.tombstoneFloorMs = finalTombstoneFloorMs;
  state.lastSyncedAtMs = syncNow;

  if (vaultDataChanged) {
    await _saveExtensionStateRaw(state, { alreadyNormalized: true });
  } else {
    // Nothing changed in vault contents — update only lightweight metadata timestamp (no vault re-encryption!)
    const prevFlags = await readHotMetaFlags();
    const nextFlags = buildMetaFlagsObject(
      state.hasPinLock,
      state.pairing,
      state.deviceNameHint,
      syncNow
    );
    if (prevFlags && typeof prevFlags.lockTimeoutMin === "number") {
      nextFlags.lockTimeoutMin = prevFlags.lockTimeoutMin;
    }
    _memMetaFlagsCache = nextFlags;
    if (_memVaultCache && _memVaultCache.state) {
      _memVaultCache.state.lastSyncedAtMs = syncNow;
    }
    if (chrome?.storage?.local) {
      try {
        await chrome.storage.local.set({ [OMNIVAULT_META_FLAGS_KEY]: nextFlags });
      } catch (_) {}
    }
  }

  return {
    itemCount: finalMergedAll.length,
    pulledCount: finalPulledCount,
    pushed: finalPushed,
    state: cloneVaultStateForCaller(state)
  };
}

async function syncBrowserVaultBidirectional(forcePush = false) {
  return withVaultMutationLock(() => _syncBrowserVaultBidirectionalRaw(forcePush));
}

async function pairWithCloudCode(rawCode) {
  // 1. Validate pairing code structure & HTTPS/key before touching any stored data
  const pairing = parsePairingCode(rawCode);
  const preState = await _loadExtensionStateRaw();
  if (preState.locked) {
    throw new Error(
      "Tiện ích đang khóa bằng PIN! Vui lòng nhập PIN mở khóa trước khi kết nối."
    );
  }

  // 2. Authenticate & verify cloud handshake + decryption in-memory BEFORE modifying local storage!
  const auth = await _fetchSupabaseJwtOnly(pairing);
  const qDev = encodeURIComponent(pairing.deviceId);
  const probeUrl = `${pairing.supabaseUrl}/rest/v1/omnivault_browser_vault?device_id=eq.${qDev}&select=*&limit=1`;
  const probeResp = await fetchWithTimeout(
    probeUrl,
    {
      method: "GET",
      headers: {
        apikey: pairing.supabaseAnonKey,
        Authorization: `Bearer ${auth.jwt}`
      }
    },
    DEFAULT_FETCH_TIMEOUT_MS
  );
  if (!probeResp.ok) {
    throw new Error(`Không xác minh được Kho Trình duyệt trên Máy chủ (${probeResp.status}).`);
  }
  const probeRows = await probeResp.json();
  const remoteRow = Array.isArray(probeRows) && probeRows.length > 0 ? probeRows[0] : null;
  if (remoteRow && remoteRow.enc_nonce_b64 && remoteRow.enc_ciphertext_b64) {
    try {
      await decryptBrowserVaultPayload(
        pairing.syncKeyB64,
        remoteRow.enc_nonce_b64,
        remoteRow.enc_ciphertext_b64
      );
    } catch (_) {
      throw new Error("Khóa giải mã trong Mã Kết Nối không khớp với dữ liệu trên Máy chủ.");
    }
  }

  // 3. Switch storage atomically under Web Lock with automatic rollback on sync/merge error
  return withVaultMutationLock(async () => {
    const st = await _loadExtensionStateRaw();
    if (st.locked) {
      throw new Error(
        "Tiện ích đang khóa bằng PIN! Vui lòng nhập PIN mở khóa trước khi kết nối."
      );
    }
    const prevSnapshot = JSON.parse(JSON.stringify(st));
    const priorLocalItems =
      st.pairing && st.pairing.localOnly && Array.isArray(st.items)
        ? st.items.map(normalizeVaultItem)
        : [];

    st.pairing = pairing;
    st.jwt = auth.jwt;
    st.jwtExpiresAtMs = auth.jwtExpiresAtMs;
    st.items = [];
    st.deletedIds = {};
    st.tombstoneFloorMs = 0;
    st.lastSyncedAtMs = 0;
    await _saveExtensionStateRaw(st);

    try {
      let itemCount = 0;
      if (priorLocalItems.length > 0) {
        const merged = await _importAndPushAllToServerRaw(priorLocalItems);
        itemCount = merged.totalServerCount;
      } else {
        const syncRes = await _syncBrowserVaultBidirectionalRaw(false);
        itemCount = syncRes.itemCount;
      }
      return {
        pairing,
        itemCount,
        mergedLocalCount: priorLocalItems.length
      };
    } catch (err) {
      // Roll back to prior local state so local-mode passwords are never lost!
      await _saveExtensionStateRaw(prevSnapshot);
      throw err;
    }
  });
}

function randomUnbiasedIndex(max) {
  if (max <= 1) return 0;
  const limit = Math.floor(0x100000000 / max) * max;
  const buf = new Uint32Array(1);
  while (true) {
    crypto.getRandomValues(buf);
    if (buf[0] < limit) {
      return buf[0] % max;
    }
  }
}

function generateStrongPassword(length = 18) {
  const len = Math.max(4, Math.min(128, Math.floor(Number(length) || 18)));
  const upper = "ABCDEFGHJKLMNPQRSTUVWXYZ";
  const lower = "abcdefghijkmnopqrstuvwxyz";
  const digits = "23456789";
  const symbols = "!@#$%^&*_-+=";
  const all = upper + lower + digits + symbols;
  const out = [
    upper[randomUnbiasedIndex(upper.length)],
    lower[randomUnbiasedIndex(lower.length)],
    digits[randomUnbiasedIndex(digits.length)],
    symbols[randomUnbiasedIndex(symbols.length)]
  ];
  for (let i = 4; i < len; i++) {
    out.push(all[randomUnbiasedIndex(all.length)]);
  }
  for (let i = out.length - 1; i > 0; i--) {
    const j = randomUnbiasedIndex(i + 1);
    const tmp = out[i];
    out[i] = out[j];
    out[j] = tmp;
  }
  return out.join("");
}

// --- RFC-4180 Browser CSV & Bitwarden JSON Bulk Parser ---
function parseCsvMatrix(csvText) {
  const rows = [];
  let curRow = [];
  let curField = "";
  let inQuotes = false;
  const s = String(csvText || "").replace(/^\uFEFF/, "");

  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    if (inQuotes) {
      if (ch === '"') {
        if (i + 1 < s.length && s[i + 1] === '"') {
          curField += '"';
          i++;
        } else {
          inQuotes = false;
        }
      } else {
        curField += ch;
      }
    } else {
      if (ch === '"' && curField.length === 0) {
        inQuotes = true;
      } else if (ch === ",") {
        curRow.push(curField);
        curField = "";
      } else if (ch === "\r" || ch === "\n") {
        if (ch === "\r" && i + 1 < s.length && s[i + 1] === "\n") {
          i++;
        }
        curRow.push(curField);
        curField = "";
        if (curRow.some((cell) => cell.length > 0)) {
          rows.push(curRow);
        }
        curRow = [];
      } else {
        curField += ch;
      }
    }
  }
  if (curField.length > 0 || curRow.length > 0) {
    curRow.push(curField);
    if (curRow.some((cell) => cell.length > 0)) {
      rows.push(curRow);
    }
  }
  return rows;
}

function parseOtpAuthUri(rawUri) {
  const t = String(rawUri || "").trim();
  if (!/^otpauth:\/\//i.test(t)) {
    throw new Error("Chuỗi TOTP URI phải bắt đầu bằng otpauth://.");
  }
  let u;
  try {
    u = new URL(t);
  } catch (_) {
    throw new Error("Không thể phân tích otpauth URI.");
  }
  const otpType = (u.hostname || "").toLowerCase();
  if (otpType === "hotp" || otpType !== "totp") {
    throw new Error(`Không hỗ trợ loại OTP "${otpType || "unknown"}" (chỉ hỗ trợ TOTP).`);
  }
  const rawPath = (u.pathname || "").replace(/^\/+/, "");
  let decodedLabel = rawPath;
  try {
    // Preserve literal '+' in URL path segments (e.g. user+tag@gmail.com)
    decodedLabel = decodeURIComponent(rawPath);
  } catch (_) {
    decodedLabel = rawPath;
  }
  const colonIdx = decodedLabel.indexOf(":");
  const labelIssuer = colonIdx >= 0 ? decodedLabel.slice(0, colonIdx).trim() : "";
  const account = colonIdx >= 0 ? decodedLabel.slice(colonIdx + 1).trim() : decodedLabel.trim();

  const rawSec = (u.searchParams.get("secret") || "").trim();
  const cleanSec = rawSec.replace(/[\s\-=]+/g, "").toUpperCase();
  if (!cleanSec || !/^[A-Z2-7]+$/.test(cleanSec) || decodeBase32(cleanSec).length === 0) {
    throw new Error("Secret Base32 trong otpauth:// không hợp lệ.");
  }

  const algRaw = (u.searchParams.get("algorithm") || "SHA1").trim().toUpperCase();
  const algorithm = algRaw === "SHA256" || algRaw === "SHA512" ? algRaw : "SHA1";
  const digitsNum = Number(u.searchParams.get("digits") || 6);
  const digits = Number.isInteger(digitsNum) && digitsNum >= 6 && digitsNum <= 8 ? digitsNum : 6;
  const periodNum = Number(u.searchParams.get("period") || 30);
  const period = Number.isFinite(periodNum) && periodNum > 0 ? Math.floor(periodNum) : 30;
  const issuer = String(u.searchParams.get("issuer") || labelIssuer || "").trim();

  return {
    type: "totp",
    secret: cleanSec,
    algorithm,
    digits,
    period,
    issuer,
    account,
    label: decodedLabel
  };
}

function parseTotpFieldWithMeta(rawTotp) {
  const t = String(rawTotp || "").trim();
  if (!t) return null;
  if (/^otpauth:\/\//i.test(t)) {
    try {
      const parsed = parseOtpAuthUri(t);
      return {
        secret: parsed.secret,
        algorithm: parsed.algorithm,
        digits: parsed.digits,
        period: parsed.period
      };
    } catch (_) {
      return null;
    }
  }
  if (/^[A-Z2-7\s\-=]{8,}$/i.test(t) && decodeBase32(t).length > 0) {
    return {
      secret: t.replace(/[\s\-=]+/g, "").toUpperCase(),
      algorithm: "SHA1",
      digits: 6,
      period: 30
    };
  }
  return null;
}

function parseTotpSecretField(rawTotp) {
  const meta = parseTotpFieldWithMeta(rawTotp);
  return meta ? meta.secret : null;
}

function yieldToEventLoop() {
  if (typeof scheduler !== "undefined" && typeof scheduler.yield === "function") {
    return scheduler.yield();
  }
  return new Promise((resolve) => setTimeout(resolve, 0));
}

function buildBitwardenVaultItem(item, now) {
  if (!item || !item.login) return null;
  const webDomains = [];
  const androidPackages = [];
  for (const u of Array.isArray(item.login.uris) ? item.login.uris : []) {
    const uriStr = String(u?.uri || "").trim();
    if (!uriStr) continue;
    const pkg = extractAndroidPackageFromUri(uriStr);
    if (pkg) {
      if (!androidPackages.some((p) => p.toLowerCase() === pkg.toLowerCase())) {
        androidPackages.push(pkg);
      }
    } else {
      const dom = extractCleanDomain(uriStr);
      if (dom && !webDomains.includes(dom)) webDomains.push(dom);
    }
  }
  const username = String(item.login.username || "").trim();
  const password = String(item.login.password || "");
  const totpMeta = parseTotpFieldWithMeta(item.login.totp);
  if (!username && !password && !totpMeta) return null;
  return normalizeVaultItem({
    id: crypto.randomUUID(),
    service_name:
      String(item.name || "").trim() ||
      webDomains[0] ||
      (androidPackages[0] ? friendlyServiceNameFromPackage(androidPackages[0]) : "Tài khoản Web"),
    username,
    password,
    totp_secret: totpMeta ? totpMeta.secret : null,
    totp_algorithm: totpMeta ? totpMeta.algorithm : "SHA1",
    totp_digits: totpMeta ? totpMeta.digits : 6,
    totp_period: totpMeta ? totpMeta.period : 30,
    web_domains: webDomains,
    android_packages: androidPackages,
    notes: String(item.notes || ""),
    folder: "Bitwarden",
    is_favorite: Boolean(item.favorite),
    created_at_ms: now,
    updated_at_ms: now
  });
}

function resolveCsvColumns(headerRow) {
  const headers = headerRow.map((h) => h.replace(/^\uFEFF/, "").trim().toLowerCase());
  const findCol = (candidates) => headers.findIndex((h) => candidates.includes(h));

  const idxName = findCol(["name", "title", "service", "account", "site", "dịch vụ", "tên"]);
  const idxUrl = findCol([
    "url",
    "login_uri",
    "website",
    "web site",
    "origin",
    "hostname",
    "signon_realm",
    "httprealm",
    "formsubmitorigin",
    "địa chỉ",
    "trang web"
  ]);
  const idxUser = findCol([
    "username",
    "login_username",
    "user",
    "login",
    "login name",
    "email",
    "tài khoản",
    "tên đăng nhập"
  ]);
  const idxPass = findCol(["password", "login_password", "pass", "mật khẩu"]);
  const idxNote = findCol(["note", "notes", "comment", "comments", "extra", "ghi chú"]);
  const idxTotp = findCol([
    "login_totp",
    "totp",
    "totp_secret",
    "otpauth",
    "verification code",
    "totp secret",
    "one-time password",
    "2fa"
  ]);

  if (idxUser < 0 && idxPass < 0) {
    throw new Error(
      "Không nhận diện được cột username / password. Vui lòng chọn đúng file .CSV xuất từ Trình duyệt."
    );
  }
  return { idxName, idxUrl, idxUser, idxPass, idxNote, idxTotp };
}

function buildCsvVaultItem(row, cols, now) {
  const urlVal = cols.idxUrl >= 0 ? String(row[cols.idxUrl] || "").trim() : "";
  const androidPkg = extractAndroidPackageFromUri(urlVal);
  const domain = androidPkg ? "" : extractCleanDomain(urlVal);

  let rawName = cols.idxName >= 0 ? String(row[cols.idxName] || "").trim() : "";
  if (rawName && (extractAndroidPackageFromUri(rawName) || /^android:\/\//i.test(rawName))) {
    rawName = "";
  } else if (/^https?:\/\//i.test(rawName)) {
    rawName = extractCleanDomain(rawName) || rawName;
  }

  const serviceName =
    rawName ||
    domain ||
    (androidPkg ? friendlyServiceNameFromPackage(androidPkg) : "Tài khoản Web");

  const username = cols.idxUser >= 0 ? String(row[cols.idxUser] || "").trim() : "";
  const password = cols.idxPass >= 0 ? String(row[cols.idxPass] ?? "") : "";
  const notes = cols.idxNote >= 0 ? String(row[cols.idxNote] || "").trim() : "";
  const totpMeta = cols.idxTotp >= 0 ? parseTotpFieldWithMeta(row[cols.idxTotp]) : null;

  if (!username && !password && !totpMeta) return null;

  return normalizeVaultItem({
    id: crypto.randomUUID(),
    service_name: serviceName,
    username,
    password,
    totp_secret: totpMeta ? totpMeta.secret : null,
    totp_algorithm: totpMeta ? totpMeta.algorithm : "SHA1",
    totp_digits: totpMeta ? totpMeta.digits : 6,
    totp_period: totpMeta ? totpMeta.period : 30,
    web_domains: domain ? [domain] : [],
    android_packages: androidPkg ? [androidPkg] : [],
    notes,
    folder: "Trình duyệt",
    created_at_ms: now,
    updated_at_ms: now
  });
}

function extractCxfFieldValue(field) {
  if (field == null) return "";
  if (typeof field === "string") return field;
  if (typeof field === "object" && field.value != null) return String(field.value);
  return "";
}

function buildFidoCxfVaultItem(item, now) {
  if (!item || typeof item !== "object") return null;
  const webDomains = [];
  const androidPackages = [];
  const pushUrlOrApp = (raw) => {
    const uriStr = String(raw || "").trim();
    if (!uriStr) return;
    const pkg = extractAndroidPackageFromUri(uriStr);
    if (pkg) {
      if (!androidPackages.some((p) => p.toLowerCase() === pkg.toLowerCase())) {
        androidPackages.push(pkg);
      }
      return;
    }
    const dom = extractCleanDomain(uriStr);
    if (dom && !webDomains.includes(dom)) webDomains.push(dom);
  };

  const applyScope = (scope) => {
    if (!scope || typeof scope !== "object") return;
    for (const u of Array.isArray(scope.urls) ? scope.urls : []) {
      pushUrlOrApp(typeof u === "string" ? u : u?.url || u?.uri || "");
    }
    for (const app of Array.isArray(scope.androidApps) ? scope.androidApps : []) {
      const appId = typeof app === "string" ? app : app?.id || app?.packageName || "";
      const cleanPkg = String(appId || "").trim();
      if (cleanPkg) {
        const extracted = extractAndroidPackageFromUri(cleanPkg) || (/^[a-zA-Z0-9_]+(\.[a-zA-Z0-9_]+)+$/.test(cleanPkg) ? cleanPkg : "");
        if (extracted && !androidPackages.some((p) => p.toLowerCase() === extracted.toLowerCase())) {
          androidPackages.push(extracted);
        }
      }
    }
  };

  applyScope(item.scope);

  let username = "";
  let password = "";
  let totpMeta = null;
  const noteParts = [];
  const passkeys = [];

  const creds = Array.isArray(item.credentials) ? item.credentials : [];
  for (const cred of creds) {
    if (!cred || typeof cred !== "object") continue;
    const cType = String(cred.type || "").trim().toLowerCase();
    applyScope(cred.scope);
    if (Array.isArray(cred.urls)) {
      for (const u of cred.urls) pushUrlOrApp(typeof u === "string" ? u : u?.url || "");
    }
    if (cType === "basic-auth" || cType === "password") {
      if (!username) {
        username = extractCxfFieldValue(cred.username).trim();
      }
      if (!password) {
        // Preserve leading/trailing password whitespace verbatim
        password = extractCxfFieldValue(cred.password);
      }
    } else if (cType === "totp") {
      const rawSec = extractCxfFieldValue(cred.secret || cred.uri || cred.otpauth);
      if (rawSec) {
        const parsed = parseTotpFieldWithMeta(rawSec);
        if (parsed) {
          const algRaw = String(cred.algorithm || parsed.algorithm || "SHA1").trim().toUpperCase();
          const algorithm = algRaw === "SHA256" || algRaw === "SHA512" ? algRaw : "SHA1";
          const digitsNum = Number(cred.digits || parsed.digits || 6);
          const digits = Number.isInteger(digitsNum) && digitsNum >= 6 && digitsNum <= 8 ? digitsNum : 6;
          const periodNum = Number(cred.period || parsed.period || 30);
          const period = Number.isFinite(periodNum) && periodNum > 0 ? Math.floor(periodNum) : 30;
          totpMeta = { secret: parsed.secret, algorithm, digits, period };
        }
      }
      if (!username && cred.username) {
        username = extractCxfFieldValue(cred.username).trim();
      }
    } else if (cType === "passkey" || cType === "fido2") {
      const credId = extractCxfFieldValue(cred.credentialId || cred.credential_id_b64url || cred.credential_id || cred.id).trim();
      const rpId = extractCxfFieldValue(cred.rpId || cred.rp_id).trim().toLowerCase().replace(/\.+$/, "");
      const rpName = extractCxfFieldValue(cred.rpName || cred.rp_name).trim() || rpId;
      const userHandle = extractCxfFieldValue(cred.userHandle || cred.user_handle_b64url || cred.user_handle).trim();
      const pkUserName = extractCxfFieldValue(cred.userName || cred.user_name || cred.username).trim();
      const pkUserDisplay = extractCxfFieldValue(cred.userDisplayName || cred.user_display_name || cred.displayName).trim() || pkUserName;
      const rawPriv = extractCxfFieldValue(cred.key || cred.privateKey || cred.private_key_pkcs8_b64 || cred.private_key).trim();
      const rawPub = extractCxfFieldValue(cred.publicKey || cred.public_key_spki_b64 || cred.public_key).trim();
      const pkCreatedRaw = Number(cred.creationDate ?? cred.created_at_ms ?? cred.createdAtMs);
      const pkCreatedMs = Number.isFinite(pkCreatedRaw) && pkCreatedRaw > 0
        ? pkCreatedRaw < 1e12 ? pkCreatedRaw * 1000 : pkCreatedRaw
        : now;
      const normalizedPk = normalizePasskeyRecord(
        {
          credential_id_b64url: credId,
          rp_id: rpId,
          rp_name: rpName,
          user_handle_b64url: userHandle,
          user_name: pkUserName,
          user_display_name: pkUserDisplay,
          private_key_pkcs8_b64: rawPriv ? normalizeStandardBase64(rawPriv) : "",
          public_key_spki_b64: rawPub ? normalizeStandardBase64(rawPub) : "",
          alg: cred.alg ?? -7,
          sign_count: cred.signCount ?? cred.sign_count ?? 0,
          created_at_ms: pkCreatedMs,
          last_used_at_ms: cred.lastUsedAtMs ?? cred.last_used_at_ms ?? null
        },
        now
      );
      if (normalizedPk) {
        passkeys.push(normalizedPk);
        pushUrlOrApp(normalizedPk.rp_id);
        if (!username && normalizedPk.user_name) {
          username = normalizedPk.user_name;
        }
      }
    } else if (cType === "note") {
      const noteText = extractCxfFieldValue(cred.content || cred.text || cred.note).trim();
      if (noteText) noteParts.push(noteText);
    }
  }

  if (typeof item.notes === "string" && item.notes.trim()) {
    noteParts.push(item.notes.trim());
  } else if (typeof item.subtitle === "string" && item.subtitle.trim() && item.subtitle.trim() !== username) {
    noteParts.push(item.subtitle.trim());
  }

  if (!username && !password && !totpMeta && passkeys.length === 0) return null;

  return normalizeVaultItem({
    id: crypto.randomUUID(),
    service_name:
      String(item.title || item.name || "").trim() ||
      webDomains[0] ||
      (passkeys[0] ? passkeys[0].rp_name || passkeys[0].rp_id : "") ||
      (androidPackages[0] ? friendlyServiceNameFromPackage(androidPackages[0]) : "Tài khoản Web"),
    username,
    password,
    totp_secret: totpMeta ? totpMeta.secret : null,
    totp_algorithm: totpMeta ? totpMeta.algorithm : "SHA1",
    totp_digits: totpMeta ? totpMeta.digits : 6,
    totp_period: totpMeta ? totpMeta.period : 30,
    web_domains: webDomains,
    android_packages: androidPackages,
    passkeys,
    notes: noteParts.join("\n"),
    folder: "FIDO CXF",
    is_favorite: Boolean(item.favorite),
    created_at_ms: now,
    updated_at_ms: now
  });
}

function flattenFidoCxfItems(root) {
  const flat = [];
  if (!root || typeof root !== "object") return flat;
  if (Array.isArray(root.accounts)) {
    for (const acc of root.accounts) {
      if (acc && Array.isArray(acc.items)) {
        for (const it of acc.items) flat.push(it);
      }
    }
  }
  return flat;
}

function parseFidoCxfDocument(root, now = Date.now()) {
  const rawItems = flattenFidoCxfItems(root);
  const out = [];
  for (const it of rawItems) {
    const built = buildFidoCxfVaultItem(it, now);
    if (built) out.push(built);
  }
  return out;
}

function parseBrowserPasswordsText(rawText) {
  const rawNoBom = String(rawText || "").replace(/^\uFEFF/, "");
  const trimmedDetect = rawNoBom.trim();
  if (!trimmedDetect) {
    throw new Error("File mật khẩu đang trống.");
  }

  const now = Date.now();
  // 1. Auto-detect FIDO CXF 1.0 JSON or Bitwarden JSON
  if (trimmedDetect.startsWith("{")) {
    let root;
    try {
      root = JSON.parse(trimmedDetect);
    } catch (e) {
      throw new Error("File JSON không hợp lệ: " + (e.message || e));
    }
    if (Array.isArray(root.accounts)) {
      return parseFidoCxfDocument(root, now);
    }
    if (!Array.isArray(root.items)) {
      throw new Error("Không nhận diện được định dạng FIDO CXF (accounts) hoặc Bitwarden (items) trong file JSON.");
    }
    const out = [];
    for (const item of root.items) {
      const built = buildBitwardenVaultItem(item, now);
      if (built) out.push(built);
    }
    return out;
  }

  // 2. Standard Browser CSV (Chrome, Edge, Cốc Cốc, Brave, Firefox, Safari/iCloud, Opera)
  // Do NOT trim rawNoBom or password cells so leading/trailing whitespace in passwords is preserved 100%!
  const matrix = parseCsvMatrix(rawNoBom);
  if (matrix.length < 2) {
    throw new Error("File CSV chưa có dòng dữ liệu mật khẩu nào.");
  }
  const cols = resolveCsvColumns(matrix[0]);
  const out = [];
  for (let r = 1; r < matrix.length; r++) {
    const built = buildCsvVaultItem(matrix[r], cols, now);
    if (built) out.push(built);
  }
  return out;
}

async function parseBrowserPasswordsTextAsync(rawText, options = {}) {
  const yieldEvery = Math.max(10, Number(options.yieldEvery) || 100);
  const onProgress = typeof options.onProgress === "function" ? options.onProgress : null;
  const yieldFn = typeof options.yieldFn === "function" ? options.yieldFn : yieldToEventLoop;

  const rawNoBom = String(rawText || "").replace(/^\uFEFF/, "");
  const trimmedDetect = rawNoBom.trim();
  if (!trimmedDetect) {
    throw new Error("File mật khẩu đang trống.");
  }

  const now = Date.now();
  if (trimmedDetect.startsWith("{")) {
    let root;
    try {
      root = JSON.parse(trimmedDetect);
    } catch (e) {
      throw new Error("File JSON không hợp lệ: " + (e.message || e));
    }
    if (Array.isArray(root.accounts)) {
      const rawItems = flattenFidoCxfItems(root);
      const total = rawItems.length;
      const out = [];
      for (let i = 0; i < total; i++) {
        const built = buildFidoCxfVaultItem(rawItems[i], now);
        if (built) out.push(built);
        if ((i + 1) % yieldEvery === 0) {
          if (onProgress) onProgress(i + 1, total);
          await yieldFn();
        }
      }
      if (onProgress) onProgress(total, total);
      return out;
    }
    if (!Array.isArray(root.items)) {
      throw new Error("Không nhận diện được định dạng FIDO CXF (accounts) hoặc Bitwarden (items) trong file JSON.");
    }
    const total = root.items.length;
    const out = [];
    for (let i = 0; i < total; i++) {
      const built = buildBitwardenVaultItem(root.items[i], now);
      if (built) out.push(built);
      if ((i + 1) % yieldEvery === 0) {
        if (onProgress) onProgress(i + 1, total);
        await yieldFn();
      }
    }
    if (onProgress) onProgress(total, total);
    return out;
  }

  const matrix = parseCsvMatrix(rawNoBom);
  if (matrix.length < 2) {
    throw new Error("File CSV chưa có dòng dữ liệu mật khẩu nào.");
  }
  const cols = resolveCsvColumns(matrix[0]);
  const totalRows = matrix.length - 1;
  const out = [];
  for (let r = 1; r < matrix.length; r++) {
    const built = buildCsvVaultItem(matrix[r], cols, now);
    if (built) out.push(built);
    if (r % yieldEvery === 0) {
      if (onProgress) onProgress(r, totalRows);
      await yieldFn();
    }
  }
  if (onProgress) onProgress(totalRows, totalRows);
  return out;
}

function analyzeImportDiff(existingItems, incomingItems, options = {}) {
  const skipPasswordOverwrite = Boolean(options && options.skipPasswordOverwrite);
  const existing = Array.isArray(existingItems) ? existingItems : [];
  const rawIncoming = Array.isArray(incomingItems) ? incomingItems : [];

  // Build O(N) hash indexes over existing vault (strict subdomain isolation INV-07)
  const byUserDomain = new Map();
  const byUserPkg = new Map();
  const byUserServiceEmpty = new Map();
  const existingDomSets = new Array(existing.length);
  const existingPkgSets = new Array(existing.length);

  for (let i = 0; i < existing.length; i++) {
    const item = existing[i];
    const userLc = String(item.username || "").trim().toLowerCase();
    const dSet = new Set();
    const pSet = new Set();
    for (const d of Array.isArray(item.web_domains) ? item.web_domains : []) {
      const dLc = String(d || "").toLowerCase();
      if (!dLc) continue;
      dSet.add(dLc);
      const key = `${userLc}\0${dLc}`;
      if (!byUserDomain.has(key)) byUserDomain.set(key, i);
    }
    for (const p of Array.isArray(item.android_packages) ? item.android_packages : []) {
      const pLc = String(p || "").toLowerCase();
      if (!pLc) continue;
      pSet.add(pLc);
      const key = `${userLc}\0${pLc}`;
      if (!byUserPkg.has(key)) byUserPkg.set(key, i);
    }
    if (dSet.size === 0 && pSet.size === 0) {
      const srvKey = `${userLc}\0${String(item.service_name || "").trim().toLowerCase()}`;
      if (!byUserServiceEmpty.has(srvKey)) byUserServiceEmpty.set(srvKey, i);
    }
    existingDomSets[i] = dSet;
    existingPkgSets[i] = pSet;
  }

  // Deduplicate within the incoming multi-file batch first (keep richest / latest entry)
  const batchIndex = new Map();
  const dedupedIncoming = [];
  let intraBatchDupCount = 0;

  for (const rawInc of rawIncoming) {
    const inc = normalizeVaultItem(rawInc);
    if (!inc.username && !inc.password && !inc.totp_secret && (!Array.isArray(inc.passkeys) || inc.passkeys.length === 0)) continue;
    const userLc = inc.username.trim().toLowerCase();
    const primaryTarget =
      (inc.web_domains[0] && `d:${inc.web_domains[0].toLowerCase()}`) ||
      (inc.android_packages[0] && `p:${inc.android_packages[0].toLowerCase()}`) ||
      `s:${inc.service_name.trim().toLowerCase()}`;
    const batchKey = `${userLc}\0${primaryTarget}`;
    if (batchIndex.has(batchKey)) {
      intraBatchDupCount++;
      const prevIdx = batchIndex.get(batchKey);
      const prev = dedupedIncoming[prevIdx];
      if (!prev.password && inc.password) prev.password = inc.password;
      else if (!skipPasswordOverwrite && inc.password && prev.password !== inc.password) prev.password = inc.password;
      if (!prev.totp_secret && inc.totp_secret) {
        prev.totp_secret = inc.totp_secret;
        prev.totp_algorithm = inc.totp_algorithm;
        prev.totp_digits = inc.totp_digits;
        prev.totp_period = inc.totp_period;
      }
      if (inc.notes.trim() && !prev.notes.includes(inc.notes.trim())) {
        prev.notes = prev.notes.trim() ? `${prev.notes.trim()}\n${inc.notes.trim()}` : inc.notes.trim();
      }
      if (Array.isArray(inc.web_domains) && inc.web_domains.length > 0) {
        const seenDom = new Set((prev.web_domains || []).map((d) => String(d).toLowerCase()));
        for (const d of inc.web_domains) {
          const dLc = String(d || "").toLowerCase();
          if (dLc && !seenDom.has(dLc)) {
            prev.web_domains.push(d);
            seenDom.add(dLc);
          }
        }
      }
      if (Array.isArray(inc.android_packages) && inc.android_packages.length > 0) {
        const seenPkg = new Set((prev.android_packages || []).map((p) => String(p).toLowerCase()));
        for (const p of inc.android_packages) {
          const pLc = String(p || "").toLowerCase();
          if (pLc && !seenPkg.has(pLc)) {
            prev.android_packages.push(p);
            seenPkg.add(pLc);
          }
        }
      }
      if (Array.isArray(inc.passkeys) && inc.passkeys.length > 0) {
        prev.passkeys = normalizePasskeysArray([...(prev.passkeys || []), ...inc.passkeys]);
      }
      continue;
    }
    batchIndex.set(batchKey, dedupedIncoming.length);
    dedupedIncoming.push(inc);
  }

  const entries = [];
  let newCount = 0;
  let updateCount = 0;
  let unchangedCount = 0;
  let weakCount = 0;

  for (const inc of dedupedIncoming) {
    const incUserLc = inc.username.trim().toLowerCase();
    let matchIdx = -1;

    if (inc.web_domains.length > 0) {
      for (const d of inc.web_domains) {
        const hit = byUserDomain.get(`${incUserLc}\0${d.toLowerCase()}`);
        if (hit !== undefined && (matchIdx < 0 || hit < matchIdx)) matchIdx = hit;
      }
    }
    if (inc.android_packages.length > 0) {
      for (const p of inc.android_packages) {
        const hit = byUserPkg.get(`${incUserLc}\0${p.toLowerCase()}`);
        if (hit !== undefined && (matchIdx < 0 || hit < matchIdx)) matchIdx = hit;
      }
    }
    if (inc.web_domains.length === 0 && inc.android_packages.length === 0) {
      const hit = byUserServiceEmpty.get(`${incUserLc}\0${inc.service_name.trim().toLowerCase()}`);
      if (hit !== undefined && (matchIdx < 0 || hit < matchIdx)) matchIdx = hit;
    }

    const hasPasskeys = Array.isArray(inc.passkeys) && inc.passkeys.length > 0;
    const isWeak = (!inc.password && !hasPasskeys) || (Boolean(inc.password) && inc.password.length < 8);
    if (isWeak) weakCount++;

    if (matchIdx < 0) {
      newCount++;
      entries.push({
        item: inc,
        status: "new",
        reason: "Thêm mới",
        isWeak,
        selected: true
      });
      continue;
    }

    const ex = existing[matchIdx];
    const reasons = [];
    if (inc.password && ex.password !== inc.password && (!skipPasswordOverwrite || !ex.password)) {
      reasons.push(ex.password ? "Đổi mật khẩu" : "Bổ sung mật khẩu");
    }
    if (!ex.totp_secret && inc.totp_secret) {
      reasons.push("Thêm 2FA");
    }
    const exDomSet = existingDomSets[matchIdx];
    const exPkgSet = existingPkgSets[matchIdx];
    if (inc.web_domains.some((d) => !exDomSet.has(d.toLowerCase()))) {
      reasons.push("Thêm tên miền");
    }
    if (inc.android_packages.some((p) => !exPkgSet.has(p.toLowerCase()))) {
      reasons.push("Thêm ứng dụng");
    }
    const incNote = inc.notes.trim();
    if (incNote && !String(ex.notes || "").includes(incNote)) {
      reasons.push("Thêm ghi chú");
    }
    const exPkIds = new Set((Array.isArray(ex.passkeys) ? ex.passkeys : []).map((pk) => pk.credential_id_b64url));
    if (Array.isArray(inc.passkeys) && inc.passkeys.some((pk) => !exPkIds.has(pk.credential_id_b64url))) {
      reasons.push("Thêm Passkey");
    }

    if (reasons.length > 0) {
      updateCount++;
      entries.push({
        item: inc,
        status: "update",
        reason: reasons.join(" • "),
        isWeak,
        selected: true
      });
    } else {
      unchangedCount++;
      entries.push({
        item: inc,
        status: "unchanged",
        reason: skipPasswordOverwrite && ex.password && inc.password && ex.password !== inc.password
          ? "Giữ mật khẩu cũ"
          : "Đã có sẵn",
        isWeak,
        selected: false
      });
    }
  }

  return {
    entries,
    newCount,
    updateCount,
    unchangedCount,
    intraBatchDupCount,
    weakCount,
    totalUnique: entries.length
  };
}

async function _importAndPushAllToServerRaw(incomingItems, options = {}) {
  const skipPasswordOverwrite = Boolean(options && options.skipPasswordOverwrite);
  if (!Array.isArray(incomingItems) || incomingItems.length === 0) {
    throw new Error("Không tìm thấy tài khoản hợp lệ nào trong file đã chọn.");
  }

  // Pull latest server state first so phone changes are preserved before merging
  const preSync = await _syncBrowserVaultBidirectionalRaw(false);

  const st = preSync && preSync.state ? preSync.state : await _loadExtensionStateRaw();
  if (st.locked) {
    throw new Error("Kho tiện ích đang khóa — vui lòng nhập PIN trước.");
  }
  if (!st.pairing) {
    throw new Error("Chưa kết nối với ứng dụng OmniVault.");
  }

  const now = Date.now();
  // Items loaded from sync/state are already normalized; copy array cleanly without redundant re-normalization
  const working = Array.isArray(st.items) ? st.items.slice() : [];
  if (!st.deletedIds || typeof st.deletedIds !== "object") {
    st.deletedIds = {};
  }

  // O(N + M) hash indexes preserving exact findIndex precedence & strict subdomain isolation (INV-07)
  const byUserDomain = new Map();
  const byUserPkg = new Map();
  const byUserServiceEmpty = new Map();
  const domainSets = new Array(working.length);
  const pkgSets = new Array(working.length);

  const registerWorkingItemAt = (item, idx) => {
    const userLc = String(item.username || "").trim().toLowerCase();
    const dSet = new Set();
    const pSet = new Set();
    const doms = Array.isArray(item.web_domains) ? item.web_domains : [];
    const pkgs = Array.isArray(item.android_packages) ? item.android_packages : [];

    for (const d of doms) {
      const dLc = String(d || "").toLowerCase();
      if (!dLc) continue;
      dSet.add(dLc);
      const key = `${userLc}\0${dLc}`;
      if (!byUserDomain.has(key)) byUserDomain.set(key, idx);
    }
    for (const p of pkgs) {
      const pLc = String(p || "").toLowerCase();
      if (!pLc) continue;
      pSet.add(pLc);
      const key = `${userLc}\0${pLc}`;
      if (!byUserPkg.has(key)) byUserPkg.set(key, idx);
    }
    if (dSet.size === 0 && pSet.size === 0) {
      const srvKey = `${userLc}\0${String(item.service_name || "").trim().toLowerCase()}`;
      if (!byUserServiceEmpty.has(srvKey)) byUserServiceEmpty.set(srvKey, idx);
    }
    domainSets[idx] = dSet;
    pkgSets[idx] = pSet;
  };

  for (let i = 0; i < working.length; i++) {
    registerWorkingItemAt(working[i], i);
  }

  let addedCount = 0;
  let updatedCount = 0;
  const updatedSeen = new Set();

  for (const rawInc of incomingItems) {
    // Normalize each incoming item exactly ONCE
    const inc = normalizeVaultItem(rawInc);
    if (!inc.username && !inc.password && !inc.totp_secret && (!Array.isArray(inc.passkeys) || inc.passkeys.length === 0)) continue;

    const incUserLc = inc.username.trim().toLowerCase();
    let matchIdx = -1;

    // 1. Exact web domain match (strictly keeps root domain and each subdomain separate)
    if (inc.web_domains.length > 0) {
      for (const d of inc.web_domains) {
        const hit = byUserDomain.get(`${incUserLc}\0${d.toLowerCase()}`);
        if (hit !== undefined && (matchIdx < 0 || hit < matchIdx)) {
          matchIdx = hit;
        }
      }
    }
    // 2. Exact Android package match
    if (inc.android_packages.length > 0) {
      for (const p of inc.android_packages) {
        const hit = byUserPkg.get(`${incUserLc}\0${p.toLowerCase()}`);
        if (hit !== undefined && (matchIdx < 0 || hit < matchIdx)) {
          matchIdx = hit;
        }
      }
    }
    // 3. Empty domains & packages -> match by service_name
    if (inc.web_domains.length === 0 && inc.android_packages.length === 0) {
      const hit = byUserServiceEmpty.get(`${incUserLc}\0${inc.service_name.trim().toLowerCase()}`);
      if (hit !== undefined && (matchIdx < 0 || hit < matchIdx)) {
        matchIdx = hit;
      }
    }

    if (matchIdx >= 0) {
      const ex = working[matchIdx];
      const exDomSet = domainSets[matchIdx];
      const exPkgSet = pkgSets[matchIdx];
      let changed = false;

      if (inc.password && ex.password !== inc.password) {
        if (!skipPasswordOverwrite || !ex.password) {
          if (ex.password) {
            ex.password_history = [
              { password: ex.password, changed_at_ms: now },
              ...(Array.isArray(ex.password_history) ? ex.password_history : [])
            ].slice(0, 10);
          }
          ex.password = inc.password;
          changed = true;
        }
      }
      if (!ex.totp_secret && inc.totp_secret) {
        ex.totp_secret = inc.totp_secret;
        ex.totp_algorithm = inc.totp_algorithm || "SHA1";
        ex.totp_digits = Number(inc.totp_digits) || 6;
        ex.totp_period = Number(inc.totp_period) || 30;
        changed = true;
      }
      for (const dom of inc.web_domains) {
        const dLc = dom.toLowerCase();
        if (!exDomSet.has(dLc)) {
          ex.web_domains.push(dom);
          exDomSet.add(dLc);
          const dk = `${incUserLc}\0${dLc}`;
          if (!byUserDomain.has(dk) || matchIdx < byUserDomain.get(dk)) {
            byUserDomain.set(dk, matchIdx);
          }
          changed = true;
        }
      }
      for (const pkg of inc.android_packages) {
        const pLc = pkg.toLowerCase();
        if (!exPkgSet.has(pLc)) {
          ex.android_packages.push(pkg);
          exPkgSet.add(pLc);
          const pk = `${incUserLc}\0${pLc}`;
          if (!byUserPkg.has(pk) || matchIdx < byUserPkg.get(pk)) {
            byUserPkg.set(pk, matchIdx);
          }
          changed = true;
        }
      }
      const incNote = inc.notes.trim();
      if (incNote && !ex.notes.includes(incNote)) {
        ex.notes = ex.notes.trim() ? `${ex.notes.trim()}\n${incNote}` : incNote;
        changed = true;
      }
      if (Array.isArray(inc.passkeys) && inc.passkeys.length > 0) {
        const exPkIds = new Set((Array.isArray(ex.passkeys) ? ex.passkeys : []).map((pk) => pk.credential_id_b64url));
        const hasNewPk = inc.passkeys.some((pk) => !exPkIds.has(pk.credential_id_b64url));
        if (hasNewPk) {
          ex.passkeys = normalizePasskeysArray([...(Array.isArray(ex.passkeys) ? ex.passkeys : []), ...inc.passkeys], now);
          changed = true;
        }
      }

      if (changed) {
        ex.updated_at_ms = now;
        delete st.deletedIds[ex.id];
        if (!updatedSeen.has(ex.id)) {
          updatedSeen.add(ex.id);
          updatedCount++;
        }
      }
    } else {
      inc.created_at_ms = now;
      inc.updated_at_ms = now;
      delete st.deletedIds[inc.id];
      const newIdx = working.length;
      working.push(inc);
      registerWorkingItemAt(inc, newIdx);
      addedCount++;
    }
  }

  st.items = working;
  await _saveExtensionStateRaw(st, { alreadyNormalized: true });

  // Immediately encrypt (AES-256-GCM) and push 100% of vault items onto Supabase Server!
  const syncRes = await _syncBrowserVaultBidirectionalRaw(true, { alreadyNormalized: true });
  return {
    importedCount: incomingItems.length,
    addedCount,
    updatedCount,
    skippedCount: Math.max(0, incomingItems.length - addedCount - updatedCount),
    totalServerCount: syncRes.itemCount
  };
}

async function importAndPushAllToServer(incomingItems, options = {}) {
  return withVaultMutationLock(() => _importAndPushAllToServerRaw(incomingItems, options));
}

function exportVaultToChromeCsv(items) {
  const esc = (s) => {
    const str = String(s || "");
    return /[",\r\n]/.test(str) ? `"${str.replace(/"/g, '""')}"` : str;
  };
  const lines = ["name,url,username,password,note"];
  for (const it of Array.isArray(items) ? items : []) {
    if (!it.username && !it.password) continue;
    const dom = Array.isArray(it.web_domains) && it.web_domains[0] ? it.web_domains[0] : "";
    const pkg = Array.isArray(it.android_packages) && it.android_packages[0] ? it.android_packages[0] : "";
    const url = dom
      ? /^https?:\/\//i.test(dom)
        ? dom
        : `https://${dom}`
      : pkg
      ? `androidapp://${pkg}`
      : "";
    const name = String(it.service_name || "").trim() || url;
    lines.push([esc(name), esc(url), esc(it.username || ""), esc(it.password || ""), esc(it.notes || "")].join(","));
  }
  return lines.join("\n") + "\n";
}

const GMAIL_ALIAS_WEB_DOMAINS = new Set([
  "accounts.google.com",
  "mail.google.com",
  "myaccount.google.com",
  "google.com"
]);

const GMAIL_ALIAS_ANDROID_PACKAGES = new Set([
  "com.google.android.gm",
  "com.google.android.gsf.login"
]);

const NOISE_PACKAGE_SEGMENTS = new Set(["com", "vn", "org", "net", "app", "android"]);
const _itemSearchIndexCache = new WeakMap();

function foldSearchText(str) {
  const s = String(str || "");
  if (!s) return "";
  // ASCII fast path avoids Unicode NFD allocation on ~85% of usernames/domains
  if (/^[\x20-\x7e]+$/.test(s)) {
    return s.toLowerCase().trim();
  }
  return s
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[đĐ]/g, "d")
    .toLowerCase()
    .trim();
}

function matchesUsernamePrefix(username, rawPrefix) {
  const q = foldSearchText(rawPrefix);
  if (!q) return true;
  const u = foldSearchText(username);
  return Boolean(u) && u.startsWith(q);
}

function buildItemSearchIndex(item) {
  const foldedUser = foldSearchText(item?.username);
  const foldedTitle = foldSearchText(item?.service_name);
  const titleTokens = foldedTitle ? foldedTitle.split(/[^a-z0-9]+/).filter(Boolean) : [];
  const cleanDomains = [];
  const foldedDomains = [];
  let hasGmailDomain = false;
  if (Array.isArray(item?.web_domains)) {
    for (const rawD of item.web_domains) {
      const d = extractCleanDomain(rawD);
      if (d) {
        cleanDomains.push(d);
        foldedDomains.push(foldSearchText(d));
        if (GMAIL_ALIAS_WEB_DOMAINS.has(d)) hasGmailDomain = true;
      }
    }
  }
  const pkgs = [];
  const pkgTokens = [];
  let hasGmailPkg = false;
  if (Array.isArray(item?.android_packages)) {
    for (const rawP of item.android_packages) {
      const p = String(rawP || "").trim().toLowerCase();
      if (!p) continue;
      pkgs.push(p);
      if (GMAIL_ALIAS_ANDROID_PACKAGES.has(p)) hasGmailPkg = true;
      const segs = p.split(".");
      for (const seg of segs) {
        if (seg && !NOISE_PACKAGE_SEGMENTS.has(seg)) {
          pkgTokens.push(seg);
        }
      }
    }
  }
  return {
    item,
    foldedUser,
    foldedTitle,
    titleTokens,
    cleanDomains,
    foldedDomains,
    pkgs,
    pkgTokens,
    isGmailAlias: hasGmailDomain || hasGmailPkg,
    // Freshness fingerprint to guard against external in-place item mutation
    _u: item?.username,
    _s: item?.service_name,
    _ts: item?.updated_at_ms,
    _dc: Array.isArray(item?.web_domains) ? item.web_domains.length : 0,
    _pc: Array.isArray(item?.android_packages) ? item.android_packages.length : 0
  };
}

function getOrBuildItemSearchIndex(item) {
  if (!item || typeof item !== "object") return null;
  const cached = _itemSearchIndexCache.get(item);
  if (
    cached &&
    cached._u === item.username &&
    cached._s === item.service_name &&
    cached._ts === item.updated_at_ms &&
    cached._dc === (Array.isArray(item.web_domains) ? item.web_domains.length : 0) &&
    cached._pc === (Array.isArray(item.android_packages) ? item.android_packages.length : 0)
  ) {
    return cached;
  }
  const built = buildItemSearchIndex(item);
  _itemSearchIndexCache.set(item, built);
  return built;
}

function scoreIndexedItem(idx, foldedQuery, options = {}) {
  if (!foldedQuery) return 1;
  if (!idx) return 0;

  if (options && options.onlyUsernamePrefix) {
    return idx.foldedUser && idx.foldedUser.startsWith(foldedQuery) ? 100 : 0;
  }

  if (idx.foldedUser && idx.foldedUser.startsWith(foldedQuery)) {
    return 100;
  }

  if (idx.foldedTitle && idx.foldedTitle.startsWith(foldedQuery)) {
    return 80;
  }

  for (let i = 0; i < idx.foldedDomains.length; i++) {
    if (idx.foldedDomains[i].startsWith(foldedQuery)) return 70;
  }

  for (let i = 0; i < idx.titleTokens.length; i++) {
    if (idx.titleTokens[i].startsWith(foldedQuery)) return 60;
  }

  if (
    (foldedQuery === "gmail" || foldedQuery === "google mail" || foldedQuery === "googlemail") &&
    idx.isGmailAlias
  ) {
    return 55;
  }

  for (let i = 0; i < idx.pkgTokens.length; i++) {
    if (idx.pkgTokens[i].startsWith(foldedQuery)) return 50;
  }

  return 0;
}

function scoreItemSearchQuery(item, rawQuery, options = {}) {
  const q =
    options && typeof options.foldedQuery === "string"
      ? options.foldedQuery
      : foldSearchText(rawQuery);
  if (!q) return 1;
  if (!item) return 0;
  const idx = (options && options.indexed) || getOrBuildItemSearchIndex(item);
  return scoreIndexedItem(idx, q, options);
}

function itemMatchesSearchQuery(item, rawQuery) {
  return scoreItemSearchQuery(item, rawQuery) > 0;
}

// ============================================================================
// Pillar 2: Real Passkeys (FIDO2 / WebAuthn L3) — WebCrypto ECDSA P-256 Engine
// Interoperable with Android PasskeyCrypto.kt (PKCS#8 + SPKI DER) & Rust Core
// ============================================================================

// Deterministic RFC 4122 v4 AAGUID shared with Android PasskeyCrypto.kt (6f6d6e69-7661-4535-8035-6f6d6e693335)
const OMNIVAULT_PASSKEY_AAGUID = new Uint8Array([
  0x6f, 0x6d, 0x6e, 0x69,
  0x76, 0x61, 0x45, 0x35,
  0x80, 0x35, 0x6f, 0x6d,
  0x6e, 0x69, 0x33, 0x35
]);

function normalizePasskeyRpHost(raw) {
  if (!raw) return "";
  const trimmed = String(raw).trim();
  if (!trimmed || /\s/.test(trimmed)) return "";
  let host = "";
  if (trimmed.includes("://")) {
    try {
      const u = new URL(trimmed);
      if (u.protocol !== "https:" && u.protocol !== "http:") return "";
      host = u.hostname;
    } catch (_) {
      return "";
    }
  } else {
    if (DISALLOWED_DOMAIN_SCHEMES.test(trimmed)) return "";
    if (
      trimmed.includes(":") &&
      !/^\[[0-9a-f:]+\](?::\d+)?(?:[/?#]|$)/i.test(trimmed) &&
      !/^[a-z0-9.-]+:\d+(?:[/?#]|$)/i.test(trimmed)
    ) {
      return "";
    }
    try {
      const u = new URL("https://" + trimmed);
      host = u.hostname;
    } catch (_) {
      return "";
    }
  }
  return String(host || "").toLowerCase().replace(/\.+$/, "");
}

function isValidPasskeyRpMatch(storedRpId, targetHost) {
  const rp = normalizePasskeyRpHost(storedRpId);
  const host = normalizePasskeyRpHost(targetHost);
  if (!rp || !host) return false;
  if (rp === host) return true;
  if (
    rp === "localhost" ||
    host === "localhost" ||
    rp.includes(":") ||
    host.includes(":") ||
    /^\d{1,3}(\.\d{1,3}){3}$/.test(rp) ||
    /^\d{1,3}(\.\d{1,3}){3}$/.test(host)
  ) {
    return false;
  }
  if (!host.endsWith("." + rp)) return false;
  // W3C WebAuthn L3 & INV-07: rpId must be at least a registrable domain (never a bare TLD or shared hosting suffix)
  const rpBase = baseRegistrableDomain(rp);
  const hostBase = baseRegistrableDomain(host);
  if (!rpBase || !hostBase || rpBase !== hostBase) return false;
  return true;
}

function concatUint8Arrays(arrays) {
  let total = 0;
  for (let i = 0; i < arrays.length; i++) {
    total += arrays[i].length;
  }
  const out = new Uint8Array(total);
  let offset = 0;
  for (let i = 0; i < arrays.length; i++) {
    out.set(arrays[i], offset);
    offset += arrays[i].length;
  }
  return out;
}

function encodeCborHead(majorType, num) {
  const major = (majorType & 0x07) << 5;
  if (num < 24) {
    return new Uint8Array([major | num]);
  }
  if (num < 0x100) {
    return new Uint8Array([major | 24, num]);
  }
  if (num < 0x10000) {
    return new Uint8Array([major | 25, (num >>> 8) & 0xff, num & 0xff]);
  }
  if (num < 0x100000000) {
    return new Uint8Array([
      major | 26,
      (num >>> 24) & 0xff,
      (num >>> 16) & 0xff,
      (num >>> 8) & 0xff,
      num & 0xff
    ]);
  }
  const hi = Math.floor(num / 0x100000000);
  const lo = num >>> 0;
  return new Uint8Array([
    major | 27,
    (hi >>> 24) & 0xff,
    (hi >>> 16) & 0xff,
    (hi >>> 8) & 0xff,
    hi & 0xff,
    (lo >>> 24) & 0xff,
    (lo >>> 16) & 0xff,
    (lo >>> 8) & 0xff,
    lo & 0xff
  ]);
}

function compareCborEncodedKeys(a, b) {
  if (a.length !== b.length) return a.length - b.length;
  for (let i = 0; i < a.length; i++) {
    if (a[i] !== b[i]) return a[i] - b[i];
  }
  return 0;
}

function encodeCbor(val) {
  if (val === null || val === undefined) {
    return new Uint8Array([0xf6]);
  }
  if (typeof val === "boolean") {
    return new Uint8Array([val ? 0xf5 : 0xf4]);
  }
  if (typeof val === "number") {
    if (!Number.isInteger(val) || !Number.isSafeInteger(val)) {
      throw new Error("encodeCbor chỉ hỗ trợ số nguyên an toàn.");
    }
    return val >= 0 ? encodeCborHead(0, val) : encodeCborHead(1, -1 - val);
  }
  if (typeof val === "string") {
    const utf8 = TEXT_ENCODER.encode(val);
    return concatUint8Arrays([encodeCborHead(3, utf8.length), utf8]);
  }
  if (val instanceof Uint8Array) {
    return concatUint8Arrays([encodeCborHead(2, val.length), val]);
  }
  if (val instanceof ArrayBuffer) {
    const u8 = new Uint8Array(val);
    return concatUint8Arrays([encodeCborHead(2, u8.length), u8]);
  }
  if (ArrayBuffer.isView(val)) {
    const u8 = new Uint8Array(val.buffer, val.byteOffset, val.byteLength);
    return concatUint8Arrays([encodeCborHead(2, u8.length), u8]);
  }
  if (Array.isArray(val)) {
    const parts = [encodeCborHead(4, val.length)];
    for (let i = 0; i < val.length; i++) {
      parts.push(encodeCbor(val[i]));
    }
    return concatUint8Arrays(parts);
  }
  if (val instanceof Map) {
    const pairs = [];
    for (const [k, v] of val.entries()) {
      pairs.push({ kb: encodeCbor(k), vb: encodeCbor(v) });
    }
    pairs.sort((a, b) => compareCborEncodedKeys(a.kb, b.kb));
    const parts = [encodeCborHead(5, pairs.length)];
    for (let i = 0; i < pairs.length; i++) {
      parts.push(pairs[i].kb, pairs[i].vb);
    }
    return concatUint8Arrays(parts);
  }
  if (typeof val === "object") {
    const keys = Object.keys(val);
    const pairs = [];
    for (let i = 0; i < keys.length; i++) {
      const k = keys[i];
      if (val[k] === undefined) continue;
      pairs.push({ kb: encodeCbor(k), vb: encodeCbor(val[k]) });
    }
    pairs.sort((a, b) => compareCborEncodedKeys(a.kb, b.kb));
    const parts = [encodeCborHead(5, pairs.length)];
    for (let i = 0; i < pairs.length; i++) {
      parts.push(pairs[i].kb, pairs[i].vb);
    }
    return concatUint8Arrays(parts);
  }
  throw new Error(`encodeCbor không hỗ trợ kiểu dữ liệu: ${typeof val}`);
}

function spkiP256ToCoseKey(spkiBytes) {
  const bytes =
    spkiBytes instanceof Uint8Array
      ? spkiBytes
      : spkiBytes instanceof ArrayBuffer
      ? new Uint8Array(spkiBytes)
      : ArrayBuffer.isView(spkiBytes)
      ? new Uint8Array(spkiBytes.buffer, spkiBytes.byteOffset, spkiBytes.byteLength)
      : null;
  if (!bytes || bytes.length < 68) {
    throw new Error("Khóa công khai SPKI P-256 không hợp lệ.");
  }
  // Standard X.509 SPKI DER BIT STRING for P-256 ends with: 0x03 0x42 0x00 0x04 || X(32) || Y(32)
  const bitStrIdx = bytes.length - 68;
  if (
    bytes[bitStrIdx] !== 0x03 ||
    bytes[bitStrIdx + 1] !== 0x42 ||
    bytes[bitStrIdx + 2] !== 0x00 ||
    bytes[bitStrIdx + 3] !== 0x04
  ) {
    throw new Error("Cấu trúc điểm uncompressed P-256 trong SPKI DER không hợp lệ.");
  }
  const x = bytes.slice(bytes.length - 64, bytes.length - 32);
  const y = bytes.slice(bytes.length - 32);
  const coseMap = new Map([
    [1, 2],  // kty: EC2
    [3, -7], // alg: ES256 (-7)
    [-1, 1], // crv: P-256 (1)
    [-2, x], // x (32 bytes)
    [-3, y]  // y (32 bytes)
  ]);
  return encodeCbor(coseMap);
}

function encodeAsn1DerUnsignedInteger(rawBytes) {
  let offset = 0;
  while (offset < rawBytes.length - 1 && rawBytes[offset] === 0x00) {
    offset++;
  }
  const trimmed = rawBytes.subarray(offset);
  const needsZeroPad = (trimmed[0] & 0x80) !== 0;
  const intLen = trimmed.length + (needsZeroPad ? 1 : 0);
  const out = new Uint8Array(2 + intLen);
  out[0] = 0x02;
  out[1] = intLen;
  if (needsZeroPad) {
    out[2] = 0x00;
    out.set(trimmed, 3);
  } else {
    out.set(trimmed, 2);
  }
  return out;
}

function p1363ToDerEcdsaSignature(raw64) {
  const bytes =
    raw64 instanceof Uint8Array
      ? raw64
      : raw64 instanceof ArrayBuffer
      ? new Uint8Array(raw64)
      : ArrayBuffer.isView(raw64)
      ? new Uint8Array(raw64.buffer, raw64.byteOffset, raw64.byteLength)
      : null;
  if (!bytes || bytes.length !== 64) {
    throw new Error("Chữ ký ECDSA P-256 raw IEEE P1363 phải có đúng 64 byte.");
  }
  const rDer = encodeAsn1DerUnsignedInteger(bytes.subarray(0, 32));
  const sDer = encodeAsn1DerUnsignedInteger(bytes.subarray(32, 64));
  const seq = new Uint8Array(2 + rDer.length + sDer.length);
  seq[0] = 0x30;
  seq[1] = rDer.length + sDer.length;
  seq.set(rDer, 2);
  seq.set(sDer, 2 + rDer.length);
  return seq;
}

function encodeUint32BE(val) {
  const n = Math.max(0, Math.floor(Number(val) || 0)) >>> 0;
  return new Uint8Array([(n >>> 24) & 0xff, (n >>> 16) & 0xff, (n >>> 8) & 0xff, n & 0xff]);
}

async function generatePasskeyP256({
  rpId,
  rpName = "",
  userIdB64Url = "",
  userName = "",
  userDisplayName = "",
  challengeB64Url = "",
  origin = "",
  userVerified = true,
  wantCredProps = false
}) {
  const cleanRpId = normalizePasskeyRpHost(rpId);
  if (!cleanRpId) {
    throw new Error("Thiếu RP ID hợp lệ để tạo Passkey.");
  }
  const cleanOrigin = String(origin || `https://${cleanRpId}`).trim();
  const cleanChallenge = String(challengeB64Url || "").trim();
  if (!cleanChallenge) {
    throw new Error("Thiếu WebAuthn challenge.");
  }

  // Generate ECDSA P-256 keypair (extractable solely to export PKCS#8 into E2EE vault, then zeroized)
  const keyPair = await crypto.subtle.generateKey(
    { name: "ECDSA", namedCurve: "P-256" },
    true,
    ["sign", "verify"]
  );
  const pkcs8Bytes = new Uint8Array(await crypto.subtle.exportKey("pkcs8", keyPair.privateKey));
  const spkiBytes = new Uint8Array(await crypto.subtle.exportKey("spki", keyPair.publicKey));
  let pkcs8B64 = "";
  try {
    pkcs8B64 = bytesToBase64(pkcs8Bytes);
  } finally {
    pkcs8Bytes.fill(0);
  }
  const spkiB64 = bytesToBase64(spkiBytes);

  const credentialId = crypto.getRandomValues(new Uint8Array(32));
  const credentialIdB64Url = bytesToBase64Url(credentialId);
  const resolvedUserHandleB64Url =
    String(userIdB64Url || "").trim() || bytesToBase64Url(crypto.getRandomValues(new Uint8Array(16)));

  const clientDataObj = {
    type: "webauthn.create",
    challenge: cleanChallenge,
    origin: cleanOrigin,
    crossOrigin: false
  };
  const clientDataBytes = TEXT_ENCODER.encode(JSON.stringify(clientDataObj));

  const rpIdHash = new Uint8Array(await crypto.subtle.digest("SHA-256", TEXT_ENCODER.encode(cleanRpId)));
  // Flags: UP(0x01) | [UV(0x04)] | BE(0x08) | BS(0x10) | AT(0x40) => 0x5D (UV=1) or 0x59 (UV=0)
  const flags = new Uint8Array([0x01 | (userVerified ? 0x04 : 0x00) | 0x08 | 0x10 | 0x40]);
  const signCountBytes = encodeUint32BE(0);
  const credIdLenBytes = new Uint8Array([(credentialId.length >>> 8) & 0xff, credentialId.length & 0xff]);
  const coseKey = spkiP256ToCoseKey(spkiBytes);

  const authData = concatUint8Arrays([
    rpIdHash,
    flags,
    signCountBytes,
    OMNIVAULT_PASSKEY_AAGUID,
    credIdLenBytes,
    credentialId,
    coseKey
  ]);

  const attestationObject = encodeCbor(
    new Map([
      ["fmt", "none"],
      ["attStmt", new Map()],
      ["authData", authData]
    ])
  );

  const now = Date.now();
  const cleanUserName = String(userName || "").trim();
  const cleanDisplayName = String(userDisplayName || cleanUserName).trim();
  const cleanRpName = String(rpName || cleanRpId).trim() || cleanRpId;

  const passkey = normalizePasskeyRecord(
    {
      credential_id_b64url: credentialIdB64Url,
      rp_id: cleanRpId,
      rp_name: cleanRpName,
      user_handle_b64url: resolvedUserHandleB64Url,
      user_name: cleanUserName,
      user_display_name: cleanDisplayName,
      private_key_pkcs8_b64: pkcs8B64,
      public_key_spki_b64: spkiB64,
      alg: -7,
      sign_count: 0,
      created_at_ms: now,
      last_used_at_ms: now
    },
    now
  );

  const clientExtensionResults = wantCredProps ? { credProps: { rk: true } } : {};

  const responseJson = {
    id: credentialIdB64Url,
    rawId: credentialIdB64Url,
    type: "public-key",
    authenticatorAttachment: "platform",
    clientExtensionResults,
    response: {
      clientDataJSON: bytesToBase64Url(clientDataBytes),
      attestationObject: bytesToBase64Url(attestationObject),
      authenticatorData: bytesToBase64Url(authData),
      publicKey: bytesToBase64Url(spkiBytes),
      publicKeyAlgorithm: -7,
      transports: ["internal", "hybrid"]
    }
  };

  return { passkey, responseJson };
}

async function signPasskeyAssertionP256({
  passkey,
  challengeB64Url = "",
  origin = "",
  signCount,
  userVerified = true
}) {
  if (!passkey || !passkey.credential_id_b64url || !passkey.rp_id || !passkey.private_key_pkcs8_b64) {
    throw new Error("Dữ liệu Passkey không hợp lệ hoặc thiếu khóa bí mật PKCS#8.");
  }
  const cleanRpId = normalizePasskeyRpHost(passkey.rp_id);
  const cleanChallenge = String(challengeB64Url || "").trim();
  if (!cleanRpId || !cleanChallenge) {
    throw new Error("Thiếu RP ID hoặc challenge để ký xác thực Passkey.");
  }
  const cleanOrigin = String(origin || `https://${cleanRpId}`).trim();

  const pkcs8Bytes = base64ToBytes(passkey.private_key_pkcs8_b64);
  let privKey;
  try {
    privKey = await crypto.subtle.importKey(
      "pkcs8",
      pkcs8Bytes,
      { name: "ECDSA", namedCurve: "P-256" },
      false, // Non-extractable private key!
      ["sign"]
    );
  } finally {
    pkcs8Bytes.fill(0);
  }

  const clientDataObj = {
    type: "webauthn.get",
    challenge: cleanChallenge,
    origin: cleanOrigin,
    crossOrigin: false
  };
  const clientDataBytes = TEXT_ENCODER.encode(JSON.stringify(clientDataObj));
  const clientDataHash = new Uint8Array(await crypto.subtle.digest("SHA-256", clientDataBytes));

  const rpIdHash = new Uint8Array(await crypto.subtle.digest("SHA-256", TEXT_ENCODER.encode(cleanRpId)));
  // Flags: UP(0x01) | [UV(0x04)] | BE(0x08) | BS(0x10) => 0x1D (UV=1) or 0x19 (UV=0)
  const flags = new Uint8Array([0x01 | (userVerified ? 0x04 : 0x00) | 0x08 | 0x10]);
  const nextCount = Math.max(0, Math.floor(Number(signCount !== undefined ? signCount : passkey.sign_count) || 0));
  const signCountBytes = encodeUint32BE(nextCount);
  const authData = concatUint8Arrays([rpIdHash, flags, signCountBytes]);

  const signedPayload = concatUint8Arrays([authData, clientDataHash]);
  const rawSig = new Uint8Array(
    await crypto.subtle.sign({ name: "ECDSA", hash: { name: "SHA-256" } }, privKey, signedPayload)
  );
  const derSig = p1363ToDerEcdsaSignature(rawSig);

  return {
    id: passkey.credential_id_b64url,
    rawId: passkey.credential_id_b64url,
    type: "public-key",
    authenticatorAttachment: "platform",
    clientExtensionResults: {},
    response: {
      clientDataJSON: bytesToBase64Url(clientDataBytes),
      authenticatorData: bytesToBase64Url(authData),
      signature: bytesToBase64Url(derSig),
      userHandle: passkey.user_handle_b64url || ""
    }
  };
}

function findMatchingPasskeysForHost(items, hostname, rpIdOpt = "", allowCredentialIdsOpt = null) {
  const cleanHost = normalizePasskeyRpHost(hostname);
  if (!cleanHost) return [];
  const reqRpId = rpIdOpt ? normalizePasskeyRpHost(rpIdOpt) : "";
  if (reqRpId && !isValidPasskeyRpMatch(reqRpId, cleanHost)) {
    return [];
  }
  const allowSet =
    Array.isArray(allowCredentialIdsOpt) && allowCredentialIdsOpt.length > 0
      ? new Set(allowCredentialIdsOpt.map((id) => String(id || "").trim()).filter(Boolean))
      : null;

  const out = [];
  for (const item of Array.isArray(items) ? items : []) {
    if (!item || !Array.isArray(item.passkeys) || item.passkeys.length === 0) continue;
    for (const pk of item.passkeys) {
      if (!pk || !pk.credential_id_b64url || !pk.rp_id || !pk.private_key_pkcs8_b64) continue;
      if (!isValidPasskeyRpMatch(pk.rp_id, cleanHost)) continue;
      if (reqRpId && normalizePasskeyRpHost(pk.rp_id) !== reqRpId) continue;
      if (allowSet && !allowSet.has(pk.credential_id_b64url)) continue;
      out.push({ item, passkey: pk });
    }
  }

  out.sort((a, b) => {
    const exactA = normalizePasskeyRpHost(a.passkey.rp_id) === cleanHost ? 1 : 0;
    const exactB = normalizePasskeyRpHost(b.passkey.rp_id) === cleanHost ? 1 : 0;
    if (exactB !== exactA) return exactB - exactA;
    const usedDiff = (Number(b.passkey.last_used_at_ms) || 0) - (Number(a.passkey.last_used_at_ms) || 0);
    if (usedDiff !== 0) return usedDiff;
    return (Number(b.passkey.created_at_ms) || 0) - (Number(a.passkey.created_at_ms) || 0);
  });
  return out;
}

// ============================================================================
// Pillar 3: Local Vault Security Audit & Anonymous HIBP k-Anonymity Breach Check
// ============================================================================

async function computeSha1HexUpper(text) {
  const bytes = TEXT_ENCODER.encode(String(text ?? ""));
  const digest = new Uint8Array(await crypto.subtle.digest("SHA-1", bytes));
  let hex = "";
  for (let i = 0; i < digest.length; i++) {
    hex += digest[i].toString(16).padStart(2, "0");
  }
  return hex.toUpperCase();
}

function parseHibpRangeText(text, suffixUpper) {
  const target = String(suffixUpper || "").trim().toUpperCase();
  if (target.length !== 35 || !/^[0-9A-F]{35}$/.test(target)) return 0;
  const lines = String(text || "").split(/\r?\n/);
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const sep = line.indexOf(":");
    if (sep <= 0) continue;
    const lineSuffix = line.slice(0, sep).trim().toUpperCase();
    if (lineSuffix !== target) continue;
    const count = parseInt(line.slice(sep + 1).trim(), 10);
    // Ignore Add-Padding decoy lines (:0)
    return Number.isFinite(count) && count > 0 ? count : 0;
  }
  return 0;
}

const COMMON_WEAK_PASSWORDS = new Set([
  "123456", "12345678", "123456789", "1234567890", "password", "password1",
  "qwerty", "qwerty123", "abc123", "111111", "11111111", "000000", "00000000",
  "admin", "admin123", "iloveyou", "letmein", "welcome", "pass1234", "matkhau", "matkhau123"
]);

function classifyWeakPasswordReason(pw) {
  if (!pw) return "";
  if (pw.length < 8) return "Quá ngắn (< 8 ký tự)";
  const lower = pw.toLowerCase();
  if (COMMON_WEAK_PASSWORDS.has(lower)) return "Mật khẩu quá phổ biến";
  if (/^(.)\1+$/.test(pw)) return "Chỉ lặp 1 ký tự";
  const classes =
    (/[a-z]/.test(pw) ? 1 : 0) +
    (/[A-Z]/.test(pw) ? 1 : 0) +
    (/[0-9]/.test(pw) ? 1 : 0) +
    (/[^a-zA-Z0-9]/.test(pw) ? 1 : 0);
  if (pw.length < 10 && classes < 2) return "Đơn điệu, dễ đoán";
  return "";
}

function auditVaultSecurity(items) {
  const list = Array.isArray(items) ? items : [];
  const weakItems = [];
  const missing2faItems = [];
  const pwGroups = new Map();
  let itemsWithPassword = 0;
  let totpCount = 0;
  let passkeyCount = 0;
  let passkeyItemCount = 0;

  for (let i = 0; i < list.length; i++) {
    const it = list[i];
    if (!it) continue;
    const pkLen = Array.isArray(it.passkeys) ? it.passkeys.length : 0;
    if (pkLen > 0) {
      passkeyCount += pkLen;
      passkeyItemCount++;
    }
    const hasTotp = Boolean(it.totp_secret);
    if (hasTotp) totpCount++;

    const pw = typeof it.password === "string" ? it.password : "";
    if (!pw) continue;
    itemsWithPassword++;

    const weakReason = classifyWeakPasswordReason(pw);
    if (weakReason) {
      weakItems.push({
        id: it.id,
        service_name: it.service_name || "Tài khoản",
        username: it.username || "",
        reason: weakReason
      });
    }

    let group = pwGroups.get(pw);
    if (!group) {
      group = [];
      pwGroups.set(pw, group);
    }
    group.push(it);

    if (!hasTotp && pkLen === 0) {
      missing2faItems.push({
        id: it.id,
        service_name: it.service_name || "Tài khoản",
        username: it.username || ""
      });
    }
  }

  const reusedItems = [];
  let reusedPasswordCount = 0;
  for (const group of pwGroups.values()) {
    if (group.length >= 2) {
      reusedPasswordCount++;
      for (const it of group) {
        reusedItems.push({
          id: it.id,
          service_name: it.service_name || "Tài khoản",
          username: it.username || "",
          reuseCount: group.length
        });
      }
    }
  }

  let score = 100;
  if (itemsWithPassword > 0) {
    const weakPenalty = Math.min(45, Math.round((weakItems.length / itemsWithPassword) * 60));
    const reusePenalty = Math.min(35, Math.round((reusedItems.length / itemsWithPassword) * 45));
    const mfaPenalty = Math.min(20, Math.round((missing2faItems.length / itemsWithPassword) * 20));
    score = Math.max(0, Math.min(100, 100 - weakPenalty - reusePenalty - mfaPenalty));
  }

  return {
    score,
    totalItems: list.length,
    itemsWithPassword,
    weakCount: weakItems.length,
    reusedCount: reusedItems.length,
    reusedPasswordCount,
    missing2faCount: missing2faItems.length,
    totpCount,
    passkeyCount,
    passkeyItemCount,
    weakItems,
    reusedItems,
    missing2faItems
  };
}

async function checkPasswordsHibpKAnonymity(items, { fetchImpl = null, onProgress = null, concurrency = 4 } = {}) {
  const list = Array.isArray(items) ? items : [];
  const byPassword = new Map();
  for (let i = 0; i < list.length; i++) {
    const it = list[i];
    if (!it || typeof it.password !== "string" || it.password.length === 0) continue;
    let bucket = byPassword.get(it.password);
    if (!bucket) {
      bucket = [];
      byPassword.set(it.password, bucket);
    }
    bucket.push(it);
  }

  // Group unique passwords strictly by 5-char uppercase SHA-1 prefix (k-Anonymity)
  const prefixMap = new Map();
  for (const [pw, pwItems] of byPassword.entries()) {
    const sha1Upper = await computeSha1HexUpper(pw);
    const prefix = sha1Upper.slice(0, 5);
    const suffix = sha1Upper.slice(5);
    let entries = prefixMap.get(prefix);
    if (!entries) {
      entries = [];
      prefixMap.set(prefix, entries);
    }
    entries.push({ suffix, items: pwItems });
  }

  const prefixes = Array.from(prefixMap.keys());
  const breachedItems = [];
  const failedPrefixes = [];
  let checkedCount = 0;
  let completedPrefixes = 0;

  const maxWorkers = Math.max(1, Math.min(6, Math.floor(Number(concurrency) || 4)));
  let nextIndex = 0;

  const worker = async () => {
    while (nextIndex < prefixes.length) {
      const idx = nextIndex++;
      const prefix = prefixes[idx];
      const entries = prefixMap.get(prefix) || [];
      try {
        const resp = await fetchWithTimeout(
          `https://api.pwnedpasswords.com/range/${prefix}`,
          {
            method: "GET",
            headers: { "Add-Padding": "true" }
          },
          10000,
          fetchImpl
        );
        if (!resp || !resp.ok) {
          failedPrefixes.push(prefix);
        } else {
          const text = await resp.text();
          for (let j = 0; j < entries.length; j++) {
            const { suffix, items: pwItems } = entries[j];
            checkedCount += pwItems.length;
            const breachCount = parseHibpRangeText(text, suffix);
            if (breachCount > 0) {
              for (let k = 0; k < pwItems.length; k++) {
                const it = pwItems[k];
                breachedItems.push({
                  id: it.id,
                  service_name: it.service_name || "Tài khoản",
                  username: it.username || "",
                  breachCount
                });
              }
            }
          }
        }
      } catch (_) {
        failedPrefixes.push(prefix);
      } finally {
        completedPrefixes++;
        if (typeof onProgress === "function") {
          try {
            onProgress(completedPrefixes, prefixes.length);
          } catch (_) {}
        }
      }
    }
  };

  if (prefixes.length > 0) {
    const workers = [];
    const count = Math.min(maxWorkers, prefixes.length);
    for (let i = 0; i < count; i++) {
      workers.push(worker());
    }
    await Promise.all(workers);
  }

  breachedItems.sort((a, b) => b.breachCount - a.breachCount);

  return {
    checkedCount,
    breachedCount: breachedItems.length,
    breachedItems,
    failedPrefixes
  };
}

// Export globals for Popup, Import Tab, Service Worker importScripts & Node unit tests
globalScope.OmniVaultCore = {
  OMNIVAULT_STORAGE_KEY,
  OMNIVAULT_META_FLAGS_KEY,
  OMNIVAULT_HOT_RECENCY_KEY,
  OMNIVAULT_JWT_CACHE_KEY,
  OMNIVAULT_SESSION_KEY,
  OMNIVAULT_SESSION_EXPIRES_KEY,
  OMNIVAULT_PENDING_UPDATES_KEY,
  OMNIVAULT_PENDING_INLINE_UNLOCK_KEY,
  OMNIVAULT_STEP1_USERS_KEY,
  OMNIVAULT_UNPAIRED_HINTS_KEY,
  SESSION_AUTOLOCK_MS,
  DEFAULT_FETCH_TIMEOUT_MS,
  fetchWithTimeout,
  bytesToBase64,
  base64ToBytes,
  bytesToBase64Url,
  base64UrlToBytes,
  parsePairingCode,
  computeTotpStep,
  computeTotpCode,
  clearTotpKeyCache,
  getTotpKeyCacheSize,
  aes256EncryptJson,
  aes256DecryptJson,
  encryptBrowserVaultPayload,
  decryptBrowserVaultPayload,
  isAllowedGitHubUpdateUrl,
  isSafeAutofillUrl,
  extractAndroidPackageFromUri,
  extractCleanDomain,
  baseRegistrableDomain,
  prettifyDomainTitle,
  itemMatchesDomain,
  buildVaultDomainIndex,
  buildItemSearchIndex,
  scoreIndexedItem,
  foldSearchText,
  matchesUsernamePrefix,
  scoreItemSearchQuery,
  itemMatchesSearchQuery,
  normalizePasskeyRecord,
  normalizeVaultItem,
  passkeyTombKey,
  filterPasskeysByTombstones,
  mergePasskeyListsUnion,
  pruneBrowserTombstonesWithFloor,
  isValidPasskeyRpMatch,
  encodeCbor,
  spkiP256ToCoseKey,
  p1363ToDerEcdsaSignature,
  generatePasskeyP256,
  signPasskeyAssertionP256,
  findMatchingPasskeysForHost,
  computeSha1HexUpper,
  parseHibpRangeText,
  auditVaultSecurity,
  checkPasswordsHibpKAnonymity,
  withVaultMutationLock,
  invalidateMemoryCaches,
  handleStorageChanged,
  getCachedVaultStateAndIndex,
  recordItemAutofilled,
  loadExtensionState,
  saveExtensionState,
  mutateVaultState,
  unpairExtensionVault,
  pairWithCloudCode,
  hasExtensionPinLock,
  setExtensionPin,
  unlockExtensionWithPin,
  clearExtensionPin,
  lockExtensionSession,
  enforceSessionExpiryIfNeeded,
  resetExtensionVault,
  touchAutoLockAlarm,
  enableLocalStandaloneMode,
  syncBrowserVaultBidirectional,
  generateStrongPassword,
  parseOtpAuthUri,
  parseTotpFieldWithMeta,
  parseTotpSecretField,
  parseFidoCxfDocument,
  parseBrowserPasswordsText,
  parseBrowserPasswordsTextAsync,
  analyzeImportDiff,
  importAndPushAllToServer,
  exportVaultToChromeCsv
};

if (typeof module !== "undefined" && module.exports) {
  module.exports = globalScope.OmniVaultCore;
}
})(typeof self !== "undefined" ? self : globalThis);
