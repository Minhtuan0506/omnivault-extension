// ============================================================================
// OmniVault Browser Sync & Crypto Core (100% Byte-Compatible with Rust Core)
// Encryption: AES-256-GCM (12-byte IV + Ciphertext || 16-byte GCM Tag)
// TOTP: RFC 6238 (SHA1 / SHA256 / SHA512)
// ============================================================================

const OMNIVAULT_STORAGE_KEY = "omnivault_state_v1";
const OMNIVAULT_SESSION_KEY = "omnivault_session_wrap_key_b64";
const OMNIVAULT_PIN_FAILS_KEY = "omnivault_pin_fails_v1";
const OMNIVAULT_AUTOLOCK_ALARM = "omnivault_autolock";
const PIN_PBKDF2_ITERS = 310000;

function bytesToBase64(bytes) {
  let bin = "";
  const u8 = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  for (let i = 0; i < u8.length; i++) {
    bin += String.fromCharCode(u8[i]);
  }
  return btoa(bin);
}

function base64ToBytes(b64) {
  const clean = (b64 || "").trim().replace(/\s+/g, "");
  const bin = atob(clean);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) {
    out[i] = bin.charCodeAt(i);
  }
  return out;
}

function base64UrlToBytes(b64url) {
  let s = (b64url || "").trim().replace(/-/g, "+").replace(/_/g, "/");
  while (s.length % 4 !== 0) s += "=";
  return base64ToBytes(s);
}

function parsePairingCode(raw) {
  const trimmed = (raw || "").trim();
  if (!trimmed.startsWith("OVB1-")) {
    throw new Error("Mã kết nối không hợp lệ (phải bắt đầu bằng OVB1-).");
  }
  const encoded = trimmed.slice(5);
  let jsonStr;
  try {
    jsonStr = new TextDecoder("utf-8").decode(base64UrlToBytes(encoded));
  } catch (_) {
    throw new Error("Không giải mã được Mã Kết Nối. Vui lòng sao chép lại từ điện thoại.");
  }
  let parsed;
  try {
    parsed = JSON.parse(jsonStr);
  } catch (_) {
    throw new Error("Cấu trúc Mã Kết Nối không hợp lệ.");
  }
  if (!parsed.u || !parsed.k || !parsed.e || !parsed.p || !parsed.d || !parsed.s) {
    throw new Error("Mã Kết Nối thiếu thông tin máy chủ hoặc khóa giải mã.");
  }
  const keyBytes = base64ToBytes(parsed.s);
  if (keyBytes.length !== 32) {
    throw new Error("Khóa mã hóa trình duyệt không đúng chuẩn AES-256 (32 byte).");
  }
  return {
    version: parsed.v || 1,
    supabaseUrl: String(parsed.u).replace(/\/+$/, ""),
    supabaseAnonKey: String(parsed.k).trim(),
    syncEmail: String(parsed.e).trim(),
    syncPassword: String(parsed.p).trim(),
    deviceId: String(parsed.d).trim(),
    deviceName: String(parsed.n || parsed.d).trim(),
    syncKeyB64: String(parsed.s).trim()
  };
}

async function importAesKey(syncKeyB64) {
  const rawKey = base64ToBytes(syncKeyB64);
  return crypto.subtle.importKey("raw", rawKey, { name: "AES-GCM" }, false, [
    "encrypt",
    "decrypt"
  ]);
}

async function aes256EncryptJson(syncKeyB64, obj) {
  const key = await importAesKey(syncKeyB64);
  const nonce = crypto.getRandomValues(new Uint8Array(12));
  const plainBytes = new TextEncoder().encode(JSON.stringify(obj));
  const ctBuf = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv: nonce, tagLength: 128 },
    key,
    plainBytes
  );
  return {
    nonceB64: bytesToBase64(nonce),
    ciphertextB64: bytesToBase64(new Uint8Array(ctBuf))
  };
}

async function aes256DecryptJson(syncKeyB64, nonceB64, ciphertextB64) {
  const key = await importAesKey(syncKeyB64);
  const nonce = base64ToBytes(nonceB64);
  const ct = base64ToBytes(ciphertextB64);
  const plainBuf = await crypto.subtle.decrypt(
    { name: "AES-GCM", iv: nonce, tagLength: 128 },
    key,
    ct
  );
  const text = new TextDecoder("utf-8").decode(plainBuf);
  return JSON.parse(text);
}

// --- RFC 6238 TOTP Generator ---
function decodeBase32(secret) {
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
  const clean = (secret || "")
    .toUpperCase()
    .replace(/[\s\-=]+/g, "");
  if (!clean) return new Uint8Array(0);
  let bits = 0;
  let value = 0;
  const out = [];
  for (let i = 0; i < clean.length; i++) {
    const idx = alphabet.indexOf(clean[i]);
    if (idx === -1) continue;
    value = (value << 5) | idx;
    bits += 5;
    if (bits >= 8) {
      out.push((value >>> (bits - 8)) & 0xff);
      bits -= 8;
    }
  }
  return new Uint8Array(out);
}

async function computeTotpCode(secret, digits = 6, period = 30, algorithm = "SHA1", nowMs = Date.now()) {
  const keyBytes = decodeBase32(secret);
  if (!keyBytes.length) return null;
  const p = Math.max(1, Number(period) || 30);
  const d = Math.min(10, Math.max(6, Number(digits) || 6));
  const epochSec = Math.floor(nowMs / 1000);
  const counter = Math.floor(epochSec / p);
  const remaining = p - (epochSec % p);

  const counterBytes = new Uint8Array(8);
  let tmp = counter;
  for (let i = 7; i >= 0; i--) {
    counterBytes[i] = tmp & 0xff;
    tmp = Math.floor(tmp / 256);
  }

  const hashName =
    String(algorithm || "SHA1").toUpperCase() === "SHA256"
      ? "SHA-256"
      : String(algorithm || "SHA1").toUpperCase() === "SHA512"
      ? "SHA-512"
      : "SHA-1";

  const hmacKey = await crypto.subtle.importKey(
    "raw",
    keyBytes,
    { name: "HMAC", hash: { name: hashName } },
    false,
    ["sign"]
  );
  const sig = new Uint8Array(await crypto.subtle.sign("HMAC", hmacKey, counterBytes));
  const offset = sig[sig.length - 1] & 0x0f;
  const binary =
    ((sig[offset] & 0x7f) << 24) |
    ((sig[offset + 1] & 0xff) << 16) |
    ((sig[offset + 2] & 0xff) << 8) |
    (sig[offset + 3] & 0xff);
  const otp = String(binary % Math.pow(10, d)).padStart(d, "0");
  return { code: otp, remainingSeconds: remaining, period: p };
}

// --- Clean Domain & Android Package Matching ---
function extractAndroidPackageFromUri(rawUrl) {
  if (!rawUrl) return "";
  const trimmed = String(rawUrl).trim();
  let rest = "";
  if (/^android:\/\//i.test(trimmed)) {
    const afterScheme = trimmed.slice(10);
    const atIdx = afterScheme.lastIndexOf("@");
    rest = atIdx >= 0 ? afterScheme.slice(atIdx + 1) : afterScheme;
  } else if (/^androidapp:\/\//i.test(trimmed)) {
    rest = trimmed.slice(13);
  } else {
    return "";
  }
  const pkg = rest.split(/[/?#]/)[0].trim();
  if (pkg && pkg.includes(".") && !pkg.includes(" ")) {
    return pkg;
  }
  return "";
}

function friendlyServiceNameFromPackage(pkg) {
  const stop = new Set([
    "com", "vn", "org", "net", "io", "app", "apps", "android",
    "mobile", "client", "bb", "mb", "gprsandroid", "production", "release", "global", "gp"
  ]);
  const parts = String(pkg || "").split(".").filter(Boolean);
  for (let i = parts.length - 1; i >= 0; i--) {
    const seg = parts[i];
    if (seg.length >= 2 && !stop.has(seg.toLowerCase())) {
      if (/[A-Z]/.test(seg)) return seg;
      return seg.charAt(0).toUpperCase() + seg.slice(1);
    }
  }
  return String(pkg || "Ứng dụng Android");
}

function isLoopbackOrPrivateHost(hostname) {
  const h = String(hostname || "").toLowerCase().replace(/^\[|\]$/g, "");
  if (!h) return false;
  if (h === "localhost" || h === "127.0.0.1" || h === "::1" || h === "0.0.0.0") {
    return true;
  }
  if (/^127\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(h)) return true;
  if (/^10\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(h)) return true;
  if (/^192\.168\.\d{1,3}\.\d{1,3}$/.test(h)) return true;
  if (/^172\.(1[6-9]|2\d|3[0-1])\.\d{1,3}\.\d{1,3}$/.test(h)) return true;
  if (/\.(local|lan|internal|localhost)$/.test(h)) return true;
  return false;
}

function isSafeAutofillUrl(rawUrl) {
  if (!rawUrl) return false;
  try {
    const u = new URL(String(rawUrl).trim());
    if (u.protocol === "https:") return true;
    if (u.protocol === "http:" && isLoopbackOrPrivateHost(u.hostname)) {
      return true;
    }
    return false;
  } catch (_) {
    return false;
  }
}

function extractCleanDomain(urlOrHost) {
  if (!urlOrHost) return "";
  const trimmed = String(urlOrHost).trim();
  if (!trimmed || /^android(app)?:\/\//i.test(trimmed)) return "";
  const raw = trimmed.toLowerCase();
  try {
    const withProto = raw.includes("://") ? raw : "https://" + raw;
    const u = new URL(withProto);
    return u.hostname.replace(/\.+$/, "").replace(/^www\./, "");
  } catch (_) {
    return raw.split("/")[0].split(":")[0].replace(/\.+$/, "").replace(/^www\./, "");
  }
}

const MULTI_PART_TLDS = new Set([
  "com.vn", "net.vn", "org.vn", "edu.vn", "gov.vn", "ac.vn", "info.vn",
  "health.vn", "int.vn", "biz.vn", "name.vn", "pro.vn",
  "co.uk", "org.uk", "ac.uk", "gov.uk",
  "com.au", "net.au", "org.au",
  "co.jp", "ne.jp", "or.jp",
  "co.kr", "com.sg", "com.tw", "com.hk", "com.br", "co.in"
]);

const SHARED_HOSTING_SUFFIXES = new Set([
  "github.io", "gitlab.io", "pages.dev", "workers.dev", "vercel.app",
  "netlify.app", "web.app", "firebaseapp.com", "herokuapp.com",
  "onrender.com", "railway.app", "fly.dev", "surge.sh",
  "ngrok-free.app", "ngrok.app", "ngrok.io", "trycloudflare.com",
  "blogspot.com", "wordpress.com", "myshopify.com",
  "azurewebsites.net", "cloudfront.net", "duckdns.org", "ddns.net"
]);

function baseRegistrableDomain(host) {
  const h = extractCleanDomain(host);
  if (!h) return "";
  if (h === "localhost" || /^\d{1,3}(\.\d{1,3}){3}$/.test(h)) return h;
  const parts = h.split(".").filter(Boolean);
  if (parts.length < 2) return "";
  const last2 = parts.slice(-2).join(".");
  if (MULTI_PART_TLDS.has(last2) || SHARED_HOSTING_SUFFIXES.has(last2)) {
    if (parts.length < 3) return "";
    return parts.slice(-3).join(".");
  }
  return last2;
}

const KNOWN_PACKAGE_TO_DOMAINS = {
  "com.vcb": ["vietcombank.com.vn", "vcbdigibank.vietcombank.com.vn"],
  "com.mbmobile": ["mbbank.com.vn"],
  "vn.com.techcombank.bb.app": ["techcombank.com", "techcombank.com.vn"],
  "com.vnpay.bidv": ["bidv.com.vn", "smartbanking.bidv.com.vn"],
  "com.vietinbank.ipay": ["vietinbank.vn", "ipay.vietinbank.vn"],
  "com.vnpay.agribank": ["agribank.com.vn"],
  "mobile.acb.com.vn": ["acb.com.vn", "online.acb.com.vn"],
  "com.vnpay.vpbankonline": ["vpbank.com.vn", "neo.vpbank.com.vn"],
  "com.tpb.mb.gprsandroid": ["tpb.vn", "ebank.tpb.vn"],
  "com.zing.zalo": ["zalo.me", "id.zalo.me", "chat.zalo.me"],
  "com.facebook.katana": ["facebook.com", "messenger.com"],
  "com.google.android.gm": ["google.com", "accounts.google.com"],
  "com.shopee.vn": ["shopee.vn"]
};

function prettifyDomainTitle(urlOrHost) {
  const clean = extractCleanDomain(urlOrHost);
  if (!clean) return "";
  const base = baseRegistrableDomain(clean);
  // Keep distinct subdomain hosts visible (e.g. 1.domain.vn vs 2.domain.vn vs domain.vn)
  if (base && clean !== base) {
    return clean;
  }
  const head = (base || clean).split(".")[0] || clean;
  return head ? head.charAt(0).toUpperCase() + head.slice(1) : clean;
}

function itemMatchesDomain(item, tabHost) {
  const cleanTab = extractCleanDomain(tabHost);
  if (!cleanTab) return 0;

  const explicitDomains = new Set();
  if (Array.isArray(item.web_domains)) {
    for (const rawD of item.web_domains) {
      const d = extractCleanDomain(rawD);
      if (d) explicitDomains.add(d);
    }
  }

  for (const d of explicitDomains) {
    if (d === cleanTab) return 3; // Strict exact hostname match (after stripping www.)
  }

  // Only bridge native Android-package items that do NOT have explicit web_domains yet
  if (explicitDomains.size === 0 && Array.isArray(item.android_packages)) {
    for (const rawPkg of item.android_packages) {
      const mapped = KNOWN_PACKAGE_TO_DOMAINS[String(rawPkg || "").trim().toLowerCase()];
      if (Array.isArray(mapped)) {
        for (const md of mapped) {
          if (extractCleanDomain(md) === cleanTab) return 2;
        }
      }
    }
  }

  return 0;
}

function normalizeVaultItem(raw) {
  const now = Date.now();
  return {
    id: raw.id || crypto.randomUUID(),
    service_name: String(raw.service_name || "Tài khoản Web").trim(),
    username: String(raw.username || "").trim(),
    password: String(raw.password || ""),
    totp_secret: raw.totp_secret && String(raw.totp_secret).trim() && raw.totp_secret !== "null"
      ? String(raw.totp_secret).trim()
      : null,
    totp_algorithm: raw.totp_algorithm || "SHA1",
    totp_digits: Number(raw.totp_digits) || 6,
    totp_period: Number(raw.totp_period) || 30,
    web_domains: Array.isArray(raw.web_domains)
      ? raw.web_domains.map(extractCleanDomain).filter(Boolean)
      : [],
    android_packages: Array.isArray(raw.android_packages) ? raw.android_packages : [],
    recovery_codes: Array.isArray(raw.recovery_codes) ? raw.recovery_codes : [],
    pin_code: raw.pin_code || null,
    notes: String(raw.notes || ""),
    folder: String(raw.folder || "Chung"),
    is_favorite: Boolean(raw.is_favorite),
    pin_totp_to_dashboard: raw.pin_totp_to_dashboard !== false,
    password_history: Array.isArray(raw.password_history) ? raw.password_history : [],
    created_at_ms: Number(raw.created_at_ms) || now,
    updated_at_ms: Number(raw.updated_at_ms) || now,
    last_autofilled_ms: raw.last_autofilled_ms ? Number(raw.last_autofilled_ms) : null
  };
}

// --- Storage Helpers ---
async function derivePinWrapKeyB64(pin, saltBytes, iterations = PIN_PBKDF2_ITERS) {
  const passBytes = new TextEncoder().encode(String(pin || ""));
  const baseKey = await crypto.subtle.importKey(
    "raw",
    passBytes,
    { name: "PBKDF2" },
    false,
    ["deriveBits"]
  );
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", salt: saltBytes, iterations, hash: "SHA-256" },
    baseKey,
    256
  );
  return bytesToBase64(new Uint8Array(bits));
}

async function getSessionWrapKeyB64() {
  if (!chrome?.storage?.session) return null;
  const data = await chrome.storage.session.get(OMNIVAULT_SESSION_KEY);
  return data[OMNIVAULT_SESSION_KEY] || null;
}

async function setSessionWrapKeyB64(wrapKeyB64) {
  if (!chrome?.storage?.session) return;
  await chrome.storage.session.set({ [OMNIVAULT_SESSION_KEY]: wrapKeyB64 });
}

async function touchAutoLockAlarm() {
  try {
    if (chrome?.alarms?.create) {
      await chrome.alarms.create(OMNIVAULT_AUTOLOCK_ALARM, { delayInMinutes: 15 });
    }
  } catch (_) {}
}

async function lockExtensionSession() {
  try {
    if (chrome?.storage?.session) {
      await chrome.storage.session.remove(OMNIVAULT_SESSION_KEY);
    }
    if (chrome?.alarms?.clear) {
      await chrome.alarms.clear(OMNIVAULT_AUTOLOCK_ALARM);
    }
  } catch (_) {}
}

async function hasExtensionPinLock() {
  const data = await chrome.storage.local.get(OMNIVAULT_STORAGE_KEY);
  const st = data[OMNIVAULT_STORAGE_KEY] || {};
  return Boolean(st.encryptedVault && st.encryptedVault.ciphertextB64);
}

async function setExtensionPin(newPin, currentPin = null) {
  const cleanPin = String(newPin || "").trim();
  if (cleanPin.length < 4 || cleanPin.length > 64) {
    throw new Error("Mã PIN phải từ 4 đến 64 ký tự.");
  }
  const data = await chrome.storage.local.get(OMNIVAULT_STORAGE_KEY);
  const st = data[OMNIVAULT_STORAGE_KEY] || {};
  let bundle;

  if (st.encryptedVault && st.encryptedVault.ciphertextB64) {
    const oldClean = String(currentPin || "").trim();
    if (!oldClean) {
      throw new Error("Vui lòng nhập mã PIN hiện tại để đổi PIN mới.");
    }
    const oldSalt = base64ToBytes(st.encryptedVault.saltB64);
    const oldIters = Number(st.encryptedVault.iterations) || PIN_PBKDF2_ITERS;
    const oldWrapKey = await derivePinWrapKeyB64(oldClean, oldSalt, oldIters);
    try {
      bundle = await aes256DecryptJson(
        oldWrapKey,
        st.encryptedVault.nonceB64,
        st.encryptedVault.ciphertextB64
      );
    } catch (_) {
      throw new Error("Mã PIN hiện tại không đúng.");
    }
  } else {
    bundle = {
      pairing: st.pairing || null,
      jwt: st.jwt || null,
      jwtExpiresAtMs: st.jwtExpiresAtMs || 0,
      items: Array.isArray(st.items) ? st.items.map(normalizeVaultItem) : [],
      pendingCapture: st.pendingCapture || null
    };
  }

  const salt = crypto.getRandomValues(new Uint8Array(16));
  const newWrapKey = await derivePinWrapKeyB64(cleanPin, salt, PIN_PBKDF2_ITERS);
  const enc = await aes256EncryptJson(newWrapKey, bundle);

  await chrome.storage.local.set({
    [OMNIVAULT_STORAGE_KEY]: {
      hasPinLock: true,
      deviceNameHint: bundle?.pairing?.deviceName || st.deviceNameHint || null,
      deletedIds: st.deletedIds && typeof st.deletedIds === "object" ? st.deletedIds : {},
      lastSyncedAtMs: st.lastSyncedAtMs || 0,
      encryptedVault: {
        saltB64: bytesToBase64(salt),
        iterations: PIN_PBKDF2_ITERS,
        nonceB64: enc.nonceB64,
        ciphertextB64: enc.ciphertextB64
      }
    }
  });
  await setSessionWrapKeyB64(newWrapKey);
  await touchAutoLockAlarm();
}

async function unlockExtensionWithPin(pin) {
  const cleanPin = String(pin || "").trim();
  if (!cleanPin) {
    throw new Error("Vui lòng nhập mã PIN.");
  }
  if (chrome?.storage?.session) {
    const fails = await chrome.storage.session.get(OMNIVAULT_PIN_FAILS_KEY);
    const info = fails[OMNIVAULT_PIN_FAILS_KEY];
    if (info && info.lockedUntilMs && Date.now() < info.lockedUntilMs) {
      const secs = Math.max(1, Math.ceil((info.lockedUntilMs - Date.now()) / 1000));
      throw new Error(`Thử sai quá nhiều lần. Đợi ${secs}s.`);
    }
  }
  const data = await chrome.storage.local.get(OMNIVAULT_STORAGE_KEY);
  const st = data[OMNIVAULT_STORAGE_KEY] || {};
  if (!st.encryptedVault || !st.encryptedVault.ciphertextB64) {
    return loadExtensionState();
  }
  const salt = base64ToBytes(st.encryptedVault.saltB64);
  const iters = Number(st.encryptedVault.iterations) || PIN_PBKDF2_ITERS;
  const wrapKeyB64 = await derivePinWrapKeyB64(cleanPin, salt, iters);
  try {
    await aes256DecryptJson(
      wrapKeyB64,
      st.encryptedVault.nonceB64,
      st.encryptedVault.ciphertextB64
    );
  } catch (_) {
    if (chrome?.storage?.session) {
      const fails = await chrome.storage.session.get(OMNIVAULT_PIN_FAILS_KEY);
      const prevCount = Number(fails[OMNIVAULT_PIN_FAILS_KEY]?.count || 0) + 1;
      const lockedUntilMs = prevCount >= 5 ? Date.now() + 30_000 : 0;
      await chrome.storage.session.set({
        [OMNIVAULT_PIN_FAILS_KEY]: { count: prevCount, lockedUntilMs }
      });
    }
    throw new Error("Mã PIN không đúng.");
  }
  if (chrome?.storage?.session) {
    await chrome.storage.session.remove(OMNIVAULT_PIN_FAILS_KEY);
  }
  await setSessionWrapKeyB64(wrapKeyB64);
  await touchAutoLockAlarm();
  return loadExtensionState();
}

async function clearExtensionPin(currentPin) {
  const data = await chrome.storage.local.get(OMNIVAULT_STORAGE_KEY);
  const st = data[OMNIVAULT_STORAGE_KEY] || {};
  if (!st.encryptedVault || !st.encryptedVault.ciphertextB64) {
    await lockExtensionSession();
    return;
  }
  const cleanPin = String(currentPin || "").trim();
  if (!cleanPin) {
    throw new Error("Vui lòng nhập mã PIN hiện tại để gỡ khóa.");
  }
  const salt = base64ToBytes(st.encryptedVault.saltB64);
  const iters = Number(st.encryptedVault.iterations) || PIN_PBKDF2_ITERS;
  const wrapKey = await derivePinWrapKeyB64(cleanPin, salt, iters);
  let bundle;
  try {
    bundle = await aes256DecryptJson(
      wrapKey,
      st.encryptedVault.nonceB64,
      st.encryptedVault.ciphertextB64
    );
  } catch (_) {
    throw new Error("Mã PIN hiện tại không đúng.");
  }
  await chrome.storage.local.set({
    [OMNIVAULT_STORAGE_KEY]: {
      hasPinLock: false,
      pairing: bundle.pairing || null,
      jwt: bundle.jwt || null,
      jwtExpiresAtMs: bundle.jwtExpiresAtMs || 0,
      items: Array.isArray(bundle.items) ? bundle.items.map(normalizeVaultItem) : [],
      deletedIds: st.deletedIds && typeof st.deletedIds === "object" ? st.deletedIds : {},
      lastSyncedAtMs: st.lastSyncedAtMs || 0,
      pendingCapture: bundle.pendingCapture || null
    }
  });
  await lockExtensionSession();
}

async function loadExtensionState() {
  const data = await chrome.storage.local.get(OMNIVAULT_STORAGE_KEY);
  const st = data[OMNIVAULT_STORAGE_KEY] || {};
  if (st.encryptedVault && st.encryptedVault.ciphertextB64) {
    const wrapKeyB64 = await getSessionWrapKeyB64();
    if (!wrapKeyB64) {
      return {
        locked: true,
        hasPinLock: true,
        deviceNameHint: st.deviceNameHint || null,
        pairing: null,
        jwt: null,
        jwtExpiresAtMs: 0,
        items: [],
        deletedIds: st.deletedIds && typeof st.deletedIds === "object" ? st.deletedIds : {},
        lastSyncedAtMs: st.lastSyncedAtMs || 0,
        pendingCapture: null
      };
    }
    try {
      const bundle = await aes256DecryptJson(
        wrapKeyB64,
        st.encryptedVault.nonceB64,
        st.encryptedVault.ciphertextB64
      );
      return {
        locked: false,
        hasPinLock: true,
        deviceNameHint: bundle?.pairing?.deviceName || st.deviceNameHint || null,
        pairing: bundle.pairing || null,
        jwt: bundle.jwt || null,
        jwtExpiresAtMs: bundle.jwtExpiresAtMs || 0,
        items: Array.isArray(bundle.items) ? bundle.items.map(normalizeVaultItem) : [],
        deletedIds: st.deletedIds && typeof st.deletedIds === "object" ? st.deletedIds : {},
        lastSyncedAtMs: st.lastSyncedAtMs || 0,
        pendingCapture: bundle.pendingCapture || null
      };
    } catch (_) {
      await lockExtensionSession();
      return {
        locked: true,
        hasPinLock: true,
        deviceNameHint: st.deviceNameHint || null,
        pairing: null,
        jwt: null,
        jwtExpiresAtMs: 0,
        items: [],
        deletedIds: st.deletedIds && typeof st.deletedIds === "object" ? st.deletedIds : {},
        lastSyncedAtMs: st.lastSyncedAtMs || 0,
        pendingCapture: null
      };
    }
  }
  return {
    locked: false,
    hasPinLock: false,
    deviceNameHint: st.pairing?.deviceName || null,
    pairing: st.pairing || null,
    jwt: st.jwt || null,
    jwtExpiresAtMs: st.jwtExpiresAtMs || 0,
    items: Array.isArray(st.items) ? st.items.map(normalizeVaultItem) : [],
    deletedIds: st.deletedIds && typeof st.deletedIds === "object" ? st.deletedIds : {},
    lastSyncedAtMs: st.lastSyncedAtMs || 0,
    pendingCapture: st.pendingCapture || null
  };
}

async function saveExtensionState(nextState) {
  const data = await chrome.storage.local.get(OMNIVAULT_STORAGE_KEY);
  const prev = data[OMNIVAULT_STORAGE_KEY] || {};
  if (prev.encryptedVault && prev.encryptedVault.ciphertextB64) {
    const wrapKeyB64 = await getSessionWrapKeyB64();
    if (!wrapKeyB64) {
      throw new Error("Kho tiện ích đang khóa — vui lòng mở khóa bằng PIN trước khi lưu.");
    }
    const bundle = {
      pairing: nextState.pairing || null,
      jwt: nextState.jwt || null,
      jwtExpiresAtMs: nextState.jwtExpiresAtMs || 0,
      items: Array.isArray(nextState.items) ? nextState.items.map(normalizeVaultItem) : [],
      pendingCapture: nextState.pendingCapture || null
    };
    const enc = await aes256EncryptJson(wrapKeyB64, bundle);
    await chrome.storage.local.set({
      [OMNIVAULT_STORAGE_KEY]: {
        hasPinLock: true,
        deviceNameHint: nextState.pairing?.deviceName || null,
        deletedIds: nextState.deletedIds && typeof nextState.deletedIds === "object" ? nextState.deletedIds : {},
        lastSyncedAtMs: nextState.lastSyncedAtMs || 0,
        encryptedVault: {
          saltB64: prev.encryptedVault.saltB64,
          iterations: prev.encryptedVault.iterations || PIN_PBKDF2_ITERS,
          nonceB64: enc.nonceB64,
          ciphertextB64: enc.ciphertextB64
        }
      }
    });
    return;
  }
  await chrome.storage.local.set({
    [OMNIVAULT_STORAGE_KEY]: {
      hasPinLock: false,
      pairing: nextState.pairing || null,
      jwt: nextState.jwt || null,
      jwtExpiresAtMs: nextState.jwtExpiresAtMs || 0,
      items: Array.isArray(nextState.items) ? nextState.items.map(normalizeVaultItem) : [],
      deletedIds: nextState.deletedIds && typeof nextState.deletedIds === "object" ? nextState.deletedIds : {},
      lastSyncedAtMs: nextState.lastSyncedAtMs || 0,
      pendingCapture: nextState.pendingCapture || null
    }
  });
}

// --- Supabase Auth + Bidirectional E2EE Sync ---
async function getSupabaseJwt(state) {
  const p = state.pairing;
  if (!p) throw new Error("Chưa kết nối với ứng dụng OmniVault.");
  if (state.jwt && state.jwtExpiresAtMs > Date.now() + 60_000) {
    return state.jwt;
  }
  const resp = await fetch(`${p.supabaseUrl}/auth/v1/token?grant_type=password`, {
    method: "POST",
    headers: {
      apikey: p.supabaseAnonKey,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      email: p.syncEmail,
      password: p.syncPassword
    })
  });
  if (!resp.ok) {
    throw new Error(`Lỗi xác thực Máy chủ Đám mây (${resp.status}).`);
  }
  const tok = await resp.json();
  state.jwt = tok.access_token;
  state.jwtExpiresAtMs = Date.now() + (Number(tok.expires_in || 3600) * 1000);
  await saveExtensionState(state);
  return state.jwt;
}

async function enableLocalStandaloneMode() {
  const st = await loadExtensionState();
  if (st.locked) {
    throw new Error("Kho tiện ích đang khóa — vui lòng nhập PIN trước.");
  }
  if (!st.pairing) {
    st.pairing = {
      version: 1,
      localOnly: true,
      deviceName: "Trình duyệt cục bộ"
    };
    await saveExtensionState(st);
  }
  return st;
}

async function syncBrowserVaultBidirectional(forcePush = false) {
  const state = await loadExtensionState();
  const p = state.pairing;
  if (!p) throw new Error("Chưa kết nối thiết bị.");
  if (p.localOnly) {
    const sortedLocal = (Array.isArray(state.items) ? state.items : [])
      .map(normalizeVaultItem)
      .sort((a, b) => {
        if (a.is_favorite !== b.is_favorite) return a.is_favorite ? -1 : 1;
        return a.service_name.localeCompare(b.service_name, "vi");
      });
    state.items = sortedLocal;
    await saveExtensionState(state);
    return {
      itemCount: sortedLocal.length,
      pulledCount: 0,
      pushed: false,
      localOnly: true
    };
  }

  const jwt = await getSupabaseJwt(state);
  const qDev = encodeURIComponent(p.deviceId);
  const getUrl = `${p.supabaseUrl}/rest/v1/omnivault_browser_vault?device_id=eq.${qDev}&select=*&limit=1`;

  const getResp = await fetch(getUrl, {
    method: "GET",
    headers: {
      apikey: p.supabaseAnonKey,
      Authorization: `Bearer ${jwt}`
    }
  });
  if (!getResp.ok) {
    throw new Error(`Không tải được Kho Trình duyệt (${getResp.status}).`);
  }
  const rows = await getResp.json();
  const remoteRow = Array.isArray(rows) && rows.length > 0 ? rows[0] : null;

  const tombstones = { ...(state.deletedIds || {}) };
  const localMap = new Map();
  for (const it of state.items) {
    localMap.set(it.id, normalizeVaultItem(it));
  }

  let needPush = forcePush || !remoteRow;
  let pulledCount = 0;

  if (remoteRow && remoteRow.enc_nonce_b64 && remoteRow.enc_ciphertext_b64) {
    const remotePayload = await aes256DecryptJson(
      p.syncKeyB64,
      remoteRow.enc_nonce_b64,
      remoteRow.enc_ciphertext_b64
    );
    const remoteDeleted = remotePayload.deleted_ids || {};
    for (const [delId, delTs] of Object.entries(remoteDeleted)) {
      const ts = Number(delTs) || 0;
      if (!tombstones[delId] || ts > tombstones[delId]) {
        tombstones[delId] = ts;
      }
    }

    const remoteItems = Array.isArray(remotePayload.items) ? remotePayload.items : [];
    // Purge stale tombstones if an item was restored from Trash on Android or re-saved with a newer timestamp
    for (const rawRemote of remoteItems) {
      const rTs = Number(rawRemote?.updated_at_ms) || 0;
      const rId = rawRemote?.id;
      if (rId && tombstones[rId] && rTs > tombstones[rId]) {
        delete tombstones[rId];
      }
    }
    for (const [id, item] of localMap.entries()) {
      if (tombstones[id] && item.updated_at_ms > tombstones[id]) {
        delete tombstones[id];
      }
    }

    for (const [locDelId, locDelTs] of Object.entries(tombstones)) {
      if ((Number(remoteDeleted[locDelId]) || 0) < locDelTs) {
        needPush = true;
      }
    }

    // Apply tombstones to local items
    for (const [id, item] of Array.from(localMap.entries())) {
      if (tombstones[id] && tombstones[id] >= item.updated_at_ms) {
        localMap.delete(id);
        pulledCount++;
      }
    }

    const remoteIds = new Set();
    for (const rawRemote of remoteItems) {
      const rItem = normalizeVaultItem(rawRemote);
      if (tombstones[rItem.id] && tombstones[rItem.id] >= rItem.updated_at_ms) {
        needPush = true;
        continue;
      }
      remoteIds.add(rItem.id);
      const lItem = localMap.get(rItem.id);
      if (!lItem) {
        localMap.set(rItem.id, rItem);
        pulledCount++;
      } else if (rItem.updated_at_ms > lItem.updated_at_ms) {
        localMap.set(rItem.id, rItem);
        pulledCount++;
      } else if (lItem.updated_at_ms > rItem.updated_at_ms) {
        needPush = true;
      }
    }

    for (const k of localMap.keys()) {
      if (!remoteIds.has(k)) {
        needPush = true;
      }
    }
  }

  const mergedItems = Array.from(localMap.values()).sort((a, b) => {
    if (a.is_favorite !== b.is_favorite) return a.is_favorite ? -1 : 1;
    return a.service_name.localeCompare(b.service_name, "vi");
  });

  if (needPush) {
    const now = Date.now();
    const payload = {
      items: mergedItems,
      deleted_ids: tombstones,
      updated_at_ms: now
    };
    const enc = await aes256EncryptJson(p.syncKeyB64, payload);
    const postUrl = `${p.supabaseUrl}/rest/v1/omnivault_browser_vault?on_conflict=device_id`;
    const postResp = await fetch(postUrl, {
      method: "POST",
      headers: {
        apikey: p.supabaseAnonKey,
        Authorization: `Bearer ${jwt}`,
        Prefer: "resolution=merge-duplicates,return=minimal",
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        device_id: p.deviceId,
        device_name: p.deviceName,
        enc_nonce_b64: enc.nonceB64,
        enc_ciphertext_b64: enc.ciphertextB64,
        item_count: mergedItems.length,
        updated_at_ms: now
      })
    });
    if (!postResp.ok) {
      throw new Error(`Lỗi đẩy dữ liệu lên Máy chủ (${postResp.status}).`);
    }
  }

  state.items = mergedItems;
  state.deletedIds = tombstones;
  state.lastSyncedAtMs = Date.now();
  await saveExtensionState(state);

  return {
    itemCount: mergedItems.length,
    pulledCount,
    pushed: needPush
  };
}

function generateStrongPassword(length = 18) {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%^&*_-+=";
  const rnd = crypto.getRandomValues(new Uint32Array(length));
  let out = "";
  for (let i = 0; i < length; i++) {
    out += chars[rnd[i] % chars.length];
  }
  return out;
}

// --- RFC-4180 Browser CSV & Bitwarden JSON Bulk Parser ---
function parseCsvMatrix(csvText) {
  const rows = [];
  let curRow = [];
  let curField = "";
  let inQuotes = false;
  const s = String(csvText || "").replace(/^\uFEFF/, "");

  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    if (inQuotes) {
      if (ch === '"') {
        if (i + 1 < s.length && s[i + 1] === '"') {
          curField += '"';
          i++;
        } else {
          inQuotes = false;
        }
      } else {
        curField += ch;
      }
    } else {
      if (ch === '"') {
        inQuotes = true;
      } else if (ch === ",") {
        curRow.push(curField.trim());
        curField = "";
      } else if (ch === "\r" || ch === "\n") {
        if (ch === "\r" && i + 1 < s.length && s[i + 1] === "\n") {
          i++;
        }
        curRow.push(curField.trim());
        curField = "";
        if (curRow.some((cell) => cell.length > 0)) {
          rows.push(curRow);
        }
        curRow = [];
      } else {
        curField += ch;
      }
    }
  }
  if (curField.length > 0 || curRow.length > 0) {
    curRow.push(curField.trim());
    if (curRow.some((cell) => cell.length > 0)) {
      rows.push(curRow);
    }
  }
  return rows;
}

function parseTotpSecretField(rawTotp) {
  const t = String(rawTotp || "").trim();
  if (!t) return null;
  if (/^otpauth:\/\//i.test(t)) {
    try {
      const u = new URL(t);
      const sec = (u.searchParams.get("secret") || "").trim();
      if (sec && decodeBase32(sec).length > 0) return sec.replace(/[\s\-=]+/g, "").toUpperCase();
    } catch (_) {
      return null;
    }
    return null;
  }
  if (/^[A-Z2-7\s\-=]{8,}$/i.test(t) && decodeBase32(t).length > 0) {
    return t.replace(/[\s\-=]+/g, "").toUpperCase();
  }
  return null;
}

function parseBrowserPasswordsText(rawText) {
  const clean = String(rawText || "").replace(/^\uFEFF/, "").trim();
  if (!clean) {
    throw new Error("File mật khẩu đang trống.");
  }

  const now = Date.now();
  // 1. Auto-detect Bitwarden JSON
  if (clean.startsWith("{")) {
    let root;
    try {
      root = JSON.parse(clean);
    } catch (e) {
      throw new Error("File JSON không hợp lệ: " + (e.message || e));
    }
    if (!Array.isArray(root.items)) {
      throw new Error("Không tìm thấy danh sách items trong file JSON.");
    }
    const out = [];
    for (const item of root.items) {
      if (!item || !item.login) continue;
      const webDomains = [];
      const androidPackages = [];
      for (const u of Array.isArray(item.login.uris) ? item.login.uris : []) {
        const uriStr = String(u?.uri || "").trim();
        if (!uriStr) continue;
        const pkg = extractAndroidPackageFromUri(uriStr);
        if (pkg) {
          if (!androidPackages.some((p) => p.toLowerCase() === pkg.toLowerCase())) {
            androidPackages.push(pkg);
          }
        } else {
          const dom = extractCleanDomain(uriStr);
          if (dom && !webDomains.includes(dom)) webDomains.push(dom);
        }
      }
      const username = String(item.login.username || "").trim();
      const password = String(item.login.password || "");
      const totpSecret = parseTotpSecretField(item.login.totp);
      if (!username && !password && !totpSecret) continue;
      out.push(
        normalizeVaultItem({
          id: crypto.randomUUID(),
          service_name:
            String(item.name || "").trim() ||
            webDomains[0] ||
            (androidPackages[0] ? friendlyServiceNameFromPackage(androidPackages[0]) : "Tài khoản Web"),
          username,
          password,
          totp_secret: totpSecret,
          web_domains: webDomains,
          android_packages: androidPackages,
          notes: String(item.notes || ""),
          folder: "Bitwarden",
          is_favorite: Boolean(item.favorite),
          created_at_ms: now,
          updated_at_ms: now
        })
      );
    }
    return out;
  }

  // 2. Standard Browser CSV (Chrome, Edge, Cốc Cốc, Brave, Firefox, Safari/iCloud, Opera)
  const matrix = parseCsvMatrix(clean);
  if (matrix.length < 2) {
    throw new Error("File CSV chưa có dòng dữ liệu mật khẩu nào.");
  }
  const headers = matrix[0].map((h) => h.replace(/^\uFEFF/, "").trim().toLowerCase());
  const findCol = (candidates) => headers.findIndex((h) => candidates.includes(h));

  const idxName = findCol(["name", "title", "service", "account", "site"]);
  const idxUrl = findCol([
    "url",
    "login_uri",
    "website",
    "web site",
    "origin",
    "hostname",
    "signon_realm",
    "httprealm",
    "formsubmitorigin"
  ]);
  const idxUser = findCol(["username", "login_username", "user", "login", "login name", "email"]);
  const idxPass = findCol(["password", "login_password", "pass"]);
  const idxNote = findCol(["note", "notes", "comment", "comments", "extra"]);
  const idxTotp = findCol(["login_totp", "totp", "otpauth", "verification code", "totp secret"]);

  if (idxUser < 0 && idxPass < 0) {
    throw new Error(
      "Không nhận diện được cột username / password. Vui lòng chọn đúng file .CSV xuất từ Trình duyệt."
    );
  }

  const out = [];
  for (let r = 1; r < matrix.length; r++) {
    const row = matrix[r];
    const urlVal = idxUrl >= 0 ? String(row[idxUrl] || "").trim() : "";
    const androidPkg = extractAndroidPackageFromUri(urlVal);
    const domain = androidPkg ? "" : extractCleanDomain(urlVal);

    let rawName = idxName >= 0 ? String(row[idxName] || "").trim() : "";
    if (rawName && (extractAndroidPackageFromUri(rawName) || /^android:\/\//i.test(rawName))) {
      rawName = "";
    } else if (/^https?:\/\//i.test(rawName)) {
      rawName = extractCleanDomain(rawName) || rawName;
    }

    const serviceName =
      rawName ||
      domain ||
      (androidPkg ? friendlyServiceNameFromPackage(androidPkg) : "Tài khoản Web");

    const username = idxUser >= 0 ? String(row[idxUser] || "").trim() : "";
    const password = idxPass >= 0 ? String(row[idxPass] || "") : "";
    const notes = idxNote >= 0 ? String(row[idxNote] || "").trim() : "";
    const totpSecret = idxTotp >= 0 ? parseTotpSecretField(row[idxTotp]) : null;

    if (!username && !password && !totpSecret) continue;

    out.push(
      normalizeVaultItem({
        id: crypto.randomUUID(),
        service_name: serviceName,
        username,
        password,
        totp_secret: totpSecret,
        web_domains: domain ? [domain] : [],
        android_packages: androidPkg ? [androidPkg] : [],
        notes,
        folder: "Trình duyệt",
        created_at_ms: now,
        updated_at_ms: now
      })
    );
  }
  return out;
}

async function importAndPushAllToServer(incomingItems) {
  if (!Array.isArray(incomingItems) || incomingItems.length === 0) {
    throw new Error("Không tìm thấy tài khoản hợp lệ nào trong file đã chọn.");
  }

  // Pull latest server state first so phone changes are preserved before merging
  await syncBrowserVaultBidirectional(false);

  const st = await loadExtensionState();
  if (!st.pairing) {
    throw new Error("Chưa kết nối với ứng dụng OmniVault.");
  }

  const now = Date.now();
  const working = Array.isArray(st.items) ? st.items.map(normalizeVaultItem) : [];
  let addedCount = 0;
  let updatedCount = 0;
  const updatedSeen = new Set();

  for (const rawInc of incomingItems) {
    const inc = normalizeVaultItem(rawInc);
    if (!inc.username && !inc.password && !inc.totp_secret) continue;

    const incUserLc = inc.username.trim().toLowerCase();

    const matchIdx = working.findIndex((ex) => {
      if (ex.username.trim().toLowerCase() !== incUserLc) return false;
      // 1. Exact web domain match (strictly keeps root domain and each subdomain separate)
      if (
        inc.web_domains.length > 0 &&
        inc.web_domains.some((d) => ex.web_domains.some((ed) => ed.toLowerCase() === d.toLowerCase()))
      ) {
        return true;
      }
      // 2. Exact Android package match
      if (
        inc.android_packages.length > 0 &&
        inc.android_packages.some((p) =>
          (ex.android_packages || []).some((ep) => ep.toLowerCase() === p.toLowerCase())
        )
      ) {
        return true;
      }
      // 4. Empty domains/packages -> match by service_name
      if (
        inc.web_domains.length === 0 &&
        inc.android_packages.length === 0 &&
        ex.web_domains.length === 0 &&
        (ex.android_packages || []).length === 0 &&
        ex.service_name.trim().toLowerCase() === inc.service_name.trim().toLowerCase()
      ) {
        return true;
      }
      return false;
    });

    if (matchIdx >= 0) {
      const ex = working[matchIdx];
      let changed = false;

      if (inc.password && ex.password !== inc.password) {
        if (ex.password) {
          ex.password_history = [
            { password: ex.password, changed_at_ms: now },
            ...(Array.isArray(ex.password_history) ? ex.password_history : [])
          ].slice(0, 10);
        }
        ex.password = inc.password;
        changed = true;
      }
      if (!ex.totp_secret && inc.totp_secret) {
        ex.totp_secret = inc.totp_secret;
        changed = true;
      }
      for (const dom of inc.web_domains) {
        if (!ex.web_domains.some((d) => d.toLowerCase() === dom.toLowerCase())) {
          ex.web_domains.push(dom);
          changed = true;
        }
      }
      for (const pkg of inc.android_packages) {
        if (!ex.android_packages.some((p) => p.toLowerCase() === pkg.toLowerCase())) {
          ex.android_packages.push(pkg);
          changed = true;
        }
      }
      const incNote = inc.notes.trim();
      if (incNote && !ex.notes.includes(incNote)) {
        ex.notes = ex.notes.trim() ? `${ex.notes.trim()}\n${incNote}` : incNote;
        changed = true;
      }

      if (changed) {
        ex.updated_at_ms = now;
        delete st.deletedIds[ex.id];
        if (!updatedSeen.has(ex.id)) {
          updatedSeen.add(ex.id);
          updatedCount++;
        }
      }
    } else {
      inc.created_at_ms = now;
      inc.updated_at_ms = now;
      delete st.deletedIds[inc.id];
      working.push(inc);
      addedCount++;
    }
  }

  st.items = working;
  await saveExtensionState(st);

  // Immediately encrypt (AES-256-GCM) and push 100% of vault items onto Supabase Server!
  const syncRes = await syncBrowserVaultBidirectional(true);
  return {
    importedCount: incomingItems.length,
    addedCount,
    updatedCount,
    totalServerCount: syncRes.itemCount
  };
}

function exportVaultToChromeCsv(items) {
  const esc = (s) => {
    const str = String(s || "");
    return /[",\r\n]/.test(str) ? `"${str.replace(/"/g, '""')}"` : str;
  };
  const lines = ["name,url,username,password,note"];
  for (const it of Array.isArray(items) ? items : []) {
    if (!it.username && !it.password) continue;
    const dom = Array.isArray(it.web_domains) && it.web_domains[0] ? it.web_domains[0] : "";
    const pkg = Array.isArray(it.android_packages) && it.android_packages[0] ? it.android_packages[0] : "";
    const url = dom
      ? /^https?:\/\//i.test(dom)
        ? dom
        : `https://${dom}`
      : pkg
      ? `androidapp://${pkg}`
      : "";
    const name = String(it.service_name || "").trim() || url;
    lines.push([esc(name), esc(url), esc(it.username || ""), esc(it.password || ""), esc(it.notes || "")].join(","));
  }
  return lines.join("\n") + "\n";
}

const GMAIL_ALIAS_WEB_DOMAINS = new Set([
  "accounts.google.com",
  "mail.google.com",
  "myaccount.google.com",
  "google.com"
]);

const GMAIL_ALIAS_ANDROID_PACKAGES = new Set([
  "com.google.android.gm",
  "com.google.android.gsf.login"
]);

function itemMatchesSearchQuery(item, rawQuery) {
  const q = String(rawQuery || "").trim().toLowerCase();
  if (!q) return true;
  if (!item) return false;
  const srv = String(item.service_name || "").toLowerCase();
  const usr = String(item.username || "").toLowerCase();
  const doms = (Array.isArray(item.web_domains) ? item.web_domains : []).map((d) =>
    String(d || "").trim().toLowerCase()
  );
  const pkgs = (Array.isArray(item.android_packages) ? item.android_packages : []).map((p) =>
    String(p || "").trim().toLowerCase()
  );
  if (
    srv.includes(q) ||
    usr.includes(q) ||
    doms.join(" ").includes(q) ||
    pkgs.join(" ").includes(q)
  ) {
    return true;
  }
  if (q === "gmail" || q === "google mail" || q === "googlemail") {
    if (
      doms.some((d) => GMAIL_ALIAS_WEB_DOMAINS.has(d)) ||
      pkgs.some((p) => GMAIL_ALIAS_ANDROID_PACKAGES.has(p))
    ) {
      return true;
    }
  }
  return false;
}

// Export globals for Popup, Import Tab & Service Worker importScripts
globalThis.OmniVaultCore = {
  parsePairingCode,
  computeTotpCode,
  isSafeAutofillUrl,
  extractAndroidPackageFromUri,
  extractCleanDomain,
  baseRegistrableDomain,
  prettifyDomainTitle,
  itemMatchesDomain,
  itemMatchesSearchQuery,
  normalizeVaultItem,
  loadExtensionState,
  saveExtensionState,
  hasExtensionPinLock,
  setExtensionPin,
  unlockExtensionWithPin,
  clearExtensionPin,
  lockExtensionSession,
  touchAutoLockAlarm,
  enableLocalStandaloneMode,
  syncBrowserVaultBidirectional,
  generateStrongPassword,
  parseBrowserPasswordsText,
  importAndPushAllToServer,
  exportVaultToChromeCsv
};
