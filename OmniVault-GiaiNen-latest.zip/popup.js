(() => {
  const viewPairing = document.getElementById("viewPairing");
  const viewVault = document.getElementById("viewVault");
  const viewEditor = document.getElementById("viewEditor");
  const pairedTopActions = document.getElementById("pairedTopActions");
  const deviceLabel = document.getElementById("deviceLabel");
  const toastBanner = document.getElementById("toastBanner");

  const pairingInput = document.getElementById("pairingInput");
  const btnConnectCode = document.getElementById("btnConnectCode");
  const btnStartLocalMode = document.getElementById("btnStartLocalMode");
  const btnCancelPairUpgrade = document.getElementById("btnCancelPairUpgrade");
  const btnUpgradeToPhoneSync = document.getElementById("btnUpgradeToPhoneSync");
  const btnOpenBulkImportTop = document.getElementById("btnOpenBulkImportTop");
  const btnOpenBulkImportVault = document.getElementById("btnOpenBulkImportVault");
  const btnOpenBulkImportUnpaired = document.getElementById("btnOpenBulkImportUnpaired");
  const btnSyncNow = document.getElementById("btnSyncNow");
  const btnOpenAdd = document.getElementById("btnOpenAdd");
  const btnUnpair = document.getElementById("btnUnpair");

  const searchInput = document.getElementById("searchInput");
  const currentSiteSection = document.getElementById("currentSiteSection");
  const currentSiteLabel = document.getElementById("currentSiteLabel");
  const currentSiteList = document.getElementById("currentSiteList");
  const allItemsCaption = document.getElementById("allItemsCaption");
  const allVaultList = document.getElementById("allVaultList");

  const editorTitle = document.getElementById("editorTitle");
  const editId = document.getElementById("editId");
  const editService = document.getElementById("editService");
  const editUsername = document.getElementById("editUsername");
  const editPassword = document.getElementById("editPassword");
  const editDomains = document.getElementById("editDomains");
  const editTotpSecret = document.getElementById("editTotpSecret");
  const editNotes = document.getElementById("editNotes");
  const btnGenPw = document.getElementById("btnGenPw");
  const btnCancelEdit = document.getElementById("btnCancelEdit");
  const btnSaveItem = document.getElementById("btnSaveItem");
  const btnDeleteItem = document.getElementById("btnDeleteItem");

  let currentState = null;
  let activeTab = null;
  let activeHost = "";
  let liveTotpMap = new Map();
  let toastTimer = null;
  let showingPairUpgrade = false;

  function showToast(msg, isError = false) {
    toastBanner.textContent = msg;
    toastBanner.className = isError ? "toast error" : "toast";
    toastBanner.hidden = false;
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      toastBanner.hidden = true;
    }, 3500);
  }

  function showView(which) {
    viewPairing.hidden = which !== "pairing";
    viewVault.hidden = which !== "vault";
    viewEditor.hidden = which !== "editor";
    pairedTopActions.hidden = which === "pairing";
  }

  async function detectActiveTab() {
    try {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      activeTab = tabs && tabs[0] ? tabs[0] : null;
      const url = activeTab?.url || "";
      if (OmniVaultCore.isSafeAutofillUrl(url)) {
        activeHost = OmniVaultCore.extractCleanDomain(url);
      } else {
        activeHost = "";
      }
    } catch (_) {
      activeTab = null;
      activeHost = "";
    }
  }

  async function refreshLiveTotps() {
    if (!currentState || !Array.isArray(currentState.items)) return;
    const nextMap = new Map();
    const now = Date.now();
    for (const it of currentState.items) {
      if (it.totp_secret) {
        try {
          const live = await OmniVaultCore.computeTotpCode(
            it.totp_secret,
            it.totp_digits,
            it.totp_period,
            it.totp_algorithm,
            now
          );
          if (live && live.code) {
            nextMap.set(it.id, live);
          }
        } catch (_) {
          // Ignore malformed secret
        }
      }
    }
    liveTotpMap = nextMap;
  }

  async function copyText(text, label) {
    if (!text) {
      showToast(`Chưa lưu ${label}`, true);
      return;
    }
    try {
      await navigator.clipboard.writeText(text);
      if (currentState && currentState.hasPinLock) {
        await OmniVaultCore.touchAutoLockAlarm();
      }
      showToast(`Đã sao chép ${label}`);
    } catch (_) {
      showToast(`Không thể sao chép ${label}`, true);
    }
  }

  async function fillIntoActiveTab(item) {
    if (!activeTab || !activeTab.id) {
      showToast("Không tìm thấy trang web đang mở", true);
      return;
    }
    try {
      chrome.tabs.sendMessage(
        activeTab.id,
        {
          type: "FILL_LOGIN_NOW",
          username: item.username,
          password: item.password
        },
        async (resp) => {
          if (chrome.runtime.lastError || !resp || !resp.filled) {
            // Fallback via chrome.scripting.executeScript if content script wasn't injected yet
            try {
              await chrome.scripting.executeScript({
                target: { tabId: activeTab.id },
                files: ["content.js"]
              });
              chrome.tabs.sendMessage(
                activeTab.id,
                {
                  type: "FILL_LOGIN_NOW",
                  username: item.username,
                  password: item.password
                },
                (r2) => {
                  if (r2 && r2.filled) {
                    if (r2.mode === "username_only" && item.password) {
                      navigator.clipboard.writeText(item.password || "");
                      showToast(`Đã điền Tài khoản & chép sẵn Mật khẩu cho bước 2!`);
                    } else {
                      showToast(`Đã điền tài khoản '${item.service_name}'`);
                    }
                  } else {
                    showToast("Không thấy ô đăng nhập trên trang — đã sao chép mật khẩu!", false);
                    navigator.clipboard.writeText(item.password || "");
                  }
                }
              );
            } catch (_) {
              await copyText(item.password, "mật khẩu");
            }
          } else {
            if (resp.mode === "username_only" && item.password) {
              await navigator.clipboard.writeText(item.password);
              showToast(`Đã điền Tài khoản & chép sẵn Mật khẩu cho bước 2!`);
            } else {
              // If account also has 2FA, auto-copy 2FA code to clipboard!
              const live = liveTotpMap.get(item.id);
              if (live && live.code) {
                await navigator.clipboard.writeText(live.code);
                showToast("Đã điền mật khẩu & sao chép sẵn mã 2FA");
              } else {
                showToast(`Đã tự động điền '${item.service_name}'`);
              }
            }
          }
        }
      );
    } catch (_) {
      await copyText(item.password, "mật khẩu");
    }
  }

  function buildVaultCard(item, isMatched = false) {
    const card = document.createElement("div");
    card.className = isMatched ? "vault-item matched" : "vault-item";

    const head = document.createElement("div");
    head.className = "item-head";

    const left = document.createElement("div");
    left.style.minWidth = "0";
    left.style.flex = "1";

    const title = document.createElement("div");
    title.className = "item-title";
    const domList = Array.isArray(item.web_domains) ? item.web_domains.filter(Boolean) : [];
    const srvLower = String(item.service_name || "").trim().toLowerCase();
    const domLower = String(domList[0] || "").trim().toLowerCase();
    const prioritizeUser = Boolean(item.username) && (isMatched || (domLower && srvLower === domLower));
    title.textContent = prioritizeUser
      ? item.username
      : item.service_name || "Tài khoản";
    left.appendChild(title);

    const sub = document.createElement("div");
    sub.className = "item-sub";
    sub.textContent = prioritizeUser
      ? item.service_name || domList[0] || "Tài khoản đã lưu"
      : item.username || "Chưa nhập tên đăng nhập";
    left.appendChild(sub);

    if (domList.length > 0) {
      const domEl = document.createElement("div");
      domEl.className = "item-domain";
      domEl.textContent = domList.join(", ");
      left.appendChild(domEl);
    }

    const editBtn = document.createElement("button");
    editBtn.className = "icon-btn";
    editBtn.title = "Sửa tài khoản";
    editBtn.textContent = "✎";
    editBtn.onclick = () => openEditor(item);

    head.appendChild(left);
    head.appendChild(editBtn);
    card.appendChild(head);

    const chipRow = document.createElement("div");
    chipRow.className = "chip-row";

    if (activeHost) {
      const fillBtn = document.createElement("button");
      fillBtn.className = "chip-btn fill";
      fillBtn.textContent = "Điền ngay";
      fillBtn.onclick = () => fillIntoActiveTab(item);
      chipRow.appendChild(fillBtn);
    }

    const copyUserBtn = document.createElement("button");
    copyUserBtn.className = "chip-btn";
    copyUserBtn.textContent = "Chép TK";
    copyUserBtn.onclick = () => copyText(item.username, "tài khoản");
    chipRow.appendChild(copyUserBtn);

    const copyPwBtn = document.createElement("button");
    copyPwBtn.className = "chip-btn";
    copyPwBtn.textContent = "Chép MK";
    copyPwBtn.onclick = () => copyText(item.password, "mật khẩu");
    chipRow.appendChild(copyPwBtn);

    card.appendChild(chipRow);

    const live = liveTotpMap.get(item.id);
    if (live && live.code) {
      const pill = document.createElement("div");
      pill.className = "totp-pill";
      pill.dataset.itemId = item.id;
      pill.dataset.totpCode = live.code;
      pill.title = "Bấm để sao chép mã 2FA";

      const codeSpan = document.createElement("span");
      codeSpan.className = "totp-code";
      const half = Math.ceil(live.code.length / 2);
      codeSpan.textContent = `2FA: ${live.code.slice(0, half)} ${live.code.slice(half)}`;

      const remSpan = document.createElement("span");
      remSpan.className = "totp-rem";
      remSpan.textContent = `${live.remainingSeconds}s`;

      pill.appendChild(codeSpan);
      pill.appendChild(remSpan);
      pill.onclick = () => {
        const curCode = pill.dataset.totpCode || live.code;
        copyText(curCode, "mã 2FA");
      };
      card.appendChild(pill);
    }

    return card;
  }

  let pinSettingsOpen = false;
  let latestUpdateStatus = null;

  const verEl = document.getElementById("extVersionLabel");
  const extUpdateBanner = document.getElementById("extUpdateBanner");
  const extUpdateTitle = document.getElementById("extUpdateTitle");
  const extUpdateDesc = document.getElementById("extUpdateDesc");
  const btnUpdatePrimary = document.getElementById("btnUpdatePrimary");
  const btnReloadUnpacked = document.getElementById("btnReloadUnpacked");

  if (verEl && chrome?.runtime?.getManifest) {
    verEl.textContent = `v${chrome.runtime.getManifest().version} ↻`;
  }

  function sendRuntimeMsg(payload) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(payload, (resp) => {
          void chrome.runtime.lastError;
          resolve(resp || null);
        });
      } catch (_) {
        resolve(null);
      }
    });
  }

  function renderUpdateBanner(status) {
    if (!extUpdateBanner) return;
    if (!status || !status.hasUpdate) {
      extUpdateBanner.hidden = true;
      if (verEl) verEl.classList.remove("has-update");
      return;
    }
    latestUpdateStatus = status;
    const targetVer = status.pendingCrxReloadVersion || status.latestVersion || "";
    if (verEl) verEl.classList.add("has-update");
    if (extUpdateTitle) {
      extUpdateTitle.textContent = targetVer
        ? `🚀 Đã có bản mới v${targetVer} trên GitHub`
        : "🚀 Đã có bản mới trên GitHub";
    }
    if (extUpdateDesc) {
      extUpdateDesc.textContent = status.isCrxManaged
        ? status.changelog || "Bấm nút bên dưới để trình duyệt tải và áp dụng tự động (giữ nguyên 100% mật khẩu)."
        : status.changelog || "Tải bản mới về giải nén đè (hoặc chạy CapNhat-Tu-GitHub.bat) rồi bấm 'Áp dụng ngay'.";
    }
    if (btnUpdatePrimary) {
      btnUpdatePrimary.textContent = status.isCrxManaged
        ? "⚡ Cập nhật tự động ngay"
        : "📥 Tải bản mới (.zip)";
    }
    if (btnReloadUnpacked) {
      btnReloadUnpacked.hidden = Boolean(status.isCrxManaged);
      btnReloadUnpacked.textContent = "🔄 Áp dụng ngay";
    }
    extUpdateBanner.hidden = false;
  }

  async function refreshGitHubUpdateStatus(force = false) {
    const resp = await sendRuntimeMsg({ type: "GET_EXTENSION_UPDATE_STATUS", force });
    if (resp) {
      renderUpdateBanner(resp);
    }
    return resp;
  }

  if (verEl) {
    verEl.onclick = async () => {
      verEl.disabled = true;
      const curVer = chrome?.runtime?.getManifest ? chrome.runtime.getManifest().version : "2.9.8";
      verEl.textContent = `v${curVer} ...`;
      try {
        const resp = await refreshGitHubUpdateStatus(true);
        if (!resp || !resp.ok) {
          showToast(resp?.error || "Không kết nối được GitHub để kiểm tra bản mới", true);
        } else if (resp.hasUpdate) {
          showToast(`Đã có bản mới v${resp.latestVersion} trên GitHub!`);
        } else {
          showToast(`✓ Đang dùng bản mới nhất (v${resp.currentVersion})`);
        }
      } finally {
        verEl.disabled = false;
        verEl.textContent = `v${curVer} ↻`;
      }
    };
  }

  if (btnUpdatePrimary) {
    btnUpdatePrimary.onclick = async () => {
      if (!latestUpdateStatus) {
        await refreshGitHubUpdateStatus(true);
      }
      if (latestUpdateStatus?.isCrxManaged) {
        btnUpdatePrimary.disabled = true;
        btnUpdatePrimary.textContent = "Đang cập nhật...";
        try {
          const res = await sendRuntimeMsg({ type: "APPLY_EXTENSION_UPDATE_NOW" });
          if (res?.reloading) {
            showToast("Đang áp dụng bản cập nhật mới...");
          } else {
            showToast(
              res?.status === "throttled"
                ? "Trình duyệt đang chờ chu kỳ kiểm tra, thử lại sau ít phút hoặc mở trang Release."
                : "Trình duyệt sẽ tự tải bản mới trong nền — kiểm tra lại sau giây lát."
            );
          }
        } finally {
          btnUpdatePrimary.disabled = false;
          btnUpdatePrimary.textContent = "⚡ Cập nhật tự động ngay";
        }
        return;
      }
      const targetUrl = latestUpdateStatus?.unpackedZipUrl || latestUpdateStatus?.releaseHtmlUrl;
      if (targetUrl) {
        chrome.tabs.create({ url: targetUrl, active: true });
        showToast("Đã mở tải bản mới — giải nén đè (hoặc chạy CapNhat-Tu-GitHub.bat) rồi bấm 'Áp dụng ngay'!");
      }
    };
  }

  if (btnReloadUnpacked) {
    btnReloadUnpacked.onclick = async () => {
      btnReloadUnpacked.disabled = true;
      await sendRuntimeMsg({ type: "APPLY_EXTENSION_UPDATE_NOW" });
      showToast("Đang nạp lại tiện ích...");
    };
  }

  const topbar = document.querySelector(".topbar");
  const topActions = document.querySelector(".top-actions");

  const btnPinConfig = document.createElement("button");
  btnPinConfig.className = "icon-btn";
  btnPinConfig.type = "button";
  btnPinConfig.title = "Đặt hoặc đổi PIN khóa phiên";
  btnPinConfig.textContent = "🔑";

  const btnLockNow = document.createElement("button");
  btnLockNow.className = "icon-btn";
  btnLockNow.type = "button";
  btnLockNow.title = "Khóa ngay phiên tiện ích";
  btnLockNow.textContent = "🔒";
  btnLockNow.hidden = true;

  if (topActions) {
    topActions.insertBefore(btnLockNow, topActions.firstChild);
    topActions.insertBefore(btnPinConfig, topActions.firstChild);
  }

  const sessionLockCard = document.createElement("div");
  sessionLockCard.className = "pin-card";
  sessionLockCard.hidden = true;
  sessionLockCard.innerHTML = `
    <h3>🔒 Kho tiện ích đang khóa</h3>
    <p id="sessionLockHint">Nhập mã PIN để mở khóa phiên trình duyệt (tự khóa sau 15 phút không dùng).</p>
    <input id="sessionPinInput" class="pin-input" type="password" inputmode="numeric" autocomplete="current-password" placeholder="Nhập mã PIN mở khóa">
    <div id="sessionPinErr" class="pin-err" hidden></div>
    <button id="btnUnlockSession" class="btn btn-primary full-width" type="button">Mở khóa phiên</button>
    <button id="btnResetVaultLock" class="btn btn-outline full-width" type="button" style="margin-top:8px;color:#b91c1c;border-color:#fca5a5;">Quên PIN? Xóa kho cục bộ &amp; kết nối lại</button>
  `;

  const pinSettingsCard = document.createElement("div");
  pinSettingsCard.className = "pin-card";
  pinSettingsCard.hidden = true;
  pinSettingsCard.innerHTML = `
    <h3 id="pinSettingsTitle">🔑 Khóa phiên bằng mã PIN</h3>
    <p>Bảo vệ dữ liệu Extension trên Chrome bằng AES-256-GCM (PBKDF2 310.000 vòng) — tự động khóa khi đóng trình duyệt hoặc sau 15 phút rảnh.</p>
    <input id="pinOldInput" class="pin-input" type="password" inputmode="numeric" placeholder="Mã PIN hiện tại" hidden>
    <input id="pinNewInput" class="pin-input" type="password" inputmode="numeric" placeholder="Mã PIN mới (4–64 ký tự)">
    <input id="pinConfirmInput" class="pin-input" type="password" inputmode="numeric" placeholder="Nhập lại mã PIN mới">
    <div id="pinConfigErr" class="pin-err" hidden></div>
    <div style="display:flex;gap:8px;">
      <button id="btnSavePin" class="btn btn-primary" style="flex:1;" type="button">Lưu mã PIN</button>
      <button id="btnClosePin" class="btn btn-outline" type="button">Đóng</button>
    </div>
    <button id="btnRemovePin" class="btn btn-danger full-width" type="button" hidden>Gỡ mã PIN khóa phiên</button>
  `;

  if (topbar && topbar.parentElement) {
    topbar.insertAdjacentElement("afterend", pinSettingsCard);
    topbar.insertAdjacentElement("afterend", sessionLockCard);
  }

  const sessionLockHint = sessionLockCard.querySelector("#sessionLockHint");
  const sessionPinInput = sessionLockCard.querySelector("#sessionPinInput");
  const sessionPinErr = sessionLockCard.querySelector("#sessionPinErr");
  const btnUnlockSession = sessionLockCard.querySelector("#btnUnlockSession");
  const btnResetVaultLock = sessionLockCard.querySelector("#btnResetVaultLock");

  const pinSettingsTitle = pinSettingsCard.querySelector("#pinSettingsTitle");
  const pinOldInput = pinSettingsCard.querySelector("#pinOldInput");
  const pinNewInput = pinSettingsCard.querySelector("#pinNewInput");
  const pinConfirmInput = pinSettingsCard.querySelector("#pinConfirmInput");
  const pinConfigErr = pinSettingsCard.querySelector("#pinConfigErr");
  const btnSavePin = pinSettingsCard.querySelector("#btnSavePin");
  const btnClosePin = pinSettingsCard.querySelector("#btnClosePin");
  const btnRemovePin = pinSettingsCard.querySelector("#btnRemovePin");

  function hideAllPopupViews() {
    for (const el of document.querySelectorAll(".view")) {
      el.hidden = true;
    }
  }

  function syncSessionLockButtons() {
    const isLocked = Boolean(currentState && currentState.locked);
    const hasPin = Boolean(currentState && currentState.hasPinLock);
    btnLockNow.hidden = isLocked || !hasPin;
    btnPinConfig.hidden = isLocked;
    btnPinConfig.title = hasPin ? "Đổi hoặc gỡ mã PIN khóa phiên" : "Bật khóa phiên bằng mã PIN";
  }

  async function submitSessionUnlock() {
    sessionPinErr.hidden = true;
    btnUnlockSession.disabled = true;
    btnUnlockSession.textContent = "Đang kiểm tra...";
    try {
      currentState = await OmniVaultCore.unlockExtensionWithPin(sessionPinInput.value);
      sessionPinInput.value = "";
      let flushedCount = 0;
      try {
        const flushRes = await new Promise((resolve) =>
          chrome.runtime.sendMessage({ type: "FLUSH_LOCKED_CAPTURES" }, (resp) => {
            void chrome.runtime.lastError;
            resolve(resp);
          })
        );
        if (flushRes && flushRes.savedCount > 0) {
          flushedCount = flushRes.savedCount;
          currentState = await OmniVaultCore.loadExtensionState();
        }
      } catch (_) {}
      await refreshLiveTotps();
      renderVaultList();
      showToast(
        flushedCount > 0
          ? `Đã mở khóa & tự lưu ${flushedCount} mật khẩu vừa đăng nhập!`
          : "Đã mở khóa OmniVault"
      );
      if (currentState.pairing) {
        OmniVaultCore.syncBrowserVaultBidirectional(false)
          .then(async () => {
            currentState = await OmniVaultCore.loadExtensionState();
            await refreshLiveTotps();
            renderVaultList();
          })
          .catch(() => {});
      }
    } catch (e) {
      sessionPinErr.textContent = String(e.message || e);
      sessionPinErr.hidden = false;
    } finally {
      btnUnlockSession.disabled = false;
      btnUnlockSession.textContent = "Mở khóa phiên";
    }
  }

  btnUnlockSession.onclick = submitSessionUnlock;
  sessionPinInput.addEventListener("keydown", (ev) => {
    if (ev.key === "Enter") {
      ev.preventDefault();
      submitSessionUnlock();
    }
  });

  if (btnResetVaultLock) {
    btnResetVaultLock.onclick = async () => {
      if (
        !window.confirm(
          "Xóa toàn bộ dữ liệu kho cục bộ trên tiện ích và ngắt kết nối hiện tại?\n\nDữ liệu trên điện thoại và đám mây vẫn được giữ nguyên."
        )
      ) {
        return;
      }
      btnResetVaultLock.disabled = true;
      try {
        await new Promise((resolve) =>
          chrome.runtime.sendMessage({ type: "RESET_EXTENSION_VAULT" }, () => {
            void chrome.runtime.lastError;
            resolve();
          })
        );
        await OmniVaultCore.resetExtensionVault();
        currentState = await OmniVaultCore.loadExtensionState();
        renderVaultList();
        showToast("Đã đặt lại kho tiện ích cục bộ");
      } catch (e) {
        showToast(String(e?.message || e), true);
      } finally {
        btnResetVaultLock.disabled = false;
      }
    };
  }

  btnLockNow.onclick = async () => {
    pinSettingsOpen = false;
    try {
      await new Promise((resolve) =>
        chrome.runtime.sendMessage({ type: "CLEAR_EPHEMERAL_CAPTURES" }, () => {
          void chrome.runtime.lastError;
          resolve();
        })
      );
    } catch (_) {}
    await OmniVaultCore.lockExtensionSession();
    currentState = await OmniVaultCore.loadExtensionState();
    renderVaultList();
    showToast("Đã khóa phiên OmniVault");
  };

  btnPinConfig.onclick = () => {
    if (currentState && currentState.locked) return;
    pinSettingsOpen = !pinSettingsOpen;
    if (pinSettingsOpen) {
      const hasPin = Boolean(currentState && currentState.hasPinLock);
      pinSettingsTitle.textContent = hasPin
        ? "🔑 Đổi hoặc gỡ mã PIN khóa phiên"
        : "🔑 Bật khóa phiên bằng mã PIN";
      pinOldInput.hidden = !hasPin;
      pinOldInput.value = "";
      pinNewInput.value = "";
      pinConfirmInput.value = "";
      pinConfigErr.hidden = true;
      btnRemovePin.hidden = !hasPin;
    }
    renderVaultList();
  };

  btnClosePin.onclick = () => {
    pinSettingsOpen = false;
    renderVaultList();
  };

  btnSavePin.onclick = async () => {
    pinConfigErr.hidden = true;
    const p1 = pinNewInput.value.trim();
    const p2 = pinConfirmInput.value.trim();
    if (p1.length < 4 || p1.length > 64) {
      pinConfigErr.textContent = "Mã PIN phải từ 4 đến 64 ký tự.";
      pinConfigErr.hidden = false;
      return;
    }
    if (p1 !== p2) {
      pinConfigErr.textContent = "Hai lần nhập mã PIN mới không khớp.";
      pinConfigErr.hidden = false;
      return;
    }
    btnSavePin.disabled = true;
    try {
      const hasPin = Boolean(currentState && currentState.hasPinLock);
      await OmniVaultCore.setExtensionPin(p1, hasPin ? pinOldInput.value : null);
      currentState = await OmniVaultCore.loadExtensionState();
      pinSettingsOpen = false;
      renderVaultList();
      showToast("Đã bật khóa phiên AES-256 (tự khóa sau 15 phút)");
    } catch (e) {
      pinConfigErr.textContent = String(e.message || e);
      pinConfigErr.hidden = false;
    } finally {
      btnSavePin.disabled = false;
    }
  };

  btnRemovePin.onclick = async () => {
    pinConfigErr.hidden = true;
    btnRemovePin.disabled = true;
    try {
      await OmniVaultCore.clearExtensionPin(pinOldInput.value);
      currentState = await OmniVaultCore.loadExtensionState();
      pinSettingsOpen = false;
      renderVaultList();
      showToast("Đã gỡ mã PIN khóa phiên");
    } catch (e) {
      pinConfigErr.textContent = String(e.message || e);
      pinConfigErr.hidden = false;
    } finally {
      btnRemovePin.disabled = false;
    }
  };

  function renderVaultList() {
    syncSessionLockButtons();
    if (currentState && currentState.locked) {
      pinSettingsOpen = false;
      pinSettingsCard.hidden = true;
      deviceLabel.textContent = currentState.deviceNameHint
        ? `${currentState.deviceNameHint} • Đang khóa`
        : "Đang khóa phiên";
      sessionLockHint.textContent = currentState.deviceNameHint
        ? `Nhập mã PIN để mở khóa thiết bị "${currentState.deviceNameHint}" (tự khóa sau 15 phút không dùng).`
        : "Nhập mã PIN để mở khóa phiên trình duyệt (tự khóa sau 15 phút không dùng).";
      hideAllPopupViews();
      sessionLockCard.hidden = false;
      setTimeout(() => sessionPinInput.focus(), 40);
      return;
    }
    sessionLockCard.hidden = true;

    if (pinSettingsOpen) {
      hideAllPopupViews();
      pinSettingsCard.hidden = false;
      return;
    }
    pinSettingsCard.hidden = true;

    if (!currentState || !currentState.pairing) {
      deviceLabel.textContent = "Chưa kết nối điện thoại";
      if (btnStartLocalMode) btnStartLocalMode.hidden = false;
      if (btnCancelPairUpgrade) btnCancelPairUpgrade.hidden = true;
      showView("pairing");
      return;
    }

    if (showingPairUpgrade && currentState.pairing.localOnly) {
      deviceLabel.textContent = "Kết nối App Điện thoại";
      if (btnStartLocalMode) btnStartLocalMode.hidden = true;
      if (btnCancelPairUpgrade) btnCancelPairUpgrade.hidden = false;
      showView("pairing");
      return;
    }

    if (btnStartLocalMode) btnStartLocalMode.hidden = false;
    if (btnCancelPairUpgrade) btnCancelPairUpgrade.hidden = true;
    if (btnUpgradeToPhoneSync) btnUpgradeToPhoneSync.hidden = !Boolean(currentState.pairing.localOnly);

    deviceLabel.textContent = currentState.pairing.localOnly
      ? "Chế độ: Lưu cục bộ trên trình duyệt"
      : `Thiết bị: ${currentState.pairing.deviceName}`;
    showView("vault");

    const rawQ = (searchInput.value || "").trim();
    const items = currentState.items || [];

    const scoredAll = items
      .map((it) => ({ it, qScore: OmniVaultCore.scoreItemSearchQuery(it, rawQ) }))
      .filter((x) => x.qScore > 0);

    if (rawQ) {
      scoredAll.sort((a, b) => {
        if (b.qScore !== a.qScore) return b.qScore - a.qScore;
        const favDiff = (b.it.is_favorite ? 1 : 0) - (a.it.is_favorite ? 1 : 0);
        if (favDiff !== 0) return favDiff;
        return String(a.it.username || a.it.service_name || "").localeCompare(
          String(b.it.username || b.it.service_name || ""),
          "vi"
        );
      });
    }
    const filtered = scoredAll.map((x) => x.it);

    // Matching current tab domain filters strictly left-to-right on username!
    currentSiteList.innerHTML = "";
    if (activeHost) {
      const matched = items
        .filter((it) => OmniVaultCore.matchesUsernamePrefix(it.username, rawQ))
        .map((it) => ({ it, score: OmniVaultCore.itemMatchesDomain(it, activeHost) }))
        .filter((x) => x.score > 0)
        .sort((a, b) => {
          if (b.score !== a.score) return b.score - a.score;
          const favDiff = (b.it.is_favorite ? 1 : 0) - (a.it.is_favorite ? 1 : 0);
          if (favDiff !== 0) return favDiff;
          const timeDiff = (Number(b.it.last_autofilled_ms) || 0) - (Number(a.it.last_autofilled_ms) || 0);
          if (timeDiff !== 0) return timeDiff;
          return String(a.it.username || "").localeCompare(String(b.it.username || ""), "vi");
        });

      if (matched.length > 0) {
        currentSiteSection.hidden = false;
        currentSiteLabel.textContent = `Khớp với ${activeHost} (${matched.length})`;
        for (const m of matched) {
          currentSiteList.appendChild(buildVaultCard(m.it, true));
        }
      } else {
        currentSiteSection.hidden = true;
      }
    } else {
      currentSiteSection.hidden = true;
    }

    allItemsCaption.textContent = `Tất cả tài khoản (${filtered.length})`;
    allVaultList.innerHTML = "";
    if (filtered.length === 0) {
      const empty = document.createElement("div");
      empty.className = "empty-box";
      empty.textContent = rawQ
        ? "Không tìm thấy tài khoản phù hợp."
        : "Kho mật khẩu đang trống. Bấm ↻ để đồng bộ hoặc ＋ để thêm mới.";
      allVaultList.appendChild(empty);
    } else {
      for (const it of filtered) {
        allVaultList.appendChild(buildVaultCard(it, false));
      }
    }
  }

  function openEditor(existing = null) {
    if (existing) {
      editorTitle.textContent = "Sửa tài khoản";
      editId.value = existing.id;
      editService.value = existing.service_name || "";
      editUsername.value = existing.username || "";
      editPassword.value = existing.password || "";
      editDomains.value = (existing.web_domains || []).join(", ");
      editTotpSecret.value = existing.totp_secret || "";
      editNotes.value = existing.notes || "";
      btnDeleteItem.hidden = false;
    } else {
      editorTitle.textContent = "Thêm tài khoản mới";
      editId.value = "";
      editService.value = activeHost ? OmniVaultCore.prettifyDomainTitle(activeHost) : "";
      editUsername.value = "";
      editPassword.value = "";
      editDomains.value = activeHost || "";
      editTotpSecret.value = "";
      editNotes.value = "";
      btnDeleteItem.hidden = true;
    }
    showView("editor");
  }

  // --- Event Handlers ---
  if (btnStartLocalMode) {
    btnStartLocalMode.onclick = async () => {
      try {
        await OmniVaultCore.enableLocalStandaloneMode();
        currentState = await OmniVaultCore.loadExtensionState();
        showingPairUpgrade = false;
        await refreshLiveTotps();
        renderVaultList();
        showToast("Đã bật Kho mật khẩu cục bộ trên trình duyệt!");
      } catch (e) {
        showToast(String(e.message || e), true);
      }
    };
  }

  if (btnUpgradeToPhoneSync) {
    btnUpgradeToPhoneSync.onclick = () => {
      showingPairUpgrade = true;
      renderVaultList();
    };
  }

  if (btnCancelPairUpgrade) {
    btnCancelPairUpgrade.onclick = () => {
      showingPairUpgrade = false;
      renderVaultList();
    };
  }

  btnConnectCode.onclick = async () => {
    const raw = pairingInput.value.trim();
    if (!raw) {
      showToast("Vui lòng dán Mã Kết Nối (OVB2-... hoặc OVB1-...) từ điện thoại", true);
      return;
    }
    btnConnectCode.disabled = true;
    btnConnectCode.textContent = "Đang kết nối & giải mã...";
    try {
      const pairing = OmniVaultCore.parsePairingCode(raw);
      const st = await OmniVaultCore.loadExtensionState();
      const priorLocalItems =
        st.pairing && st.pairing.localOnly && Array.isArray(st.items) ? [...st.items] : [];
      st.pairing = pairing;
      st.jwt = null;
      st.jwtExpiresAtMs = 0;
      st.items = [];
      st.deletedIds = {};
      showingPairUpgrade = false;
      await OmniVaultCore.saveExtensionState(st);

      let itemCount = 0;
      if (priorLocalItems.length > 0) {
        const merged = await OmniVaultCore.importAndPushAllToServer(priorLocalItems);
        itemCount = merged.totalServerCount;
      } else {
        const syncRes = await OmniVaultCore.syncBrowserVaultBidirectional(false);
        itemCount = syncRes.itemCount;
      }
      currentState = await OmniVaultCore.loadExtensionState();
      await refreshLiveTotps();
      pairingInput.value = "";
      renderVaultList();
      showToast(
        priorLocalItems.length > 0
          ? `Đã kết nối & gộp ${priorLocalItems.length} tài khoản cục bộ (${itemCount} tổng)!`
          : `Đã kết nối! Đồng bộ ${itemCount} tài khoản.`
      );
    } catch (e) {
      showToast(String(e.message || e), true);
    } finally {
      btnConnectCode.disabled = false;
      btnConnectCode.textContent = "Kết nối & Tải mật khẩu";
    }
  };

  btnSyncNow.onclick = async () => {
    if (currentState && currentState.pairing && currentState.pairing.localOnly) {
      showingPairUpgrade = true;
      renderVaultList();
      showToast("Dán Mã Kết Nối OVB2-... (hoặc OVB1-...) để đồng bộ với Điện thoại");
      return;
    }
    btnSyncNow.disabled = true;
    try {
      const res = await OmniVaultCore.syncBrowserVaultBidirectional(false);
      currentState = await OmniVaultCore.loadExtensionState();
      if (currentState.hasPinLock) {
        await OmniVaultCore.touchAutoLockAlarm();
      }
      await refreshLiveTotps();
      renderVaultList();
      showToast(`Đã đồng bộ (${res.itemCount} tài khoản)`);
    } catch (e) {
      showToast(String(e.message || e), true);
    } finally {
      btnSyncNow.disabled = false;
    }
  };

  function openBulkImporterTab() {
    chrome.tabs.create({ url: chrome.runtime.getURL("import.html"), active: true });
  }

  if (btnOpenBulkImportTop) btnOpenBulkImportTop.onclick = openBulkImporterTab;
  if (btnOpenBulkImportVault) btnOpenBulkImportVault.onclick = openBulkImporterTab;
  if (btnOpenBulkImportUnpaired) btnOpenBulkImportUnpaired.onclick = openBulkImporterTab;

  btnOpenAdd.onclick = () => openEditor(null);
  btnCancelEdit.onclick = () => renderVaultList();

  btnGenPw.onclick = () => {
    editPassword.value = OmniVaultCore.generateStrongPassword(18);
  };

  btnSaveItem.onclick = async () => {
    const srv = editService.value.trim();
    const usr = editUsername.value.trim();
    const pw = editPassword.value;
    const doms = editDomains.value
      .split(",")
      .map((s) => OmniVaultCore.extractCleanDomain(s))
      .filter(Boolean);
    const rawSecret = editTotpSecret.value.trim();
    const notes = editNotes.value.trim();

    if (!srv && !pw && doms.length === 0) {
      showToast("Vui lòng nhập Tên dịch vụ hoặc Mật khẩu", true);
      return;
    }

    let secret = null;
    let parsedTotpMeta = null;
    if (rawSecret) {
      if (/^otpauth:\/\//i.test(rawSecret)) {
        try {
          parsedTotpMeta = OmniVaultCore.parseOtpAuthUri(rawSecret);
          secret = parsedTotpMeta.secret;
        } catch (e) {
          showToast(String(e?.message || e), true);
          return;
        }
      } else {
        const cleanB32 = OmniVaultCore.parseTotpSecretField(rawSecret);
        if (!cleanB32) {
          showToast("Mã bí mật 2FA TOTP (Base32) không hợp lệ", true);
          return;
        }
        secret = cleanB32;
      }
    }

    btnSaveItem.disabled = true;
    btnSaveItem.textContent = "Đang lưu...";
    try {
      const st = await OmniVaultCore.loadExtensionState();
      const now = Date.now();
      const id = editId.value || crypto.randomUUID();
      const existing = st.items.find((x) => x.id === id);

      const record = OmniVaultCore.normalizeVaultItem({
        ...(existing || {}),
        id,
        service_name: srv || (doms[0] ? OmniVaultCore.prettifyDomainTitle(doms[0]) : "") || usr || "Tài khoản Web",
        username: usr,
        password: pw,
        totp_secret: secret,
        totp_algorithm: parsedTotpMeta ? parsedTotpMeta.algorithm : existing?.totp_algorithm || "SHA1",
        totp_digits: parsedTotpMeta ? parsedTotpMeta.digits : existing?.totp_digits || 6,
        totp_period: parsedTotpMeta ? parsedTotpMeta.period : existing?.totp_period || 30,
        web_domains: doms,
        notes,
        created_at_ms: existing ? existing.created_at_ms : now,
        updated_at_ms: now
      });

      const idx = st.items.findIndex((x) => x.id === id);
      if (idx >= 0) {
        st.items[idx] = record;
      } else {
        st.items.push(record);
      }
      delete st.deletedIds[id];

      await OmniVaultCore.saveExtensionState(st);
      await OmniVaultCore.syncBrowserVaultBidirectional(true);
      currentState = await OmniVaultCore.loadExtensionState();
      await refreshLiveTotps();
      renderVaultList();
      showToast(`Đã lưu & đồng bộ '${record.service_name}'`);
    } catch (e) {
      showToast(String(e.message || e), true);
    } finally {
      btnSaveItem.disabled = false;
      btnSaveItem.textContent = "Lưu & Đồng bộ";
    }
  };

  btnDeleteItem.onclick = async () => {
    const id = editId.value;
    if (!id) return;
    if (!confirm("Xóa tài khoản này khỏi Trình duyệt và chuyển vào Thùng rác trên Điện thoại?")) {
      return;
    }
    btnDeleteItem.disabled = true;
    try {
      const st = await OmniVaultCore.loadExtensionState();
      st.items = st.items.filter((x) => x.id !== id);
      st.deletedIds[id] = Date.now();
      await OmniVaultCore.saveExtensionState(st);
      await OmniVaultCore.syncBrowserVaultBidirectional(true);
      currentState = await OmniVaultCore.loadExtensionState();
      await refreshLiveTotps();
      renderVaultList();
      showToast("Đã xóa và đồng bộ");
    } catch (e) {
      showToast(String(e.message || e), true);
    } finally {
      btnDeleteItem.disabled = false;
    }
  };

  btnUnpair.onclick = async () => {
    if (!confirm("Ngắt kết nối kho mật khẩu trên trình duyệt này? (Dữ liệu trên điện thoại vẫn giữ nguyên)")) {
      return;
    }
    await OmniVaultCore.saveExtensionState({
      pairing: null,
      jwt: null,
      jwtExpiresAtMs: 0,
      items: [],
      deletedIds: {},
      lastSyncedAtMs: 0
    });
    currentState = await OmniVaultCore.loadExtensionState();
    renderVaultList();
    showToast("Đã ngắt kết nối trình duyệt");
  };

  searchInput.addEventListener("input", () => renderVaultList());

  function updateTotpPillsInPlace() {
    const pills = document.querySelectorAll(".totp-pill[data-item-id]");
    for (const pill of pills) {
      const id = pill.dataset.itemId;
      const live = id ? liveTotpMap.get(id) : null;
      if (!live || !live.code) continue;
      pill.dataset.totpCode = live.code;
      const codeEl = pill.querySelector(".totp-code");
      const remEl = pill.querySelector(".totp-rem");
      if (codeEl) {
        const half = Math.ceil(live.code.length / 2);
        codeEl.textContent = `2FA: ${live.code.slice(0, half)} ${live.code.slice(half)}`;
      }
      if (remEl) {
        remEl.textContent = `${live.remainingSeconds}s`;
      }
    }
  }

  // Tick every 1s to update live 2FA countdown in-place (zero DOM wipe / zero dropped clicks)
  setInterval(async () => {
    if (!viewVault.hidden && currentState && !currentState.locked && currentState.pairing) {
      await refreshLiveTotps();
      updateTotpPillsInPlace();
    }
  }, 1000);

  // Initial load + background refresh
  (async () => {
    await detectActiveTab();
    currentState = await OmniVaultCore.loadExtensionState();
    await refreshLiveTotps();
    renderVaultList();
    refreshGitHubUpdateStatus(false).catch(() => {});

    if (!currentState.locked && currentState.pairing) {
      try {
        await OmniVaultCore.syncBrowserVaultBidirectional(false);
        currentState = await OmniVaultCore.loadExtensionState();
        await refreshLiveTotps();
        renderVaultList();
      } catch (_) {
        // Offline cached vault remains usable
      }
    }
  })();
})();
