(() => {
  const viewPairing = document.getElementById("viewPairing");
  const viewVault = document.getElementById("viewVault");
  const viewEditor = document.getElementById("viewEditor");
  const pairedBottomActions = document.getElementById("pairedBottomActions");
  const popupScrollArea = document.getElementById("popupScrollArea");
  const deviceLabel = document.getElementById("deviceLabel");
  const toastBanner = document.getElementById("toastBanner");

  const pairingInput = document.getElementById("pairingInput");
  const btnConnectCode = document.getElementById("btnConnectCode");
  const btnStartLocalMode = document.getElementById("btnStartLocalMode");
  const btnCancelPairUpgrade = document.getElementById("btnCancelPairUpgrade");
  const btnUpgradeToPhoneSync = document.getElementById("btnUpgradeToPhoneSync");
  const btnOpenBulkImportTop = document.getElementById("btnOpenBulkImportTop");
  const btnOpenBulkImportVault = document.getElementById("btnOpenBulkImportVault");
  const btnOpenBulkImportUnpaired = document.getElementById("btnOpenBulkImportUnpaired");
  const btnSyncNow = document.getElementById("btnSyncNow");
  const btnOpenAdd = document.getElementById("btnOpenAdd");
  const btnUnpair = document.getElementById("btnUnpair");

  const searchInput = document.getElementById("searchInput");
  const currentSiteSection = document.getElementById("currentSiteSection");
  const currentSiteLabel = document.getElementById("currentSiteLabel");
  const currentSiteList = document.getElementById("currentSiteList");
  const allItemsCaption = document.getElementById("allItemsCaption");
  const allVaultList = document.getElementById("allVaultList");

  const editorTitle = document.getElementById("editorTitle");
  const editId = document.getElementById("editId");
  const editService = document.getElementById("editService");
  const editUsername = document.getElementById("editUsername");
  const editPassword = document.getElementById("editPassword");
  const editDomains = document.getElementById("editDomains");
  const editTotpSecret = document.getElementById("editTotpSecret");
  const editNotes = document.getElementById("editNotes");
  const btnGenPw = document.getElementById("btnGenPw");
  const btnCancelEdit = document.getElementById("btnCancelEdit");
  const btnSaveItem = document.getElementById("btnSaveItem");
  const btnDeleteItem = document.getElementById("btnDeleteItem");

  let currentState = null;
  let activeTab = null;
  let activeHost = "";
  let indexedItems = [];
  let itemsById = new Map();
  let domainIndex = new Map();
  let liveTotpMap = new Map();
  let lastStepByPeriod = new Map();
  let toastTimer = null;
  let showingPairUpgrade = false;

  function clearSensitivePopupCaches() {
    indexedItems = [];
    itemsById.clear();
    domainIndex = new Map();
    liveTotpMap.clear();
    lastStepByPeriod.clear();
    if (typeof OmniVaultCore.clearTotpKeyCache === "function") {
      OmniVaultCore.clearTotpKeyCache();
    }
  }

  function setVaultState(nextState) {
    currentState = nextState;
    if (!currentState || currentState.locked || !Array.isArray(currentState.items)) {
      clearSensitivePopupCaches();
      return;
    }
    const items = currentState.items;
    indexedItems = new Array(items.length);
    itemsById = new Map();
    for (let i = 0; i < items.length; i++) {
      const it = items[i];
      indexedItems[i] = OmniVaultCore.buildItemSearchIndex(it);
      itemsById.set(it.id, it);
    }
    domainIndex = OmniVaultCore.buildVaultDomainIndex(items).byDomain;
    // Prune stale TOTP cache entries for removed items or changed secrets
    for (const [id, entry] of Array.from(liveTotpMap.entries())) {
      const it = itemsById.get(id);
      if (!it || !it.totp_secret || entry.secret !== it.totp_secret) {
        liveTotpMap.delete(id);
      }
    }
  }

  function showToast(msg, isError = false) {
    toastBanner.textContent = msg;
    toastBanner.className = isError ? "toast error" : "toast";
    toastBanner.hidden = false;
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      toastBanner.hidden = true;
    }, 3500);
  }

  function showView(which) {
    viewPairing.hidden = which !== "pairing";
    viewVault.hidden = which !== "vault";
    viewEditor.hidden = which !== "editor";
    if (pairedBottomActions) {
      pairedBottomActions.hidden = which !== "vault";
    }
  }

  async function detectActiveTab() {
    try {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      activeTab = tabs && tabs[0] ? tabs[0] : null;
      const url = activeTab?.url || "";
      if (OmniVaultCore.isSafeAutofillUrl(url)) {
        activeHost = OmniVaultCore.extractCleanDomain(url);
      } else {
        activeHost = "";
      }
    } catch (_) {
      activeTab = null;
      activeHost = "";
    }
  }

  function formatTotpDisplay(code) {
    const s = String(code || "");
    const half = Math.ceil(s.length / 2);
    return `2FA: ${s.slice(0, half)} ${s.slice(half)}`;
  }

  async function getOrComputeTotpForItem(item, nowMs = Date.now()) {
    if (!item || !item.totp_secret) return null;
    const { step, remainingSeconds, period } = OmniVaultCore.computeTotpStep(item.totp_period, nowMs);
    const cached = liveTotpMap.get(item.id);
    if (cached && cached.step === step && cached.secret === item.totp_secret && cached.code) {
      cached.remainingSeconds = remainingSeconds;
      return cached;
    }
    try {
      const live = await OmniVaultCore.computeTotpCode(
        item.totp_secret,
        item.totp_digits,
        period,
        item.totp_algorithm,
        nowMs
      );
      if (live && live.code) {
        const entry = {
          code: live.code,
          remainingSeconds: live.remainingSeconds,
          period: live.period,
          step: live.step,
          secret: item.totp_secret
        };
        liveTotpMap.set(item.id, entry);
        lastStepByPeriod.set(period, live.step);
        return entry;
      }
    } catch (_) {
      // Ignore malformed secret
    }
    return null;
  }

  // Smart TOTP Scheduler: runs WebCrypto HMAC ONLY for currently mounted/visible cards
  // and ONLY when their TOTP step rolls over (29/30 seconds update ONLY countdown integer!)
  async function updateVisibleTotpPills(forceRecompute = false) {
    if (!currentState || currentState.locked || viewVault.hidden) return;
    const pills = document.querySelectorAll(".totp-pill[data-item-id]");
    if (pills.length === 0) return;

    const nowMs = Date.now();
    const pendingJobs = [];

    for (let i = 0; i < pills.length; i++) {
      const pill = pills[i];
      const id = pill.dataset.itemId;
      const item = id ? itemsById.get(id) : null;
      if (!item || !item.totp_secret) continue;

      const { step, remainingSeconds, period } = OmniVaultCore.computeTotpStep(item.totp_period, nowMs);
      const cached = liveTotpMap.get(id);
      const remEl = pill.querySelector(".totp-rem");

      if (!forceRecompute && cached && cached.step === step && cached.secret === item.totp_secret && cached.code) {
        cached.remainingSeconds = remainingSeconds;
        if (pill.dataset.totpCode !== cached.code) {
          pill.dataset.totpCode = cached.code;
          const codeEl = pill.querySelector(".totp-code");
          if (codeEl) codeEl.textContent = formatTotpDisplay(cached.code);
        }
        if (remEl) remEl.textContent = `${remainingSeconds}s`;
        continue;
      }

      if (remEl) remEl.textContent = `${remainingSeconds}s`;
      pendingJobs.push(
        getOrComputeTotpForItem(item, nowMs).then((live) => {
          if (!live || !live.code || !pill.isConnected) return;
          pill.dataset.totpCode = live.code;
          const codeEl = pill.querySelector(".totp-code");
          if (codeEl) codeEl.textContent = formatTotpDisplay(live.code);
          if (remEl) remEl.textContent = `${live.remainingSeconds}s`;
        })
      );
    }

    if (pendingJobs.length > 0) {
      await Promise.all(pendingJobs);
    }
  }

  async function copyText(text, label) {
    if (!text) {
      showToast(`Chưa lưu ${label}`, true);
      return false;
    }
    try {
      await navigator.clipboard.writeText(text);
      if (currentState && currentState.hasPinLock) {
        await OmniVaultCore.touchAutoLockAlarm();
      }
      showToast(`Đã sao chép ${label}`);
      return true;
    } catch (_) {
      showToast(`Không thể sao chép ${label}`, true);
      return false;
    }
  }

  async function fillIntoActiveTab(item) {
    if (!currentState || currentState.locked) {
      showToast("Kho OmniVault đang khóa. Vui lòng nhập PIN trước.", true);
      return;
    }
    let liveTab = null;
    try {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      liveTab = tabs && tabs[0] ? tabs[0] : null;
    } catch (_) {
      liveTab = null;
    }
    if (!liveTab || !liveTab.id) {
      showToast("Không tìm thấy trang web đang mở", true);
      return;
    }
    const liveUrl = liveTab.url || "";
    if (!OmniVaultCore.isSafeAutofillUrl(liveUrl)) {
      activeTab = liveTab;
      activeHost = "";
      renderVaultList();
      showToast("Trang hiện tại không phải HTTPS an toàn để tự động điền", true);
      return;
    }
    const liveHost = OmniVaultCore.extractCleanDomain(liveUrl);
    if (!liveHost || OmniVaultCore.itemMatchesDomain(item, liveHost) < 2) {
      activeTab = liveTab;
      activeHost = liveHost;
      renderVaultList();
      showToast("Tên miền trang hiện tại không khớp với tài khoản này!", true);
      return;
    }
    activeTab = liveTab;
    activeHost = liveHost;

    if (currentState.hasPinLock) {
      await OmniVaultCore.touchAutoLockAlarm();
    }

    try {
      chrome.tabs.sendMessage(
        activeTab.id,
        {
          type: "FILL_LOGIN_NOW",
          username: item.username,
          password: item.password
        },
        async (resp) => {
          if (chrome.runtime.lastError || !resp || !resp.filled) {
            // Fallback via chrome.scripting.executeScript (top frame only: allFrames: false)
            try {
              await chrome.scripting.executeScript({
                target: { tabId: activeTab.id, allFrames: false },
                files: ["content.js"]
              });
              chrome.tabs.sendMessage(
                activeTab.id,
                {
                  type: "FILL_LOGIN_NOW",
                  username: item.username,
                  password: item.password
                },
                (r2) => {
                  if (r2 && r2.filled) {
                    if (r2.mode === "username_only" && item.password) {
                      navigator.clipboard.writeText(item.password || "");
                      showToast(`Đã điền Tài khoản & chép sẵn Mật khẩu cho bước 2!`);
                    } else {
                      showToast(`Đã điền tài khoản '${item.service_name}'`);
                    }
                  } else {
                    showToast("Không thấy ô đăng nhập trên trang — đã sao chép mật khẩu!", false);
                    navigator.clipboard.writeText(item.password || "");
                  }
                }
              );
            } catch (_) {
              await copyText(item.password, "mật khẩu");
            }
          } else {
            if (resp.mode === "username_only" && item.password) {
              await navigator.clipboard.writeText(item.password);
              showToast(`Đã điền Tài khoản & chép sẵn Mật khẩu cho bước 2!`);
            } else {
              // If account also has 2FA, auto-copy 2FA code to clipboard (compute on-demand if needed)!
              const live = item.totp_secret ? await getOrComputeTotpForItem(item) : null;
              if (live && live.code) {
                await navigator.clipboard.writeText(live.code);
                showToast("Đã điền mật khẩu & sao chép sẵn mã 2FA");
              } else {
                showToast(`Đã tự động điền '${item.service_name}'`);
              }
            }
          }
        }
      );
    } catch (_) {
      await copyText(item.password, "mật khẩu");
    }
  }

  const COPY_ICON_SVG =
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' +
    '<rect x="9" y="9" width="11" height="11" rx="2.2"></rect>' +
    '<path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>' +
    "</svg>";

  const CHECK_ICON_SVG =
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' +
    '<polyline points="20 6 9 17 4 12"></polyline>' +
    "</svg>";

  // Parse SVG icons ONCE into <template> elements and clone nodes instead of re-parsing HTML 2*N times
  const copyIconTemplate = document.createElement("template");
  copyIconTemplate.innerHTML = COPY_ICON_SVG;
  const checkIconTemplate = document.createElement("template");
  checkIconTemplate.innerHTML = CHECK_ICON_SVG;

  function cloneCopyIconNode() {
    return copyIconTemplate.content.firstElementChild.cloneNode(true);
  }

  function cloneCheckIconNode() {
    return checkIconTemplate.content.firstElementChild.cloneNode(true);
  }

  function buildCredentialRow({ value, emptyText, isSecret, copyTitle, copyLabel }) {
    const row = document.createElement("div");
    row.className = "cred-row";

    const copyBtn = document.createElement("button");
    copyBtn.type = "button";
    copyBtn.className = "copy-icon-btn";
    copyBtn.title = copyTitle;
    copyBtn.setAttribute("aria-label", copyTitle);
    copyBtn.appendChild(cloneCopyIconNode());
    let feedbackTimer = null;
    copyBtn.onclick = async () => {
      const ok = await copyText(value, copyLabel);
      if (ok) {
        copyBtn.replaceChildren(cloneCheckIconNode());
        copyBtn.classList.add("copied");
        if (feedbackTimer) clearTimeout(feedbackTimer);
        feedbackTimer = setTimeout(() => {
          copyBtn.replaceChildren(cloneCopyIconNode());
          copyBtn.classList.remove("copied");
        }, 900);
      }
    };

    const valEl = document.createElement("span");
    const hasVal = Boolean(value);
    valEl.className = "cred-value" + (isSecret ? " cred-secret" : "") + (hasVal ? "" : " cred-empty");
    if (hasVal) {
      valEl.textContent = isSecret ? "••••••••••••" : value;
      if (!isSecret) {
        valEl.title = value;
      }
    } else {
      valEl.textContent = emptyText;
    }

    row.appendChild(copyBtn);
    row.appendChild(valEl);
    return row;
  }

  function buildVaultCard(item, isMatched = false) {
    const card = document.createElement("div");
    card.className = isMatched ? "vault-item matched" : "vault-item";

    const head = document.createElement("div");
    head.className = "item-head";

    const left = document.createElement("div");
    left.style.minWidth = "0";
    left.style.flex = "1";

    const domList = Array.isArray(item.web_domains) ? item.web_domains.filter(Boolean) : [];
    const serviceTitle = String(item.service_name || "").trim() || domList[0] || "Tài khoản";

    const title = document.createElement("div");
    title.className = "item-title";
    title.textContent = serviceTitle;
    left.appendChild(title);

    const hasExtraDomains =
      domList.length > 1 ||
      (domList.length === 1 && domList[0].trim().toLowerCase() !== serviceTitle.toLowerCase());
    if (hasExtraDomains) {
      const domEl = document.createElement("div");
      domEl.className = "item-domain";
      domEl.textContent = domList.join(", ");
      left.appendChild(domEl);
    }

    const headActions = document.createElement("div");
    headActions.className = "item-head-actions";

    const canFillActiveTab = Boolean(
      activeHost && OmniVaultCore.itemMatchesDomain(item, activeHost) >= 2
    );
    if (canFillActiveTab) {
      const fillBtn = document.createElement("button");
      fillBtn.type = "button";
      fillBtn.className = "chip-btn fill chip-btn-compact";
      fillBtn.textContent = "Điền";
      fillBtn.title = "Điền tự động vào trang đang mở";
      fillBtn.onclick = () => fillIntoActiveTab(item);
      headActions.appendChild(fillBtn);
    }

    const editBtn = document.createElement("button");
    editBtn.type = "button";
    editBtn.className = "icon-btn";
    editBtn.title = "Sửa tài khoản";
    editBtn.textContent = "✎";
    editBtn.onclick = () => openEditor(item);
    headActions.appendChild(editBtn);

    head.appendChild(left);
    head.appendChild(headActions);
    card.appendChild(head);

    const credRows = document.createElement("div");
    credRows.className = "cred-rows";
    credRows.appendChild(
      buildCredentialRow({
        value: item.username || "",
        emptyText: "Chưa nhập tên đăng nhập",
        isSecret: false,
        copyTitle: "Sao chép tài khoản",
        copyLabel: "tài khoản"
      })
    );
    credRows.appendChild(
      buildCredentialRow({
        value: item.password || "",
        emptyText: "Chưa lưu mật khẩu",
        isSecret: true,
        copyTitle: "Sao chép mật khẩu",
        copyLabel: "mật khẩu"
      })
    );
    card.appendChild(credRows);

    if (item.totp_secret) {
      const nowMs = Date.now();
      const { step, remainingSeconds } = OmniVaultCore.computeTotpStep(item.totp_period, nowMs);
      const cached = liveTotpMap.get(item.id);
      const hasValidCode = Boolean(
        cached && cached.step === step && cached.secret === item.totp_secret && cached.code
      );

      const pill = document.createElement("div");
      pill.className = "totp-pill";
      pill.dataset.itemId = item.id;
      pill.dataset.totpCode = hasValidCode ? cached.code : "";
      pill.title = "Bấm để sao chép mã 2FA";

      const codeSpan = document.createElement("span");
      codeSpan.className = "totp-code";
      codeSpan.textContent = hasValidCode ? formatTotpDisplay(cached.code) : "2FA: ••• •••";

      const remSpan = document.createElement("span");
      remSpan.className = "totp-rem";
      remSpan.textContent = `${remainingSeconds}s`;

      pill.appendChild(codeSpan);
      pill.appendChild(remSpan);
      pill.onclick = async () => {
        let curCode = pill.dataset.totpCode;
        if (!curCode) {
          const live = await getOrComputeTotpForItem(item);
          curCode = live && live.code ? live.code : "";
          if (curCode) {
            pill.dataset.totpCode = curCode;
            codeSpan.textContent = formatTotpDisplay(curCode);
          }
        }
        copyText(curCode, "mã 2FA");
      };
      card.appendChild(pill);
    }

    return card;
  }

  let pinSettingsOpen = false;
  let latestUpdateStatus = null;
  let updateBannerManualOpen = false;
  let inlineUpdateRunning = false;

  const verEl = document.getElementById("extVersionLabel");
  const extUpdateBanner = document.getElementById("extUpdateBanner");
  const extUpdateTitle = document.getElementById("extUpdateTitle");
  const extUpdateDesc = document.getElementById("extUpdateDesc");
  const btnUpdatePrimary = document.getElementById("btnUpdatePrimary");
  const btnReloadUnpacked = document.getElementById("btnReloadUnpacked");
  const btnManualZipDownload = document.getElementById("btnManualZipDownload");
  const btnDismissUpdateBanner = document.getElementById("btnDismissUpdateBanner");

  if (verEl && chrome?.runtime?.getManifest) {
    verEl.textContent = `v${chrome.runtime.getManifest().version} ↻`;
  }

  function sendRuntimeMsg(payload) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(payload, (resp) => {
          void chrome.runtime.lastError;
          resolve(resp || null);
        });
      } catch (_) {
        resolve(null);
      }
    });
  }

  async function renderUpdateBanner(status, showUpToDateCard = false) {
    if (!extUpdateBanner) return;
    if (status) {
      latestUpdateStatus = status;
    }
    if (!status || !status.hasUpdate) {
      if (verEl) verEl.classList.remove("has-update");
      if (!showUpToDateCard) {
        updateBannerManualOpen = false;
        extUpdateBanner.hidden = true;
        extUpdateBanner.classList.remove("up-to-date");
        return;
      }
      updateBannerManualOpen = true;
      extUpdateBanner.classList.add("up-to-date");
      const curVer = status?.currentVersion || (chrome?.runtime?.getManifest ? chrome.runtime.getManifest().version : "");
      if (extUpdateTitle) {
        extUpdateTitle.textContent = `✓ Đang dùng bản mới nhất (v${curVer})`;
      }
      let folderHint = "Cập nhật 1 chạm trực tiếp ngay trên giao diện tiện ích (xác thực SHA-256 & RSA-2048).";
      if (!status?.isCrxManaged && globalThis.OmniVaultUpdater?.isFileSystemAccessSupported?.()) {
        const savedDir = await globalThis.OmniVaultUpdater.getStoredDirectoryHandle().catch(() => null);
        folderHint = savedDir
          ? `Đã liên kết thư mục "${savedDir.name}" — sẵn sàng cập nhật 1 chạm khi có bản mới.`
          : "Mở Trình cập nhật để liên kết sẵn thư mục tiện ích (1 lần duy nhất) cho cập nhật 1 chạm.";
      }
      if (extUpdateDesc) extUpdateDesc.textContent = folderHint;
      if (btnUpdatePrimary) {
        btnUpdatePrimary.textContent = "⚙️ Trình cập nhật";
        btnUpdatePrimary.hidden = false;
      }
      if (btnReloadUnpacked) btnReloadUnpacked.hidden = true;
      if (btnManualZipDownload) btnManualZipDownload.hidden = true;
      if (btnDismissUpdateBanner) btnDismissUpdateBanner.hidden = false;
      extUpdateBanner.hidden = false;
      return;
    }

    updateBannerManualOpen = false;
    extUpdateBanner.classList.remove("up-to-date");
    const targetVer = status.pendingCrxReloadVersion || status.latestVersion || "";
    if (verEl) verEl.classList.add("has-update");
    if (extUpdateTitle) {
      extUpdateTitle.textContent = targetVer
        ? `🚀 Đã có bản mới v${targetVer} trên GitHub`
        : "🚀 Đã có bản mới trên GitHub";
    }
    if (extUpdateDesc) {
      extUpdateDesc.textContent = status.isCrxManaged
        ? status.changelog || "Bấm nút bên dưới để trình duyệt tải và áp dụng tự động (giữ nguyên 100% mật khẩu)."
        : status.changelog || "Bấm '⚡ Cập nhật ngay' để tự tải từ GitHub, xác thực chữ ký số RSA-2048 & tự nạp lại (giữ nguyên 100% mật khẩu).";
    }
    if (btnUpdatePrimary) {
      btnUpdatePrimary.textContent = status.isCrxManaged
        ? "⚡ Cập nhật tự động ngay"
        : "⚡ Cập nhật ngay";
      btnUpdatePrimary.hidden = false;
    }
    if (btnReloadUnpacked) {
      btnReloadUnpacked.hidden = Boolean(status.isCrxManaged);
      btnReloadUnpacked.textContent = "🔄 Nạp lại";
    }
    if (btnManualZipDownload) {
      btnManualZipDownload.hidden = Boolean(status.isCrxManaged);
    }
    if (btnDismissUpdateBanner) {
      btnDismissUpdateBanner.hidden = true;
    }
    extUpdateBanner.hidden = false;
  }

  async function refreshGitHubUpdateStatus(force = false, showUpToDateCard = false) {
    const resp = await sendRuntimeMsg({ type: "GET_EXTENSION_UPDATE_STATUS", force });
    if (resp) {
      await renderUpdateBanner(resp, showUpToDateCard);
    }
    return resp;
  }

  if (verEl) {
    verEl.onclick = async () => {
      verEl.disabled = true;
      const curVer = chrome?.runtime?.getManifest ? chrome.runtime.getManifest().version : "3.1.3";
      verEl.textContent = `v${curVer} ...`;
      try {
        const resp = await refreshGitHubUpdateStatus(true, true);
        if (!resp || !resp.ok) {
          showToast(resp?.error || "Không kết nối được GitHub để kiểm tra bản mới", true);
        } else if (resp.hasUpdate) {
          showToast(`Đã có bản mới v${resp.latestVersion} — bấm '⚡ Cập nhật ngay'!`);
        } else {
          showToast(`✓ Đang dùng bản mới nhất (v${resp.currentVersion})`);
        }
      } finally {
        verEl.disabled = false;
        verEl.textContent = `v${curVer} ↻`;
      }
    };
  }

  if (btnDismissUpdateBanner) {
    btnDismissUpdateBanner.onclick = () => {
      updateBannerManualOpen = false;
      if (extUpdateBanner) {
        extUpdateBanner.hidden = true;
        extUpdateBanner.classList.remove("up-to-date");
      }
    };
  }

  if (btnManualZipDownload) {
    btnManualZipDownload.onclick = () => {
      const candidateUrl =
        latestUpdateStatus?.unpackedZipUrl ||
        latestUpdateStatus?.unpackedLatestUrl ||
        latestUpdateStatus?.releaseHtmlUrl;
      const targetUrl = OmniVaultCore.isAllowedGitHubUpdateUrl(candidateUrl)
        ? candidateUrl
        : "https://github.com/Minhtuan0506/omnivault-extension/releases/latest";
      chrome.tabs.create({ url: targetUrl, active: true });
      showToast("Đã mở tải tệp .zip thủ công từ GitHub!");
    };
  }

  if (btnUpdatePrimary) {
    btnUpdatePrimary.onclick = async () => {
      if (inlineUpdateRunning) return;

      // When user manually opened up-to-date panel -> open full Updater Center window
      if (updateBannerManualOpen && !latestUpdateStatus?.hasUpdate) {
        await sendRuntimeMsg({ type: "OPEN_EXTENSION_UPDATER", autoStart: false });
        return;
      }

      if (!latestUpdateStatus) {
        await refreshGitHubUpdateStatus(true);
      }
      if (latestUpdateStatus?.isCrxManaged) {
        btnUpdatePrimary.disabled = true;
        btnUpdatePrimary.textContent = "Đang cập nhật...";
        try {
          const res = await sendRuntimeMsg({ type: "APPLY_EXTENSION_UPDATE_NOW" });
          if (res?.reloading) {
            showToast("Đang áp dụng bản cập nhật mới...");
          } else {
            showToast(
              res?.status === "throttled"
                ? "Trình duyệt đang chờ chu kỳ kiểm tra, thử lại sau ít phút hoặc mở trang Release."
                : "Trình duyệt sẽ tự tải bản mới trong nền — kiểm tra lại sau giây lát."
            );
          }
        } finally {
          btnUpdatePrimary.disabled = false;
          btnUpdatePrimary.textContent = "⚡ Cập nhật tự động ngay";
        }
        return;
      }

      // Unpacked 1-click in-extension self-update:
      // 1) If folder handle is already stored AND readwrite permission is already granted in this session,
      //    execute download -> SHA-256 + RSA-2048 verify -> extract -> write -> reload RIGHT INSIDE POPUP!
      // 2) Otherwise open the dedicated updater.html window (so OS folder/permission dialogs never close popup).
      const updater = globalThis.OmniVaultUpdater;
      const manifestKey = chrome?.runtime?.getManifest ? String(chrome.runtime.getManifest().key || "").trim() : "";
      if (updater?.isFileSystemAccessSupported?.() && manifestKey) {
        const savedDir = await updater.getStoredDirectoryHandle().catch(() => null);
        const perm = savedDir ? await updater.queryDirectoryPermission(savedDir).catch(() => "prompt") : "prompt";
        if (savedDir && perm === "granted") {
          inlineUpdateRunning = true;
          btnUpdatePrimary.disabled = true;
          if (btnReloadUnpacked) btnReloadUnpacked.disabled = true;
          if (btnManualZipDownload) btnManualZipDownload.disabled = true;
          btnUpdatePrimary.textContent = "⏳ Đang cập nhật...";
          try {
            const res = await updater.performSelfUpdate({
              dirHandle: savedDir,
              updateInfo: latestUpdateStatus,
              pinnedSpkiB64: manifestKey,
              onProgress: (ev) => {
                if (!extUpdateDesc) return;
                if (ev.stage === "writing" && ev.total) {
                  extUpdateDesc.textContent = `Đang ghi tệp an toàn (${ev.current}/${ev.total})...`;
                } else if (ev.message) {
                  extUpdateDesc.textContent = ev.message;
                }
              }
            });
            showToast(`✓ Đã cập nhật lên v${res.version} — đang nạp lại tiện ích!`);
            await sendRuntimeMsg({ type: "APPLY_EXTENSION_UPDATE_NOW" });
            return;
          } catch (err) {
            showToast(String(err?.message || err), true);
            await sendRuntimeMsg({ type: "OPEN_EXTENSION_UPDATER", autoStart: false });
            return;
          } finally {
            inlineUpdateRunning = false;
            btnUpdatePrimary.disabled = false;
            if (btnReloadUnpacked) btnReloadUnpacked.disabled = false;
            if (btnManualZipDownload) btnManualZipDownload.disabled = false;
            btnUpdatePrimary.textContent = "⚡ Cập nhật ngay";
          }
        }
      }

      // Open dedicated updater window for folder selection / 1-click permission confirmation
      await sendRuntimeMsg({ type: "OPEN_EXTENSION_UPDATER", autoStart: true });
    };
  }

  if (btnReloadUnpacked) {
    btnReloadUnpacked.onclick = async () => {
      btnReloadUnpacked.disabled = true;
      await sendRuntimeMsg({ type: "APPLY_EXTENSION_UPDATE_NOW" });
      showToast("Đang nạp lại tiện ích...");
    };
  }

  const btnPinConfig = document.getElementById("btnPinConfig");
  const btnLockNow = document.getElementById("btnLockNow");

  const sessionLockCard = document.createElement("div");
  sessionLockCard.className = "pin-card";
  sessionLockCard.hidden = true;
  sessionLockCard.innerHTML = `
    <h3>🔒 Kho tiện ích đang khóa</h3>
    <p id="sessionLockHint">Nhập mã PIN để mở khóa phiên trình duyệt (tự khóa sau 15 phút không dùng).</p>
    <input id="sessionPinInput" class="pin-input" type="password" inputmode="numeric" autocomplete="current-password" placeholder="Nhập mã PIN mở khóa">
    <div id="sessionPinErr" class="pin-err" hidden></div>
    <button id="btnUnlockSession" class="btn btn-primary full-width" type="button">Mở khóa phiên</button>
    <button id="btnResetVaultLock" class="btn btn-outline full-width" type="button" style="margin-top:8px;color:#b91c1c;border-color:#fca5a5;">Quên PIN? Xóa kho cục bộ &amp; kết nối lại</button>
  `;

  const pinSettingsCard = document.createElement("div");
  pinSettingsCard.className = "pin-card";
  pinSettingsCard.hidden = true;
  pinSettingsCard.innerHTML = `
    <h3 id="pinSettingsTitle">🔑 Khóa phiên bằng mã PIN</h3>
    <p>Bảo vệ dữ liệu Extension trên Chrome bằng AES-256-GCM (PBKDF2 600.000 vòng) — tự động khóa khi đóng trình duyệt hoặc sau 15 phút rảnh.</p>
    <input id="pinOldInput" class="pin-input" type="password" inputmode="numeric" placeholder="Mã PIN hiện tại" hidden>
    <input id="pinNewInput" class="pin-input" type="password" inputmode="numeric" placeholder="Mã PIN mới (4–64 ký tự)">
    <input id="pinConfirmInput" class="pin-input" type="password" inputmode="numeric" placeholder="Nhập lại mã PIN mới">
    <div id="pinConfigErr" class="pin-err" hidden></div>
    <div style="display:flex;gap:8px;">
      <button id="btnSavePin" class="btn btn-primary" style="flex:1;" type="button">Lưu mã PIN</button>
      <button id="btnClosePin" class="btn btn-outline" type="button">Đóng</button>
    </div>
    <button id="btnRemovePin" class="btn btn-danger full-width" type="button" hidden>Gỡ mã PIN khóa phiên</button>
  `;

  if (popupScrollArea) {
    popupScrollArea.prepend(pinSettingsCard);
    popupScrollArea.prepend(sessionLockCard);
  }

  const sessionLockHint = sessionLockCard.querySelector("#sessionLockHint");
  const sessionPinInput = sessionLockCard.querySelector("#sessionPinInput");
  const sessionPinErr = sessionLockCard.querySelector("#sessionPinErr");
  const btnUnlockSession = sessionLockCard.querySelector("#btnUnlockSession");
  const btnResetVaultLock = sessionLockCard.querySelector("#btnResetVaultLock");

  const pinSettingsTitle = pinSettingsCard.querySelector("#pinSettingsTitle");
  const pinOldInput = pinSettingsCard.querySelector("#pinOldInput");
  const pinNewInput = pinSettingsCard.querySelector("#pinNewInput");
  const pinConfirmInput = pinSettingsCard.querySelector("#pinConfirmInput");
  const pinConfigErr = pinSettingsCard.querySelector("#pinConfigErr");
  const btnSavePin = pinSettingsCard.querySelector("#btnSavePin");
  const btnClosePin = pinSettingsCard.querySelector("#btnClosePin");
  const btnRemovePin = pinSettingsCard.querySelector("#btnRemovePin");

  function hideAllPopupViews() {
    for (const el of document.querySelectorAll(".view")) {
      el.hidden = true;
    }
    if (pairedBottomActions) {
      pairedBottomActions.hidden = true;
    }
  }

  function syncSessionLockButtons() {
    const isLocked = Boolean(currentState && currentState.locked);
    const hasPin = Boolean(currentState && currentState.hasPinLock);
    if (btnLockNow) {
      btnLockNow.hidden = isLocked || !hasPin;
    }
    if (btnPinConfig) {
      btnPinConfig.hidden = isLocked;
      btnPinConfig.title = hasPin ? "Đổi hoặc gỡ mã PIN khóa phiên" : "Bật khóa phiên bằng mã PIN";
    }
  }

  async function submitSessionUnlock() {
    sessionPinErr.hidden = true;
    btnUnlockSession.disabled = true;
    btnUnlockSession.textContent = "Đang kiểm tra...";
    try {
      const enteredPin = sessionPinInput.value;
      // Delegate PBKDF2 600k + 310k->600k re-wrap upgrade to Service Worker so closing Popup cannot abort upgrade
      let unlockedState = null;
      const swRes = await sendRuntimeMsg({ type: "UNLOCK_EXTENSION_WITH_PIN", pin: enteredPin });
      if (swRes && swRes.ok && swRes.state) {
        unlockedState = swRes.state;
      } else if (swRes && swRes.ok === false && swRes.error) {
        throw new Error(swRes.error);
      } else {
        unlockedState = await OmniVaultCore.unlockExtensionWithPin(enteredPin);
      }
      setVaultState(unlockedState);
      sessionPinInput.value = "";
      let pendingHosts = [];
      try {
        const flushRes = await sendRuntimeMsg({ type: "FLUSH_LOCKED_CAPTURES" });
        if (flushRes && Array.isArray(flushRes.pendingHosts) && flushRes.pendingHosts.length > 0) {
          pendingHosts = flushRes.pendingHosts;
        }
      } catch (_) {}
      renderVaultList();
      showToast(
        pendingHosts.length > 0
          ? `Đã mở khóa! Các đăng nhập lúc khóa (${pendingHosts.join(", ")}) chưa lưu tạm vì bảo mật.`
          : "Đã mở khóa OmniVault"
      );
      if (currentState.pairing && !currentState.pairing.localOnly) {
        OmniVaultCore.syncBrowserVaultBidirectional(false)
          .then((syncRes) => {
            if (syncRes && syncRes.pulledCount > 0 && syncRes.state) {
              setVaultState(syncRes.state);
              renderVaultList();
            }
          })
          .catch(() => {});
      }
    } catch (e) {
      sessionPinErr.textContent = String(e.message || e);
      sessionPinErr.hidden = false;
    } finally {
      btnUnlockSession.disabled = false;
      btnUnlockSession.textContent = "Mở khóa phiên";
    }
  }

  btnUnlockSession.onclick = submitSessionUnlock;
  sessionPinInput.addEventListener("keydown", (ev) => {
    if (ev.key === "Enter") {
      ev.preventDefault();
      submitSessionUnlock();
    }
  });

  if (btnResetVaultLock) {
    btnResetVaultLock.onclick = async () => {
      if (
        !window.confirm(
          "Xóa toàn bộ dữ liệu kho cục bộ trên tiện ích và ngắt kết nối hiện tại?\n\nDữ liệu trên điện thoại và đám mây vẫn được giữ nguyên."
        )
      ) {
        return;
      }
      btnResetVaultLock.disabled = true;
      try {
        await sendRuntimeMsg({ type: "RESET_EXTENSION_VAULT" });
        await OmniVaultCore.resetExtensionVault();
        setVaultState(await OmniVaultCore.loadExtensionState());
        renderVaultList();
        showToast("Đã đặt lại kho tiện ích cục bộ");
      } catch (e) {
        showToast(String(e?.message || e), true);
      } finally {
        btnResetVaultLock.disabled = false;
      }
    };
  }

  btnLockNow.onclick = async () => {
    pinSettingsOpen = false;
    try {
      await sendRuntimeMsg({ type: "CLEAR_EPHEMERAL_CAPTURES" });
    } catch (_) {}
    await OmniVaultCore.lockExtensionSession();
    setVaultState(await OmniVaultCore.loadExtensionState());
    renderVaultList();
    showToast("Đã khóa phiên OmniVault");
  };

  btnPinConfig.onclick = () => {
    if (currentState && currentState.locked) return;
    pinSettingsOpen = !pinSettingsOpen;
    if (pinSettingsOpen) {
      const hasPin = Boolean(currentState && currentState.hasPinLock);
      pinSettingsTitle.textContent = hasPin
        ? "🔑 Đổi hoặc gỡ mã PIN khóa phiên"
        : "🔑 Bật khóa phiên bằng mã PIN";
      pinOldInput.hidden = !hasPin;
      pinOldInput.value = "";
      pinNewInput.value = "";
      pinConfirmInput.value = "";
      pinConfigErr.hidden = true;
      btnRemovePin.hidden = !hasPin;
    }
    renderVaultList();
  };

  btnClosePin.onclick = () => {
    pinSettingsOpen = false;
    renderVaultList();
  };

  btnSavePin.onclick = async () => {
    pinConfigErr.hidden = true;
    const p1 = pinNewInput.value.trim();
    const p2 = pinConfirmInput.value.trim();
    if (p1.length < 4 || p1.length > 64) {
      pinConfigErr.textContent = "Mã PIN phải từ 4 đến 64 ký tự.";
      pinConfigErr.hidden = false;
      return;
    }
    if (p1 !== p2) {
      pinConfigErr.textContent = "Hai lần nhập mã PIN mới không khớp.";
      pinConfigErr.hidden = false;
      return;
    }
    btnSavePin.disabled = true;
    try {
      const hasPin = Boolean(currentState && currentState.hasPinLock);
      const oldPin = hasPin ? pinOldInput.value : null;
      const swRes = await sendRuntimeMsg({ type: "SET_EXTENSION_PIN", newPin: p1, currentPin: oldPin });
      if (swRes && swRes.ok && swRes.state) {
        setVaultState(swRes.state);
      } else if (swRes && swRes.ok === false && swRes.error) {
        throw new Error(swRes.error);
      } else {
        await OmniVaultCore.setExtensionPin(p1, oldPin);
        setVaultState(await OmniVaultCore.loadExtensionState());
      }
      pinSettingsOpen = false;
      renderVaultList();
      showToast("Đã bật khóa phiên AES-256 (tự khóa sau 15 phút)");
    } catch (e) {
      pinConfigErr.textContent = String(e.message || e);
      pinConfigErr.hidden = false;
    } finally {
      btnSavePin.disabled = false;
    }
  };

  btnRemovePin.onclick = async () => {
    pinConfigErr.hidden = true;
    btnRemovePin.disabled = true;
    try {
      const oldPin = pinOldInput.value;
      const swRes = await sendRuntimeMsg({ type: "CLEAR_EXTENSION_PIN", currentPin: oldPin });
      if (swRes && swRes.ok && swRes.state) {
        setVaultState(swRes.state);
      } else if (swRes && swRes.ok === false && swRes.error) {
        throw new Error(swRes.error);
      } else {
        await OmniVaultCore.clearExtensionPin(oldPin);
        setVaultState(await OmniVaultCore.loadExtensionState());
      }
      pinSettingsOpen = false;
      renderVaultList();
      showToast("Đã gỡ mã PIN khóa phiên");
    } catch (e) {
      pinConfigErr.textContent = String(e.message || e);
      pinConfigErr.hidden = false;
    } finally {
      btnRemovePin.disabled = false;
    }
  };

  // --- Virtualized List Renderer for #allVaultList & Windowed #currentSiteList ---
  const VIRTUAL_LIST_THRESHOLD = 24;
  const VIRTUAL_OVERSCAN = 4;
  const CARD_GAP_PX = 8;
  const SITE_LIST_PAGE_SIZE = 40;

  let virtualItems = [];
  let virtualHeights = [];
  let virtualOffsets = [0];
  let virtualEnabled = false;
  let virtualStart = -1;
  let virtualEnd = -1;
  let virtualTopSpacer = null;
  let virtualSliceContainer = null;
  let virtualBottomSpacer = null;
  let virtualScrollRaf = 0;

  let siteMatchedItems = [];
  let siteRenderedCount = 0;

  function estimateVaultCardHeight(item) {
    const domList = Array.isArray(item.web_domains) ? item.web_domains.filter(Boolean) : [];
    const serviceTitle = String(item.service_name || "").trim() || domList[0] || "Tài khoản";
    const hasExtraDomains =
      domList.length > 1 ||
      (domList.length === 1 && domList[0].trim().toLowerCase() !== serviceTitle.toLowerCase());
    let h = 118;
    if (hasExtraDomains) h += 16;
    if (item.totp_secret) h += 40;
    return h + CARD_GAP_PX;
  }

  function rebuildVirtualOffsetsFrom(startIdx = 0) {
    const n = virtualHeights.length;
    if (virtualOffsets.length !== n + 1) {
      virtualOffsets = new Array(n + 1);
      virtualOffsets[0] = 0;
      startIdx = 0;
    }
    let acc = virtualOffsets[startIdx] || 0;
    for (let i = startIdx; i < n; i++) {
      acc += virtualHeights[i];
      virtualOffsets[i + 1] = acc;
    }
  }

  function findFirstIndexAtOffset(y) {
    const n = virtualItems.length;
    if (n === 0 || y <= 0) return 0;
    let lo = 0;
    let hi = n - 1;
    while (lo < hi) {
      const mid = (lo + hi) >>> 1;
      if (virtualOffsets[mid + 1] <= y) {
        lo = mid + 1;
      } else {
        hi = mid;
      }
    }
    return lo;
  }

  function renderVirtualSlice(force = false) {
    if (!virtualEnabled || !virtualSliceContainer || !popupScrollArea || viewVault.hidden) return;
    const n = virtualItems.length;
    if (n === 0) return;

    const scrollTop = popupScrollArea.scrollTop || 0;
    const viewportH = popupScrollArea.clientHeight || 460;
    const listOffsetTop = allVaultList.offsetTop || 0;
    const localTop = Math.max(0, scrollTop - listOffsetTop);
    const localBottom = Math.max(viewportH, scrollTop + viewportH - listOffsetTop);

    const nextStart = Math.max(0, findFirstIndexAtOffset(localTop) - VIRTUAL_OVERSCAN);
    const nextEnd = Math.min(n, findFirstIndexAtOffset(localBottom) + 1 + VIRTUAL_OVERSCAN);

    if (!force && nextStart === virtualStart && nextEnd === virtualEnd) {
      return;
    }

    virtualStart = nextStart;
    virtualEnd = nextEnd;

    const totalHeight = virtualOffsets[n] || 0;
    const topH = virtualOffsets[nextStart] || 0;
    const botH = Math.max(0, totalHeight - (virtualOffsets[nextEnd] || totalHeight));

    virtualTopSpacer.style.height = `${topH}px`;
    virtualBottomSpacer.style.height = `${botH}px`;

    const frag = document.createDocumentFragment();
    for (let i = nextStart; i < nextEnd; i++) {
      frag.appendChild(buildVaultCard(virtualItems[i], false));
    }
    virtualSliceContainer.replaceChildren(frag);

    // Refine height estimates from actual measured card heights
    const children = virtualSliceContainer.children;
    let firstChanged = -1;
    for (let i = 0; i < children.length; i++) {
      const itemIdx = nextStart + i;
      const measured = children[i].offsetHeight;
      if (measured > 0) {
        const withGap = measured + CARD_GAP_PX;
        if (Math.abs(virtualHeights[itemIdx] - withGap) >= 2) {
          virtualHeights[itemIdx] = withGap;
          if (firstChanged < 0) firstChanged = itemIdx;
        }
      }
    }
    if (firstChanged >= 0) {
      rebuildVirtualOffsetsFrom(firstChanged);
      const updatedTotal = virtualOffsets[n] || 0;
      virtualTopSpacer.style.height = `${virtualOffsets[nextStart] || 0}px`;
      virtualBottomSpacer.style.height = `${Math.max(0, updatedTotal - (virtualOffsets[nextEnd] || updatedTotal))}px`;
    }

    updateVisibleTotpPills(false).catch(() => {});
  }

  function scheduleVirtualSliceRender() {
    if (!virtualEnabled || virtualScrollRaf) return;
    virtualScrollRaf = requestAnimationFrame(() => {
      virtualScrollRaf = 0;
      renderVirtualSlice(false);
    });
  }

  if (popupScrollArea) {
    popupScrollArea.addEventListener("scroll", scheduleVirtualSliceRender, { passive: true });
  }

  function appendCurrentSiteBatch() {
    if (siteRenderedCount >= siteMatchedItems.length) return;
    const end = Math.min(siteMatchedItems.length, siteRenderedCount + SITE_LIST_PAGE_SIZE);
    const frag = document.createDocumentFragment();
    for (let i = siteRenderedCount; i < end; i++) {
      frag.appendChild(buildVaultCard(siteMatchedItems[i].it, true));
    }
    currentSiteList.appendChild(frag);
    siteRenderedCount = end;
    updateVisibleTotpPills(false).catch(() => {});
  }

  if (currentSiteList) {
    currentSiteList.addEventListener(
      "scroll",
      () => {
        if (
          siteRenderedCount < siteMatchedItems.length &&
          currentSiteList.scrollTop + currentSiteList.clientHeight >= currentSiteList.scrollHeight - 40
        ) {
          appendCurrentSiteBatch();
        }
      },
      { passive: true }
    );
  }

  function renderVaultList() {
    syncSessionLockButtons();
    if (currentState && currentState.locked) {
      pinSettingsOpen = false;
      pinSettingsCard.hidden = true;
      virtualEnabled = false;
      deviceLabel.textContent = currentState.deviceNameHint
        ? `${currentState.deviceNameHint} • Đang khóa`
        : "Đang khóa phiên";
      sessionLockHint.textContent = currentState.deviceNameHint
        ? `Nhập mã PIN để mở khóa thiết bị "${currentState.deviceNameHint}" (tự khóa sau 15 phút không dùng).`
        : "Nhập mã PIN để mở khóa phiên trình duyệt (tự khóa sau 15 phút không dùng).";
      hideAllPopupViews();
      sessionLockCard.hidden = false;
      setTimeout(() => sessionPinInput.focus(), 40);
      return;
    }
    sessionLockCard.hidden = true;

    if (pinSettingsOpen) {
      virtualEnabled = false;
      hideAllPopupViews();
      pinSettingsCard.hidden = false;
      return;
    }
    pinSettingsCard.hidden = true;

    if (!currentState || !currentState.pairing) {
      virtualEnabled = false;
      deviceLabel.textContent = "Chưa kết nối điện thoại";
      if (btnStartLocalMode) btnStartLocalMode.hidden = false;
      if (btnCancelPairUpgrade) btnCancelPairUpgrade.hidden = true;
      showView("pairing");
      return;
    }

    if (showingPairUpgrade && currentState.pairing.localOnly) {
      virtualEnabled = false;
      deviceLabel.textContent = "Kết nối App Điện thoại";
      if (btnStartLocalMode) btnStartLocalMode.hidden = true;
      if (btnCancelPairUpgrade) btnCancelPairUpgrade.hidden = false;
      showView("pairing");
      return;
    }

    if (btnStartLocalMode) btnStartLocalMode.hidden = false;
    if (btnCancelPairUpgrade) btnCancelPairUpgrade.hidden = true;
    if (btnUpgradeToPhoneSync) btnUpgradeToPhoneSync.hidden = !Boolean(currentState.pairing.localOnly);

    deviceLabel.textContent = currentState.pairing.localOnly
      ? "Chế độ: Lưu cục bộ trên trình duyệt"
      : `Thiết bị: ${currentState.pairing.deviceName}`;
    showView("vault");

    const rawQ = (searchInput.value || "").trim();
    const foldedQ = OmniVaultCore.foldSearchText(rawQ);

    // Pre-indexed zero-allocation scoring
    let filtered;
    if (!foldedQ) {
      filtered = currentState.items || [];
    } else {
      const scoredAll = [];
      for (let i = 0; i < indexedItems.length; i++) {
        const entry = indexedItems[i];
        const qScore = OmniVaultCore.scoreIndexedItem(entry, foldedQ);
        if (qScore > 0) {
          scoredAll.push({ it: entry.item, qScore });
        }
      }
      scoredAll.sort((a, b) => {
        if (b.qScore !== a.qScore) return b.qScore - a.qScore;
        const favDiff = (b.it.is_favorite ? 1 : 0) - (a.it.is_favorite ? 1 : 0);
        if (favDiff !== 0) return favDiff;
        return String(a.it.username || a.it.service_name || "").localeCompare(
          String(b.it.username || b.it.service_name || ""),
          "vi"
        );
      });
      filtered = scoredAll.map((x) => x.it);
    }

    // Matching current tab domain filters strictly left-to-right on username (O(1) domain index lookup)!
    currentSiteList.textContent = "";
    siteMatchedItems = [];
    siteRenderedCount = 0;
    if (activeHost) {
      const domainHits = domainIndex.get(activeHost) || [];
      const matched = [];
      for (let i = 0; i < domainHits.length; i++) {
        const hit = domainHits[i];
        if (!foldedQ || OmniVaultCore.foldSearchText(hit.item.username).startsWith(foldedQ)) {
          matched.push({ it: hit.item, score: hit.score });
        }
      }
      matched.sort((a, b) => {
        if (b.score !== a.score) return b.score - a.score;
        const favDiff = (b.it.is_favorite ? 1 : 0) - (a.it.is_favorite ? 1 : 0);
        if (favDiff !== 0) return favDiff;
        const timeDiff = (Number(b.it.last_autofilled_ms) || 0) - (Number(a.it.last_autofilled_ms) || 0);
        if (timeDiff !== 0) return timeDiff;
        return String(a.it.username || "").localeCompare(String(b.it.username || ""), "vi");
      });

      if (matched.length > 0) {
        currentSiteSection.hidden = false;
        currentSiteLabel.textContent = `Khớp với ${activeHost} (${matched.length})`;
        siteMatchedItems = matched;
        appendCurrentSiteBatch();
      } else {
        currentSiteSection.hidden = true;
      }
    } else {
      currentSiteSection.hidden = true;
    }

    allItemsCaption.textContent = `Tất cả tài khoản (${filtered.length})`;
    allVaultList.textContent = "";
    virtualStart = -1;
    virtualEnd = -1;

    if (filtered.length === 0) {
      virtualEnabled = false;
      allVaultList.style.gap = "";
      const empty = document.createElement("div");
      empty.className = "empty-box";
      empty.textContent = rawQ
        ? "Không tìm thấy tài khoản phù hợp."
        : "Kho mật khẩu đang trống. Bấm ↻ để đồng bộ hoặc ＋ để thêm mới.";
      allVaultList.appendChild(empty);
      return;
    }

    if (filtered.length <= VIRTUAL_LIST_THRESHOLD) {
      virtualEnabled = false;
      allVaultList.style.gap = "";
      const frag = document.createDocumentFragment();
      for (let i = 0; i < filtered.length; i++) {
        frag.appendChild(buildVaultCard(filtered[i], false));
      }
      allVaultList.appendChild(frag);
      updateVisibleTotpPills(false).catch(() => {});
      return;
    }

    // Virtualized rendering for large vaults (renders only visible viewport slice + overscan buffer!)
    virtualEnabled = true;
    virtualItems = filtered;
    virtualHeights = new Array(filtered.length);
    for (let i = 0; i < filtered.length; i++) {
      virtualHeights[i] = estimateVaultCardHeight(filtered[i]);
    }
    rebuildVirtualOffsetsFrom(0);

    allVaultList.style.gap = "0px";
    virtualTopSpacer = document.createElement("div");
    virtualTopSpacer.style.cssText = "flex-shrink: 0; pointer-events: none;";
    virtualSliceContainer = document.createElement("div");
    virtualSliceContainer.className = "vault-list";
    virtualBottomSpacer = document.createElement("div");
    virtualBottomSpacer.style.cssText = "flex-shrink: 0; pointer-events: none;";

    allVaultList.appendChild(virtualTopSpacer);
    allVaultList.appendChild(virtualSliceContainer);
    allVaultList.appendChild(virtualBottomSpacer);

    renderVirtualSlice(true);
  }

  function openEditor(existing = null) {
    if (existing) {
      editorTitle.textContent = "Sửa tài khoản";
      editId.value = existing.id;
      editService.value = existing.service_name || "";
      editUsername.value = existing.username || "";
      editPassword.value = existing.password || "";
      editDomains.value = (existing.web_domains || []).join(", ");
      editTotpSecret.value = existing.totp_secret || "";
      editNotes.value = existing.notes || "";
      btnDeleteItem.hidden = false;
    } else {
      editorTitle.textContent = "Thêm tài khoản mới";
      editId.value = "";
      editService.value = activeHost ? OmniVaultCore.prettifyDomainTitle(activeHost) : "";
      editUsername.value = "";
      editPassword.value = "";
      editDomains.value = activeHost || "";
      editTotpSecret.value = "";
      editNotes.value = "";
      btnDeleteItem.hidden = true;
    }
    showView("editor");
  }

  // --- Event Handlers ---
  if (btnStartLocalMode) {
    btnStartLocalMode.onclick = async () => {
      try {
        const nextSt = await OmniVaultCore.enableLocalStandaloneMode();
        setVaultState(nextSt);
        showingPairUpgrade = false;
        renderVaultList();
        showToast("Đã bật Kho mật khẩu cục bộ trên trình duyệt!");
      } catch (e) {
        showToast(String(e.message || e), true);
      }
    };
  }

  if (btnUpgradeToPhoneSync) {
    btnUpgradeToPhoneSync.onclick = () => {
      showingPairUpgrade = true;
      renderVaultList();
    };
  }

  if (btnCancelPairUpgrade) {
    btnCancelPairUpgrade.onclick = () => {
      showingPairUpgrade = false;
      renderVaultList();
    };
  }

  btnConnectCode.onclick = async () => {
    const raw = pairingInput.value.trim();
    if (!raw) {
      showToast("Vui lòng dán Mã Kết Nối (OVB2-... hoặc OVB1-...) từ điện thoại", true);
      return;
    }
    btnConnectCode.disabled = true;
    btnConnectCode.textContent = "Đang kết nối & giải mã...";
    try {
      // HIGH-EXT-05: Authenticate & verify cloud handshake BEFORE modifying any local items!
      const pairRes = await OmniVaultCore.pairWithCloudCode(raw);
      showingPairUpgrade = false;
      setVaultState(await OmniVaultCore.loadExtensionState());
      pairingInput.value = "";
      renderVaultList();
      showToast(
        pairRes.mergedLocalCount > 0
          ? `Đã kết nối & gộp ${pairRes.mergedLocalCount} tài khoản cục bộ (${pairRes.itemCount} tổng)!`
          : `Đã kết nối! Đồng bộ ${pairRes.itemCount} tài khoản.`
      );
    } catch (e) {
      showToast(String(e.message || e), true);
    } finally {
      btnConnectCode.disabled = false;
      btnConnectCode.textContent = "Kết nối & Tải mật khẩu";
    }
  };

  btnSyncNow.onclick = async () => {
    if (currentState && currentState.pairing && currentState.pairing.localOnly) {
      showingPairUpgrade = true;
      renderVaultList();
      showToast("Dán Mã Kết Nối OVB2-... (hoặc OVB1-...) để đồng bộ với Điện thoại");
      return;
    }
    btnSyncNow.disabled = true;
    try {
      const res = await OmniVaultCore.syncBrowserVaultBidirectional(false);
      setVaultState(res.state || (await OmniVaultCore.loadExtensionState()));
      if (currentState.hasPinLock) {
        await OmniVaultCore.touchAutoLockAlarm();
      }
      renderVaultList();
      showToast(`Đã đồng bộ (${res.itemCount} tài khoản)`);
    } catch (e) {
      showToast(String(e.message || e), true);
    } finally {
      btnSyncNow.disabled = false;
    }
  };

  function openBulkImporterTab() {
    chrome.tabs.create({ url: chrome.runtime.getURL("import.html"), active: true });
  }

  if (btnOpenBulkImportTop) btnOpenBulkImportTop.onclick = openBulkImporterTab;
  if (btnOpenBulkImportVault) btnOpenBulkImportVault.onclick = openBulkImporterTab;
  if (btnOpenBulkImportUnpaired) btnOpenBulkImportUnpaired.onclick = openBulkImporterTab;

  btnOpenAdd.onclick = () => openEditor(null);
  btnCancelEdit.onclick = () => renderVaultList();

  btnGenPw.onclick = () => {
    editPassword.value = OmniVaultCore.generateStrongPassword(18);
  };

  btnSaveItem.onclick = async () => {
    const srv = editService.value.trim();
    const usr = editUsername.value.trim();
    const pw = editPassword.value;
    const doms = editDomains.value
      .split(",")
      .map((s) => OmniVaultCore.extractCleanDomain(s))
      .filter(Boolean);
    const rawSecret = editTotpSecret.value.trim();
    const notes = editNotes.value.trim();

    if (!srv && !pw && doms.length === 0) {
      showToast("Vui lòng nhập Tên dịch vụ hoặc Mật khẩu", true);
      return;
    }

    let secret = null;
    let parsedTotpMeta = null;
    if (rawSecret) {
      if (/^otpauth:\/\//i.test(rawSecret)) {
        try {
          parsedTotpMeta = OmniVaultCore.parseOtpAuthUri(rawSecret);
          secret = parsedTotpMeta.secret;
        } catch (e) {
          showToast(String(e?.message || e), true);
          return;
        }
      } else {
        const cleanB32 = OmniVaultCore.parseTotpSecretField(rawSecret);
        if (!cleanB32) {
          showToast("Mã bí mật 2FA TOTP (Base32) không hợp lệ", true);
          return;
        }
        secret = cleanB32;
      }
    }

    btnSaveItem.disabled = true;
    btnSaveItem.textContent = "Đang lưu...";
    try {
      const record = await OmniVaultCore.mutateVaultState((st) => {
        if (st.locked) {
          throw new Error("Kho tiện ích đang khóa — vui lòng nhập PIN trước khi lưu.");
        }
        const now = Date.now();
        const id = editId.value || crypto.randomUUID();
        const existing = st.items.find((x) => x.id === id);
        let passwordHistory = Array.isArray(existing?.password_history)
          ? [...existing.password_history]
          : [];
        if (existing && existing.password && existing.password !== pw) {
          passwordHistory = [
            { password: existing.password, changed_at_ms: now },
            ...passwordHistory
          ].slice(0, 10);
        }

        const nextRecord = OmniVaultCore.normalizeVaultItem({
          ...(existing || {}),
          id,
          service_name:
            srv || (doms[0] ? OmniVaultCore.prettifyDomainTitle(doms[0]) : "") || usr || "Tài khoản Web",
          username: usr,
          password: pw,
          password_history: passwordHistory,
          totp_secret: secret,
          totp_algorithm: parsedTotpMeta ? parsedTotpMeta.algorithm : existing?.totp_algorithm || "SHA1",
          totp_digits: parsedTotpMeta ? parsedTotpMeta.digits : existing?.totp_digits || 6,
          totp_period: parsedTotpMeta ? parsedTotpMeta.period : existing?.totp_period || 30,
          web_domains: doms,
          notes,
          created_at_ms: existing ? existing.created_at_ms : now,
          updated_at_ms: now
        });

        const idx = st.items.findIndex((x) => x.id === id);
        if (idx >= 0) {
          st.items[idx] = nextRecord;
        } else {
          st.items.push(nextRecord);
        }
        if (!st.deletedIds || typeof st.deletedIds !== "object") {
          st.deletedIds = {};
        }
        delete st.deletedIds[id];
        return { save: true, result: nextRecord };
      });

      const syncRes = await OmniVaultCore.syncBrowserVaultBidirectional(true);
      setVaultState(syncRes.state || (await OmniVaultCore.loadExtensionState()));
      if (currentState.hasPinLock) {
        await OmniVaultCore.touchAutoLockAlarm();
      }
      renderVaultList();
      showToast(`Đã lưu & đồng bộ '${record.service_name}'`);
    } catch (e) {
      showToast(String(e.message || e), true);
    } finally {
      btnSaveItem.disabled = false;
      btnSaveItem.textContent = "Lưu & Đồng bộ";
    }
  };

  btnDeleteItem.onclick = async () => {
    const id = editId.value;
    if (!id) return;
    if (!confirm("Xóa tài khoản này khỏi Trình duyệt và chuyển vào Thùng rác trên Điện thoại?")) {
      return;
    }
    btnDeleteItem.disabled = true;
    try {
      await OmniVaultCore.mutateVaultState((st) => {
        if (st.locked) {
          throw new Error("Kho tiện ích đang khóa — vui lòng nhập PIN trước khi xóa.");
        }
        st.items = st.items.filter((x) => x.id !== id);
        if (!st.deletedIds || typeof st.deletedIds !== "object") {
          st.deletedIds = {};
        }
        st.deletedIds[id] = Date.now();
        return { save: true, result: true };
      });
      const syncRes = await OmniVaultCore.syncBrowserVaultBidirectional(true);
      setVaultState(syncRes.state || (await OmniVaultCore.loadExtensionState()));
      if (currentState.hasPinLock) {
        await OmniVaultCore.touchAutoLockAlarm();
      }
      renderVaultList();
      showToast("Đã xóa và đồng bộ");
    } catch (e) {
      showToast(String(e.message || e), true);
    } finally {
      btnDeleteItem.disabled = false;
    }
  };

  btnUnpair.onclick = async () => {
    if (!confirm("Ngắt kết nối kho mật khẩu trên trình duyệt này? (Dữ liệu trên điện thoại vẫn giữ nguyên)")) {
      return;
    }
    try {
      await sendRuntimeMsg({ type: "CLEAR_EPHEMERAL_CAPTURES" });
      setVaultState(await OmniVaultCore.unpairExtensionVault());
      renderVaultList();
      showToast("Đã ngắt kết nối trình duyệt");
    } catch (e) {
      showToast(String(e.message || e), true);
    }
  };

  searchInput.addEventListener("input", () => {
    if (popupScrollArea) popupScrollArea.scrollTop = 0;
    renderVaultList();
  });

  // Smart 1s TOTP tick: updates countdown text only during 29/30s and runs WebCrypto HMAC
  // ONLY on visible cards when their TOTP step rolls over!
  setInterval(() => {
    if (!viewVault.hidden && currentState && !currentState.locked && currentState.pairing) {
      updateVisibleTotpPills(false).catch(() => {});
    }
  }, 1000);

  // Wipe cached TOTP keys and decrypted search index on popup close (INV-03)
  window.addEventListener("pagehide", () => {
    clearSensitivePopupCaches();
  });

  // Coalesced single-pass popup startup: 1 decrypt + 1 virtualized DOM paint!
  (async () => {
    const [, loadedState] = await Promise.all([
      detectActiveTab(),
      OmniVaultCore.loadExtensionState()
    ]);
    setVaultState(loadedState);
    renderVaultList();
    refreshGitHubUpdateStatus(false).catch(() => {});

    if (currentState && !currentState.locked && currentState.pairing && !currentState.pairing.localOnly) {
      try {
        const syncRes = await OmniVaultCore.syncBrowserVaultBidirectional(false);
        // Only re-index & re-paint if remote actually delivered new/updated items!
        if (syncRes && syncRes.pulledCount > 0 && syncRes.state) {
          setVaultState(syncRes.state);
          renderVaultList();
        }
      } catch (_) {
        // Offline cached vault remains usable
      }
    }
  })();
})();
