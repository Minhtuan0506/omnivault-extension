// ============================================================================
// OmniVault Content Script MV3 (2027 Standard) — Closed Shadow DOM & Autofill
// Supports React / Vue / Angular / Next.js / Shadow DOM & 2-Step SSO Logins
// ============================================================================

(() => {
  if (window !== window.top) return;

  function isLoopbackHost(hostname) {
    const h = String(hostname || "").toLowerCase().replace(/^\[|\]$/g, "");
    return h === "localhost" || h === "127.0.0.1" || h === "::1";
  }

  function isSafePageOrigin() {
    if (location.protocol === "https:") return true;
    if (location.protocol === "http:" && isLoopbackHost(location.hostname)) {
      return true;
    }
    return false;
  }

  // M8: Never initialize observers, listeners, or caches on unsafe non-HTTPS pages
  if (!isSafePageOrigin()) return;
  if (window.__omnivaultContentLoaded) return;
  window.__omnivaultContentLoaded = true;

  const STEP1_USER_TTL_MS = 300_000;
  const knownPasswordInputs = new WeakSet();
  const lifecycleAbort = typeof AbortController === "function" ? new AbortController() : null;
  const lifecycleSignal = lifecycleAbort ? lifecycleAbort.signal : undefined;
  let tornDown = false;
  let activeMenuEl = null;
  let activeMenuMode = "";
  let activeMenuFilterFn = null;
  let activeMenuAnchor = null;
  let saveBannerEl = null;
  let domainMatchCache = { fetchedAt: 0, matches: [], paired: false, locked: false };
  let liveCredCache = { pwEl: null, username: "", password: "", updatedAt: 0 };
  let pendingUnlockAnchor = { input: null, isStep1User: false, savedAt: 0 };
  let step1UsernameMem = "";
  let step1UsernameSavedAt = 0;
  let unpairedHintShownInPage = false;
  let pendingMatchAnchor = null;
  let lastMatchTriggerEl = null;
  let lastMatchTriggerAt = 0;
  const pendingAckTimers = new Set();

  function cancelPendingAckTimers() {
    for (const tid of pendingAckTimers) {
      clearTimeout(tid);
    }
    pendingAckTimers.clear();
  }

  function isOwnOverlayEvent(e) {
    const t = e && e.target;
    if (!t) return false;
    if (activeMenuEl && (t === activeMenuEl || (activeMenuEl.contains && activeMenuEl.contains(t)))) {
      return true;
    }
    if (saveBannerEl && (t === saveBannerEl || (saveBannerEl.contains && saveBannerEl.contains(t)))) {
      return true;
    }
    return false;
  }

  function safeSendMessage(payload, callback) {
    try {
      if (!chrome?.runtime?.id) {
        teardownContentScript();
        if (typeof callback === "function") callback(null);
        return;
      }
      chrome.runtime.sendMessage(payload, (res) => {
        if (chrome.runtime.lastError) {
          if (typeof callback === "function") callback(null);
          return;
        }
        if (typeof callback === "function") callback(res);
      });
    } catch (_) {
      if (!chrome?.runtime?.id) {
        teardownContentScript();
      }
      if (typeof callback === "function") callback(null);
    }
  }

  function setNativeInputValue(el, val) {
    if (!el) return;
    el.focus();
    const prevVal = el.value;
    const proto = Object.getPrototypeOf(el);
    const desc =
      Object.getOwnPropertyDescriptor(proto, "value") ||
      Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value");
    if (desc && desc.set) {
      desc.set.call(el, val);
    } else {
      el.value = val;
    }
    // Reset React 16-19 internal _valueTracker so controlled inputs commit state immediately
    if (el._valueTracker && typeof el._valueTracker.setValue === "function") {
      try {
        el._valueTracker.setValue(prevVal);
      } catch (_) {}
    }
    try {
      el.dispatchEvent(
        new InputEvent("input", { bubbles: true, cancelable: true, inputType: "insertText", data: val })
      );
    } catch (_) {
      el.dispatchEvent(new Event("input", { bubbles: true }));
    }
    el.dispatchEvent(new Event("change", { bubbles: true }));
    el.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, key: "Unidentified" }));
  }

  const knownShadowHosts = new Set();
  const observedShadowRoots = new WeakSet();
  const inputMetaCache = new WeakMap();
  const textSecurityCache = new WeakMap();
  const standaloneUserCache = new WeakMap();
  const MUTATION_DEBOUNCE_MS = 150;
  const MUTATION_MAX_WAIT_MS = 500;
  const MAX_PENDING_ADDED_NODES = 200;

  let domMutationEpoch = 1;
  let initialShadowScanDone = false;
  let cachedDocInputsEpoch = -1;
  let cachedDocInputs = [];
  let cachedHasVisiblePwEpoch = -1;
  let cachedHasVisiblePw = false;
  let cachedVisiblePwEl = null;

  let mutationDebounceTimer = null;
  let mutationFirstQueuedAt = 0;
  const pendingAddedNodes = new Set();
  let pendingHadRemovals = false;

  function invalidateDomInputCaches() {
    domMutationEpoch++;
    cachedDocInputsEpoch = -1;
    cachedHasVisiblePwEpoch = -1;
    cachedVisiblePwEl = null;
  }

  function observeShadowRootIfOpen(shadowRoot) {
    if (tornDown || !shadowRoot || observedShadowRoots.has(shadowRoot) || typeof MutationObserver !== "function") {
      return;
    }
    observedShadowRoots.add(shadowRoot);
    try {
      domObserver.observe(shadowRoot, { childList: true, subtree: true });
    } catch (_) {}
  }

  function inspectSubtreeForShadowHosts(rootNode, budget = { remaining: 400 }) {
    if (!rootNode || !(rootNode instanceof Element) || budget.remaining <= 0) return;
    if (rootNode === activeMenuEl || rootNode === saveBannerEl) return;
    budget.remaining--;
    if (rootNode.shadowRoot) {
      knownShadowHosts.add(rootNode);
      observeShadowRootIfOpen(rootNode.shadowRoot);
    }
    if (typeof document.createTreeWalker !== "function") return;
    try {
      const walker = document.createTreeWalker(rootNode, NodeFilter.SHOW_ELEMENT);
      let node;
      while ((node = walker.nextNode()) && budget.remaining > 0) {
        budget.remaining--;
        if (node.shadowRoot) {
          knownShadowHosts.add(node);
          observeShadowRootIfOpen(node.shadowRoot);
        }
      }
    } catch (_) {}
  }

  function flushDomMutations() {
    mutationDebounceTimer = null;
    mutationFirstQueuedAt = 0;
    if (tornDown) {
      pendingAddedNodes.clear();
      return;
    }
    if (!chrome?.runtime?.id) {
      teardownContentScript();
      return;
    }
    const budget = { remaining: 400 };
    if (pendingHadRemovals) {
      pendingHadRemovals = false;
      for (const host of Array.from(knownShadowHosts)) {
        if (!host || !host.isConnected || !host.shadowRoot) {
          knownShadowHosts.delete(host);
        }
      }
    }
    for (const node of pendingAddedNodes) {
      if (node && node.isConnected) {
        inspectSubtreeForShadowHosts(node, budget);
      }
    }
    pendingAddedNodes.clear();
    invalidateDomInputCaches();

    // Multi-step SPA transition detection: if a newly rendered password input took focus, refresh match cache
    const active = document.activeElement;
    if (
      active instanceof HTMLInputElement &&
      active !== activeMenuAnchor &&
      isSafePageOrigin() &&
      isPasswordLikeInput(active) &&
      isVisibleInput(active)
    ) {
      if (!activeMenuEl && domainMatchCache.paired && Date.now() - domainMatchCache.fetchedAt > 3000) {
        domainMatchCache.fetchedAt = 0;
      }
    }
  }

  const domObserver =
    typeof MutationObserver === "function"
      ? new MutationObserver((records) => {
          if (tornDown) return;
          if (!chrome?.runtime?.id) {
            teardownContentScript();
            return;
          }
          let sawRelevant = false;
          for (const rec of records) {
            if (rec.addedNodes && rec.addedNodes.length > 0) {
              for (const n of rec.addedNodes) {
                if (n instanceof Element && n !== activeMenuEl && n !== saveBannerEl) {
                  if (pendingAddedNodes.size < MAX_PENDING_ADDED_NODES) {
                    pendingAddedNodes.add(n);
                  }
                  sawRelevant = true;
                }
              }
            }
            if (rec.removedNodes && rec.removedNodes.length > 0) {
              for (const n of rec.removedNodes) {
                if (n instanceof Element && n !== activeMenuEl && n !== saveBannerEl) {
                  pendingHadRemovals = true;
                  sawRelevant = true;
                  break;
                }
              }
            }
          }
          if (!sawRelevant) return;
          const now = Date.now();
          if (mutationFirstQueuedAt === 0) {
            mutationFirstQueuedAt = now;
          }
          if (
            pendingAddedNodes.size >= MAX_PENDING_ADDED_NODES ||
            now - mutationFirstQueuedAt >= MUTATION_MAX_WAIT_MS
          ) {
            if (mutationDebounceTimer !== null) {
              clearTimeout(mutationDebounceTimer);
              mutationDebounceTimer = null;
            }
            flushDomMutations();
            return;
          }
          if (mutationDebounceTimer !== null) {
            clearTimeout(mutationDebounceTimer);
          }
          const remainingMaxWait = Math.max(0, MUTATION_MAX_WAIT_MS - (now - mutationFirstQueuedAt));
          mutationDebounceTimer = setTimeout(
            flushDomMutations,
            Math.min(MUTATION_DEBOUNCE_MS, remainingMaxWait)
          );
        })
      : null;

  function teardownContentScript() {
    if (tornDown) return;
    tornDown = true;
    try {
      if (lifecycleAbort) lifecycleAbort.abort();
    } catch (_) {}
    try {
      if (domObserver) domObserver.disconnect();
    } catch (_) {}
    if (mutationDebounceTimer !== null) {
      clearTimeout(mutationDebounceTimer);
      mutationDebounceTimer = null;
    }
    mutationFirstQueuedAt = 0;
    cancelPendingAckTimers();
    pendingAddedNodes.clear();
    knownShadowHosts.clear();
    closeInlineMenu();
    if (saveBannerEl) {
      try {
        saveBannerEl.remove();
      } catch (_) {}
      saveBannerEl = null;
    }
    domainMatchCache = { fetchedAt: 0, matches: [], paired: false, locked: false };
    liveCredCache = { pwEl: null, username: "", password: "", updatedAt: 0 };
    pendingUnlockAnchor = { input: null, isStep1User: false, savedAt: 0 };
    step1UsernameMem = "";
    step1UsernameSavedAt = 0;
    pendingMatchAnchor = null;
  }

  function startDomMutationObserver() {
    if (!domObserver || tornDown) return;
    const target = document.documentElement || document.body;
    if (target) {
      try {
        domObserver.observe(target, { childList: true, subtree: true });
      } catch (_) {}
    } else {
      document.addEventListener(
        "DOMContentLoaded",
        () => {
          if (tornDown) return;
          const root = document.documentElement || document.body;
          if (root) {
            try {
              domObserver.observe(root, { childList: true, subtree: true });
            } catch (_) {}
          }
        },
        { once: true, signal: lifecycleSignal }
      );
    }
  }

  startDomMutationObserver();

  function registerShadowHostsFromEvent(e) {
    if (!e || typeof e.composedPath !== "function") return;
    try {
      const path = e.composedPath();
      let addedAny = false;
      for (const node of path) {
        if (node && node instanceof ShadowRoot && node.host) {
          if (!knownShadowHosts.has(node.host)) {
            knownShadowHosts.add(node.host);
            observeShadowRootIfOpen(node);
            addedAny = true;
          }
        } else if (node && node.shadowRoot) {
          if (!knownShadowHosts.has(node)) {
            knownShadowHosts.add(node);
            observeShadowRootIfOpen(node.shadowRoot);
            addedAny = true;
          }
        }
      }
      if (addedAny) invalidateDomInputCaches();
    } catch (_) {}
  }

  function ensureInitialShadowHostScan() {
    if (initialShadowScanDone) return;
    initialShadowScanDone = true;
    const rootNode = document.documentElement || document.body;
    if (!rootNode || typeof document.createTreeWalker !== "function") return;
    inspectSubtreeForShadowHosts(rootNode, { remaining: 1000 });
  }

  function isElementActuallyVisible(el, requireEditable) {
    if (!el || el.disabled || (requireEditable && el.readOnly)) return false;
    if (el.isConnected === false) return false;
    // Modern 2026-2027 native Blink C++ visibility check (avoids 8x parent getComputedStyle reflows)
    if (typeof el.checkVisibility === "function") {
      if (!el.checkVisibility({ checkOpacity: true, checkVisibilityCSS: true })) {
        return false;
      }
      if (el.closest && el.closest("[inert], [aria-hidden='true']")) return false;
      const rect = el.getBoundingClientRect();
      return rect.width >= 30 && rect.height >= 14;
    }
    // Legacy fallback when checkVisibility is unavailable
    if (el.closest && el.closest("[inert], [aria-hidden='true'], [hidden]")) return false;
    const rect = el.getBoundingClientRect();
    if (rect.width < 30 || rect.height < 14) return false;
    let cur = el;
    for (let i = 0; i < 8 && cur && cur instanceof Element; i++) {
      const st = window.getComputedStyle(cur);
      if (st.display === "none" || st.visibility === "hidden" || Number(st.opacity) <= 0.05) {
        return false;
      }
      cur = cur.parentElement || (cur.getRootNode && cur.getRootNode().host) || null;
    }
    return true;
  }

  function isVisibleInput(el) {
    return isElementActuallyVisible(el, true);
  }

  function isVisibleReadableInput(el) {
    return isElementActuallyVisible(el, false);
  }

  function queryAllInputsDeep(root = document, depth = 0, seen = null) {
    if (!root || depth > 5) return [];
    if (depth === 0 && root === document) {
      ensureInitialShadowHostScan();
      if (cachedDocInputsEpoch === domMutationEpoch) {
        return cachedDocInputs;
      }
    }
    const visited = seen || new Set();
    if (visited.has(root)) return [];
    visited.add(root);

    const results = [];
    const direct = root.querySelectorAll ? root.querySelectorAll("input") : [];
    for (const inp of direct) {
      results.push(inp);
    }
    for (const host of knownShadowHosts) {
      if (!host || !host.isConnected || !host.shadowRoot) {
        knownShadowHosts.delete(host);
        continue;
      }
      if (root === document || (root.contains && root.contains(host))) {
        results.push(...queryAllInputsDeep(host.shadowRoot, depth + 1, visited));
      }
    }
    if (depth === 0 && root === document) {
      cachedDocInputs = results;
      cachedDocInputsEpoch = domMutationEpoch;
    }
    return results;
  }

  function hasVisiblePasswordOnPage() {
    if (cachedHasVisiblePwEpoch === domMutationEpoch) {
      if (!cachedHasVisiblePw) return false;
      if (cachedVisiblePwEl && cachedVisiblePwEl.isConnected && isVisibleInput(cachedVisiblePwEl)) {
        return true;
      }
    }
    const allInputs = queryAllInputsDeep(document);
    let foundPw = null;
    for (let i = 0; i < allInputs.length; i++) {
      const inp = allInputs[i];
      if (isPasswordLikeInput(inp) && isVisibleInput(inp)) {
        foundPw = inp;
        break;
      }
    }
    cachedHasVisiblePw = Boolean(foundPw);
    cachedVisiblePwEl = foundPw;
    cachedHasVisiblePwEpoch = domMutationEpoch;
    return cachedHasVisiblePw;
  }

  function normalizeVi(str) {
    return String(str || "")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[đĐ]/g, "d")
      .toLowerCase();
  }

  function matchesUsernameLeftToRight(username, rawPrefix) {
    const qNorm = normalizeVi(String(rawPrefix || "").trim());
    if (!qNorm) return true;
    const uNorm = normalizeVi(String(username || "").trim());
    return Boolean(uNorm) && uNorm.startsWith(qNorm);
  }

  const NON_PASSWORD_INPUT_TYPES = new Set([
    "hidden",
    "submit",
    "button",
    "checkbox",
    "radio",
    "file",
    "image",
    "reset",
    "search",
    "email",
    "url",
    "date",
    "datetime-local",
    "month",
    "week",
    "time",
    "number",
    "range",
    "color"
  ]);
  const PASSWORD_CUE_REGEX = /(pass|pwd|mat.?khau|secret|mask|pin)/i;
  const OTP_CUE_REGEX =
    /(otp|totp|2fa|mfa|two.?factor|verification.?code|auth.?code|security.?code|ma.?xac.?thuc|ma.?otp|smart.?otp)/i;

  function getInputMetadata(el) {
    const ariaLabel = el.getAttribute ? el.getAttribute("aria-label") || "" : "";
    const sig = `${el.name || ""}\0${el.id || ""}\0${el.autocomplete || ""}\0${el.placeholder || ""}\0${ariaLabel}`;
    const cached = inputMetaCache.get(el);
    if (cached && cached.sig === sig) {
      return cached.meta;
    }
    const labelText = (el.labels && el.labels[0] ? el.labels[0].textContent : "") || ariaLabel;
    const meta = normalizeVi(
      `${el.name || ""} ${el.id || ""} ${el.autocomplete || ""} ${el.placeholder || ""} ${labelText}`
    );
    inputMetaCache.set(el, { sig, meta });
    return meta;
  }

  function isOtpLikeInput(el) {
    if (!(el instanceof HTMLInputElement)) return false;
    const ac = (el.autocomplete || "").toLowerCase();
    if (ac.includes("one-time-code")) return true;
    const meta = getInputMetadata(el);
    if (OTP_CUE_REGEX.test(meta)) {
      return true;
    }
    if (el.maxLength >= 1 && el.maxLength <= 6 && /(code|ma|digit|so)/i.test(meta)) {
      return true;
    }
    return false;
  }

  function isPasswordLikeInput(el) {
    if (!(el instanceof HTMLInputElement)) return false;
    const t = (el.type || "").toLowerCase();
    if (NON_PASSWORD_INPUT_TYPES.has(t)) {
      return false;
    }
    if (isOtpLikeInput(el)) return false;
    // Fast DOM properties checked BEFORE any getComputedStyle call!
    if (t === "password") {
      knownPasswordInputs.add(el);
      return true;
    }
    const ac = (el.autocomplete || "").toLowerCase();
    if (ac.includes("current-password") || ac.includes("new-password")) {
      knownPasswordInputs.add(el);
      return true;
    }
    if (knownPasswordInputs.has(el)) return true;

    const meta = getInputMetadata(el);
    const cls = typeof el.className === "string" ? el.className : "";
    const hasInlineTextSec = Boolean(el.style && el.style.webkitTextSecurity);
    if (!hasInlineTextSec && !PASSWORD_CUE_REGEX.test(meta) && !PASSWORD_CUE_REGEX.test(cls)) {
      return false;
    }
    const styleSig = `${cls}|${el.style ? el.style.cssText : ""}`;
    const cachedSec = textSecurityCache.get(el);
    if (cachedSec && cachedSec.sig === styleSig) {
      return cachedSec.masked;
    }
    try {
      const st = window.getComputedStyle(el);
      const masked = Boolean(st.webkitTextSecurity && st.webkitTextSecurity !== "none");
      textSecurityCache.set(el, { sig: styleSig, masked });
      if (masked) {
        knownPasswordInputs.add(el);
        return true;
      }
    } catch (_) {}
    return false;
  }

  function isNonLoginNoiseInput(el, meta) {
    if (el.type === "search" || el.type === "number" || el.type === "hidden") return true;
    if (el.closest('[role="search"]')) return true;
    if (
      /(search|tim.?kiem|filter|bo.?loc|chat|comment|binh.?luan|reply|promo|voucher|coupon|ma.?giam|otp|totp|2fa|verification|ma.?xac.?thuc|captcha)/.test(
        meta
      )
    ) {
      return true;
    }
    if (el.maxLength >= 4 && el.maxLength <= 6 && /(code|ma|pin|otp)/.test(meta)) {
      return true;
    }
    return false;
  }

  function isStandaloneLoginUsernameInput(el) {
    if (!(el instanceof HTMLInputElement)) return false;
    const t = (el.type || "text").toLowerCase();
    if (!["text", "email", "tel", ""].includes(t)) return false;

    const urlPath = `${location.hostname} ${location.pathname} ${location.hash}`.toLowerCase();
    const meta = getInputMetadata(el);
    const cached = standaloneUserCache.get(el);
    if (
      cached &&
      cached.epoch === domMutationEpoch &&
      cached.meta === meta &&
      cached.type === t &&
      cached.urlPath === urlPath
    ) {
      return cached.result;
    }

    const compute = () => {
      if (isNonLoginNoiseInput(el, meta)) return false;

      const ac = (el.autocomplete || "").toLowerCase();
      if (/(username|email|webauthn)/.test(ac)) return true;

      const strongUserCue =
        /(user|userid|username|login|identifier|account|email|e-mail|phone|mobile|sdt|so.?dien.?thoai|tai.?khoan|ten.?dang.?nhap|cif|ma.?khach.?hang)/.test(
          meta
        );
      if (!strongUserCue) return false;

      const urlIsAuth =
        /(login|signin|sign-in|auth|sso|oauth|account|id\.|passport|dang-nhap|dangnhap|digibank|ibank|ebank|smartbanking)/.test(
          urlPath
        );
      if (urlIsAuth) return true;

      const container = el.closest("form, [role='dialog'], main, section") || document.body;
      const btnText = normalizeVi(
        Array.from(container.querySelectorAll("button, input[type='submit'], [role='button']"))
          .slice(0, 8)
          .map((b) => b.textContent || b.value || "")
          .join(" ")
      );
      return /(dang.?nhap|tiep.?tuc|next|continue|sign.?in|log.?in)/.test(btnText);
    };

    const result = compute();
    standaloneUserCache.set(el, { epoch: domMutationEpoch, meta, type: t, urlPath, result });
    return result;
  }

  function resolveUsernameScope(pwInput) {
    if (!pwInput || pwInput === document.body) return document;
    const form = pwInput.closest ? pwInput.closest("form") : null;
    if (form) return form;
    let cur = pwInput.parentElement;
    for (let i = 0; i < 6 && cur; i++) {
      const inps = queryAllInputsDeep(cur);
      if (inps.length >= 2) return cur;
      cur = cur.parentElement;
    }
    return document;
  }

  function findUsernameFieldNear(pwInput, allowReadOnly = false) {
    const scope = resolveUsernameScope(pwInput);
    const visFn = allowReadOnly ? isVisibleReadableInput : isVisibleInput;
    const candidates = queryAllInputsDeep(scope).filter((el) => {
      if (!visFn(el) || el === pwInput || isPasswordLikeInput(el)) return false;
      const t = (el.type || "text").toLowerCase();
      return ["text", "email", "tel", ""].includes(t);
    });

    const scored = candidates.map((el) => {
      const meta = getInputMetadata(el);
      const ac = (el.autocomplete || "").toLowerCase();
      let score = 0;
      if (/(username|email|webauthn)/.test(ac)) score += 8;
      if (
        /(user|login|identifier|email|mail|phone|tel|sdt|so.?dien.?thoai|tai.?khoan|ten.?dang.?nhap|account|cif)/.test(
          meta
        )
      ) {
        score += 6;
      }
      if (
        pwInput &&
        pwInput !== document.body &&
        typeof el.compareDocumentPosition === "function" &&
        (el.compareDocumentPosition(pwInput) & Node.DOCUMENT_POSITION_FOLLOWING)
      ) {
        score += 2;
      }
      if (isNonLoginNoiseInput(el, meta)) score -= 12;
      return { el, score };
    });
    scored.sort((a, b) => b.score - a.score);
    return scored.length > 0 && scored[0].score >= 0 ? scored[0].el : null;
  }

  function getActiveStep1Username() {
    if (step1UsernameMem && Date.now() - step1UsernameSavedAt < STEP1_USER_TTL_MS) {
      return step1UsernameMem;
    }
    step1UsernameMem = "";
    step1UsernameSavedAt = 0;
    return "";
  }

  function extractBestUsernameNear(pwInput, opts = {}) {
    const usrEl = findUsernameFieldNear(pwInput, true);
    const direct = usrEl ? String(usrEl.value || "").trim() : "";
    if (direct) return direct;
    if (opts && opts.allowFallback === false) return "";
    if (Date.now() - liveCredCache.updatedAt < STEP1_USER_TTL_MS && liveCredCache.username) {
      return liveCredCache.username;
    }
    const s1 = getActiveStep1Username();
    if (s1) return s1;
    const idChip =
      typeof document.querySelector === "function"
        ? document.querySelector("[data-identifier], [data-email]")
        : null;
    if (idChip) {
      const chipVal = String(
        idChip.getAttribute("data-identifier") || idChip.getAttribute("data-email") || ""
      ).trim();
      if (chipVal) return chipVal;
    }
    return "";
  }

  function pickPrimaryPasswordInput(pwInputs) {
    const nonEmpty = (pwInputs || []).filter((inp) => inp && inp.value);
    if (nonEmpty.length === 0) return null;
    if (nonEmpty.length === 1) return nonEmpty[0];
    const preferredNew = nonEmpty.find((inp) => {
      const ac = (inp.autocomplete || "").toLowerCase();
      const meta = getInputMetadata(inp);
      if (ac.includes("new-password")) {
        return !/(confirm|repeat|retype|nhap.?lai|xac.?nhan)/i.test(meta);
      }
      return /(new|moi)/i.test(meta) && !/(confirm|repeat|retype|nhap.?lai|xac.?nhan)/i.test(meta);
    });
    return preferredNew || nonEmpty[nonEmpty.length - 1];
  }

  function extractCurrentPasswordNear(newPwEl, scopeRoot = null) {
    const newVal = newPwEl && newPwEl.value ? String(newPwEl.value) : "";
    if (!newVal) return "";
    const root = scopeRoot || (newPwEl ? resolveUsernameScope(newPwEl) : document);
    const filledPws = queryAllInputsDeep(root).filter(
      (inp) => isPasswordLikeInput(inp) && inp.value && inp !== newPwEl && inp.value !== newVal
    );
    if (filledPws.length === 0) return "";
    const explicitOld = filledPws.find((inp) => {
      const ac = (inp.autocomplete || "").toLowerCase();
      const meta = getInputMetadata(inp);
      return ac.includes("current-password") || /(current|old|hien.?tai|mat.?khau.?cu|\bcu\b)/i.test(meta);
    });
    return String((explicitOld || filledPws[0]).value || "");
  }

  function fillCredentialsOnPage(username, password, anchorInput = null) {
    const allInputs = queryAllInputsDeep(document);
    const pwInputs = allInputs.filter((el) => isPasswordLikeInput(el) && isVisibleInput(el));
    const pwField =
      anchorInput && isPasswordLikeInput(anchorInput) && isVisibleInput(anchorInput)
        ? anchorInput
        : pwInputs[0] || null;

    if (pwField) {
      const userField =
        anchorInput && !isPasswordLikeInput(anchorInput) && isVisibleInput(anchorInput)
          ? anchorInput
          : findUsernameFieldNear(pwField);
      let filledUser = false;
      let filledPw = false;
      if (userField && username) {
        setNativeInputValue(userField, username);
        filledUser = true;
      }
      if (password) {
        setNativeInputValue(pwField, password);
        filledPw = true;
      }
      if (filledUser || filledPw) {
        return { filled: true, mode: filledUser && filledPw ? "both" : "password_only" };
      }
    }

    // Multi-step login Step 1 (username/email/phone screen with no password field yet)
    if (username) {
      const targetUser =
        anchorInput &&
        !isPasswordLikeInput(anchorInput) &&
        isVisibleInput(anchorInput) &&
        isStandaloneLoginUsernameInput(anchorInput)
          ? anchorInput
          : allInputs.find((el) => isVisibleInput(el) && isStandaloneLoginUsernameInput(el)) ||
            findUsernameFieldNear(document.body);

      if (targetUser) {
        setNativeInputValue(targetUser, username);
        persistStep1Username(username);
        return { filled: true, mode: "username_only" };
      }
    }

    return { filled: false, mode: "none" };
  }

  function closeInlineMenu() {
    if (activeMenuEl) {
      activeMenuEl.remove();
      activeMenuEl = null;
    }
    activeMenuMode = "";
    activeMenuFilterFn = null;
    activeMenuAnchor = null;
  }

  const DROPDOWN_PAGE_SIZE = 40;
  const INLINE_MENU_CSS = `
    .ov-panel {
      position: fixed;
      z-index: 2147483646;
      background: rgba(255, 255, 255, 0.99);
      border: 1.5px solid #BBD0EA;
      border-radius: 12px;
      box-shadow: 0 12px 30px rgba(7, 14, 26, 0.18);
      padding: 6px;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      color: #070E1A;
      box-sizing: border-box;
      pointer-events: auto;
    }
    .ov-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 6px;
      padding: 4px 8px 6px;
      border-bottom: 1px solid #DCE8F8;
      font-size: 11.2px;
      font-weight: 800;
      color: #1D4ED8;
    }
    .ov-badge {
      background: #E6EFFD;
      color: #1D4ED8;
      border: 1px solid #BFD6F8;
      border-radius: 999px;
      padding: 1px 7px;
      font-size: 10.5px;
      font-weight: 800;
      white-space: nowrap;
      flex-shrink: 0;
    }
    .ov-search-wrap {
      padding: 5px 2px 2px;
    }
    .ov-search {
      width: 100%;
      box-sizing: border-box;
      padding: 6px 9px;
      border: 1.2px solid #BBD0EA;
      border-radius: 8px;
      background: #F8FBFF;
      color: #070E1A;
      font-size: 12px;
      font-weight: 600;
      outline: none;
      font-family: inherit;
    }
    .ov-list {
      overflow-y: auto;
      overscroll-behavior: contain;
      display: flex;
      flex-direction: column;
      gap: 2px;
      margin-top: 4px;
      padding-right: 2px;
    }
    .ov-row {
      display: flex;
      flex-direction: column;
      align-items: flex-start;
      width: 100%;
      border: none;
      background: transparent;
      cursor: pointer;
      padding: 5px 8px;
      border-radius: 7px;
      text-align: left;
      box-sizing: border-box;
      font-family: inherit;
    }
    .ov-row:hover {
      background: #EAF2FC;
    }
    .ov-title {
      font-size: 12.2px;
      font-weight: 800;
      color: #070E1A;
      width: 100%;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .ov-sub {
      font-size: 10.8px;
      font-weight: 600;
      color: #26364B;
      margin-top: 1px;
      width: 100%;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .ov-empty {
      padding: 10px 8px;
      text-align: center;
      font-size: 11.8px;
      color: #475B76;
      font-weight: 600;
    }
    .ov-lock-body {
      padding: 5px 2px 2px;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .ov-lock-btn {
      width: 100%;
      border: none;
      border-radius: 8px;
      padding: 7px 10px;
      background: #1D4ED8;
      color: #FFFFFF;
      font-size: 12px;
      font-weight: 800;
      cursor: pointer;
      font-family: inherit;
    }
    .ov-lock-btn:hover {
      background: #1E40AF;
    }
  `;
  let sharedInlineMenuSheet = null;

  function getInlineMenuStyleSheet() {
    if (sharedInlineMenuSheet) return sharedInlineMenuSheet;
    if (typeof CSSStyleSheet === "function") {
      try {
        const sheet = new CSSStyleSheet();
        if (typeof sheet.replaceSync === "function") {
          sheet.replaceSync(INLINE_MENU_CSS);
          sharedInlineMenuSheet = sheet;
          return sheet;
        }
      } catch (_) {}
    }
    return null;
  }

  function prepareDomainMatches(rawList) {
    return (Array.isArray(rawList) ? rawList : []).map((m) => ({
      ...m,
      foldedUser: normalizeVi(String(m.username || "").trim()),
      foldedTitle: normalizeVi(String(m.service_name || "").trim())
    }));
  }

  function computeAnchorScreenRect(anchorInput) {
    try {
      const rect = anchorInput && anchorInput.getBoundingClientRect ? anchorInput.getBoundingClientRect() : null;
      const chromeTopOffset = Math.max(0, (window.outerHeight || 0) - (window.innerHeight || 0));
      const baseLeft = Number(window.screenX ?? window.screenLeft ?? 0) || 0;
      const baseTop = Number(window.screenY ?? window.screenTop ?? 0) || 0;
      return {
        screenLeft: Math.round(baseLeft + (rect ? rect.left : 80)),
        screenTop: Math.round(baseTop + chromeTopOffset + (rect ? rect.bottom + 8 : 120)),
        availLeft: Number(window.screen?.availLeft) || 0,
        availTop: Number(window.screen?.availTop) || 0,
        screenWidth: Number(window.screen?.availWidth || window.screen?.width || 0),
        screenHeight: Number(window.screen?.availHeight || window.screen?.height || 0)
      };
    } catch (_) {
      return null;
    }
  }

  function requestInlineUnlockForAnchor(anchorInput, isStep1User = false) {
    if (!isSafePageOrigin()) return;
    pendingUnlockAnchor = {
      input: anchorInput || null,
      isStep1User: Boolean(isStep1User),
      savedAt: Date.now()
    };
    const anchorRect = computeAnchorScreenRect(anchorInput);
    safeSendMessage({ type: "OPEN_INLINE_UNLOCK_PROMPT", anchorRect }, (res) => {
      if (res && res.alreadyUnlocked && anchorInput && anchorInput.isConnected) {
        const isPw = isPasswordLikeInput(anchorInput);
        const preferredUsername = isPw ? extractBestUsernameNear(anchorInput) : String(anchorInput.value || "").trim();
        safeSendMessage({ type: "GET_DOMAIN_MATCHES", preferredUsername }, (mRes) => {
          if (!mRes || !mRes.paired || mRes.locked) return;
          if (mRes.step1Username && !step1UsernameMem) {
            step1UsernameMem = String(mRes.step1Username).trim();
            step1UsernameSavedAt = Date.now();
          }
          const list = prepareDomainMatches(mRes.matches);
          domainMatchCache = { fetchedAt: Date.now(), matches: list, paired: true, locked: false };
          if (list.length > 0) {
            showInlineAutofillMenu(anchorInput, list, Boolean(isStep1User));
          }
        });
      }
    });
  }

  function computeControlledWheelDelta(ev, maxStepPx = 42, discreteScale = 0.36, touchpadScale = 0.55) {
    let raw = Number(ev && ev.deltaY) || 0;
    if (!Number.isFinite(raw) || raw === 0) return 0;
    if (ev.deltaMode === 1) {
      raw *= 16; // DOM_DELTA_LINE
    } else if (ev.deltaMode === 2) {
      raw *= 120; // DOM_DELTA_PAGE
    }
    const absRaw = Math.abs(raw);
    // Continuous, strictly monotonic transfer curve (no speed drop cliff at 35px!)
    const knee = 35;
    const kneeOut = knee * touchpadScale;
    const target120 = Math.min(maxStepPx, 120 * discreteScale);
    const tailSlope = target120 > kneeOut ? (target120 - kneeOut) / (120 - knee) : discreteScale;
    const mag = absRaw <= knee ? absRaw * touchpadScale : kneeOut + (absRaw - knee) * tailSlope;
    const clamped = Math.min(maxStepPx, mag);
    return raw < 0 ? -clamped : clamped;
  }

  function showInlineLockedPrompt(anchorInput, isStep1User = false, _deviceNameHint = "") {
    if (!anchorInput || !isSafePageOrigin()) return;
    if (activeMenuEl && activeMenuAnchor === anchorInput && activeMenuMode === "locked") {
      return;
    }
    closeInlineMenu();

    const rect = anchorInput.getBoundingClientRect();
    const panelWidth = Math.max(204, Math.min(248, rect.width || 220));
    const spaceBelow = window.innerHeight - rect.bottom - 12;
    const spaceAbove = rect.top - 12;
    const placeAbove = spaceBelow < 96 && spaceAbove > spaceBelow;
    const leftPx = Math.max(8, Math.min(window.innerWidth - panelWidth - 8, rect.left));

    const host = document.createElement("div");
    // HIGH-EXT-01 / H6: Keep Light-DOM host geometry, display, and attributes strictly invariant (no data-ov-mode!)
    host.style.cssText =
      "all: initial; position: fixed; z-index: 2147483646; top: 0; left: 0; width: 0; height: 0; overflow: visible; pointer-events: none; display: block;";
    const shadow = host.attachShadow({ mode: "closed" });

    const sheet = getInlineMenuStyleSheet();
    if (sheet && "adoptedStyleSheets" in shadow) {
      try {
        shadow.adoptedStyleSheets = [sheet];
      } catch (_) {
        const styleEl = document.createElement("style");
        styleEl.textContent = INLINE_MENU_CSS;
        shadow.appendChild(styleEl);
      }
    } else {
      const styleEl = document.createElement("style");
      styleEl.textContent = INLINE_MENU_CSS;
      shadow.appendChild(styleEl);
    }

    const panel = document.createElement("div");
    panel.className = "ov-panel";
    panel.style.left = `${leftPx}px`;
    panel.style.width = `${panelWidth}px`;
    if (placeAbove) {
      panel.style.bottom = `${Math.max(8, window.innerHeight - rect.top + 5)}px`;
    } else {
      panel.style.top = `${Math.max(8, rect.bottom + 5)}px`;
    }
    for (const evtName of ["keydown", "keyup", "keypress"]) {
      panel.addEventListener(evtName, (ev) => ev.stopPropagation());
    }
    panel.addEventListener(
      "wheel",
      (ev) => {
        if (!ev.isTrusted || ev.ctrlKey) return;
        ev.preventDefault();
        ev.stopPropagation();
      },
      { passive: false }
    );

    const header = document.createElement("div");
    header.className = "ov-header";
    const headerTitle = document.createElement("span");
    headerTitle.textContent = "🔒 OmniVault đang khóa";
    header.appendChild(headerTitle);
    panel.appendChild(header);

    const body = document.createElement("div");
    body.className = "ov-lock-body";

    const unlockBtn = document.createElement("button");
    unlockBtn.type = "button";
    unlockBtn.className = "ov-lock-btn";
    unlockBtn.textContent = "🔓 Nhập PIN để mở khóa";
    unlockBtn.addEventListener("mousedown", (ev) => {
      if (!ev.isTrusted) return;
      ev.preventDefault();
      ev.stopPropagation();
      closeInlineMenu();
      requestInlineUnlockForAnchor(anchorInput, isStep1User);
    });

    body.appendChild(unlockBtn);
    panel.appendChild(body);

    shadow.appendChild(panel);
    document.documentElement.appendChild(host);
    activeMenuEl = host;
    activeMenuMode = "locked";
    activeMenuAnchor = anchorInput;
    activeMenuFilterFn = null;
  }

  function showInlineAutofillMenu(anchorInput, matches, isStep1UserOnly = false) {
    closeInlineMenu();
    if (!matches || matches.length === 0 || !isSafePageOrigin()) return;

    const preparedMatches =
      typeof matches[0].foldedUser === "string" ? matches : prepareDomainMatches(matches);

    const rect = anchorInput.getBoundingClientRect();
    const showSearch = preparedMatches.length > 5;
    const panelWidth = Math.max(248, Math.min(312, rect.width));
    const spaceBelow = window.innerHeight - rect.bottom - 12;
    const spaceAbove = rect.top - 12;
    const placeAbove = spaceBelow < 210 && spaceAbove > spaceBelow;
    const availHeight = Math.max(165, Math.min(340, placeAbove ? spaceAbove : spaceBelow));
    const chromeHeight = showSearch ? 78 : 40;
    const listMaxHeight = Math.max(110, Math.min(252, availHeight - chromeHeight));
    const leftPx = Math.max(8, Math.min(window.innerWidth - panelWidth - 8, rect.left));

    const host = document.createElement("div");
    // HIGH-EXT-01: Keep Light-DOM host geometry & display strictly invariant so page JS cannot probe filter results.
    host.style.cssText =
      "all: initial; position: fixed; z-index: 2147483646; top: 0; left: 0; width: 0; height: 0; overflow: visible; pointer-events: none; display: block;";
    const shadow = host.attachShadow({ mode: "closed" });

    const sheet = getInlineMenuStyleSheet();
    if (sheet && "adoptedStyleSheets" in shadow) {
      try {
        shadow.adoptedStyleSheets = [sheet];
      } catch (_) {
        const styleEl = document.createElement("style");
        styleEl.textContent = INLINE_MENU_CSS;
        shadow.appendChild(styleEl);
      }
    } else {
      const styleEl = document.createElement("style");
      styleEl.textContent = INLINE_MENU_CSS;
      shadow.appendChild(styleEl);
    }

    const panel = document.createElement("div");
    panel.className = "ov-panel";
    panel.style.left = `${leftPx}px`;
    panel.style.width = `${panelWidth}px`;
    if (placeAbove) {
      panel.style.bottom = `${Math.max(8, window.innerHeight - rect.top + 5)}px`;
    } else {
      panel.style.top = `${Math.max(8, rect.bottom + 5)}px`;
    }
    for (const evtName of ["keydown", "keyup", "keypress"]) {
      panel.addEventListener(evtName, (ev) => ev.stopPropagation());
    }

    const header = document.createElement("div");
    header.className = "ov-header";
    const headerTitle = document.createElement("span");
    headerTitle.textContent = isStep1UserOnly
      ? "OmniVault — Chọn tài khoản (Bước 1)"
      : "OmniVault — Chọn tài khoản tự điền";
    const countBadge = document.createElement("span");
    countBadge.className = "ov-badge";
    countBadge.textContent = `${preparedMatches.length} TK`;
    header.appendChild(headerTitle);
    header.appendChild(countBadge);
    panel.appendChild(header);

    let searchBox = null;
    if (showSearch) {
      const searchWrap = document.createElement("div");
      searchWrap.className = "ov-search-wrap";
      searchBox = document.createElement("input");
      searchBox.className = "ov-search";
      searchBox.type = "text";
      searchBox.placeholder = `🔎 Tìm nhanh trong ${preparedMatches.length} tài khoản...`;
      searchBox.autocomplete = "off";
      searchBox.spellcheck = false;
      searchBox.addEventListener("mousedown", (ev) => ev.stopPropagation());
      searchBox.addEventListener("input", () => renderList(searchBox.value, true));
      searchWrap.appendChild(searchBox);
      panel.appendChild(searchWrap);
    }

    const listWrap = document.createElement("div");
    listWrap.className = "ov-list";
    listWrap.style.maxHeight = `${listMaxHeight}px`;
    panel.appendChild(listWrap);

    // Smooth, controlled mouse-wheel scrolling (~1 row/notch) with sub-pixel Precision Touchpad accumulation!
    let wheelRem = 0;
    let lastWheelAt = 0;
    panel.addEventListener(
      "wheel",
      (ev) => {
        if (!ev.isTrusted || ev.ctrlKey) return;
        const scaledDelta = computeControlledWheelDelta(ev, 42, 0.36, 0.55);
        ev.preventDefault();
        ev.stopPropagation();
        if (scaledDelta !== 0 && listWrap.scrollHeight > listWrap.clientHeight) {
          const now = Date.now();
          if (now - lastWheelAt > 150 || (scaledDelta > 0 && wheelRem < 0) || (scaledDelta < 0 && wheelRem > 0)) {
            wheelRem = 0;
          }
          lastWheelAt = now;
          wheelRem += scaledDelta;
          const delta = Math.trunc(wheelRem + (wheelRem >= 0 ? 1e-9 : -1e-9));
          wheelRem -= delta;
          if (Math.abs(wheelRem) < 1e-9) wheelRem = 0;
          if (delta !== 0) {
            listWrap.scrollTop += delta;
          }
        }
      },
      { passive: false }
    );

    const isPwAnchor = isPasswordLikeInput(anchorInput);
    const useUserPrimary =
      preparedMatches.length > 1 ||
      preparedMatches.some(
        (it) =>
          it.domain &&
          String(it.service_name || "").trim().toLowerCase() === String(it.domain || "").trim().toLowerCase()
      );

    let currentFiltered = preparedMatches;
    let renderedCount = 0;

    const selectItem = (m) => {
      closeInlineMenu();
      safeSendMessage(
        {
          type: "REQUEST_CREDENTIAL_FILL",
          itemId: m.id,
          step1Only: isStep1UserOnly
        },
        (res) => {
          if (!res || !res.ok) return;
          fillCredentialsOnPage(res.username || "", res.password || "", anchorInput);
        }
      );
    };

    // Single delegated mousedown handler on list container (replaces 3*M per-item closures!)
    listWrap.addEventListener("mousedown", (ev) => {
      if (!ev.isTrusted) return;
      const targetEl = ev.target instanceof Element ? ev.target : ev.target?.parentElement;
      const btn = targetEl && targetEl.closest ? targetEl.closest("button.ov-row") : null;
      if (!btn) return;
      ev.preventDefault();
      ev.stopPropagation();
      const idx = Number(btn.dataset.ovIdx);
      const chosen = Number.isInteger(idx) ? currentFiltered[idx] : null;
      if (chosen) {
        selectItem(chosen);
      }
    });

    const appendNextBatch = () => {
      if (renderedCount >= currentFiltered.length) return;
      const end = Math.min(currentFiltered.length, renderedCount + DROPDOWN_PAGE_SIZE);
      const frag = document.createDocumentFragment();
      for (let i = renderedCount; i < end; i++) {
        const m = currentFiltered[i];
        const row = document.createElement("button");
        row.type = "button";
        row.className = "ov-row";
        row.dataset.ovIdx = String(i);

        const title = document.createElement("div");
        title.className = "ov-title";

        const sub = document.createElement("div");
        sub.className = "ov-sub";

        const starPrefix = m.is_favorite ? "★ " : "";
        if (m.username && useUserPrimary) {
          title.textContent = `${starPrefix}${m.username}`;
          const baseSub = m.service_name || m.domain || "Tài khoản đã lưu";
          sub.textContent = m.step1_matched ? `✓ Khớp bước 1 • ${baseSub}` : baseSub;
        } else {
          title.textContent = `${starPrefix}${m.service_name || "Tài khoản"}`;
          const domainTag =
            m.domain && !String(m.service_name || "").toLowerCase().includes(String(m.domain).toLowerCase())
              ? m.domain
              : "";
          const baseSub = domainTag
            ? `${m.username || "Điền mật khẩu"} • ${domainTag}`
            : m.username || "Điền mật khẩu đã lưu";
          sub.textContent = m.step1_matched ? `✓ Khớp bước 1 • ${baseSub}` : baseSub;
        }

        row.appendChild(title);
        row.appendChild(sub);
        frag.appendChild(row);
      }
      listWrap.appendChild(frag);
      renderedCount = end;
    };

    listWrap.addEventListener(
      "scroll",
      () => {
        if (
          renderedCount < currentFiltered.length &&
          listWrap.scrollTop + listWrap.clientHeight >= listWrap.scrollHeight - 40
        ) {
          appendNextBatch();
        }
      },
      { passive: true }
    );

    const renderList = (rawFilter = "", fromSearchBox = false) => {
      const qNorm = normalizeVi(String(rawFilter || "").trim());
      if (!qNorm) {
        currentFiltered = preparedMatches;
      } else if (!isPwAnchor) {
        currentFiltered = preparedMatches.filter(
          (m) => Boolean(m.foldedUser) && m.foldedUser.startsWith(qNorm)
        );
      } else {
        currentFiltered = preparedMatches.filter((m) =>
          m.foldedUser ? m.foldedUser.startsWith(qNorm) : m.foldedTitle.startsWith(qNorm)
        );
      }

      // Toggle visibility strictly inside closed ShadowRoot — NEVER mutate Light-DOM host.style.display!
      if (!isPwAnchor && !fromSearchBox && qNorm && currentFiltered.length === 0) {
        panel.style.display = "none";
      } else {
        panel.style.display = "block";
      }

      countBadge.textContent = qNorm
        ? `${currentFiltered.length}/${preparedMatches.length} TK`
        : `${preparedMatches.length} TK`;

      listWrap.textContent = "";
      listWrap.scrollTop = 0;
      renderedCount = 0;

      if (currentFiltered.length === 0) {
        const emptyRow = document.createElement("div");
        emptyRow.className = "ov-empty";
        emptyRow.textContent = "Không có tài khoản nào bắt đầu bằng ký tự vừa nhập.";
        listWrap.appendChild(emptyRow);
        return;
      }

      appendNextBatch();
    };

    if (searchBox) {
      searchBox.addEventListener("keydown", (ev) => {
        if (ev.key === "Escape") {
          ev.preventDefault();
          closeInlineMenu();
          try {
            anchorInput.focus();
          } catch (_) {}
        } else if (ev.key === "Enter" && ev.isTrusted && currentFiltered.length > 0) {
          ev.preventDefault();
          selectItem(currentFiltered[0]);
        }
      });
    }

    let initVal = "";
    if (!isPwAnchor) {
      initVal = String(anchorInput.value || "");
    } else {
      const nearbyUser = extractBestUsernameNear(anchorInput);
      const nearFolded = normalizeVi(nearbyUser);
      if (nearFolded && preparedMatches.some((m) => m.foldedUser && m.foldedUser.startsWith(nearFolded))) {
        initVal = nearbyUser;
      }
    }
    if (searchBox && initVal) searchBox.value = initVal;
    renderList(initVal, false);

    shadow.appendChild(panel);
    document.documentElement.appendChild(host);
    activeMenuEl = host;
    activeMenuMode = "autofill";
    activeMenuAnchor = anchorInput;
    activeMenuFilterFn = !isPwAnchor
      ? (typedVal) => {
          if (searchBox) searchBox.value = typedVal;
          renderList(typedVal, false);
        }
      : null;
  }

  function resolveEventElement(e) {
    if (typeof e.composedPath === "function") {
      const path = e.composedPath();
      if (Array.isArray(path) && path[0] instanceof Element) {
        return path[0];
      }
    }
    return e.target instanceof Element ? e.target : null;
  }

  function resolveEventInput(e) {
    const el = resolveEventElement(e);
    return el instanceof HTMLInputElement ? el : null;
  }

  function persistStep1Username(rawUser) {
    const u = String(rawUser || "").trim();
    if (!u) return;
    step1UsernameMem = u;
    step1UsernameSavedAt = Date.now();
    liveCredCache.username = u;
    liveCredCache.updatedAt = Date.now();
    safeSendMessage({ type: "SET_STEP1_USERNAME", username: u });
  }

  function updateLiveCredFromInput(el, precomputed = null) {
    if (!(el instanceof HTMLInputElement) || !isSafePageOrigin()) return;
    const isPw = precomputed && typeof precomputed.isPw === "boolean" ? precomputed.isPw : isPasswordLikeInput(el);
    if (isPw) {
      if (el.value) {
        const directUser = extractBestUsernameNear(el, { allowFallback: false });
        const hasCurrentPw = Boolean(extractCurrentPasswordNear(el));
        const resolvedUser =
          directUser || (hasCurrentPw ? "" : extractBestUsernameNear(el) || liveCredCache.username);
        liveCredCache = {
          pwEl: el,
          username: resolvedUser,
          password: el.value,
          updatedAt: Date.now()
        };
      }
      return;
    }
    const isStandaloneUser =
      precomputed && typeof precomputed.isStandaloneUser === "boolean"
        ? precomputed.isStandaloneUser
        : isStandaloneLoginUsernameInput(el);
    if (isStandaloneUser && el.value.trim()) {
      const u = el.value.trim();
      liveCredCache.username = u;
      liveCredCache.updatedAt = Date.now();
      const hasVisiblePw =
        precomputed && typeof precomputed.hasVisiblePw === "boolean"
          ? precomputed.hasVisiblePw
          : hasVisiblePasswordOnPage();
      if (!hasVisiblePw) {
        persistStep1Username(u);
      }
    }
  }

  function triggerLoginInputMenuIfNeeded(t) {
    if (tornDown || !t || !isVisibleInput(t) || !isSafePageOrigin()) return;
    if (activeMenuEl && activeMenuAnchor === t) return;
    const isPw = isPasswordLikeInput(t);
    const hasVisiblePwOnPage = isPw || hasVisiblePasswordOnPage();
    const isStandaloneUser = !isPw && isStandaloneLoginUsernameInput(t);
    const isStep1User = isStandaloneUser && !hasVisiblePwOnPage;
    const isPairedUserNextToPw = isStandaloneUser && hasVisiblePwOnPage;

    if (!isPw && !isStep1User && !isPairedUserNextToPw) return;

    // H8: Deduplicate focusin + click double IPC on the same input within 250ms
    const now = Date.now();
    if (pendingMatchAnchor === t) return;
    if (lastMatchTriggerEl === t && now - lastMatchTriggerAt < 250) return;
    pendingMatchAnchor = t;
    lastMatchTriggerEl = t;
    lastMatchTriggerAt = now;

    const preferredUsername = isPw ? extractBestUsernameNear(t) : String(t.value || "").trim();
    safeSendMessage({ type: "GET_DOMAIN_MATCHES", preferredUsername }, (res) => {
      if (pendingMatchAnchor === t) pendingMatchAnchor = null;
      if (tornDown || !t.isConnected) return;
      if (!res || !res.paired) {
        domainMatchCache = { fetchedAt: Date.now(), matches: [], paired: false, locked: false };
        return;
      }
      if (res.locked) {
        domainMatchCache = { fetchedAt: 0, matches: [], paired: true, locked: true };
        showInlineLockedPrompt(t, isStep1User, res.deviceNameHint || "");
        return;
      }
      if (res.step1Username && !step1UsernameMem) {
        step1UsernameMem = String(res.step1Username).trim();
        step1UsernameSavedAt = Date.now();
      }
      const list = prepareDomainMatches(res.matches);
      domainMatchCache = { fetchedAt: Date.now(), matches: list, paired: true, locked: false };
      if (list.length > 0) {
        showInlineAutofillMenu(t, list, isStep1User);
      }
    });
  }

  document.addEventListener(
    "focusin",
    (e) => {
      if (!e.isTrusted) return;
      if (!chrome?.runtime?.id) {
        teardownContentScript();
        return;
      }
      registerShadowHostsFromEvent(e);
      if (isOwnOverlayEvent(e) || !isSafePageOrigin()) return;
      const t = resolveEventInput(e);
      triggerLoginInputMenuIfNeeded(t);
    },
    { capture: true, signal: lifecycleSignal }
  );

  document.addEventListener(
    "input",
    (e) => {
      if (!e.isTrusted) return;
      if (!chrome?.runtime?.id) {
        teardownContentScript();
        return;
      }
      if (isOwnOverlayEvent(e)) return;
      const el = resolveEventInput(e);
      if (!el || !isSafePageOrigin()) return;

      // Single-pass input handling (eliminates duplicate queryAllInputsDeep + visibility scans per keystroke)
      const isPw = isPasswordLikeInput(el);
      if (isPw) {
        updateLiveCredFromInput(el, { isPw: true });
        return;
      }

      if (el === activeMenuAnchor && activeMenuFilterFn) {
        const val = el.value || "";
        if (val.trim()) {
          liveCredCache.username = val.trim();
          liveCredCache.updatedAt = Date.now();
          if (!hasVisiblePasswordOnPage()) {
            persistStep1Username(val.trim());
          }
        }
        activeMenuFilterFn(val);
        return;
      }

      const isStandaloneUser = isStandaloneLoginUsernameInput(el);
      if (!isStandaloneUser) return;

      const hasVisiblePwOnPage = hasVisiblePasswordOnPage();
      updateLiveCredFromInput(el, {
        isPw: false,
        isStandaloneUser: true,
        hasVisiblePw: hasVisiblePwOnPage
      });

      if (!activeMenuEl && isVisibleInput(el)) {
        const isStep1User = !hasVisiblePwOnPage;
        const cacheFresh = Date.now() - domainMatchCache.fetchedAt < 12000;
        // H8: Respect 12s cache even when matches.length === 0 or !paired to prevent per-keystroke SW IPC storms!
        if (cacheFresh && !domainMatchCache.locked) {
          if (domainMatchCache.paired && domainMatchCache.matches.length > 0) {
            showInlineAutofillMenu(el, domainMatchCache.matches, isStep1User);
          }
        } else if (pendingMatchAnchor !== el) {
          pendingMatchAnchor = el;
          const preferredUsername = String(el.value || "").trim();
          safeSendMessage({ type: "GET_DOMAIN_MATCHES", preferredUsername }, (res) => {
            if (pendingMatchAnchor === el) pendingMatchAnchor = null;
            if (tornDown || !el.isConnected) return;
            if (!res || !res.paired) {
              domainMatchCache = { fetchedAt: Date.now(), matches: [], paired: false, locked: false };
              return;
            }
            if (res.locked) {
              domainMatchCache = { fetchedAt: 0, matches: [], paired: true, locked: true };
              showInlineLockedPrompt(el, isStep1User, res.deviceNameHint || "");
              return;
            }
            const list = prepareDomainMatches(res.matches);
            domainMatchCache = { fetchedAt: Date.now(), matches: list, paired: true, locked: false };
            if (list.length > 0) {
              showInlineAutofillMenu(el, list, isStep1User);
            }
          });
        }
      }
    },
    { capture: true, signal: lifecycleSignal }
  );

  document.addEventListener(
    "change",
    (e) => {
      if (!e.isTrusted) return;
      if (!chrome?.runtime?.id) {
        teardownContentScript();
        return;
      }
      if (isOwnOverlayEvent(e)) return;
      updateLiveCredFromInput(resolveEventInput(e));
    },
    { capture: true, signal: lifecycleSignal }
  );

  document.addEventListener(
    "mousedown",
    (e) => {
      if (activeMenuEl && !isOwnOverlayEvent(e) && resolveEventElement(e) !== activeMenuAnchor) {
        closeInlineMenu();
      }
    },
    { capture: true, signal: lifecycleSignal }
  );

  window.addEventListener("scroll", closeInlineMenu, { passive: true, signal: lifecycleSignal });
  window.addEventListener("pagehide", cancelPendingAckTimers, { signal: lifecycleSignal });
  window.addEventListener("beforeunload", cancelPendingAckTimers, { signal: lifecycleSignal });

  // Render auto-save / confirm-update / undo / locked notice inside closed Shadow DOM
  function showCaptureNoticeBanner(notice) {
    if (tornDown || !notice || !isSafePageOrigin()) return;
    if (notice.kind === "unpaired") {
      if (unpairedHintShownInPage) return;
      unpairedHintShownInPage = true;
      safeSendMessage({ type: "MARK_UNPAIRED_HINT_SHOWN" }, (res) => {
        if (tornDown) return;
        if (res && res.alreadyShown) return;
        mountCaptureNoticeBanner(notice);
      });
      return;
    }
    mountCaptureNoticeBanner(notice);
  }

  function mountCaptureNoticeBanner(notice) {
    if (tornDown || !notice || !isSafePageOrigin()) return;

    const mount = () => {
      if (!document.documentElement) return;
      if (saveBannerEl) saveBannerEl.remove();

      const outer = document.createElement("div");
      outer.style.cssText =
        "all: initial; position: fixed; top: 0; right: 0; width: 0; height: 0; overflow: visible; pointer-events: none; z-index: 2147483647;";
      const shadow = outer.attachShadow({ mode: "closed" });

      const box = document.createElement("div");
      box.style.cssText = `
        position: fixed; top: 16px; right: 16px; z-index: 2147483647;
        width: 330px; background: #FFFFFF; border: 1.5px solid #BBD0EA;
        border-radius: 14px; box-shadow: 0 14px 34px rgba(7, 14, 26, 0.22);
        padding: 13px 15px; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
        color: #070E1A; box-sizing: border-box; pointer-events: auto;
      `;

      const heading = document.createElement("div");
      const desc = document.createElement("div");
      desc.style.cssText =
        "font-size: 12.2px; font-weight: 600; color: #26364B; margin: 5px 0 11px; word-break: break-word; line-height: 1.4;";

      const actions = document.createElement("div");
      actions.style.cssText = "display: flex; gap: 8px; justify-content: flex-end;";

      let dismissTimer = null;
      const clearDismissTimer = () => {
        if (dismissTimer) {
          clearTimeout(dismissTimer);
          dismissTimer = null;
        }
      };
      const scheduleDismiss = (ms) => {
        clearDismissTimer();
        dismissTimer = setTimeout(() => {
          dismissTimer = null;
          if (outer.isConnected) outer.remove();
        }, ms);
      };

      let dismissMs = 3000;
      const summaryLine = `${notice.host || location.hostname}${notice.username ? " • " + notice.username : ""}`;

      if (notice.kind === "confirm_update") {
        dismissMs = 30000;
        heading.style.cssText = "font-size: 13.8px; font-weight: 800; color: #1D4ED8;";
        heading.textContent = "Cập nhật mật khẩu đã lưu?";
        desc.textContent = `${summaryLine} vừa đăng nhập hoặc đổi sang mật khẩu mới khác với bản đang lưu trong OmniVault.`;

        const confirmBtn = document.createElement("button");
        confirmBtn.type = "button";
        confirmBtn.textContent = "Cập nhật";
        confirmBtn.style.cssText = `
          padding: 6px 12px; border-radius: 9px; border: 1px solid #1D4ED8;
          background: #1D4ED8; color: #FFFFFF; font-size: 12px; font-weight: 700; cursor: pointer;
        `;

        const dismissBtn = document.createElement("button");
        dismissBtn.type = "button";
        dismissBtn.textContent = "Giữ bản cũ";
        dismissBtn.style.cssText = `
          padding: 6px 12px; border-radius: 9px; border: 1px solid #BBD0EA;
          background: #F1F5FB; color: #26364B; font-size: 12px; font-weight: 700; cursor: pointer;
        `;

        confirmBtn.addEventListener("click", (ev) => {
          if (!ev.isTrusted) return;
          confirmBtn.disabled = true;
          dismissBtn.disabled = true;
          confirmBtn.textContent = "Đang cập nhật...";
          safeSendMessage({ type: "CONFIRM_PENDING_UPDATE", proposalId: notice.noticeId }, (res) => {
            if (res && res.ok) {
              domainMatchCache = { fetchedAt: 0, matches: [], paired: true };
              heading.style.color = "#059669";
              heading.textContent = "✓ OmniVault đã cập nhật mật khẩu";
              desc.textContent = summaryLine;
              confirmBtn.hidden = true;
              dismissBtn.hidden = true;
              if (res.noticeId) {
                const undoBtn = document.createElement("button");
                undoBtn.type = "button";
                undoBtn.textContent = "Hoàn tác";
                undoBtn.style.cssText = `
                  padding: 6px 12px; border-radius: 9px; border: 1px solid #FCA5A5;
                  background: #FEF2F2; color: #B91C1C; font-size: 12px; font-weight: 700; cursor: pointer;
                `;
                undoBtn.addEventListener("click", (uev) => {
                  if (!uev.isTrusted) return;
                  clearDismissTimer();
                  undoBtn.disabled = true;
                  undoBtn.textContent = "Đang hoàn tác...";
                  safeSendMessage({ type: "UNDO_AUTO_SAVED_LOGIN", noticeId: res.noticeId }, (ures) => {
                    if (ures && ures.ok) {
                      domainMatchCache = { fetchedAt: 0, matches: [], paired: true };
                      heading.style.color = "#475569";
                      heading.textContent = "Đã hoàn tác cập nhật mật khẩu";
                      undoBtn.hidden = true;
                      scheduleDismiss(1200);
                    } else {
                      undoBtn.textContent = "Lỗi hoàn tác";
                      scheduleDismiss(3000);
                    }
                  });
                });
                actions.prepend(undoBtn);
              }
              scheduleDismiss(3000);
            } else {
              dismissBtn.disabled = false;
              confirmBtn.textContent = res?.error || "Hết hạn — mở OmniVault để cập nhật";
            }
          });
        });

        dismissBtn.addEventListener("click", (ev) => {
          if (!ev.isTrusted) return;
          clearDismissTimer();
          safeSendMessage({ type: "DISMISS_PENDING_UPDATE", proposalId: notice.noticeId });
          outer.remove();
        });

        actions.appendChild(dismissBtn);
        actions.appendChild(confirmBtn);
      } else if (notice.kind === "auto_saved") {
        dismissMs = 3000;
        heading.style.cssText = "font-size: 13.8px; font-weight: 800; color: #059669;";
        heading.textContent =
          notice.mode === "updated"
            ? "✓ OmniVault đã cập nhật mật khẩu"
            : "✓ OmniVault đã tự lưu mật khẩu";
        desc.textContent = summaryLine;

        const undoBtn = document.createElement("button");
        undoBtn.type = "button";
        undoBtn.textContent = "Hoàn tác";
        undoBtn.style.cssText = `
          padding: 6px 12px; border-radius: 9px; border: 1px solid #FCA5A5;
          background: #FEF2F2; color: #B91C1C; font-size: 12px; font-weight: 700; cursor: pointer;
        `;
        undoBtn.addEventListener("click", (ev) => {
          if (!ev.isTrusted) return;
          clearDismissTimer();
          undoBtn.disabled = true;
          undoBtn.textContent = "Đang hoàn tác...";
          safeSendMessage({ type: "UNDO_AUTO_SAVED_LOGIN", noticeId: notice.noticeId }, (res) => {
            if (res && res.ok) {
              heading.style.color = "#475569";
              heading.textContent = "Đã hoàn tác lưu mật khẩu";
              undoBtn.hidden = true;
              scheduleDismiss(1200);
            } else {
              undoBtn.textContent = "Lỗi hoàn tác";
              scheduleDismiss(3000);
            }
          });
        });
        actions.appendChild(undoBtn);
      } else if (notice.kind === "locked_pending") {
        dismissMs = 12000;
        heading.style.cssText = "font-size: 13.8px; font-weight: 800; color: #B45309;";
        heading.textContent = "🔒 Kho OmniVault đang khóa PIN";
        desc.textContent = `Vì bảo mật, mật khẩu của ${summaryLine} chưa được giữ tạm khi kho khóa. Mở khóa ngay để tự điền hoặc lưu tài khoản.`;
        const unlockNowBtn = document.createElement("button");
        unlockNowBtn.type = "button";
        unlockNowBtn.textContent = "🔓 Mở khóa ngay";
        unlockNowBtn.style.cssText = `
          padding: 6px 12px; border-radius: 9px; border: 1px solid #1D4ED8;
          background: #1D4ED8; color: #FFFFFF; font-size: 12px; font-weight: 700; cursor: pointer;
        `;
        unlockNowBtn.addEventListener("click", (ev) => {
          if (!ev.isTrusted) return;
          clearDismissTimer();
          outer.remove();
          requestInlineUnlockForAnchor(liveCredCache.pwEl || document.activeElement, false);
        });
        actions.appendChild(unlockNowBtn);
      } else {
        dismissMs = 10000;
        heading.style.cssText = "font-size: 13.8px; font-weight: 800; color: #1D4ED8;";
        heading.textContent = "OmniVault chưa kết nối thiết bị";
        desc.textContent =
          "Bấm biểu tượng tiện ích OmniVault và dán Mã Kết Nối từ điện thoại để tự động lưu & đồng bộ mật khẩu.";
      }

      if (notice.kind !== "confirm_update") {
        const closeBtn = document.createElement("button");
        closeBtn.type = "button";
        closeBtn.textContent = "Đóng";
        closeBtn.style.cssText = `
          padding: 6px 12px; border-radius: 9px; border: 1px solid #BBD0EA;
          background: #F1F5FB; color: #26364B; font-size: 12px; font-weight: 700; cursor: pointer;
        `;
        closeBtn.addEventListener("click", (ev) => {
          if (!ev.isTrusted) return;
          clearDismissTimer();
          outer.remove();
        });
        actions.appendChild(closeBtn);
      }

      box.appendChild(heading);
      box.appendChild(desc);
      box.appendChild(actions);
      shadow.appendChild(box);
      document.documentElement.appendChild(outer);
      saveBannerEl = outer;

      scheduleDismiss(dismissMs);
    };

    if (document.documentElement) {
      mount();
    } else {
      document.addEventListener("DOMContentLoaded", mount, { once: true, signal: lifecycleSignal });
    }
  }

  function isLikelySubmitButton(btn) {
    if (!btn) return false;
    const rawType = btn.getAttribute ? btn.getAttribute("type") : null;
    const hasOwningForm = Boolean(btn.form || (btn.closest && btn.closest("form")));
    const btnType = (
      rawType ||
      (btn instanceof HTMLButtonElement && hasOwningForm
        ? "submit"
        : btn instanceof HTMLInputElement
        ? btn.type
        : "")
    ).toLowerCase();
    const aria = btn.getAttribute ? btn.getAttribute("aria-label") || "" : "";
    const title = btn.title || "";
    const id = btn.id || "";
    const cls = typeof btn.className === "string" ? btn.className : "";
    const txt = btn.textContent || "";
    const val = btn.value || "";
    const btnMeta = normalizeVi(`${aria} ${title} ${id} ${cls} ${txt} ${val}`);
    const labelMeta = normalizeVi(`${aria} ${title} ${txt} ${val}`).trim();

    if (
      /(show|hide|view|toggle|visibility|eye|reveal|hien|an.?mat.?khau|clear|xoa|reset|cancel|huy|close|dong|back|quay.?lai|forgot|quen|help|tro.?giup|copy|sao.?chep|generate|tao.?mat.?khau)/i.test(
        btnMeta
      )
    ) {
      return false;
    }

    const explicitAuthCue =
      /(dang.?nhap|dang.?ky|login|log.?in|sign.?in|signin|sign.?up|signup|register|doi.?mat.?khau|change.?password|reset.?password|mat.?khau|password|auth|authenticate|logon|log.?on)/i;
    const genericNonAuthCue =
      /(?:^|\b)(save|luu|next|tiep|tiep.?theo|tiep.?tuc|continue|done|xong|finish|hoan.?tat)(?:\b|$)/i;

    // AF-03 / INV-06: Generic "save"/"luu"/"next"/"tiep" buttons must never trigger credential capture
    // unless explicitly paired with an authentication/password label.
    if (genericNonAuthCue.test(labelMeta) && !explicitAuthCue.test(labelMeta)) {
      return false;
    }

    if (btnType === "submit" || btnType === "image") {
      if (!rawType && !txt.trim()) {
        const rect = btn.getBoundingClientRect ? btn.getBoundingClientRect() : { width: 0 };
        if (
          rect.width > 0 &&
          rect.width < 46 &&
          !/(submit|login|signin|dang.?nhap|enter)/i.test(btnMeta)
        ) {
          return false;
        }
      }
      return true;
    }

    return explicitAuthCue.test(btnMeta);
  }

  // Strictly for forms/dialogs that ALREADY contain a genuine visible filled <input type="password">
  // (e.g. Change Password / Reset Password pages whose button says "Lưu", "Save changes", "Cập nhật", "Xác nhận").
  function isPasswordChangeSubmitButton(btn, hasFilledPassword) {
    if (!btn || !hasFilledPassword) return false;
    const rawType = btn.getAttribute ? btn.getAttribute("type") : null;
    const hasOwningForm = Boolean(btn.form || (btn.closest && btn.closest("form")));
    const btnType = (
      rawType ||
      (btn instanceof HTMLButtonElement && hasOwningForm
        ? "submit"
        : btn instanceof HTMLInputElement
        ? btn.type
        : "")
    ).toLowerCase();
    const aria = btn.getAttribute ? btn.getAttribute("aria-label") || "" : "";
    const title = btn.title || "";
    const id = btn.id || "";
    const cls = typeof btn.className === "string" ? btn.className : "";
    const txt = btn.textContent || "";
    const val = btn.value || "";
    const btnMeta = normalizeVi(`${aria} ${title} ${id} ${cls} ${txt} ${val}`).trim();
    const labelMeta = normalizeVi(`${aria} ${title} ${txt} ${val}`).trim();
    if (
      /(?:^|\b)(show|hide|view|toggle|visibility|eye|reveal|hien|an.?mat.?khau|clear|xoa|reset|cancel|huy|close|dong|back|quay.?lai|forgot|quen|help|tro.?giup|copy|sao.?chep|generate|tao.?mat.?khau)(?:\b|$)/i.test(
        btnMeta
      )
    ) {
      return false;
    }
    // M1: Block unrelated social / messaging / draft / sharing buttons even if a password field exists nearby
    if (
      /(?:^|\b)(theo.?doi|bo.?theo.?doi|follow|unfollow|gui.?tin.?nhan|tin.?nhan|nhan.?tin|send.?message|message|chat|binh.?luan|comment|reply|tra.?loi|luu.?nhap|save.?draft|draft|nhap|chia.?se|share|dang.?bai|bookmark|yeu.?thich|like|thich)(?:\b|$)/i.test(
        labelMeta || btnMeta
      )
    ) {
      return false;
    }
    if (btnType === "submit" || btnType === "image") {
      return true;
    }
    return /(?:^|\b)(save|save.?changes|luu|luu.?thay.?doi|cap.?nhat|update|xac.?nhan|confirm|dong.?y|hoan.?tat|finish|done|tiep.?tuc|continue|apply|ap.?dung|submit|doi.?mat.?khau|thay.?doi|change.?password|change)(?:\b|$)/i.test(
      labelMeta || btnMeta
    );
  }

  let lastCaptureSig = "";
  let lastCaptureAt = 0;

  function submitCapturedCredentialsNow(pwEl, scopeRoot = null) {
    if (tornDown || !isSafePageOrigin()) return;
    const fallbackPw = Date.now() - liveCredCache.updatedAt < 120_000 ? liveCredCache.password : "";
    const password = (pwEl && pwEl.value) || fallbackPw;
    if (!password) return;

    const refEl = pwEl || liveCredCache.pwEl || document.body;
    const currentPassword = pwEl ? extractCurrentPasswordNear(pwEl, scopeRoot) : "";
    const directUser = extractBestUsernameNear(refEl, { allowFallback: false });
    // H5: On multi-password change-password forms without a username input in scope,
    // NEVER fall back to stale Step-1 username or page-wide [data-email] — let background.js match via currentPassword!
    const isChangePasswordForm = Boolean(currentPassword && !directUser);
    const username = isChangePasswordForm ? "" : directUser || extractBestUsernameNear(refEl);
    const sig = `${location.hostname}|${username}|${password}|${currentPassword}`;
    const now = Date.now();
    if (sig === lastCaptureSig && now - lastCaptureAt < 2500) return;
    lastCaptureSig = sig;
    lastCaptureAt = now;

    // Clear in-memory Step-1 username so subsequent forms on the same SPA cannot inherit stale state
    step1UsernameMem = "";
    step1UsernameSavedAt = 0;

    safeSendMessage(
      { type: "SUBMIT_LOGIN_CAPTURE", username, password, currentPassword, isChangePasswordForm },
      (res) => {
        if (tornDown || !res) return;
        if (
          res.notice &&
          (res.status === "auto_saved" ||
            res.status === "confirm_update" ||
            res.status === "locked_pending" ||
            res.status === "unpaired")
        ) {
          showCaptureNoticeBanner(res.notice);
          // M4: Delay ACK_TAB_CAPTURE_NOTICE by 1200ms (cancelled on pagehide/beforeunload)
          // so fast post-login redirects re-display the banner on the destination page!
          const ackNoticeId = res.notice.noticeId;
          if (ackNoticeId) {
            const ackTimer = setTimeout(() => {
              pendingAckTimers.delete(ackTimer);
              if (!tornDown) {
                safeSendMessage({ type: "ACK_TAB_CAPTURE_NOTICE", noticeId: ackNoticeId });
              }
            }, 1200);
            pendingAckTimers.add(ackTimer);
          }
        }
      }
    );
  }

  document.addEventListener(
    "submit",
    (e) => {
      if (!e.isTrusted) return;
      if (!chrome?.runtime?.id) {
        teardownContentScript();
        return;
      }
      if (!isSafePageOrigin()) return;
      const form = resolveEventElement(e);
      if (!(form instanceof HTMLFormElement)) return;
      const formInputs = queryAllInputsDeep(form);
      let pw = pickPrimaryPasswordInput(
        formInputs.filter((inp) => Boolean(inp.value) && isPasswordLikeInput(inp))
      );
      if (
        !pw &&
        liveCredCache.pwEl &&
        Date.now() - liveCredCache.updatedAt < 5000 &&
        form.contains(liveCredCache.pwEl)
      ) {
        pw = liveCredCache.pwEl;
      }
      if (!pw) {
        const step1Usr = formInputs.find(
          (inp) => Boolean(inp.value && inp.value.trim()) && isStandaloneLoginUsernameInput(inp)
        );
        if (step1Usr) {
          persistStep1Username(step1Usr.value.trim());
        }
        return;
      }
      submitCapturedCredentialsNow(pw, form);
    },
    { capture: true, signal: lifecycleSignal }
  );

  // Capture modern SPA logins & password-change forms synchronously before frameworks clear fields or redirect
  document.addEventListener(
    "click",
    (e) => {
      if (!e.isTrusted) return;
      if (!chrome?.runtime?.id) {
        teardownContentScript();
        return;
      }
      registerShadowHostsFromEvent(e);
      if (!isSafePageOrigin()) return;
      const targetEl = resolveEventElement(e);
      if (targetEl instanceof HTMLInputElement && !activeMenuEl && !isOwnOverlayEvent(e)) {
        triggerLoginInputMenuIfNeeded(targetEl);
      }
      const btn =
        targetEl && targetEl.closest
          ? targetEl.closest(
              "button, input[type='submit'], input[type='button'], input[type='image'], [role='button'], a[class*='btn'], a[class*='login'], a[class*='submit'], a[href='#'], a[href^='javascript']"
            )
          : null;
      if (!btn) return;

      // H8: Check submit-button semantics BEFORE any DOM scan or visibility layout reflow!
      const isAuthBtn = isLikelySubmitButton(btn);
      const isPwChgBtn = !isAuthBtn && isPasswordChangeSubmitButton(btn, true);
      if (!isAuthBtn && !isPwChgBtn) return;

      const scopeRoot = btn.closest("form, [role='dialog'], main, section") || document;
      const scopeInputs = queryAllInputsDeep(scopeRoot);
      let pw = pickPrimaryPasswordInput(
        scopeInputs.filter((inp) => Boolean(inp.value) && isPasswordLikeInput(inp) && isVisibleInput(inp))
      );

      // M1: Only explicit auth buttons may fall back outside scopeRoot or to visible liveCredCache.pwEl;
      // generic change-password buttons ("Lưu"/"Cập nhật") strictly require a filled visible password in the SAME scopeRoot!
      if (!pw && isAuthBtn) {
        if (scopeRoot !== document) {
          pw = pickPrimaryPasswordInput(
            queryAllInputsDeep(document).filter(
              (inp) => Boolean(inp.value) && isPasswordLikeInput(inp) && isVisibleInput(inp)
            )
          );
        }
        if (
          !pw &&
          liveCredCache.password &&
          Date.now() - liveCredCache.updatedAt < 15_000 &&
          liveCredCache.pwEl &&
          liveCredCache.pwEl.isConnected &&
          isVisibleInput(liveCredCache.pwEl)
        ) {
          pw = liveCredCache.pwEl;
        }
      }

      if (pw) {
        submitCapturedCredentialsNow(pw, scopeRoot);
      } else if (isAuthBtn) {
        const step1Usr = scopeInputs.find(
          (inp) => Boolean(inp.value && inp.value.trim()) && isStandaloneLoginUsernameInput(inp) && isVisibleInput(inp)
        );
        if (step1Usr) {
          persistStep1Username(step1Usr.value.trim());
        }
      }
    },
    { capture: true, signal: lifecycleSignal }
  );

  document.addEventListener(
    "keydown",
    (e) => {
      if (!e.isTrusted) return;
      if (!chrome?.runtime?.id) {
        teardownContentScript();
        return;
      }
      if (e.key !== "Enter" || !isSafePageOrigin()) return;
      registerShadowHostsFromEvent(e);
      const target = resolveEventInput(e);
      if (!target) return;
      if (
        isPasswordLikeInput(target) &&
        (target.value || (liveCredCache.pwEl === target && liveCredCache.password))
      ) {
        const scope = target.closest("form, [role='dialog'], main, section") || document;
        const primaryPw =
          pickPrimaryPasswordInput(
            queryAllInputsDeep(scope).filter(
              (inp) => Boolean(inp.value) && isPasswordLikeInput(inp) && isVisibleInput(inp)
            )
          ) || target;
        submitCapturedCredentialsNow(primaryPw, scope);
        return;
      }
      if (isStandaloneLoginUsernameInput(target)) {
        const scope = target.closest("form, [role='dialog'], main, section") || document;
        const pw = pickPrimaryPasswordInput(
          queryAllInputsDeep(scope).filter(
            (inp) => Boolean(inp.value) && isPasswordLikeInput(inp) && isVisibleInput(inp)
          )
        );
        if (pw) {
          submitCapturedCredentialsNow(pw, scope);
        } else if (target.value.trim()) {
          persistStep1Username(target.value.trim());
        }
      }
    },
    { capture: true, signal: lifecycleSignal }
  );

  // Listen for direct 1-tap Autofill command from Popup and proactive capture notices pushed by Service Worker
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (sender && sender.id && sender.id !== chrome.runtime.id) return false;
    if (msg && msg.type === "FILL_LOGIN_NOW") {
      if (!isSafePageOrigin()) {
        sendResponse({ filled: false, mode: "unsafe_origin" });
        return true;
      }
      const res = fillCredentialsOnPage(msg.username || "", msg.password || "");
      sendResponse({ filled: res.filled, mode: res.mode });
      return true;
    }
    if (msg && msg.type === "SHOW_TAB_CAPTURE_NOTICE" && msg.notice) {
      if (!isSafePageOrigin()) {
        sendResponse({ ok: false, shown: false });
        return true;
      }
      showCaptureNoticeBanner(msg.notice);
      sendResponse({ ok: true, shown: true });
      return true;
    }
    if (msg && msg.type === "VAULT_UNLOCKED_REFRESH_AUTOFILL") {
      if (!isSafePageOrigin()) {
        sendResponse({ ok: false });
        return true;
      }
      domainMatchCache = { fetchedAt: 0, matches: [], paired: true, locked: false };
      closeInlineMenu();

      let targetInput =
        pendingUnlockAnchor.input &&
        Date.now() - pendingUnlockAnchor.savedAt < 300_000 &&
        pendingUnlockAnchor.input.isConnected &&
        isVisibleInput(pendingUnlockAnchor.input)
          ? pendingUnlockAnchor.input
          : null;
      let isStep1User = Boolean(pendingUnlockAnchor.isStep1User);

      if (!targetInput) {
        const allInputs = queryAllInputsDeep(document);
        const visPw = allInputs.find((el) => isPasswordLikeInput(el) && isVisibleInput(el));
        const visUser = allInputs.find((el) => !isPasswordLikeInput(el) && isStandaloneLoginUsernameInput(el) && isVisibleInput(el));
        targetInput = visUser || visPw || null;
        isStep1User = Boolean(visUser && !visPw);
      }

      if (targetInput) {
        try {
          targetInput.focus();
        } catch (_) {}
        const isPw = isPasswordLikeInput(targetInput);
        const preferredUsername = isPw ? extractBestUsernameNear(targetInput) : String(targetInput.value || "").trim();
        safeSendMessage({ type: "GET_DOMAIN_MATCHES", preferredUsername }, (res) => {
          if (!res || !res.paired || res.locked) return;
          const list = prepareDomainMatches(res.matches);
          domainMatchCache = { fetchedAt: Date.now(), matches: list, paired: true, locked: false };
          if (list.length > 0 && targetInput.isConnected) {
            showInlineAutofillMenu(targetInput, list, isStep1User);
          }
        });
      }
      sendResponse({ ok: true, refreshed: Boolean(targetInput) });
      return true;
    }
    return false;
  });
})();
