@echo off
setlocal EnableExtensions
chcp 65001 >nul
set "BAT_SELF=%~f0"
set "EXT_DIR=%~dp0"
setlocal EnableDelayedExpansion
(
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $raw=[IO.File]::ReadAllText($env:BAT_SELF,[Text.Encoding]::UTF8); $m='###POWERSHELL_BELOW###'; $i=$raw.LastIndexOf($m); if($i -lt 0){exit 1}; & ([ScriptBlock]::Create($raw.Substring($i+$m.Length)))"
  set "ERR=!ERRORLEVEL!"
  echo.
  pause
  exit /b !ERR!
)

###POWERSHELL_BELOW###
$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$ExtDir = $env:EXT_DIR.TrimEnd('\')
$ManifestPath = Join-Path $ExtDir "manifest.json"
if (-not (Test-Path $ManifestPath)) {
    Write-Host "[!] Khong tim thay manifest.json trong thu muc: $ExtDir" -ForegroundColor Red
    Write-Host "    Vui long dat file nay trong thu muc tien ich OmniVault roi chay lai." -ForegroundColor Yellow
    exit 1
}

function Compare-SemVer {
    param([string]$A, [string]$B)
    $pa = ($A -replace '^v', '') -split '\.' | ForEach-Object { [int]($_ -replace '[^0-9].*$', '') }
    $pb = ($B -replace '^v', '') -split '\.' | ForEach-Object { [int]($_ -replace '[^0-9].*$', '') }
    $len = [Math]::Max($pa.Count, $pb.Count)
    for ($i = 0; $i -lt $len; $i++) {
        $va = if ($i -lt $pa.Count) { $pa[$i] } else { 0 }
        $vb = if ($i -lt $pb.Count) { $pb[$i] } else { 0 }
        if ($va -ne $vb) { return ($va - $vb) }
    }
    return 0
}

$curManifest = Get-Content -Raw -Encoding UTF8 $ManifestPath | ConvertFrom-Json
$curVer = [string]$curManifest.version
$pinnedPubKeyB64 = ([string]$curManifest.key).Trim()
if ([string]::IsNullOrWhiteSpace($pinnedPubKeyB64)) {
    Write-Host "[!] manifest.json thieu khoa cong khai RSA (key) de xac thuc ban cap nhat." -ForegroundColor Red
    exit 1
}

$spki = [Convert]::FromBase64String($pinnedPubKeyB64)
if ($spki.Length -ne 294 -or $spki[32] -ne 0) {
    Write-Host "[!] Khoa cong khai RSA-2048 SPKI trong manifest.json khong hop le." -ForegroundColor Red
    exit 1
}

Write-Host "=========================================================" -ForegroundColor Cyan
Write-Host "  OMNIVAULT EXTENSION - CAP NHAT TRUC TIEP TU GITHUB     " -ForegroundColor Cyan
Write-Host "=========================================================" -ForegroundColor Cyan
Write-Host "[*] Thu muc hien tai  : $ExtDir" -ForegroundColor Gray
Write-Host "[*] Phien ban hien tai: v$curVer" -ForegroundColor White
Write-Host "[*] Dang kiem tra ban moi nhat tren GitHub..." -ForegroundColor Yellow

$latestVer = ""
$zipUrl = ""
$changelog = ""
$vj = $null
$ts = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()

try {
    $rel = Invoke-RestMethod -Uri "https://api.github.com/repos/Minhtuan0506/omnivault-extension/releases/latest" -Headers @{ "User-Agent" = "OmniVault-Updater"; "Accept" = "application/vnd.github+json" }
    $latestVer = ([string]$rel.tag_name) -replace '^v', ''
    $changelog = [string]$rel.body
    $asset = $rel.assets | Where-Object { $_.name -match '^OmniVault-GiaiNen-.*\.zip$' } | Select-Object -First 1
    if ($asset) {
        $zipUrl = [string]$asset.browser_download_url
    }
    $vjAsset = $rel.assets | Where-Object { $_.name -eq 'version.json' } | Select-Object -First 1
    if ($vjAsset) {
        $vj = Invoke-RestMethod -Uri ([string]$vjAsset.browser_download_url) -Headers @{ "User-Agent" = "OmniVault-Updater" }
    } else {
        $vj = Invoke-RestMethod -Uri "https://minhtuan0506.github.io/omnivault-extension/version.json?t=$ts" -Headers @{ "User-Agent" = "OmniVault-Updater" }
    }
} catch {
    $vj = Invoke-RestMethod -Uri "https://minhtuan0506.github.io/omnivault-extension/version.json?t=$ts" -Headers @{ "User-Agent" = "OmniVault-Updater" }
    $latestVer = ([string]$vj.version) -replace '^v', ''
    $changelog = [string]$vj.changelog
    $zipUrl = [string]$vj.unpacked_zip_url
}

if (-not $zipUrl) {
    $zipUrl = "https://minhtuan0506.github.io/omnivault-extension/OmniVault-GiaiNen-latest.zip"
}
if ($zipUrl -notmatch '^https://(github\.com/Minhtuan0506/omnivault-extension/|minhtuan0506\.github\.io/omnivault-extension/)') {
    throw "URL tai goi cap nhat khong thuoc kho GitHub chinh thuc: $zipUrl"
}

Write-Host "[*] Ban moi nhat GitHub : v$latestVer" -ForegroundColor Green
if ((Compare-SemVer $latestVer $curVer) -le 0) {
    Write-Host "[+] Ban dang su dung phien ban moi nhat (v$curVer). Khong can cap nhat them!" -ForegroundColor Green
    exit 0
}

if (-not $vj) {
    throw "Thieu metadata version.json da ky de xac thuc tinh toan ven ban cap nhat!"
}
$vjVer = ([string]$vj.version) -replace '^v', ''
if ((Compare-SemVer $vjVer $latestVer) -ne 0) {
    throw "Phien ban trong version.json (v$vjVer) khong khop Release (v$latestVer)!"
}
$zipSha256Expected = ([string]$vj.zip_sha256).Trim().ToLowerInvariant()
$zipSigRsaB64 = ([string]$vj.signature_rsa_b64).Trim()
if ([string]::IsNullOrWhiteSpace($zipSha256Expected) -or [string]::IsNullOrWhiteSpace($zipSigRsaB64)) {
    throw "Thieu zip_sha256 hoac signature_rsa_b64 trong version.json - tu choi cai dat ban chua ky!"
}

if ($changelog) {
    Write-Host "[*] Thay doi moi:" -ForegroundColor Cyan
    Write-Host "    $changelog" -ForegroundColor White
}

$tmpRoot = Join-Path $env:TEMP ("omnivault_ext_dl_" + [Guid]::NewGuid().ToString("N"))
$zipFile = Join-Path $tmpRoot "update.zip"
$unpackDir = Join-Path $tmpRoot "unpack"
New-Item -ItemType Directory -Force -Path $unpackDir | Out-Null

try {
    Write-Host "[*] Dang tai goi v$latestVer tu GitHub..." -ForegroundColor Yellow
    Invoke-WebRequest -Uri $zipUrl -OutFile $zipFile -Headers @{ "User-Agent" = "OmniVault-Updater" } -UseBasicParsing

    Write-Host "[*] Dang kiem tra SHA-256 & chu ky so RSA-2048..." -ForegroundColor Yellow
    $zipBytes = [System.IO.File]::ReadAllBytes($zipFile)
    $sha256Alg = [System.Security.Cryptography.SHA256]::Create()
    try {
        $hashBytes = $sha256Alg.ComputeHash($zipBytes)
    } finally {
        $sha256Alg.Dispose()
    }
    $actualZipSha256 = ([BitConverter]::ToString($hashBytes) -replace '-', '').ToLowerInvariant()
    if ($actualZipSha256 -ne $zipSha256Expected) {
        throw "SHA-256 goi cap nhat KHONG KHOP! Ky vong=$zipSha256Expected, Thuc te=$actualZipSha256"
    }

    $rsaParams = New-Object System.Security.Cryptography.RSAParameters
    $rsaParams.Modulus = [byte[]]$spki[33..288]
    $rsaParams.Exponent = [byte[]]$spki[291..293]
    $rsa = New-Object System.Security.Cryptography.RSACryptoServiceProvider
    try {
        $rsa.ImportParameters($rsaParams)
        $canonical = "omnivault-ext-zip-v1|$latestVer|$actualZipSha256"
        $canonicalBytes = [System.Text.Encoding]::UTF8.GetBytes($canonical)
        $sigBytes = [Convert]::FromBase64String($zipSigRsaB64)
        $sigOk = $rsa.VerifyData(
            $canonicalBytes,
            [System.Security.Cryptography.CryptoConfig]::MapNameToOID("SHA256"),
            $sigBytes
        )
        if (-not $sigOk) {
            throw "Chu ky RSA-2048 KHONG HOP LE! Goi cap nhat da bi sua doi hoac gia mao."
        }
    } finally {
        $rsa.Dispose()
    }
    Write-Host "[+] Chu ky RSA-2048 & SHA-256 hop le ($actualZipSha256)." -ForegroundColor Green

    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [System.IO.Compression.ZipFile]::ExtractToDirectory($zipFile, $unpackDir)

    $checkManifest = Join-Path $unpackDir "manifest.json"
    if (-not (Test-Path $checkManifest)) {
        throw "Goi tai ve khong hop le (thieu manifest.json)"
    }
    $newManifest = Get-Content -Raw -Encoding UTF8 $checkManifest | ConvertFrom-Json
    if (([string]$newManifest.key).Trim() -ne $pinnedPubKeyB64) {
        throw "manifest.json trong goi moi co khoa cong khai (key) khong khop voi ban hien tai!"
    }
    if ((Compare-SemVer ([string]$newManifest.version) $latestVer) -ne 0) {
        throw "manifest.json phien ban ($($newManifest.version)) khong khop voi v$latestVer!"
    }

    $extFullRoot = [System.IO.Path]::GetFullPath($ExtDir).TrimEnd('\') + '\'
    Write-Host "[*] Dang chep de cac tep cap nhat vao thu muc hien tai..." -ForegroundColor Yellow
    Get-ChildItem -Path $unpackDir -Recurse -File | ForEach-Object {
        $relPath = $_.FullName.Substring($unpackDir.Length).TrimStart('\')
        $destPath = [System.IO.Path]::GetFullPath((Join-Path $ExtDir $relPath))
        if (-not $destPath.StartsWith($extFullRoot, [System.StringComparison]::OrdinalIgnoreCase)) {
            throw "Phat hien duong dan nguy hiem ngoai thu muc extension: $relPath"
        }
        $destParent = Split-Path -Parent $destPath
        if (-not (Test-Path $destParent)) {
            New-Item -ItemType Directory -Force -Path $destParent | Out-Null
        }
        Copy-Item -Force -Path $_.FullName -Destination $destPath
    }

    Write-Host ""
    Write-Host "=========================================================" -ForegroundColor Green
    Write-Host "  DA CAP NHAT OMNIVAULT EXTENSION LEN v$latestVer!       " -ForegroundColor Green
    Write-Host "  - Toan bo mat khau & ket noi duoc giu nguyen 100%.     " -ForegroundColor White
    Write-Host "  - Hay mo bieu tuong OmniVault tren trinh duyet ->       " -ForegroundColor Yellow
    Write-Host "    bam nut [Ap dung ngay] (hoac Tai lai trong extensions)." -ForegroundColor Yellow
    Write-Host "=========================================================" -ForegroundColor Green
} finally {
    Remove-Item -Recurse -Force -Path $tmpRoot -ErrorAction SilentlyContinue
}
