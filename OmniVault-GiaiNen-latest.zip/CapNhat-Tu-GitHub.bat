@echo off
chcp 65001 >nul
set "BAT_SELF=%~f0"
set "EXT_DIR=%~dp0"
set "PS_TMP=%TEMP%\omnivault_upd_%RANDOM%.ps1"
(
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$raw = [IO.File]::ReadAllText($env:BAT_SELF, [Text.Encoding]::UTF8); $marker = '###POWERSHELL_BELOW###'; $idx = $raw.LastIndexOf($marker); [IO.File]::WriteAllText($env:PS_TMP, $raw.Substring($idx + $marker.Length), [Text.UTF8Encoding]::new($false))"
  powershell -NoProfile -ExecutionPolicy Bypass -File "%PS_TMP%"
  call set "ERR=%%ERRORLEVEL%%"
  del "%PS_TMP%" >nul 2>nul
  echo.
  pause
  exit /b %ERRORLEVEL%
)

###POWERSHELL_BELOW###
$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$ExtDir = $env:EXT_DIR.TrimEnd('\')
$ManifestPath = Join-Path $ExtDir "manifest.json"
if (-not (Test-Path $ManifestPath)) {
    Write-Host "[!] Khong tim thay manifest.json trong thu muc: $ExtDir" -ForegroundColor Red
    Write-Host "    Vui long dat file nay trong thu muc tien ich OmniVault roi chay lai." -ForegroundColor Yellow
    exit 1
}

function Compare-SemVer {
    param([string]$A, [string]$B)
    $pa = ($A -replace '^v', '') -split '\.' | ForEach-Object { [int]($_ -replace '[^0-9].*$', '') }
    $pb = ($B -replace '^v', '') -split '\.' | ForEach-Object { [int]($_ -replace '[^0-9].*$', '') }
    $len = [Math]::Max($pa.Count, $pb.Count)
    for ($i = 0; $i -lt $len; $i++) {
        $va = if ($i -lt $pa.Count) { $pa[$i] } else { 0 }
        $vb = if ($i -lt $pb.Count) { $pb[$i] } else { 0 }
        if ($va -ne $vb) { return ($va - $vb) }
    }
    return 0
}

$curManifest = Get-Content -Raw -Encoding UTF8 $ManifestPath | ConvertFrom-Json
$curVer = [string]$curManifest.version

Write-Host "=========================================================" -ForegroundColor Cyan
Write-Host "  OMNIVAULT EXTENSION - CAP NHAT TRUC TIEP TU GITHUB     " -ForegroundColor Cyan
Write-Host "=========================================================" -ForegroundColor Cyan
Write-Host "[*] Thu muc hien tai  : $ExtDir" -ForegroundColor Gray
Write-Host "[*] Phien ban hien tai: v$curVer" -ForegroundColor White
Write-Host "[*] Dang kiem tra ban moi nhat tren GitHub..." -ForegroundColor Yellow

$latestVer = ""
$zipUrl = ""
$changelog = ""

try {
    $rel = Invoke-RestMethod -Uri "https://api.github.com/repos/Minhtuan0506/omnivault-extension/releases/latest" -Headers @{ "User-Agent" = "OmniVault-Updater"; "Accept" = "application/vnd.github+json" }
    $latestVer = ([string]$rel.tag_name) -replace '^v', ''
    $changelog = [string]$rel.body
    $asset = $rel.assets | Where-Object { $_.name -match '^OmniVault-GiaiNen-.*\.zip$' } | Select-Object -First 1
    if ($asset) {
        $zipUrl = [string]$asset.browser_download_url
    }
} catch {
    $ts = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
    $vj = Invoke-RestMethod -Uri "https://minhtuan0506.github.io/omnivault-extension/version.json?t=$ts" -Headers @{ "User-Agent" = "OmniVault-Updater" }
    $latestVer = ([string]$vj.version) -replace '^v', ''
    $changelog = [string]$vj.changelog
    $zipUrl = [string]$vj.unpacked_zip_url
}

if (-not $zipUrl) {
    $zipUrl = "https://minhtuan0506.github.io/omnivault-extension/OmniVault-GiaiNen-latest.zip"
}

Write-Host "[*] Ban moi nhat GitHub : v$latestVer" -ForegroundColor Green
if ((Compare-SemVer $latestVer $curVer) -le 0) {
    Write-Host "[+] Ban dang su dung phien ban moi nhat (v$curVer). Khong can cap nhat them!" -ForegroundColor Green
    exit 0
}

if ($changelog) {
    Write-Host "[*] Thay doi moi:" -ForegroundColor Cyan
    Write-Host "    $changelog" -ForegroundColor White
}

$tmpRoot = Join-Path $env:TEMP ("omnivault_ext_dl_" + [Guid]::NewGuid().ToString("N"))
$zipFile = Join-Path $tmpRoot "update.zip"
$unpackDir = Join-Path $tmpRoot "unpack"
New-Item -ItemType Directory -Force -Path $unpackDir | Out-Null

try {
    Write-Host "[*] Dang tai goi v$latestVer tu GitHub..." -ForegroundColor Yellow
    Invoke-WebRequest -Uri $zipUrl -OutFile $zipFile -Headers @{ "User-Agent" = "OmniVault-Updater" } -UseBasicParsing

    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [System.IO.Compression.ZipFile]::ExtractToDirectory($zipFile, $unpackDir)

    $checkManifest = Join-Path $unpackDir "manifest.json"
    if (-not (Test-Path $checkManifest)) {
        throw "Goi tai ve khong hop le (thieu manifest.json)"
    }

    Write-Host "[*] Dang chep de cac tep cap nhat vao thu muc hien tai..." -ForegroundColor Yellow
    Get-ChildItem -Path $unpackDir -Recurse -File | ForEach-Object {
        $relPath = $_.FullName.Substring($unpackDir.Length).TrimStart('\')
        $destPath = Join-Path $ExtDir $relPath
        $destParent = Split-Path -Parent $destPath
        if (-not (Test-Path $destParent)) {
            New-Item -ItemType Directory -Force -Path $destParent | Out-Null
        }
        Copy-Item -Force -Path $_.FullName -Destination $destPath
    }

    Write-Host ""
    Write-Host "=========================================================" -ForegroundColor Green
    Write-Host "  DA CAP NHAT OMNIVAULT EXTENSION LEN v$latestVer!       " -ForegroundColor Green
    Write-Host "  - Toan bo mat khau & ket noi duoc giu nguyen 100%.     " -ForegroundColor White
    Write-Host "  - Hay mo bieu tuong OmniVault tren trinh duyet ->       " -ForegroundColor Yellow
    Write-Host "    bam nut [Ap dung ngay] (hoac Tai lai trong extensions)." -ForegroundColor Yellow
    Write-Host "=========================================================" -ForegroundColor Green
} finally {
    Remove-Item -Recurse -Force -Path $tmpRoot -ErrorAction SilentlyContinue
}
