﻿# OmniVault Extension — Native Messaging 100% Auto-Updater Host (Windows, Zero Admin)
# Strict Chromium Native Messaging stdio framing (4-byte LE uint32 length + UTF-8 JSON).
# Security:
#   - Pinned target directory ($PSScriptRoot) — NEVER accepts arbitrary paths over IPC
#   - Official GitHub URL allowlist only (Minhtuan0506/omnivault-extension)
#   - SHA-256 + RSA-2048 RSASSA-PKCS1-v1_5 verification against local manifest.json.key
#   - Zip-Slip, Zip-Bomb (<= 100 files, <= 10 MiB), and manifest-last atomic ordering

$ErrorActionPreference = "Stop"
$ProgressPreference    = "SilentlyContinue"
$WarningPreference     = "SilentlyContinue"
$VerbosePreference     = "SilentlyContinue"
$InformationPreference = "SilentlyContinue"

try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType](3072 -bor 12288)
} catch {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
}
Add-Type -AssemblyName System.IO.Compression | Out-Null
Add-Type -AssemblyName System.IO.Compression.FileSystem | Out-Null

$ExtDir      = $PSScriptRoot
$Utf8NoBom   = New-Object System.Text.UTF8Encoding($false)
$MaxMsgBytes = 65536
$MaxJsonBytes = 1024 * 1024
$MaxZipBytes = 10 * 1024 * 1024
$MaxEntries  = 100
$HostVersion = "1.1.0"

$ReleaseApiUrl   = "https://api.github.com/repos/Minhtuan0506/omnivault-extension/releases/latest"
$PagesVersionUrl = "https://minhtuan0506.github.io/omnivault-extension/version.json"
$PagesZipUrl     = "https://minhtuan0506.github.io/omnivault-extension/OmniVault-GiaiNen-latest.zip"

$StdIn  = [Console]::OpenStandardInput()
$StdOut = [Console]::OpenStandardOutput()

function Read-ExactBytes {
    param([System.IO.Stream]$Stream, [int]$Count)
    $buf = New-Object byte[] $Count
    $off = 0
    while ($off -lt $Count) {
        $n = $Stream.Read($buf, $off, $Count - $off)
        if ($n -le 0) { return $null }
        $off += $n
    }
    return $buf
}

function Read-NativeMessage {
    $lenBytes = Read-ExactBytes -Stream $StdIn -Count 4
    if ($null -eq $lenBytes) { return $null }
    $msgLen = [BitConverter]::ToInt32($lenBytes, 0)
    if ($msgLen -le 0 -or $msgLen -gt $MaxMsgBytes) {
        throw "Invalid native message length: $msgLen"
    }
    $payloadBytes = Read-ExactBytes -Stream $StdIn -Count $msgLen
    if ($null -eq $payloadBytes) { return $null }
    $jsonText = $Utf8NoBom.GetString($payloadBytes)
    return ($jsonText | ConvertFrom-Json)
}

function Write-NativeMessage {
    param([hashtable]$Payload)
    $json = $Payload | ConvertTo-Json -Depth 8 -Compress
    $bytes = $Utf8NoBom.GetBytes($json)
    $lenBytes = [BitConverter]::GetBytes([int]$bytes.Length)
    $StdOut.Write($lenBytes, 0, 4)
    $StdOut.Write($bytes, 0, $bytes.Length)
    $StdOut.Flush()
}

function Test-AllowedGitHubUrl {
    param([string]$Url)
    if ([string]::IsNullOrWhiteSpace($Url)) { return $false }
    try {
        $u = [Uri]$Url.Trim()
        if ($u.Scheme -ne "https") { return $false }
        if (-not [string]::IsNullOrEmpty($u.UserInfo)) { return $false }
        $h = $u.Host.ToLowerInvariant()
        if ($h -eq "github.com") {
            return ($u.AbsolutePath -match '^/Minhtuan0506/omnivault-extension(?:/|$)')
        }
        if ($h -eq "api.github.com") {
            return ($u.AbsolutePath -match '^/repos/Minhtuan0506/omnivault-extension(?:/|$)')
        }
        if ($h -eq "minhtuan0506.github.io") {
            return ($u.AbsolutePath -match '^/omnivault-extension(?:/|$)')
        }
        return $false
    } catch {
        return $false
    }
}

function Compare-SemVer {
    param([string]$A, [string]$B)
    $pa = @(($A -replace '^[vV]', '').Split('.') | ForEach-Object {
        $digits = $_ -replace '[^0-9].*$', ''
        if ([string]::IsNullOrEmpty($digits)) { 0 } else { [int]$digits }
    })
    $pb = @(($B -replace '^[vV]', '').Split('.') | ForEach-Object {
        $digits = $_ -replace '[^0-9].*$', ''
        if ([string]::IsNullOrEmpty($digits)) { 0 } else { [int]$digits }
    })
    $n = [Math]::Max($pa.Length, $pb.Length)
    for ($i = 0; $i -lt $n; $i++) {
        $va = if ($i -lt $pa.Length) { $pa[$i] } else { 0 }
        $vb = if ($i -lt $pb.Length) { $pb[$i] } else { 0 }
        if ($va -ne $vb) { return ($va - $vb) }
    }
    return 0
}

function Read-DerLen {
    param([byte[]]$Buf, [ref]$Pos)
    $b = $Buf[$Pos.Value]; $Pos.Value++
    if (($b -band 0x80) -eq 0) { return [int]$b }
    $num = $b -band 0x7F
    if ($num -lt 1 -or $num -gt 4) { throw "Invalid DER length" }
    $val = 0
    for ($i = 0; $i -lt $num; $i++) {
        $val = ($val -shl 8) -bor $Buf[$Pos.Value]
        $Pos.Value++
    }
    return $val
}

function ConvertFrom-SpkiToRsa {
    param([string]$SpkiB64)
    $der = [Convert]::FromBase64String($SpkiB64.Trim())
    $p = 0
    if ($der[$p++] -ne 0x30) { throw "SPKI missing outer SEQUENCE" }
    $null = Read-DerLen $der ([ref]$p)
    if ($der[$p++] -ne 0x30) { throw "SPKI missing AlgorithmIdentifier" }
    $algLen = Read-DerLen $der ([ref]$p); $p += $algLen
    if ($der[$p++] -ne 0x03) { throw "SPKI missing BIT STRING" }
    $null = Read-DerLen $der ([ref]$p)
    if ($der[$p++] -ne 0x00) { throw "SPKI BIT STRING nonzero padding" }
    if ($der[$p++] -ne 0x30) { throw "SPKI missing RSAPublicKey SEQUENCE" }
    $null = Read-DerLen $der ([ref]$p)
    if ($der[$p++] -ne 0x02) { throw "SPKI missing modulus INTEGER" }
    $modLen = Read-DerLen $der ([ref]$p)
    $mod = New-Object byte[] $modLen
    [Array]::Copy($der, $p, $mod, 0, $modLen); $p += $modLen
    if ($mod.Length -gt 1 -and $mod[0] -eq 0x00) {
        $trimmed = New-Object byte[] ($mod.Length - 1)
        [Array]::Copy($mod, 1, $trimmed, 0, $trimmed.Length)
        $mod = $trimmed
    }
    if ($der[$p++] -ne 0x02) { throw "SPKI missing exponent INTEGER" }
    $expLen = Read-DerLen $der ([ref]$p)
    $exp = New-Object byte[] $expLen
    [Array]::Copy($der, $p, $exp, 0, $expLen)
    $rsaParams = New-Object System.Security.Cryptography.RSAParameters
    $rsaParams.Modulus  = $mod
    $rsaParams.Exponent = $exp
    $rsa = New-Object System.Security.Cryptography.RSACryptoServiceProvider
    $rsa.ImportParameters($rsaParams)
    return $rsa
}

function Get-FileSha256Lower {
    param([string]$FilePath)
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        $fs = [System.IO.File]::OpenRead($FilePath)
        try {
            $hash = $sha.ComputeHash($fs)
            return ([BitConverter]::ToString($hash) -replace '-', '').ToLowerInvariant()
        } finally {
            $fs.Dispose()
        }
    } finally {
        $sha.Dispose()
    }
}

function Download-AllowedFileWithLimit {
    param([string]$Url, [string]$DestPath, [int]$LimitBytes)
    if (-not (Test-AllowedGitHubUrl $Url)) {
        throw "Rejected untrusted download URL: $Url"
    }
    $req = [System.Net.HttpWebRequest]::Create($Url)
    $req.UserAgent = "OmniVault-Native-Updater/$HostVersion"
    $req.Timeout = 30000
    $req.ReadWriteTimeout = 30000
    $req.AllowAutoRedirect = $true
    $req.MaximumAutomaticRedirections = 5
    $resp = $req.GetResponse()
    try {
        if ($resp.ResponseUri -and $resp.ResponseUri.Scheme -ne "https") {
            throw "Rejected non-HTTPS redirect target: $($resp.ResponseUri.AbsoluteUri)"
        }
        if ($resp.ContentLength -gt $LimitBytes) {
            throw "Download exceeds 10 MB safety limit"
        }
        $inStream = $resp.GetResponseStream()
        $outStream = [System.IO.File]::Open($DestPath, [System.IO.FileMode]::Create, [System.IO.FileAccess]::Write)
        try {
            $buf = New-Object byte[] 16384
            $total = 0
            while ($true) {
                $n = $inStream.Read($buf, 0, $buf.Length)
                if ($n -le 0) { break }
                $total += $n
                if ($total -gt $LimitBytes) {
                    throw "Download stream exceeds 10 MB safety limit"
                }
                $outStream.Write($buf, 0, $n)
            }
        } finally {
            $outStream.Dispose()
            $inStream.Dispose()
        }
    } finally {
        $resp.Dispose()
    }
}

function Fetch-JsonTextFromUrl {
    param([string]$Url, [int]$LimitBytes = $MaxJsonBytes)
    if (-not (Test-AllowedGitHubUrl $Url)) {
        throw "Rejected untrusted metadata URL: $Url"
    }
    $req = [System.Net.HttpWebRequest]::Create($Url)
    $req.UserAgent = "OmniVault-Native-Updater/$HostVersion"
    $req.Accept = "application/vnd.github+json, application/json"
    $req.Timeout = 20000
    $req.ReadWriteTimeout = 20000
    $req.AllowAutoRedirect = $true
    $req.MaximumAutomaticRedirections = 5
    $resp = $req.GetResponse()
    try {
        if ($resp.ResponseUri -and $resp.ResponseUri.Scheme -ne "https") {
            throw "Rejected non-HTTPS metadata redirect target"
        }
        if ($resp.ContentLength -gt $LimitBytes) {
            throw "Metadata JSON exceeds 1 MiB safety limit"
        }
        $inStream = $resp.GetResponseStream()
        $ms = New-Object System.IO.MemoryStream
        try {
            $buf = New-Object byte[] 16384
            $total = 0
            while ($true) {
                $n = $inStream.Read($buf, 0, $buf.Length)
                if ($n -le 0) { break }
                $total += $n
                if ($total -gt $LimitBytes) {
                    throw "Metadata JSON stream exceeds 1 MiB safety limit"
                }
                $ms.Write($buf, 0, $n)
            }
            return $Utf8NoBom.GetString($ms.ToArray())
        } finally {
            $ms.Dispose()
            $inStream.Dispose()
        }
    } finally {
        $resp.Dispose()
    }
}

function Copy-FileWithRetry {
    param([string]$Src, [string]$Dst, [int]$MaxAttempts = 4)
    $delays = @(150, 350, 700)
    $lastErr = $null
    for ($attempt = 0; $attempt -lt $MaxAttempts; $attempt++) {
        try {
            # Use .NET File.Copy directly so paths containing PowerShell wildcard characters (`[`, `]`) never fail
            [System.IO.File]::Copy($Src, $Dst, $true)
            return
        } catch {
            $lastErr = $_
            if ($attempt -lt ($MaxAttempts - 1)) {
                Start-Sleep -Milliseconds $delays[[Math]::Min($attempt, $delays.Length - 1)]
            }
        }
    }
    throw $lastErr
}

function Invoke-SelfUpdate {
    param([bool]$ForceUpdate = $false)

    $extDirInfo = Get-Item -LiteralPath $ExtDir -Force -ErrorAction Stop
    if (($extDirInfo.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) {
        throw "Thu muc tien ich la reparse point khong an toan — huy cap nhat."
    }
    $manifestPath = Join-Path $ExtDir "manifest.json"
    if (-not (Test-Path -LiteralPath $manifestPath)) {
        throw "Khong tim thay manifest.json trong thu muc tien ich."
    }
    $localManifest = [System.IO.File]::ReadAllText($manifestPath, $Utf8NoBom) | ConvertFrom-Json
    $curVer = ([string]$localManifest.version -replace '^[vV]', '').Trim()
    $pinnedKey = [string]$localManifest.key
    if ([string]::IsNullOrWhiteSpace($pinnedKey)) {
        throw "Thieu khoa cong khai manifest.json.key de xac thuc goi cap nhat."
    }
    $pinnedKey = $pinnedKey.Trim()

    # 1. Fetch signed version.json metadata (prefer GitHub Pages CDN first to avoid API rate limit, fallback Releases API)
    $verJsonUrl = ""
    $releaseZipUrl = ""
    $releaseTagVer = ""
    $vj = $null
    try {
        $pagesRaw = Fetch-JsonTextFromUrl ($PagesVersionUrl + "?t=" + [DateTimeOffset]::UtcNow.ToUnixTimeSeconds())
        $candidate = $pagesRaw | ConvertFrom-Json
        if ($candidate -and $candidate.version -and $candidate.zip_sha256 -and $candidate.signature_rsa_b64) {
            $vj = $candidate
        }
    } catch {}

    if ($null -eq $vj) {
        try {
            $relRaw = Fetch-JsonTextFromUrl $ReleaseApiUrl
            $relObj = $relRaw | ConvertFrom-Json
            if ($relObj -and $relObj.tag_name) {
                $releaseTagVer = ([string]$relObj.tag_name -replace '^[vV]', '').Trim()
            }
            if ($relObj -and $relObj.assets) {
                foreach ($a in @($relObj.assets)) {
                    $aname = [string]$a.name
                    $aurl  = [string]$a.browser_download_url
                    if ($aname -match '^version\.json$' -and (Test-AllowedGitHubUrl $aurl)) {
                        $verJsonUrl = $aurl
                    } elseif ($aname -match 'OmniVault-GiaiNen-.*\.zip$' -and (Test-AllowedGitHubUrl $aurl)) {
                        $releaseZipUrl = $aurl
                    }
                }
            }
        } catch {}

        if ($verJsonUrl) {
            try {
                $raw = Fetch-JsonTextFromUrl $verJsonUrl
                $candidate = $raw | ConvertFrom-Json
                if ($candidate -and $candidate.version -and $candidate.zip_sha256 -and $candidate.signature_rsa_b64) {
                    $vj = $candidate
                }
            } catch {}
        }
    }
    if ($null -eq $vj) {
        throw "Khong tai duoc sieu du lieu chu ky so version.json tu GitHub."
    }

    $latestVer   = ([string]$vj.version -replace '^[vV]', '').Trim()
    $expectedSha = ([string]$vj.zip_sha256).Trim().ToLowerInvariant()
    $sigRsaB64   = ([string]$vj.signature_rsa_b64).Trim()
    if ($latestVer -notmatch '^\d+\.\d+\.\d+$') {
        throw "Phien ban trong version.json khong hop le."
    }
    if ($expectedSha -notmatch '^[0-9a-f]{64}$') {
        throw "Ma SHA-256 trong version.json khong hop le."
    }

    if ($curVer -and ((Compare-SemVer $latestVer $curVer) -lt 0)) {
        throw "Chan ha cap phien ban khong an toan ($curVer -> $latestVer)."
    }
    if ((-not $ForceUpdate) -and $curVer -and ((Compare-SemVer $latestVer $curVer) -le 0)) {
        return @{
            ok              = $true
            alreadyUpToDate = $true
            version         = $curVer
            currentVersion  = $curVer
            latestVersion   = $latestVer
            writtenCount    = 0
            dirName         = (Split-Path -Leaf $ExtDir)
            dirPath         = $ExtDir
        }
    }

    # 2. Download ZIP from allowlisted GitHub endpoints (Release first when version matches, Pages mirror fallback)
    $zipCandidates = @()
    if ($releaseZipUrl -and (Test-AllowedGitHubUrl $releaseZipUrl) -and (-not $releaseTagVer -or (Compare-SemVer $releaseTagVer $latestVer) -eq 0)) {
        $zipCandidates += $releaseZipUrl
    }
    if ($vj.unpacked_zip_url -and (Test-AllowedGitHubUrl ([string]$vj.unpacked_zip_url))) {
        if ($zipCandidates -notcontains [string]$vj.unpacked_zip_url) { $zipCandidates += [string]$vj.unpacked_zip_url }
    }
    $mirrorUrl = if ($vj.unpacked_latest -and (Test-AllowedGitHubUrl ([string]$vj.unpacked_latest))) {
        [string]$vj.unpacked_latest
    } else {
        $PagesZipUrl
    }
    if ($zipCandidates -notcontains $mirrorUrl) { $zipCandidates += $mirrorUrl }

    $tmpDir = Join-Path $env:TEMP ("omnivault_native_upd_" + [Guid]::NewGuid().ToString("N"))
    $null = New-Item -ItemType Directory -Force -Path $tmpDir
    try {
        $zipPath = Join-Path $tmpDir "update.zip"
        $verified = $false
        $lastErr = "Khong tai duoc goi ZIP."

        foreach ($candUrl in $zipCandidates) {
            try {
                if (Test-Path -LiteralPath $zipPath) { Remove-Item -Force -LiteralPath $zipPath }
                Download-AllowedFileWithLimit -Url $candUrl -DestPath $zipPath -LimitBytes $MaxZipBytes
                $actualSha = Get-FileSha256Lower $zipPath
                if ($actualSha -ne $expectedSha) {
                    throw "Ma SHA-256 goi ZIP khong khop!"
                }
                $canonicalBytes = $Utf8NoBom.GetBytes("omnivault-ext-zip-v1|$latestVer|$actualSha")
                $sigBytes = [Convert]::FromBase64String($sigRsaB64)
                $rsa = ConvertFrom-SpkiToRsa $pinnedKey
                try {
                    $sigOk = $rsa.VerifyData($canonicalBytes, [System.Security.Cryptography.CryptoConfig]::MapNameToOID("SHA256"), $sigBytes)
                } finally {
                    $rsa.Dispose()
                }
                if (-not $sigOk) {
                    throw "Chu ky so RSA-2048 KHONG HOP LE!"
                }
                $verified = $true
                break
            } catch {
                $lastErr = $_.Exception.Message
            }
        }
        if (-not $verified) {
            throw $lastErr
        }

        # 3. Extract ZIP safely into staging folder with Zip-Slip & Zip-Bomb guards
        $stageDir = Join-Path $tmpDir "stage"
        $null = New-Item -ItemType Directory -Force -Path $stageDir
        $stageFullRoot = [System.IO.Path]::GetFullPath($stageDir)
        if (-not $stageFullRoot.EndsWith("\")) { $stageFullRoot += "\" }

        $stagedRelFiles = New-Object System.Collections.Generic.List[string]
        $seenLower = New-Object System.Collections.Generic.HashSet[string]
        $totalUncomp = [long]0

        $arch = [System.IO.Compression.ZipFile]::OpenRead($zipPath)
        try {
            if ($arch.Entries.Count -eq 0 -or $arch.Entries.Count -gt $MaxEntries) {
                throw "So luong tep trong ZIP khong hop le ($($arch.Entries.Count))."
            }
            foreach ($entry in $arch.Entries) {
                $rawName = [string]$entry.FullName
                if ([string]::IsNullOrWhiteSpace($rawName)) { continue }
                if ($rawName.Contains([char]0) -or $rawName.Contains("\") -or $rawName.Contains(":") -or $rawName.StartsWith("/")) {
                    throw "Phat hien duong dan nguy hiem (Zip-Slip): $rawName"
                }
                if ($rawName.EndsWith("/")) { continue }
                $segs = $rawName.Split("/")
                foreach ($seg in $segs) {
                    if ([string]::IsNullOrEmpty($seg) -or $seg -eq "." -or $seg -eq "..") {
                        throw "Phat hien duong dan vuot cap (Zip-Slip): $rawName"
                    }
                    $baseUpper = ($seg.Split(".")[0]).ToUpperInvariant()
                    if ($baseUpper -match '^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])$') {
                        throw "Ten tep khong hop le tren Windows: $rawName"
                    }
                }
                $lower = $rawName.ToLowerInvariant()
                if (-not $seenLower.Add($lower)) {
                    throw "Phat hien tep trung lap trong ZIP: $rawName"
                }

                $destPath = [System.IO.Path]::GetFullPath((Join-Path $stageDir ($rawName -replace '/', '\')))
                if (-not $destPath.StartsWith($stageFullRoot, [System.StringComparison]::OrdinalIgnoreCase)) {
                    throw "Chan ghi tep ngoai thu muc dich (Zip-Slip): $rawName"
                }
                $parentDir = Split-Path -Parent $destPath
                if (-not (Test-Path -LiteralPath $parentDir)) {
                    $null = [System.IO.Directory]::CreateDirectory($parentDir)
                }

                $inS = $entry.Open()
                $outS = [System.IO.File]::Open($destPath, [System.IO.FileMode]::Create, [System.IO.FileAccess]::Write)
                try {
                    $buf = New-Object byte[] 16384
                    while ($true) {
                        $n = $inS.Read($buf, 0, $buf.Length)
                        if ($n -le 0) { break }
                        $totalUncomp += $n
                        if ($totalUncomp -gt $MaxZipBytes) {
                            throw "Goi ZIP vuot gioi han giai nen an toan 10 MB."
                        }
                        $outS.Write($buf, 0, $n)
                    }
                } finally {
                    $outS.Dispose()
                    $inS.Dispose()
                }
                $stagedRelFiles.Add($rawName)
            }
        } finally {
            $arch.Dispose()
        }

        # 4. Verify staged manifest.json key & version match BEFORE modifying ExtDir
        $stagedManifestPath = Join-Path $stageDir "manifest.json"
        if (-not (Test-Path -LiteralPath $stagedManifestPath)) {
            throw "Goi cap nhat thieu manifest.json."
        }
        $newManifest = [System.IO.File]::ReadAllText($stagedManifestPath, $Utf8NoBom) | ConvertFrom-Json
        if (([string]$newManifest.key).Trim() -ne $pinnedKey) {
            throw "Khoa manifest.json.key trong goi moi khong khop — huy de bao toan du lieu!"
        }
        if ((Compare-SemVer ([string]$newManifest.version) $latestVer) -ne 0) {
            throw "Phien ban trong manifest.json khong khop phien ban da ky."
        }

        # 5. Atomic write order: all non-manifest files FIRST, manifest.json LAST (NEVER overwrite native_updater_host.json)
        $ordered = New-Object System.Collections.Generic.List[string]
        foreach ($rel in $stagedRelFiles) {
            $relLower = $rel.ToLowerInvariant()
            if ($relLower -eq "manifest.json" -or $relLower -eq "native_updater_host.json") {
                continue
            }
            $ordered.Add($rel)
        }
        $ordered.Add("manifest.json")

        $written = 0
        foreach ($rel in $ordered) {
            $src = Join-Path $stageDir ($rel -replace '/', '\')
            $dst = Join-Path $ExtDir ($rel -replace '/', '\')
            $dstParent = Split-Path -Parent $dst
            if (-not (Test-Path -LiteralPath $dstParent)) {
                $null = [System.IO.Directory]::CreateDirectory($dstParent)
            } else {
                $dstParentItem = Get-Item -LiteralPath $dstParent -Force -ErrorAction SilentlyContinue
                if ($null -ne $dstParentItem -and (($dstParentItem.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0)) {
                    throw "Thu muc dich la reparse point khong an toan: $rel"
                }
            }
            # Skip overwriting byte-identical files (avoids Defender/handle churn across all files)
            if (Test-Path -LiteralPath $dst) {
                $dstItem = Get-Item -LiteralPath $dst -Force -ErrorAction SilentlyContinue
                if ($null -ne $dstItem -and (($dstItem.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0)) {
                    throw "Tep dich la reparse point khong an toan: $rel"
                }
                if ((Get-FileSha256Lower $src) -eq (Get-FileSha256Lower $dst)) {
                    $written++
                    continue
                }
            }
            Copy-FileWithRetry -Src $src -Dst $dst
            $written++
        }

        return @{
            ok              = $true
            alreadyUpToDate = $false
            version         = $latestVer
            writtenCount    = $written
            sha256          = $expectedSha
            dirName         = (Split-Path -Leaf $ExtDir)
            dirPath         = $ExtDir
        }
    } finally {
        Remove-Item -Recurse -Force -LiteralPath $tmpDir -ErrorAction SilentlyContinue
    }
}

function Get-UserDownloadsPath {
    try {
        $regVal = (Get-ItemProperty -LiteralPath "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders" -Name "{374DE290-123F-4565-9164-39C4925E467B}" -ErrorAction SilentlyContinue)."{374DE290-123F-4565-9164-39C4925E467B}"
        if (-not [string]::IsNullOrWhiteSpace($regVal)) {
            $expanded = [Environment]::ExpandEnvironmentVariables([string]$regVal)
            if (Test-Path -LiteralPath $expanded -PathType Container) {
                return [System.IO.Path]::GetFullPath($expanded)
            }
        }
    } catch {}
    $fallback = Join-Path ([Environment]::GetFolderPath("UserProfile")) "Downloads"
    if (Test-Path -LiteralPath $fallback -PathType Container) {
        return [System.IO.Path]::GetFullPath($fallback)
    }
    return ""
}

function Test-IsSafeDownloadsFile([string]$DownloadsRoot, [string]$FileName) {
    if ([string]::IsNullOrWhiteSpace($DownloadsRoot) -or [string]::IsNullOrWhiteSpace($FileName)) {
        return $null
    }
    if ($FileName -match '[\\/:*?"<>|]' -or $FileName.Contains("..")) {
        return $null
    }
    if ($FileName -notmatch '\.(csv|json)$') {
        return $null
    }
    $fullRoot = [System.IO.Path]::GetFullPath($DownloadsRoot).TrimEnd('\') + '\'
    $fullPath = [System.IO.Path]::GetFullPath((Join-Path $DownloadsRoot $FileName))
    if (-not $fullPath.StartsWith($fullRoot, [System.StringComparison]::OrdinalIgnoreCase)) {
        return $null
    }
    if ((Split-Path -Parent $fullPath).TrimEnd('\') -ne $fullRoot.TrimEnd('\')) {
        return $null
    }
    if (-not (Test-Path -LiteralPath $fullPath -PathType Leaf)) {
        return $null
    }
    $fi = Get-Item -LiteralPath $fullPath -Force -ErrorAction SilentlyContinue
    if ($null -eq $fi) { return $null }
    if (($fi.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) {
        return $null
    }
    $maxImportBytes = 16 * 1024 * 1024
    if ($fi.Length -le 0 -or $fi.Length -gt $maxImportBytes) {
        return $null
    }
    return $fi
}

function Test-LooksLikePasswordExport([System.IO.FileInfo]$FileInfo) {
    if ($null -eq $FileInfo) { return $false }
    $fs = [System.IO.File]::OpenRead($FileInfo.FullName)
    try {
        $probeLen = [int][Math]::Min(8192, $FileInfo.Length)
        $buf = New-Object byte[] $probeLen
        $read = $fs.Read($buf, 0, $probeLen)
        if ($read -le 0) { return $false }
        $sample = $Utf8NoBom.GetString($buf, 0, $read).TrimStart([char]0xFEFF)
        if ($FileInfo.Extension -ieq ".json") {
            $trim = $sample.TrimStart()
            if (-not $trim.StartsWith("{")) { return $false }
            # Accept FIDO CXF 1.0 ("accounts" + "version") or Bitwarden export ("items")
            $isCxf = ($trim -match '"accounts"\s*:\s*\[' -and $trim -match '"version"\s*:')
            $isBw  = ($trim -match '"items"\s*:\s*\[')
            return ($isCxf -or $isBw)
        }
        $firstLine = ($sample -split "\r?\n", 2)[0].ToLowerInvariant()
        if ([string]::IsNullOrWhiteSpace($firstLine)) { return $false }
        $hasPassCol = ($firstLine -match '(^|,)\s*"?(password|login_password|pass|mật khẩu)"?\s*(,|$)')
        $hasUserOrUrlCol = ($firstLine -match '(^|,)\s*"?(username|login_username|user|email|url|login_uri|website|origin|hostname|tài khoản|địa chỉ)"?\s*(,|$)')
        return ($hasPassCol -and $hasUserOrUrlCol)
    } catch {
        return $false
    } finally {
        $fs.Dispose()
    }
}

function Invoke-ReadLatestPasswordExport {
    param(
        [int]$MaxAgeMinutes = 1440,
        [string]$ExpectedFileName = "",
        [int]$OffsetBytes = 0,
        [int]$ChunkBytes = 524288
    )

    $downloads = Get-UserDownloadsPath
    if ([string]::IsNullOrWhiteSpace($downloads)) {
        return @{ ok = $true; found = $false; error = "Khong tim thay thu muc Downloads." }
    }

    $clampedAge = [Math]::Max(1, [Math]::Min(10080, $MaxAgeMinutes))
    $clampedChunk = [Math]::Max(32768, [Math]::Min(524288, $ChunkBytes))
    $clampedOffset = [Math]::Max(0, $OffsetBytes)
    $targetFi = $null

    if (-not [string]::IsNullOrWhiteSpace($ExpectedFileName)) {
        $cand = Test-IsSafeDownloadsFile -DownloadsRoot $downloads -FileName $ExpectedFileName
        if ($null -ne $cand -and (Test-LooksLikePasswordExport $cand)) {
            $targetFi = $cand
        }
    } else {
        $cutoffUtc = [DateTime]::UtcNow.AddMinutes(-$clampedAge)
        $candidates = Get-ChildItem -LiteralPath $downloads -File -ErrorAction SilentlyContinue |
            Where-Object {
                ($_.Extension -ieq ".csv" -or $_.Extension -ieq ".json") -and
                $_.LastWriteTimeUtc -ge $cutoffUtc
            } |
            Sort-Object LastWriteTimeUtc -Descending

        foreach ($f in $candidates) {
            $safeFi = Test-IsSafeDownloadsFile -DownloadsRoot $downloads -FileName $f.Name
            if ($null -ne $safeFi -and (Test-LooksLikePasswordExport $safeFi)) {
                $targetFi = $safeFi
                break
            }
        }
    }

    if ($null -eq $targetFi) {
        return @{ ok = $true; found = $false }
    }

    $totalLen = [int64]$targetFi.Length
    if ($clampedOffset -ge $totalLen) {
        return @{ ok = $false; found = $true; error = "Vi tri doc tep vuot kich thuoc tep." }
    }

    $sha = Get-FileSha256Lower $targetFi.FullName
    $toRead = [int][Math]::Min($clampedChunk, $totalLen - $clampedOffset)
    $chunkBuf = New-Object byte[] $toRead
    $fs = [System.IO.File]::OpenRead($targetFi.FullName)
    try {
        $null = $fs.Seek($clampedOffset, [System.IO.SeekOrigin]::Begin)
        $filled = 0
        while ($filled -lt $toRead) {
            $n = $fs.Read($chunkBuf, $filled, $toRead - $filled)
            if ($n -le 0) { break }
            $filled += $n
        }
        if ($filled -lt $toRead) {
            $trimmed = New-Object byte[] $filled
            [Array]::Copy($chunkBuf, 0, $trimmed, 0, $filled)
            $chunkBuf = $trimmed
        }
    } finally {
        $fs.Dispose()
    }

    $nextOffset = $clampedOffset + $chunkBuf.Length
    $lastWriteMs = [DateTimeOffset]::new($targetFi.LastWriteTimeUtc).ToUnixTimeMilliseconds()
    return @{
        ok              = $true
        found           = $true
        fileName        = $targetFi.Name
        sha256          = $sha
        sizeBytes       = $totalLen
        lastWriteMs     = $lastWriteMs
        offsetBytes     = $clampedOffset
        nextOffsetBytes = $nextOffset
        hasMore         = ($nextOffset -lt $totalLen)
        chunkB64        = [Convert]::ToBase64String($chunkBuf)
    }
}

function Invoke-DeleteVerifiedPasswordExport {
    param(
        [string]$FileName,
        [string]$ExpectedSha256,
        [int64]$ExpectedSizeBytes
    )

    $downloads = Get-UserDownloadsPath
    if ([string]::IsNullOrWhiteSpace($downloads)) {
        return @{ ok = $false; error = "Khong tim thay thu muc Downloads." }
    }
    $cleanSha = ([string]$ExpectedSha256).Trim().ToLowerInvariant()
    if ($cleanSha -notmatch '^[0-9a-f]{64}$') {
        return @{ ok = $false; error = "Ma SHA-256 xac thuc xoa tep khong hop le." }
    }

    $safeFi = Test-IsSafeDownloadsFile -DownloadsRoot $downloads -FileName $FileName
    if ($null -eq $safeFi) {
        return @{ ok = $true; deleted = $false; alreadyMissing = $true }
    }
    if ($ExpectedSizeBytes -gt 0 -and $safeFi.Length -ne $ExpectedSizeBytes) {
        return @{ ok = $false; error = "Kich thuoc tep da thay doi — huy xoa de bao toan du lieu." }
    }
    $actualSha = Get-FileSha256Lower $safeFi.FullName
    if ($actualSha -ne $cleanSha) {
        return @{ ok = $false; error = "Noi dung tep da thay doi (SHA-256 khong khop) — huy xoa de an toan." }
    }
    if (-not (Test-LooksLikePasswordExport $safeFi)) {
        return @{ ok = $false; error = "Tep khong phai file xuat mat khau hop le — tu choi xoa." }
    }

    # Best-effort single-pass zero overwrite before unlinking plaintext export
    try {
        $len = [int64]$safeFi.Length
        $zeroBlock = New-Object byte[] ([int][Math]::Min(65536, [Math]::Max(1, $len)))
        $wfs = [System.IO.File]::Open($safeFi.FullName, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Write, [System.IO.FileShare]::None)
        try {
            $rem = $len
            while ($rem -gt 0) {
                $chunk = [int][Math]::Min($zeroBlock.Length, $rem)
                $wfs.Write($zeroBlock, 0, $chunk)
                $rem -= $chunk
            }
            $wfs.Flush($true)
        } finally {
            $wfs.Dispose()
        }
    } catch {}

    Remove-Item -LiteralPath $safeFi.FullName -Force -ErrorAction Stop
    return @{ ok = $true; deleted = $true; fileName = $safeFi.Name }
}

try {
    $msg = Read-NativeMessage
    if ($null -eq $msg) { exit 0 }

    $action = [string]$msg.action
    if ($action -eq "ping") {
        $manifestPath = Join-Path $ExtDir "manifest.json"
        if (-not (Test-Path -LiteralPath $manifestPath)) {
            Write-NativeMessage @{ ok = $false; ready = $false; error = "Khong tim thay manifest.json trong thu muc cai dat." }
            exit 0
        }
        $m = [System.IO.File]::ReadAllText($manifestPath, $Utf8NoBom) | ConvertFrom-Json
        if ([string]::IsNullOrWhiteSpace([string]$m.key)) {
            Write-NativeMessage @{ ok = $false; ready = $false; error = "manifest.json thieu khoa cong khai key." }
            exit 0
        }
        Write-NativeMessage @{
            ok             = $true
            ready          = $true
            hostVersion    = $HostVersion
            dirName        = (Split-Path -Leaf $ExtDir)
            dirPath        = $ExtDir
            currentVersion = [string]$m.version
        }
        exit 0
    }

    if ($action -eq "update") {
        $forceFlag = [bool]$msg.force
        $res = Invoke-SelfUpdate -ForceUpdate $forceFlag
        Write-NativeMessage $res
        exit 0
    }

    if ($action -eq "read_latest_export") {
        $maxAge = if ($null -ne $msg.maxAgeMinutes) { [int]$msg.maxAgeMinutes } else { 1440 }
        $expName = if ($null -ne $msg.expectedFileName) { [string]$msg.expectedFileName } else { "" }
        $offset = if ($null -ne $msg.offsetBytes) { [int]$msg.offsetBytes } else { 0 }
        $res = Invoke-ReadLatestPasswordExport -MaxAgeMinutes $maxAge -ExpectedFileName $expName -OffsetBytes $offset
        Write-NativeMessage $res
        exit 0
    }

    if ($action -eq "delete_verified_export") {
        $fName = if ($null -ne $msg.fileName) { [string]$msg.fileName } else { "" }
        $expSha = if ($null -ne $msg.expectedSha256) { [string]$msg.expectedSha256 } else { "" }
        $expSize = if ($null -ne $msg.expectedSizeBytes) { [int64]$msg.expectedSizeBytes } else { 0 }
        $res = Invoke-DeleteVerifiedPasswordExport -FileName $fName -ExpectedSha256 $expSha -ExpectedSizeBytes $expSize
        Write-NativeMessage $res
        exit 0
    }

    Write-NativeMessage @{ ok = $false; error = "Lenh khong duoc ho tro: $action" }
} catch {
    try {
        Write-NativeMessage @{ ok = $false; error = [string]$_.Exception.Message }
    } catch {}
}
