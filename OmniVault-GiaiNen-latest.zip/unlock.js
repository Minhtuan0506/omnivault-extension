(function () {
  "use strict";

  const params = new URLSearchParams(window.location.search);
  const targetHost = String(params.get("host") || "").trim();
  const deviceName = String(params.get("device") || "").trim();

  const hostPill = document.getElementById("hostPill");
  const deviceHint = document.getElementById("deviceHint");
  const unlockHint = document.getElementById("unlockHint");
  const unlockForm = document.getElementById("unlockForm");
  const pinInput = document.getElementById("pinInput");
  const pinError = document.getElementById("pinError");
  const btnUnlock = document.getElementById("btnUnlock");
  const btnCancel = document.getElementById("btnCancel");

  if (targetHost && hostPill) {
    hostPill.textContent = targetHost;
    hostPill.hidden = false;
  }
  if (deviceName && deviceHint) {
    deviceHint.textContent = `Thiết bị: ${deviceName}`;
  }
  if (targetHost && unlockHint) {
    unlockHint.textContent = `Nhập mã PIN mở khóa OmniVault để tự điền tài khoản cho ${targetHost}.`;
  }

  function sendRuntimeMsg(payload) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(payload, (resp) => {
          void chrome.runtime.lastError;
          resolve(resp || null);
        });
      } catch (_) {
        resolve(null);
      }
    });
  }

  function showError(msg) {
    if (!pinError) return;
    if (!msg) {
      pinError.hidden = true;
      return;
    }
    pinError.textContent = msg;
    pinError.hidden = false;
  }

  let unlocking = false;

  async function submitUnlock(ev) {
    if (ev) ev.preventDefault();
    if (unlocking) return;
    const pin = String(pinInput?.value || "");
    if (!pin) {
      showError("Vui lòng nhập mã PIN.");
      pinInput?.focus();
      return;
    }

    unlocking = true;
    showError("");
    btnUnlock.disabled = true;
    btnUnlock.textContent = "Đang mở khóa...";
    try {
      const resp = await sendRuntimeMsg({
        type: "UNLOCK_EXTENSION_WITH_PIN",
        pin,
        notifyPendingTab: true
      });
      if (!resp || !resp.ok) {
        showError(resp?.error || "Mã PIN không đúng.");
        if (pinInput) {
          pinInput.value = "";
          pinInput.focus();
        }
        return;
      }
      if (pinInput) pinInput.value = "";
      window.close();
    } catch (e) {
      showError(String(e?.message || e || "Lỗi mở khóa phiên."));
    } finally {
      unlocking = false;
      btnUnlock.disabled = false;
      btnUnlock.textContent = "🔓 Mở khóa & Tự điền";
    }
  }

  unlockForm?.addEventListener("submit", submitUnlock);
  btnCancel?.addEventListener("click", () => window.close());
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      e.preventDefault();
      window.close();
    }
  });

  // Focus PIN input immediately when window opens
  setTimeout(() => pinInput?.focus(), 30);
})();
