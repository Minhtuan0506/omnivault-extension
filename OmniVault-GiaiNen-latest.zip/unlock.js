(function () {
  "use strict";

  const params = new URLSearchParams(window.location.search);
  const targetHost = String(params.get("host") || "").trim();

  const hostPill = document.getElementById("hostPill");
  const unlockForm = document.getElementById("unlockForm");
  const pinInput = document.getElementById("pinInput");
  const pinError = document.getElementById("pinError");
  const btnUnlock = document.getElementById("btnUnlock");
  const btnCancel = document.getElementById("btnCancel");

  // H2: Notify service worker while unlock window is open so silent background auto-update won't interrupt PIN entry
  try {
    if (typeof chrome?.runtime?.connect === "function") {
      chrome.runtime.connect({ name: "omnivault_ui_open" });
    }
  } catch (_) {}

  if (targetHost && hostPill) {
    hostPill.textContent = targetHost;
    hostPill.hidden = false;
  }

  function sendRuntimeMsg(payload) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(payload, (resp) => {
          void chrome.runtime.lastError;
          resolve(resp || null);
        });
      } catch (_) {
        resolve(null);
      }
    });
  }

  function showError(msg) {
    if (!pinError) return;
    if (!msg) {
      pinError.hidden = true;
      return;
    }
    pinError.textContent = msg;
    pinError.hidden = false;
  }

  let unlocking = false;

  async function submitUnlock(ev) {
    if (ev) ev.preventDefault();
    if (unlocking) return;
    const pin = String(pinInput?.value || "");
    if (!pin) {
      showError("Vui lòng nhập mã PIN.");
      pinInput?.focus();
      return;
    }

    unlocking = true;
    showError("");
    btnUnlock.disabled = true;
    btnUnlock.textContent = "Đang mở...";
    try {
      // M5: Warm-wake Service Worker safely without touching PIN fail counter, then submit PIN strictly ONCE with includeState: false
      let resp = await sendRuntimeMsg({
        type: "UNLOCK_EXTENSION_WITH_PIN",
        pin,
        notifyPendingTab: true,
        includeState: false
      });
      if (!resp) {
        await sendRuntimeMsg({ type: "PING_SW" });
        showError("Không kết nối được dịch vụ nền — thử lại.");
        return;
      }
      if (!resp.ok) {
        showError(resp.error || "Mã PIN không đúng.");
        if (pinInput) {
          pinInput.value = "";
          pinInput.focus();
        }
        return;
      }
      if (pinInput) pinInput.value = "";
      window.close();
    } catch (e) {
      showError(String(e?.message || e || "Lỗi mở khóa phiên."));
    } finally {
      unlocking = false;
      btnUnlock.disabled = false;
      btnUnlock.textContent = "Mở khóa";
    }
  }

  unlockForm?.addEventListener("submit", submitUnlock);
  btnCancel?.addEventListener("click", () => {
    if (pinInput) pinInput.value = "";
    window.close();
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      e.preventDefault();
      if (pinInput) pinInput.value = "";
      window.close();
    }
  });
  window.addEventListener("pagehide", () => {
    if (pinInput) pinInput.value = "";
  });

  // Warm-ping SW and focus PIN input immediately when window opens
  sendRuntimeMsg({ type: "PING_SW" }).catch(() => {});
  setTimeout(() => pinInput?.focus(), 30);
})();
