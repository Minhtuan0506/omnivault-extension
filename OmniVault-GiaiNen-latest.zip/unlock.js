(function () {
  "use strict";

  const params = new URLSearchParams(window.location.search);
  const targetHost = String(params.get("host") || "").trim();

  const unlockRoot = document.getElementById("unlockRoot");
  const hostPill = document.getElementById("hostPill");
  const unlockForm = document.getElementById("unlockForm");
  const pinInput = document.getElementById("pinInput");
  const btnTogglePin = document.getElementById("btnTogglePin");
  const eyeIconOpen = document.getElementById("eyeIconOpen");
  const eyeIconClosed = document.getElementById("eyeIconClosed");
  const pinError = document.getElementById("pinError");
  const btnUnlock = document.getElementById("btnUnlock");
  const btnCancel = document.getElementById("btnCancel");

  // H2: Notify service worker while unlock window is open so silent background auto-update won't interrupt PIN entry
  try {
    if (typeof chrome?.runtime?.connect === "function") {
      chrome.runtime.connect({ name: "omnivault_ui_open" });
    }
  } catch (_) {}

  if (targetHost && hostPill) {
    hostPill.textContent = targetHost;
    hostPill.hidden = false;
  }

  // Dynamically fit outer popup window height to exact rendered content across Windows 100%-200% DPI & browser zoom (zero scrollbars, zero clipped buttons, bottom-edge clamped)
  function fitWindowToContent() {
    try {
      const contentEl = unlockRoot || document.body;
      if (!contentEl) return;
      const contentH = Math.ceil(contentEl.getBoundingClientRect().height || contentEl.scrollHeight || 0);
      if (contentH <= 0) return;
      const zoomRatio =
        window.outerWidth > 0 && window.innerWidth > 0
          ? Math.max(0.75, Math.min(2.5, (window.outerWidth - 16) / window.innerWidth))
          : 1;
      const chromeFrameH =
        window.outerHeight > 0 && window.innerHeight > 0
          ? Math.max(24, window.outerHeight - Math.round(window.innerHeight * zoomRatio))
          : 44;
      const targetOuterH = Math.max(196, Math.min(360, Math.ceil(contentH * zoomRatio) + chromeFrameH + 2));
      if (typeof chrome?.windows?.getCurrent === "function" && typeof chrome?.windows?.update === "function") {
        chrome.windows.getCurrent((win) => {
          void chrome.runtime?.lastError;
          if (!win || win.id == null) return;
          const upd = {};
          if (Math.abs((win.height || 0) - targetOuterH) > 2) {
            upd.height = targetOuterH;
          }
          const availTop = Number.isFinite(Number(window.screen?.availTop)) ? Number(window.screen.availTop) : 0;
          const availH = Number(window.screen?.availHeight) || 0;
          if (availH > targetOuterH && typeof win.top === "number" && win.top + targetOuterH > availTop + availH - 8) {
            upd.top = Math.max(availTop + 8, Math.round(availTop + availH - targetOuterH - 8));
          }
          if (Object.keys(upd).length > 0) {
            chrome.windows.update(win.id, upd).catch?.(() => {});
          }
        });
      } else if (typeof window.resizeTo === "function" && window.outerWidth > 0) {
        if (Math.abs(window.outerHeight - targetOuterH) > 2) {
          window.resizeTo(window.outerWidth, targetOuterH);
        }
      }
    } catch (_) {}
  }

  function sendRuntimeMsg(payload) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(payload, (resp) => {
          void chrome.runtime.lastError;
          resolve(resp || null);
        });
      } catch (_) {
        resolve(null);
      }
    });
  }

  function showError(msg) {
    if (!pinError) return;
    if (!msg) {
      pinError.hidden = true;
      requestAnimationFrame(fitWindowToContent);
      return;
    }
    pinError.textContent = msg;
    pinError.hidden = false;
    requestAnimationFrame(fitWindowToContent);
  }

  if (btnTogglePin && pinInput) {
    btnTogglePin.addEventListener("click", () => {
      const nextShow = pinInput.type !== "text";
      pinInput.type = nextShow ? "text" : "password";
      btnTogglePin.setAttribute("aria-pressed", nextShow ? "true" : "false");
      btnTogglePin.style.color = nextShow ? "#1d4ed8" : "";
      if (eyeIconOpen) eyeIconOpen.hidden = nextShow;
      if (eyeIconClosed) eyeIconClosed.hidden = !nextShow;
      pinInput.focus();
    });
  }

  let unlocking = false;

  async function submitUnlock(ev) {
    if (ev) ev.preventDefault();
    if (unlocking) return;
    const pin = String(pinInput?.value || "");
    if (!pin) {
      showError("Vui lòng nhập mã PIN.");
      pinInput?.focus();
      return;
    }

    unlocking = true;
    showError("");
    btnUnlock.disabled = true;
    btnUnlock.textContent = "Đang mở...";
    try {
      // M5: Warm-wake Service Worker safely without touching PIN fail counter, then submit PIN strictly ONCE with includeState: false
      let resp = await sendRuntimeMsg({
        type: "UNLOCK_EXTENSION_WITH_PIN",
        pin,
        notifyPendingTab: true,
        includeState: false
      });
      if (!resp) {
        await sendRuntimeMsg({ type: "PING_SW" });
        showError("Không kết nối được dịch vụ nền — thử lại.");
        return;
      }
      if (!resp.ok) {
        showError(resp.error || "Mã PIN không đúng.");
        if (pinInput) {
          pinInput.value = "";
          pinInput.focus();
        }
        return;
      }
      if (pinInput) pinInput.value = "";
      window.close();
    } catch (e) {
      showError(String(e?.message || e || "Lỗi mở khóa phiên."));
    } finally {
      unlocking = false;
      btnUnlock.disabled = false;
      btnUnlock.textContent = "Mở khóa";
    }
  }

  unlockForm?.addEventListener("submit", submitUnlock);
  btnCancel?.addEventListener("click", () => {
    if (pinInput) pinInput.value = "";
    window.close();
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      e.preventDefault();
      if (pinInput) pinInput.value = "";
      window.close();
    }
  });
  window.addEventListener("pagehide", () => {
    if (pinInput) pinInput.value = "";
  });

  // Fit popup cleanly to actual rendered height, warm-ping SW, and focus PIN input immediately
  requestAnimationFrame(() => {
    fitWindowToContent();
    setTimeout(fitWindowToContent, 60);
  });
  sendRuntimeMsg({ type: "PING_SW" }).catch(() => {});
  setTimeout(() => pinInput?.focus(), 30);
})();
