/**
 * OmniVault Extension — In-Extension Self-Updater Core (2027 Standard)
 *
 * Pure Web Platform APIs (Chrome/Edge/Brave/CocCoc MV3 >= 120, zero external deps):
 *  - IndexedDB persistent FileSystemDirectoryHandle storage
 *  - Pure-JS ZIP parser & extractor using native DecompressionStream("deflate-raw") + CRC-32 check
 *  - WebCrypto SHA-256 + RSA-2048 (RSASSA-PKCS1-v1_5) signature verification against pinned manifest.json key
 *  - Zip-Slip / Zip-Bomb protection, directory ownership verification, and atomic-ordered writes (manifest.json last)
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) {
    module.exports = api;
  }
  root.OmniVaultUpdater = api;
})(typeof globalThis !== "undefined" ? globalThis : self, function () {
  "use strict";

  const UPDATER_IDB_NAME = "omnivault_ext_updater_db";
  const UPDATER_IDB_STORE = "handles";
  const UPDATER_DIR_KEY = "extension_dir";

  const MAX_ZIP_ENTRIES = 100;
  const MAX_ZIP_DOWNLOAD_BYTES = 10 * 1024 * 1024; // 10 MiB
  const MAX_UNCOMPRESSED_BYTES = 10 * 1024 * 1024; // 10 MiB
  const FETCH_META_TIMEOUT_MS = 20_000;
  const FETCH_ZIP_TIMEOUT_MS = 30_000;

  function createFetchTimeout(timeoutMs) {
    const ms = Math.max(1000, Number(timeoutMs) || FETCH_META_TIMEOUT_MS);
    if (typeof AbortSignal !== "undefined" && typeof AbortSignal.timeout === "function") {
      return { signal: AbortSignal.timeout(ms), clear() {} };
    }
    if (typeof AbortController !== "undefined") {
      const controller = new AbortController();
      const timer = setTimeout(() => {
        try {
          controller.abort(new DOMException("Request timed out", "TimeoutError"));
        } catch (_) {
          controller.abort();
        }
      }, ms);
      return {
        signal: controller.signal,
        clear() {
          clearTimeout(timer);
        }
      };
    }
    return { signal: undefined, clear() {} };
  }

  async function fetchWithTimeout(url, options = {}, timeoutMs = FETCH_META_TIMEOUT_MS, fetchImpl = globalThis.fetch) {
    const opts = options && typeof options === "object" ? { ...options } : {};
    let timeoutHandle = null;
    if (!opts.signal) {
      timeoutHandle = createFetchTimeout(timeoutMs);
      if (timeoutHandle.signal) opts.signal = timeoutHandle.signal;
    }
    try {
      return await fetchImpl(url, opts);
    } finally {
      if (timeoutHandle) timeoutHandle.clear();
    }
  }

  const GITHUB_VERSION_JSON_URL = "https://minhtuan0506.github.io/omnivault-extension/version.json";
  const DEFAULT_UNPACKED_LATEST_URL = "https://minhtuan0506.github.io/omnivault-extension/OmniVault-GiaiNen-latest.zip";

  const textEncoder = new TextEncoder();
  const textDecoderFatal = new TextDecoder("utf-8", { fatal: true });

  // ---------------------------------------------------------------------------
  // Version & URL Validation Helpers
  // ---------------------------------------------------------------------------
  function compareVersions(a, b) {
    const pa = String(a || "0").replace(/^v/i, "").split(".").map((x) => parseInt(x, 10) || 0);
    const pb = String(b || "0").replace(/^v/i, "").split(".").map((x) => parseInt(x, 10) || 0);
    const len = Math.max(pa.length, pb.length);
    for (let i = 0; i < len; i++) {
      const va = pa[i] || 0;
      const vb = pb[i] || 0;
      if (va !== vb) return va - vb;
    }
    return 0;
  }

  function isAllowedUpdateUrl(rawUrl) {
    if (typeof globalThis !== "undefined" && globalThis.OmniVaultCore?.isAllowedGitHubUpdateUrl) {
      return globalThis.OmniVaultCore.isAllowedGitHubUpdateUrl(rawUrl);
    }
    try {
      const u = new URL(String(rawUrl || "").trim());
      if (u.protocol !== "https:" || u.username || u.password) return false;
      const host = u.hostname.toLowerCase();
      if (host === "github.com") {
        return /^\/Minhtuan0506\/omnivault-extension(?:\/|$)/i.test(u.pathname);
      }
      if (host === "minhtuan0506.github.io") {
        return /^\/omnivault-extension(?:\/|$)/i.test(u.pathname);
      }
      return false;
    } catch (_) {
      return false;
    }
  }

  function base64ToUint8Array(b64) {
    if (typeof globalThis !== "undefined" && globalThis.OmniVaultCore?.base64ToBytes) {
      return globalThis.OmniVaultCore.base64ToBytes(b64);
    }
    const clean = String(b64 || "").replace(/\s+/g, "");
    if (!clean) return new Uint8Array(0);
    if (typeof Uint8Array.fromBase64 === "function") {
      return Uint8Array.fromBase64(clean);
    }
    if (typeof atob === "function") {
      const bin = atob(clean);
      const out = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
      return out;
    }
    if (typeof Buffer !== "undefined") {
      return new Uint8Array(Buffer.from(clean, "base64"));
    }
    throw new Error("Không hỗ trợ giải mã Base64 trong môi trường này.");
  }

  function bytesToHexLower(bytes) {
    let hex = "";
    for (let i = 0; i < bytes.length; i++) {
      hex += bytes[i].toString(16).padStart(2, "0");
    }
    return hex;
  }

  // ---------------------------------------------------------------------------
  // IEEE 802.3 CRC-32 (lazy table, zero external deps)
  // ---------------------------------------------------------------------------
  let crc32Table = null;
  function getCrc32Table() {
    if (crc32Table) return crc32Table;
    const table = new Uint32Array(256);
    for (let i = 0; i < 256; i++) {
      let c = i;
      for (let k = 0; k < 8; k++) {
        c = (c & 1) !== 0 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
      }
      table[i] = c >>> 0;
    }
    crc32Table = table;
    return table;
  }

  function computeCrc32(bytes) {
    const table = getCrc32Table();
    let crc = 0xffffffff;
    for (let i = 0; i < bytes.length; i++) {
      crc = table[(crc ^ bytes[i]) & 0xff] ^ (crc >>> 8);
    }
    return (crc ^ 0xffffffff) >>> 0;
  }

  // ---------------------------------------------------------------------------
  // IndexedDB Persistent FileSystemDirectoryHandle Storage
  // ---------------------------------------------------------------------------
  function isFileSystemAccessSupported() {
    return typeof globalThis !== "undefined" && typeof globalThis.showDirectoryPicker === "function";
  }

  function openUpdaterIdb() {
    return new Promise((resolve, reject) => {
      if (typeof indexedDB === "undefined" || !indexedDB?.open) {
        resolve(null);
        return;
      }
      try {
        const req = indexedDB.open(UPDATER_IDB_NAME, 1);
        req.onupgradeneeded = () => {
          const db = req.result;
          if (!db.objectStoreNames.contains(UPDATER_IDB_STORE)) {
            db.createObjectStore(UPDATER_IDB_STORE);
          }
        };
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error || new Error("IndexedDB open error"));
      } catch (e) {
        reject(e);
      }
    });
  }

  async function saveDirectoryHandle(dirHandle) {
    if (!dirHandle) return false;
    const db = await openUpdaterIdb();
    if (!db) return false;
    try {
      return await new Promise((resolve, reject) => {
        const tx = db.transaction(UPDATER_IDB_STORE, "readwrite");
        tx.objectStore(UPDATER_IDB_STORE).put(dirHandle, UPDATER_DIR_KEY);
        tx.oncomplete = () => resolve(true);
        tx.onerror = () => reject(tx.error || new Error("IDB put failed"));
        tx.onabort = () => reject(tx.error || new Error("IDB put aborted"));
      });
    } finally {
      db.close();
    }
  }

  async function getStoredDirectoryHandle() {
    const db = await openUpdaterIdb().catch(() => null);
    if (!db) return null;
    try {
      return await new Promise((resolve) => {
        const tx = db.transaction(UPDATER_IDB_STORE, "readonly");
        const req = tx.objectStore(UPDATER_IDB_STORE).get(UPDATER_DIR_KEY);
        req.onsuccess = () => resolve(req.result || null);
        req.onerror = () => resolve(null);
      });
    } finally {
      db.close();
    }
  }

  async function clearStoredDirectoryHandle() {
    const db = await openUpdaterIdb().catch(() => null);
    if (!db) return false;
    try {
      return await new Promise((resolve) => {
        const tx = db.transaction(UPDATER_IDB_STORE, "readwrite");
        tx.objectStore(UPDATER_IDB_STORE).delete(UPDATER_DIR_KEY);
        tx.oncomplete = () => resolve(true);
        tx.onerror = () => resolve(false);
        tx.onabort = () => resolve(false);
      });
    } finally {
      db.close();
    }
  }

  async function queryDirectoryPermission(dirHandle) {
    if (!dirHandle || typeof dirHandle.queryPermission !== "function") return "prompt";
    try {
      return await dirHandle.queryPermission({ mode: "readwrite" });
    } catch (_) {
      return "prompt";
    }
  }

  async function requestDirectoryPermission(dirHandle) {
    if (!dirHandle || typeof dirHandle.requestPermission !== "function") return "denied";
    return await dirHandle.requestPermission({ mode: "readwrite" });
  }

  // ---------------------------------------------------------------------------
  // Pure-JS ZIP Parser & Extractor with Strict Zip-Slip & Zip-Bomb Guards
  // ---------------------------------------------------------------------------
  function validateZipEntryPath(rawPath) {
    if (typeof rawPath !== "string" || rawPath.length === 0 || rawPath.length > 260) {
      throw new Error("Đường dẫn tệp trong gói ZIP không hợp lệ.");
    }
    if (rawPath.includes("\0") || rawPath.includes("\\") || rawPath.includes(":")) {
      throw new Error(`Phát hiện ký tự đường dẫn nguy hiểm trong ZIP: ${rawPath}`);
    }
    if (rawPath.startsWith("/")) {
      throw new Error(`Phát hiện đường dẫn tuyệt đối (Zip-Slip): ${rawPath}`);
    }
    const isDir = rawPath.endsWith("/");
    const trimmed = isDir ? rawPath.slice(0, -1) : rawPath;
    if (!trimmed) {
      return { path: "", isDir: true };
    }
    const segments = trimmed.split("/");
    for (let i = 0; i < segments.length; i++) {
      const seg = segments[i];
      if (!seg || seg === "." || seg === ".." || /[\x00-\x1f\x7f]/.test(seg)) {
        throw new Error(`Phát hiện đường dẫn vượt cấp (Zip-Slip): ${rawPath}`);
      }
      // Reject Windows reserved device names
      const baseName = seg.split(".")[0].toUpperCase();
      if (/^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])$/.test(baseName)) {
        throw new Error(`Tên tệp không hợp lệ trên Windows trong ZIP: ${rawPath}`);
      }
    }
    return { path: trimmed, isDir };
  }

  async function inflateRawWithLimit(compressedBytes, maxBytes) {
    if (typeof DecompressionStream !== "function") {
      throw new Error("Trình duyệt không hỗ trợ DecompressionStream('deflate-raw').");
    }
    const ds = new DecompressionStream("deflate-raw");
    const writer = ds.writable.getWriter();
    const writePromise = (async () => {
      try {
        await writer.write(compressedBytes);
        await writer.close();
      } catch (_) {
        // Error surfaced on reader side
      }
    })();

    const reader = ds.readable.getReader();
    const chunks = [];
    let total = 0;
    try {
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        if (value && value.byteLength > 0) {
          total += value.byteLength;
          if (total > maxBytes) {
            try {
              await reader.cancel("ZIP bomb limit exceeded");
            } catch (_) {}
            throw new Error("Gói ZIP vượt quá giới hạn dung lượng giải nén an toàn (10 MB).");
          }
          chunks.push(value);
        }
      }
    } finally {
      await writePromise.catch(() => {});
    }

    const out = new Uint8Array(total);
    let offset = 0;
    for (let i = 0; i < chunks.length; i++) {
      out.set(chunks[i], offset);
      offset += chunks[i].byteLength;
    }
    return out;
  }

  async function extractZipEntries(zipInput) {
    const bytes =
      zipInput instanceof Uint8Array
        ? zipInput
        : zipInput instanceof ArrayBuffer
          ? new Uint8Array(zipInput)
          : ArrayBuffer.isView(zipInput)
            ? new Uint8Array(zipInput.buffer, zipInput.byteOffset, zipInput.byteLength)
            : null;

    if (!bytes || bytes.byteLength < 22) {
      throw new Error("Tệp ZIP không hợp lệ hoặc bị cắt cụt.");
    }
    if (bytes.byteLength > MAX_ZIP_DOWNLOAD_BYTES) {
      throw new Error("Tệp ZIP vượt quá dung lượng tối đa cho phép (10 MB).");
    }

    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);

    // Locate End of Central Directory (EOCD: 0x06054b50) scanning backward
    const minEocdPos = Math.max(0, bytes.byteLength - 22 - 65535);
    let eocdOffset = -1;
    for (let pos = bytes.byteLength - 22; pos >= minEocdPos; pos--) {
      if (view.getUint32(pos, true) === 0x06054b50) {
        const commentLen = view.getUint16(pos + 20, true);
        if (pos + 22 + commentLen === bytes.byteLength) {
          eocdOffset = pos;
          break;
        }
      }
    }
    if (eocdOffset < 0) {
      throw new Error("Không tìm thấy cấu trúc mục lục cuối (EOCD) của tệp ZIP.");
    }

    const diskNumber = view.getUint16(eocdOffset + 4, true);
    const cdStartDisk = view.getUint16(eocdOffset + 6, true);
    const totalEntries = view.getUint16(eocdOffset + 10, true);
    const cdSize = view.getUint32(eocdOffset + 12, true);
    const cdOffset = view.getUint32(eocdOffset + 16, true);

    if (diskNumber !== 0 || cdStartDisk !== 0) {
      throw new Error("Không hỗ trợ gói ZIP chia nhiều phần.");
    }
    if (totalEntries === 0 || totalEntries > MAX_ZIP_ENTRIES) {
      throw new Error(`Số lượng tệp trong ZIP không hợp lệ (${totalEntries}, tối đa ${MAX_ZIP_ENTRIES}).`);
    }
    if (cdOffset + cdSize > eocdOffset) {
      throw new Error("Bảng mục lục ZIP (Central Directory) bị hỏng.");
    }

    const entries = [];
    const seenLowerPaths = new Set();
    let totalUncompressed = 0;
    let cursor = cdOffset;

    for (let i = 0; i < totalEntries; i++) {
      if (cursor + 46 > cdOffset + cdSize) {
        throw new Error("Mục Central Directory trong ZIP bị cắt cụt.");
      }
      if (view.getUint32(cursor, true) !== 0x02014b50) {
        throw new Error("Chữ ký Central Directory của ZIP không hợp lệ.");
      }

      const generalFlag = view.getUint16(cursor + 8, true);
      const compressionMethod = view.getUint16(cursor + 10, true);
      const expectedCrc32 = view.getUint32(cursor + 16, true);
      const compSize = view.getUint32(cursor + 20, true);
      const uncompSize = view.getUint32(cursor + 24, true);
      const nameLen = view.getUint16(cursor + 28, true);
      const extraLen = view.getUint16(cursor + 30, true);
      const commentLen = view.getUint16(cursor + 32, true);
      const localHeaderOffset = view.getUint32(cursor + 42, true);

      if ((generalFlag & 0x01) !== 0) {
        throw new Error("Không hỗ trợ tệp ZIP có mã hóa mật khẩu.");
      }
      if (cursor + 46 + nameLen + extraLen + commentLen > cdOffset + cdSize) {
        throw new Error("Độ dài mục Central Directory vượt biên tệp ZIP.");
      }

      const nameBytes = bytes.subarray(cursor + 46, cursor + 46 + nameLen);
      const rawName = textDecoderFatal.decode(nameBytes);
      cursor += 46 + nameLen + extraLen + commentLen;

      const { path: cleanPath, isDir } = validateZipEntryPath(rawName);
      if (isDir) continue;

      const lowerKey = cleanPath.toLowerCase();
      if (seenLowerPaths.has(lowerKey)) {
        throw new Error(`Phát hiện tệp trùng lặp trong ZIP: ${cleanPath}`);
      }
      seenLowerPaths.add(lowerKey);

      if (compSize > MAX_ZIP_DOWNLOAD_BYTES || uncompSize > MAX_UNCOMPRESSED_BYTES) {
        throw new Error(`Tệp trong ZIP quá lớn: ${cleanPath}`);
      }
      if (totalUncompressed + uncompSize > MAX_UNCOMPRESSED_BYTES) {
        throw new Error("Tổng dung lượng giải nén ZIP vượt giới hạn an toàn (10 MB).");
      }

      if (localHeaderOffset + 30 > cdOffset) {
        throw new Error(`Header cục bộ của tệp '${cleanPath}' vượt biên ZIP.`);
      }
      if (view.getUint32(localHeaderOffset, true) !== 0x04034b50) {
        throw new Error(`Chữ ký Local File Header không hợp lệ cho '${cleanPath}'.`);
      }
      const localNameLen = view.getUint16(localHeaderOffset + 26, true);
      const localExtraLen = view.getUint16(localHeaderOffset + 28, true);
      const dataStart = localHeaderOffset + 30 + localNameLen + localExtraLen;
      const dataEnd = dataStart + compSize;
      if (dataEnd > cdOffset) {
        throw new Error(`Dữ liệu nén của tệp '${cleanPath}' vượt biên ZIP.`);
      }

      const compressedSlice = bytes.subarray(dataStart, dataEnd);
      let fileBytes;
      if (compressionMethod === 0) {
        if (compSize !== uncompSize) {
          throw new Error(`Kích thước tệp STORED không khớp cho '${cleanPath}'.`);
        }
        fileBytes = compressedSlice.slice();
      } else if (compressionMethod === 8) {
        const remainingBudget = MAX_UNCOMPRESSED_BYTES - totalUncompressed;
        fileBytes = await inflateRawWithLimit(compressedSlice, remainingBudget);
      } else {
        throw new Error(`Không hỗ trợ thuật toán nén ZIP #${compressionMethod} cho '${cleanPath}'.`);
      }

      if (fileBytes.byteLength !== uncompSize) {
        throw new Error(`Dung lượng sau giải nén không khớp cho '${cleanPath}'.`);
      }
      const actualCrc = computeCrc32(fileBytes);
      if (actualCrc !== expectedCrc32) {
        throw new Error(`Lỗi kiểm tra toàn vẹn CRC-32 cho '${cleanPath}'.`);
      }

      totalUncompressed += fileBytes.byteLength;
      entries.push({ path: cleanPath, bytes: fileBytes });
    }

    if (entries.length === 0) {
      throw new Error("Gói ZIP không chứa tệp hợp lệ nào.");
    }
    return entries;
  }

  // ---------------------------------------------------------------------------
  // WebCrypto SHA-256 + RSA-2048 Signature Verification
  // ---------------------------------------------------------------------------
  async function sha256Hex(bytes) {
    const view =
      bytes instanceof Uint8Array
        ? bytes
        : new Uint8Array(bytes instanceof ArrayBuffer ? bytes : bytes.buffer);
    const digest = await crypto.subtle.digest("SHA-256", view);
    return bytesToHexLower(new Uint8Array(digest));
  }

  async function verifySignedZipPackage({
    zipBytes,
    version,
    expectedSha256,
    signatureRsaB64,
    pinnedSpkiB64
  }) {
    const cleanVer = String(version || "").replace(/^v/i, "").trim();
    if (!/^\d+\.\d+\.\d+$/.test(cleanVer)) {
      throw new Error(`Phiên bản cập nhật không hợp lệ: '${version}'.`);
    }
    const cleanExpectedSha = String(expectedSha256 || "").trim().toLowerCase();
    if (!/^[0-9a-f]{64}$/.test(cleanExpectedSha)) {
      throw new Error("Thiếu hoặc sai định dạng mã kiểm tra SHA-256 trong version.json.");
    }
    const cleanSig = String(signatureRsaB64 || "").trim();
    if (!cleanSig) {
      throw new Error("Thiếu chữ ký số RSA-2048 trong version.json — từ chối cập nhật!");
    }
    const cleanSpki = String(pinnedSpkiB64 || "").trim();
    if (!cleanSpki) {
      throw new Error("Không đọc được khóa công khai (manifest.json.key) để xác thực gói cập nhật.");
    }

    const actualSha256 = await sha256Hex(zipBytes);
    if (actualSha256 !== cleanExpectedSha) {
      throw new Error(
        `Mã kiểm tra SHA-256 gói ZIP không khớp (tải về bị lỗi hoặc bị chỉnh sửa) — đã hủy cập nhật!`
      );
    }

    const spkiBytes = base64ToUint8Array(cleanSpki);
    const sigBytes = base64ToUint8Array(cleanSig);
    if (spkiBytes.byteLength < 128 || sigBytes.byteLength < 128) {
      throw new Error("Khóa công khai hoặc chữ ký RSA-2048 không đúng kích thước.");
    }

    const publicKey = await crypto.subtle.importKey(
      "spki",
      spkiBytes,
      { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
      false,
      ["verify"]
    );

    const canonicalPayload = `omnivault-ext-zip-v1|${cleanVer}|${actualSha256}`;
    const canonicalBytes = textEncoder.encode(canonicalPayload);
    const valid = await crypto.subtle.verify("RSASSA-PKCS1-v1_5", publicKey, sigBytes, canonicalBytes);
    if (!valid) {
      throw new Error(
        "Chữ ký số RSA-2048 của gói ZIP KHÔNG HỢP LỆ — đã hủy cập nhật để bảo vệ an toàn!"
      );
    }

    return { ok: true, version: cleanVer, sha256: actualSha256 };
  }

  // ---------------------------------------------------------------------------
  // Directory Ownership Check & Safe Atomic-Ordered Writer
  // ---------------------------------------------------------------------------
  async function verifyTargetExtensionDirectory(dirHandle, pinnedSpkiB64) {
    if (!dirHandle || typeof dirHandle.getFileHandle !== "function") {
      throw new Error("Tay cầm thư mục tiện ích không hợp lệ.");
    }
    let manifestFileHandle;
    try {
      manifestFileHandle = await dirHandle.getFileHandle("manifest.json");
    } catch (_) {
      throw new Error(
        "Thư mục đã chọn không có tệp manifest.json! Vui lòng chọn đúng thư mục chứa tiện ích OmniVault."
      );
    }
    let existingManifest;
    try {
      const file = await manifestFileHandle.getFile();
      const rawText = await file.text();
      existingManifest = JSON.parse(rawText);
    } catch (_) {
      throw new Error("Không đọc được manifest.json trong thư mục đã chọn.");
    }

    const expectedKey = String(pinnedSpkiB64 || "").trim();
    const dirKey = String(existingManifest?.key || "").trim();
    if (!expectedKey || dirKey !== expectedKey) {
      throw new Error(
        "Thư mục đã chọn KHÔNG PHẢI thư mục tiện ích OmniVault hiện tại (khóa manifest.json.key không khớp) — đã hủy để tránh ghi nhầm!"
      );
    }

    return {
      ok: true,
      currentVersion: String(existingManifest?.version || ""),
      name: String(existingManifest?.name || "OmniVault")
    };
  }

  function isOptionalDesktopHelperPath(relPath) {
    return /\.(bat|cmd|ps1)$/i.test(String(relPath || "").trim());
  }

  function isRetryableFsWriteError(err) {
    const name = String(err?.name || "");
    return (
      name === "AbortError" ||
      name === "NoModificationAllowedError" ||
      name === "InvalidStateError" ||
      name === "NotReadableError" ||
      name === "UnknownError"
    );
  }

  function sleepMs(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  async function isExistingFileIdentical(targetDir, fileName, nextBytes) {
    try {
      const existingHandle = await targetDir.getFileHandle(fileName, { create: false });
      if (!existingHandle || typeof existingHandle.getFile !== "function") return false;
      const existingFile = await existingHandle.getFile();
      if (!existingFile || typeof existingFile.arrayBuffer !== "function") return false;
      if (existingFile.size !== nextBytes.byteLength) return false;
      const existingBytes = new Uint8Array(await existingFile.arrayBuffer());
      if (existingBytes.byteLength !== nextBytes.byteLength) return false;
      for (let i = 0; i < nextBytes.byteLength; i++) {
        if (existingBytes[i] !== nextBytes[i]) return false;
      }
      return true;
    } catch (_) {
      return false;
    }
  }

  async function writeFileBytesWithRetry(targetDir, fileName, entryPath, bytes, maxAttempts = 4) {
    const backoffMs = [200, 500, 1000];
    let lastErr = null;
    for (let attempt = 0; attempt < maxAttempts; attempt++) {
      let writable = null;
      try {
        const fileHandle = await targetDir.getFileHandle(fileName, { create: true });
        writable = await fileHandle.createWritable();
        await writable.write(bytes);
        await writable.close();
        return;
      } catch (writeErr) {
        lastErr = writeErr;
        try {
          if (writable && typeof writable.abort === "function") {
            await writable.abort();
          }
        } catch (_) {}
        if (attempt < maxAttempts - 1 && isRetryableFsWriteError(writeErr)) {
          await sleepMs(backoffMs[Math.min(attempt, backoffMs.length - 1)]);
          continue;
        }
        break;
      }
    }
    const origName = String(lastErr?.name || "Error");
    const origMsg = String(lastErr?.message || lastErr || "Không thể ghi tệp");
    const wrapped = new Error(`Không ghi được tệp '${entryPath}' (${origName}: ${origMsg})`);
    wrapped.name = "FsWriteError";
    wrapped.originalName = origName;
    wrapped.originalMessage = origMsg;
    wrapped.filePath = entryPath;
    throw wrapped;
  }

  async function applyVerifiedEntriesToDirectory(
    dirHandle,
    entries,
    expectedVersion,
    pinnedSpkiB64,
    onProgress
  ) {
    if (!Array.isArray(entries) || entries.length === 0) {
      throw new Error("Không có tệp nào để ghi cập nhật.");
    }

    // 1. Validate inner manifest.json BEFORE touching a single file on disk
    const manifestEntry = entries.find((e) => e.path.toLowerCase() === "manifest.json");
    if (!manifestEntry) {
      throw new Error("Gói cập nhật ZIP thiếu tệp manifest.json.");
    }
    let newManifest;
    try {
      newManifest = JSON.parse(textDecoderFatal.decode(manifestEntry.bytes));
    } catch (_) {
      throw new Error("Tệp manifest.json trong gói cập nhật bị hỏng.");
    }

    const expectedKey = String(pinnedSpkiB64 || "").trim();
    if (!expectedKey || String(newManifest?.key || "").trim() !== expectedKey) {
      throw new Error(
        "Gói cập nhật có khóa manifest.json.key khác bản hiện tại — hủy để bảo toàn Extension ID & dữ liệu kho!"
      );
    }
    const cleanExpectedVer = String(expectedVersion || "").replace(/^v/i, "").trim();
    if (cleanExpectedVer && compareVersions(newManifest?.version, cleanExpectedVer) !== 0) {
      throw new Error(
        `Phiên bản trong manifest.json (${newManifest?.version}) không khớp phiên bản đã ký (${cleanExpectedVer}).`
      );
    }

    // 2. Re-verify target directory ownership right before writing
    await verifyTargetExtensionDirectory(dirHandle, expectedKey);

    // 3. Atomic ordering: regular files first -> active updater files -> manifest.json strictly LAST
    const activeUpdaterSet = new Set(["updater.html", "release_center.js", "updater.js", "zip_updater.js"]);
    const regularNonManifest = [];
    const activeUpdaterEntries = [];
    for (const e of entries) {
      const lp = e.path.toLowerCase();
      if (lp === "manifest.json") continue;
      if (activeUpdaterSet.has(lp)) {
        activeUpdaterEntries.push(e);
      } else {
        regularNonManifest.push(e);
      }
    }
    const ordered = [...regularNonManifest, ...activeUpdaterEntries, manifestEntry];

    let writtenCount = 0;
    let skippedIdenticalCount = 0;
    const skippedOptionalFiles = [];

    for (let i = 0; i < ordered.length; i++) {
      const entry = ordered[i];
      if (typeof onProgress === "function") {
        onProgress({
          stage: "writing",
          current: i + 1,
          total: ordered.length,
          file: entry.path
        });
      }

      const parts = entry.path.split("/");
      let targetDir = dirHandle;
      for (let s = 0; s < parts.length - 1; s++) {
        targetDir = await targetDir.getDirectoryHandle(parts[s], { create: true });
      }
      const fileName = parts[parts.length - 1];

      // Skip disk write when identical bytes are already on disk (faster & avoids Defender/SafeBrowsing locks)
      if (await isExistingFileIdentical(targetDir, fileName, entry.bytes)) {
        skippedIdenticalCount += 1;
        writtenCount += 1;
        continue;
      }

      if (isOptionalDesktopHelperPath(entry.path)) {
        // Chromium File System Access API hard-blocks writing .bat/.cmd/.ps1 scripts on Windows;
        // these optional desktop launchers are NOT needed by the browser runtime, so skip gracefully if blocked!
        try {
          await writeFileBytesWithRetry(targetDir, fileName, entry.path, entry.bytes, 1);
          writtenCount += 1;
        } catch (_) {
          skippedOptionalFiles.push(entry.path);
        }
        continue;
      }

      await writeFileBytesWithRetry(targetDir, fileName, entry.path, entry.bytes, 4);
      writtenCount += 1;
    }

    return {
      ok: true,
      version: String(newManifest.version || cleanExpectedVer),
      writtenCount,
      skippedIdenticalCount,
      skippedOptionalFiles
    };
  }

  // ---------------------------------------------------------------------------
  // Network Fetchers (Strict Allowlist + Streaming Size Cap + Timeout Guard)
  // ---------------------------------------------------------------------------
  async function fetchBytesWithLimit(url, fetchImpl, timeoutMs = FETCH_ZIP_TIMEOUT_MS) {
    if (!isAllowedUpdateUrl(url)) {
      throw new Error(`Từ chối tải từ địa chỉ không thuộc kho OmniVault chính thức: ${url}`);
    }
    const timeoutHandle = createFetchTimeout(timeoutMs);
    const fetchOpts = { cache: "no-store" };
    if (timeoutHandle.signal) {
      fetchOpts.signal = timeoutHandle.signal;
    }
    try {
      const res = await fetchImpl(url, fetchOpts);
      if (!res.ok) {
        throw new Error(`Không tải được gói cập nhật (HTTP ${res.status}).`);
      }
      const contentLen = Number(res.headers?.get?.("content-length") || 0);
      if (contentLen > MAX_ZIP_DOWNLOAD_BYTES) {
        throw new Error("Dung lượng gói tải về vượt quá giới hạn an toàn (10 MB).");
      }

      if (res.body && typeof res.body.getReader === "function") {
        const reader = res.body.getReader();
        const chunks = [];
        let total = 0;
        while (true) {
          const { value, done } = await reader.read();
          if (done) break;
          if (value && value.byteLength > 0) {
            total += value.byteLength;
            if (total > MAX_ZIP_DOWNLOAD_BYTES) {
              try {
                await reader.cancel("Download exceeds limit");
              } catch (_) {}
              throw new Error("Dung lượng gói tải về vượt quá giới hạn an toàn (10 MB).");
            }
            chunks.push(value);
          }
        }
        const out = new Uint8Array(total);
        let off = 0;
        for (let i = 0; i < chunks.length; i++) {
          out.set(chunks[i], off);
          off += chunks[i].byteLength;
        }
        return out;
      }

      const arr = new Uint8Array(await res.arrayBuffer());
      if (arr.byteLength > MAX_ZIP_DOWNLOAD_BYTES) {
        throw new Error("Dung lượng gói tải về vượt quá giới hạn an toàn (10 MB).");
      }
      return arr;
    } finally {
      timeoutHandle.clear();
    }
  }

  async function fetchSignedVersionMetadata(preferredUrls = [], fetchImpl = globalThis.fetch) {
    const now = Date.now();
    const candidates = [];
    for (const raw of preferredUrls) {
      if (raw && isAllowedUpdateUrl(raw)) {
        candidates.push(raw);
      }
    }
    candidates.push(`${GITHUB_VERSION_JSON_URL}?t=${now}`);

    let lastErr = null;
    for (const url of candidates) {
      try {
        const res = await fetchWithTimeout(url, { cache: "no-store" }, FETCH_META_TIMEOUT_MS, fetchImpl);
        if (!res.ok) {
          lastErr = new Error(`HTTP ${res.status}`);
          continue;
        }
        const vj = await res.json();
        const ver = String(vj?.version || "").replace(/^v/i, "").trim();
        const zipSha256 = String(vj?.zip_sha256 || "").trim().toLowerCase();
        const sigRsa = String(vj?.signature_rsa_b64 || "").trim();
        if (ver && zipSha256 && sigRsa) {
          return {
            latestVersion: ver,
            changelog: String(vj?.changelog || "").trim(),
            unpackedZipUrl: isAllowedUpdateUrl(vj?.unpacked_zip_url) ? vj.unpacked_zip_url : "",
            unpackedLatestUrl: isAllowedUpdateUrl(vj?.unpacked_latest)
              ? vj.unpacked_latest
              : DEFAULT_UNPACKED_LATEST_URL,
            zipSha256,
            signatureRsaB64: sigRsa,
            releaseHtmlUrl: isAllowedUpdateUrl(vj?.release_url) ? vj.release_url : ""
          };
        }
      } catch (e) {
        lastErr = e;
      }
    }
    throw new Error(
      `Không tải được siêu dữ liệu chữ ký số version.json từ GitHub (${lastErr?.message || "lỗi mạng"}).`
    );
  }

  // ---------------------------------------------------------------------------
  // End-to-End Self-Update Orchestrator
  // ---------------------------------------------------------------------------
  async function performSelfUpdate({
    dirHandle,
    updateInfo,
    pinnedSpkiB64,
    onProgress,
    fetchImpl = globalThis.fetch
  }) {
    const report = (payload) => {
      if (typeof onProgress === "function") {
        try {
          onProgress(payload);
        } catch (_) {}
      }
    };

    const spki =
      String(pinnedSpkiB64 || "").trim() ||
      (typeof chrome !== "undefined" && chrome?.runtime?.getManifest
        ? String(chrome.runtime.getManifest().key || "").trim()
        : "");

    if (!spki) {
      throw new Error("Không tìm thấy khóa công khai manifest.json.key của bản cài hiện tại.");
    }

    // Pre-check directory before downloading anything so wrong folder fails instantaneously!
    await verifyTargetExtensionDirectory(dirHandle, spki);

    report({ stage: "metadata", message: "Đang kiểm tra siêu dữ liệu chữ ký số từ GitHub..." });

    let meta = {
      latestVersion: String(updateInfo?.latestVersion || "").replace(/^v/i, "").trim(),
      unpackedZipUrl: String(updateInfo?.unpackedZipUrl || "").trim(),
      unpackedLatestUrl: String(updateInfo?.unpackedLatestUrl || "").trim(),
      zipSha256: String(updateInfo?.zipSha256 || "").trim().toLowerCase(),
      signatureRsaB64: String(updateInfo?.signatureRsaB64 || "").trim(),
      versionJsonUrl: String(updateInfo?.versionJsonUrl || "").trim()
    };

    if (!meta.latestVersion || !meta.zipSha256 || !meta.signatureRsaB64) {
      const fresh = await fetchSignedVersionMetadata(
        meta.versionJsonUrl ? [meta.versionJsonUrl] : [],
        fetchImpl
      );
      meta = {
        ...meta,
        ...fresh,
        unpackedZipUrl: fresh.unpackedZipUrl || meta.unpackedZipUrl,
        unpackedLatestUrl: fresh.unpackedLatestUrl || meta.unpackedLatestUrl || DEFAULT_UNPACKED_LATEST_URL
      };
    }

    report({
      stage: "downloading",
      version: meta.latestVersion,
      message: `Đang tải gói v${meta.latestVersion} từ GitHub...`
    });

    const downloadUrls = [];
    if (meta.unpackedZipUrl && isAllowedUpdateUrl(meta.unpackedZipUrl)) {
      downloadUrls.push(meta.unpackedZipUrl);
    }
    const latestUrl = meta.unpackedLatestUrl || DEFAULT_UNPACKED_LATEST_URL;
    if (isAllowedUpdateUrl(latestUrl) && !downloadUrls.includes(latestUrl)) {
      downloadUrls.push(latestUrl);
    }
    if (downloadUrls.length === 0) {
      throw new Error("Không có đường dẫn tải hợp lệ thuộc kho GitHub chính thức.");
    }

    let zipBytes = null;
    let lastVerifyErr = null;
    for (let i = 0; i < downloadUrls.length; i++) {
      const candidateUrl = downloadUrls[i];
      try {
        const downloaded = await fetchBytesWithLimit(candidateUrl, fetchImpl);
        report({
          stage: "verifying",
          version: meta.latestVersion,
          message: "Đang xác thực SHA-256 & chữ ký số RSA-2048..."
        });
        await verifySignedZipPackage({
          zipBytes: downloaded,
          version: meta.latestVersion,
          expectedSha256: meta.zipSha256,
          signatureRsaB64: meta.signatureRsaB64,
          pinnedSpkiB64: spki
        });
        zipBytes = downloaded;
        break;
      } catch (e) {
        lastVerifyErr = e;
      }
    }

    if (!zipBytes) {
      throw lastVerifyErr || new Error("Tải hoặc xác thực gói cập nhật thất bại.");
    }

    report({
      stage: "extracting",
      version: meta.latestVersion,
      message: "Đang giải nén an toàn & kiểm tra CRC-32..."
    });
    const entries = await extractZipEntries(zipBytes);

    report({
      stage: "writing",
      version: meta.latestVersion,
      current: 0,
      total: entries.length,
      message: `Đang ghi ${entries.length} tệp cập nhật...`
    });
    const writeRes = await applyVerifiedEntriesToDirectory(
      dirHandle,
      entries,
      meta.latestVersion,
      spki,
      onProgress
    );

    report({
      stage: "reloading",
      version: writeRes.version,
      writtenCount: writeRes.writtenCount,
      message: `Hoàn tất v${writeRes.version}! Đang nạp lại tiện ích...`
    });

    return {
      ok: true,
      version: writeRes.version,
      writtenCount: writeRes.writtenCount,
      sha256: meta.zipSha256
    };
  }

  return {
    UPDATER_IDB_NAME,
    UPDATER_IDB_STORE,
    UPDATER_DIR_KEY,
    MAX_ZIP_ENTRIES,
    MAX_ZIP_DOWNLOAD_BYTES,
    MAX_UNCOMPRESSED_BYTES,
    FETCH_META_TIMEOUT_MS,
    FETCH_ZIP_TIMEOUT_MS,
    fetchWithTimeout,
    compareVersions,
    isAllowedUpdateUrl,
    computeCrc32,
    sha256Hex,
    isFileSystemAccessSupported,
    saveDirectoryHandle,
    getStoredDirectoryHandle,
    clearStoredDirectoryHandle,
    queryDirectoryPermission,
    requestDirectoryPermission,
    validateZipEntryPath,
    extractZipEntries,
    verifySignedZipPackage,
    verifyTargetExtensionDirectory,
    applyVerifiedEntriesToDirectory,
    fetchSignedVersionMetadata,
    performSelfUpdate
  };
});
