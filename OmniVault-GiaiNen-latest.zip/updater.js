(function () {
  "use strict";

  const versionBadge = document.getElementById("versionBadge");
  const statusHeadline = document.getElementById("statusHeadline");
  const changelogBox = document.getElementById("changelogBox");
  const nativeHostCard = document.getElementById("nativeHostCard");
  const nativeHostTitle = document.getElementById("nativeHostTitle");
  const nativeHostDesc = document.getElementById("nativeHostDesc");
  const chkAutoUpdateBg = document.getElementById("chkAutoUpdateBg");
  const folderCard = document.getElementById("folderCard");
  const folderTitle = document.getElementById("folderTitle");
  const folderChip = document.getElementById("folderChip");
  const folderDesc = document.getElementById("folderDesc");
  const btnPickFolder = document.getElementById("btnPickFolder");
  const btnForgetFolder = document.getElementById("btnForgetFolder");
  const btnRecheckNative = document.getElementById("btnRecheckNative");
  const statusAlert = document.getElementById("statusAlert");
  const progressCard = document.getElementById("progressCard");

  // Notify service worker while updater window is open so deferred silent auto-update won't interrupt UI
  try {
    if (typeof chrome?.runtime?.connect === "function") {
      chrome.runtime.connect({ name: "omnivault_ui_open" });
    }
  } catch (_) {}

  const stepDownload = document.getElementById("stepDownload");
  const stepDownloadText = document.getElementById("stepDownloadText");
  const stepVerify = document.getElementById("stepVerify");
  const stepVerifyText = document.getElementById("stepVerifyText");
  const stepWrite = document.getElementById("stepWrite");
  const stepWriteText = document.getElementById("stepWriteText");
  const stepReload = document.getElementById("stepReload");
  const stepReloadText = document.getElementById("stepReloadText");

  const btnPrimaryAction = document.getElementById("btnPrimaryAction");
  const btnSecondaryAction = document.getElementById("btnSecondaryAction");
  const btnDownloadZip = document.getElementById("btnDownloadZip");
  const btnReloadExt = document.getElementById("btnReloadExt");
  const btnOpenRelease = document.getElementById("btnOpenRelease");

  const manifest = chrome?.runtime?.getManifest ? chrome.runtime.getManifest() : {};
  const pinnedSpkiB64 = String(manifest.key || "").trim();
  const currentVersion = String(manifest.version || "0.0.0");
  const isCrxManaged = Boolean(manifest.update_url);
  const fsSupported = OmniVaultUpdater.isFileSystemAccessSupported();
  const autoStartRequested = new URLSearchParams(window.location.search).get("auto") === "1";

  let updateStatus = null;
  let nativeStatus = { available: false, autoUpdateBgEnabled: true, dirName: "" };
  let nativeStatusFetchedAt = 0;
  let storedDirHandle = null;
  let storedDirPermission = "prompt";
  let busy = false;

  function sendRuntimeMsg(payload) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(payload, (resp) => {
          void chrome.runtime.lastError;
          resolve(resp || null);
        });
      } catch (_) {
        resolve(null);
      }
    });
  }

  function showAlert(message, type = "info") {
    if (!statusAlert) return;
    if (!message) {
      statusAlert.hidden = true;
      return;
    }
    statusAlert.className = `alert ${type}`;
    statusAlert.textContent = message;
    statusAlert.hidden = false;
  }

  function setStepState(el, state, dotSymbol) {
    if (!el) return;
    el.className = state ? `step ${state}` : "step";
    const dot = el.querySelector(".step-dot");
    if (dot && dotSymbol) dot.textContent = dotSymbol;
  }

  function resetProgressSteps() {
    setStepState(stepDownload, "", "1");
    setStepState(stepVerify, "", "2");
    setStepState(stepWrite, "", "3");
    setStepState(stepReload, "", "4");
    stepDownloadText.textContent = "Tải gói cập nhật chính chủ từ GitHub";
    stepVerifyText.textContent = "Xác thực SHA-256 & chữ ký số RSA-2048";
    stepWriteText.textContent = "Giải nén an toàn & ghi tệp (manifest.json sau cùng)";
    stepReloadText.textContent = "Nạp lại tiện ích & giữ nguyên toàn bộ dữ liệu kho";
  }

  function applyProgressEvent(ev) {
    progressCard.hidden = false;
    if (ev.stage === "metadata" || ev.stage === "downloading") {
      setStepState(stepDownload, "active", "1");
      if (ev.message) stepDownloadText.textContent = ev.message;
    } else if (ev.stage === "verifying") {
      setStepState(stepDownload, "done", "✓");
      setStepState(stepVerify, "active", "2");
      if (ev.message) stepVerifyText.textContent = ev.message;
    } else if (ev.stage === "extracting") {
      setStepState(stepDownload, "done", "✓");
      setStepState(stepVerify, "done", "✓");
      setStepState(stepWrite, "active", "3");
      if (ev.message) stepWriteText.textContent = ev.message;
    } else if (ev.stage === "writing") {
      setStepState(stepDownload, "done", "✓");
      setStepState(stepVerify, "done", "✓");
      setStepState(stepWrite, "active", "3");
      if (typeof ev.current === "number" && typeof ev.total === "number" && ev.total > 0) {
        stepWriteText.textContent = `Đang ghi tệp an toàn (${ev.current}/${ev.total}): ${ev.file || ""}`;
      } else if (ev.message) {
        stepWriteText.textContent = ev.message;
      }
    } else if (ev.stage === "reloading") {
      setStepState(stepDownload, "done", "✓");
      setStepState(stepVerify, "done", "✓");
      setStepState(stepWrite, "done", "✓");
      setStepState(stepReload, "active", "4");
      if (ev.message) stepReloadText.textContent = ev.message;
    }
  }

  function markCurrentStepError() {
    for (const el of [stepDownload, stepVerify, stepWrite, stepReload]) {
      if (el.classList.contains("active")) {
        setStepState(el, "error", "!");
        return;
      }
    }
  }

  function setBusy(nextBusy) {
    busy = nextBusy;
    btnPrimaryAction.disabled = nextBusy;
    btnSecondaryAction.disabled = nextBusy;
    btnPickFolder.disabled = nextBusy;
    btnForgetFolder.disabled = nextBusy;
    btnReloadExt.disabled = nextBusy;
  }

  async function refreshFolderState(forceNativeProbe = false) {
    if (isCrxManaged) {
      if (nativeHostCard) nativeHostCard.hidden = true;
      folderCard.hidden = true;
      return;
    }

    if (forceNativeProbe || Date.now() - nativeStatusFetchedAt > 5000) {
      const nResp = await sendRuntimeMsg({ type: "GET_NATIVE_UPDATER_STATUS" });
      if (nResp && nResp.ok) {
        nativeStatus = nResp;
        nativeStatusFetchedAt = Date.now();
      } else {
        nativeStatus = { available: false, autoUpdateBgEnabled: true, dirName: "" };
      }
    }

    if (nativeStatus.available) {
      if (nativeHostCard) nativeHostCard.hidden = false;
      if (nativeHostTitle) {
        nativeHostTitle.textContent = `🤖 Tự động 100% • Thư mục: ${nativeStatus.dirName || "OmniVault"}`;
      }
      if (nativeHostDesc) {
        const pathLine = nativeStatus.dirPath ? `Thư mục tự cập nhật: ${nativeStatus.dirPath} — ` : "";
        nativeHostDesc.textContent =
          `${pathLine}tự kiểm tra mỗi 20 phút, xác thực SHA-256 & RSA-2048 và tự nạp lại không cần chọn thư mục hay hỏi quyền.`;
      }
      if (chkAutoUpdateBg) {
        chkAutoUpdateBg.checked = Boolean(nativeStatus.autoUpdateBgEnabled);
      }
      folderCard.hidden = true;
      return;
    }

    if (nativeHostCard) nativeHostCard.hidden = true;
    folderCard.hidden = false;

    if (!fsSupported) {
      folderTitle.textContent = "📁 Trình duyệt chưa hỗ trợ File System Access API";
      folderChip.className = "status-chip prompt";
      folderChip.textContent = "Dùng .zip thủ công";
      folderDesc.textContent =
        "Hãy dùng nút '📥 Tải .zip thủ công' bên dưới hoặc nâng cấp Chrome/Edge lên bản mới nhất để cập nhật 1 chạm.";
      btnPickFolder.hidden = true;
      btnForgetFolder.hidden = true;
      return;
    }

    storedDirHandle = await OmniVaultUpdater.getStoredDirectoryHandle();
    if (!storedDirHandle) {
      storedDirPermission = "prompt";
      folderTitle.textContent = "📁 Chưa liên kết thư mục cài tiện ích";
      folderChip.className = "status-chip unlinked";
      folderChip.textContent = "Chọn 1 lần duy nhất";
      folderDesc.textContent =
        "Chọn đúng thư mục đang nạp OmniVault (chứa tệp manifest.json). Hệ thống sẽ xác minh khóa chính chủ trước khi ghi tệp.";
      btnPickFolder.textContent = "📂 Chọn thư mục OmniVault";
      btnPickFolder.hidden = false;
      btnForgetFolder.hidden = true;
      return;
    }

    storedDirPermission = await OmniVaultUpdater.queryDirectoryPermission(storedDirHandle);
    folderTitle.textContent = `📁 Thư mục: ${storedDirHandle.name || "OmniVault"}`;
    if (storedDirPermission === "granted") {
      folderChip.className = "status-chip ready";
      folderChip.textContent = "Sẵn sàng 1 chạm";
      folderDesc.textContent =
        "Đã cấp quyền ghi cho thư mục tiện ích này — bấm cập nhật sẽ tải, xác thực chữ ký RSA-2048, giải nén và tự nạp lại ngay.";
    } else {
      folderChip.className = "status-chip prompt";
      folderChip.textContent = "Đã liên kết";
      folderDesc.textContent =
        "Thư mục đã được ghi nhớ sẵn — khi bấm cập nhật, trình duyệt chỉ hỏi xác nhận cho phép ghi 1 lần trong phiên.";
    }
    btnPickFolder.textContent = "📂 Đổi thư mục khác";
    btnPickFolder.hidden = false;
    btnForgetFolder.hidden = false;
  }

  function renderUI() {
    const curVer = updateStatus?.currentVersion || currentVersion;
    const latestVer = updateStatus?.latestVersion || curVer;
    const hasUpdate = Boolean(updateStatus?.hasUpdate);

    versionBadge.textContent = hasUpdate ? `v${curVer} → v${latestVer}` : `v${curVer}`;

    if (!updateStatus) {
      statusHeadline.className = "headline";
      statusHeadline.textContent = "Đang kiểm tra bản mới từ GitHub...";
      changelogBox.hidden = true;
      btnPrimaryAction.textContent = "⏳ Đang kiểm tra...";
      btnSecondaryAction.hidden = true;
      return;
    }

    if (!updateStatus.ok) {
      statusHeadline.className = "headline";
      statusHeadline.textContent = `Không kết nối được GitHub (đang dùng v${curVer})`;
      changelogBox.hidden = true;
      showAlert(updateStatus.error || "Không kiểm tra được bản cập nhật từ GitHub.", "error");
      btnPrimaryAction.textContent = "🔄 Thử kiểm tra lại";
      btnSecondaryAction.hidden = true;
      return;
    }

    if (updateStatus.changelog) {
      changelogBox.textContent = updateStatus.changelog;
      changelogBox.hidden = false;
    } else {
      changelogBox.hidden = true;
    }

    if (hasUpdate) {
      const targetVer = updateStatus.pendingCrxReloadVersion || latestVer;
      statusHeadline.className = "headline has-update";
      statusHeadline.textContent = `🚀 Có bản mới v${targetVer} trên GitHub`;
      if (isCrxManaged) {
        btnPrimaryAction.textContent = `⚡ Cập nhật tự động ngay lên v${targetVer}`;
        btnSecondaryAction.hidden = true;
      } else if (nativeStatus.available) {
        btnPrimaryAction.textContent = `⚡ Cập nhật tự động 100% lên v${targetVer}`;
        btnSecondaryAction.textContent = "🔄 Kiểm tra lại từ GitHub";
        btnSecondaryAction.hidden = false;
      } else if (!fsSupported) {
        btnPrimaryAction.textContent = `📥 Tải gói cập nhật v${targetVer} (.zip)`;
        btnSecondaryAction.hidden = true;
      } else if (storedDirHandle) {
        btnPrimaryAction.textContent = `⚡ Cập nhật ngay lên v${targetVer}`;
        btnSecondaryAction.textContent = "🔄 Kiểm tra lại từ GitHub";
        btnSecondaryAction.hidden = false;
      } else {
        btnPrimaryAction.textContent = `📂 Chọn thư mục OmniVault & Cập nhật v${targetVer}`;
        btnSecondaryAction.textContent = "🔄 Kiểm tra lại từ GitHub";
        btnSecondaryAction.hidden = false;
      }
      return;
    }

    // Already on latest version
    statusHeadline.className = "headline up-to-date";
    statusHeadline.textContent = `✓ Đang dùng bản mới nhất (v${curVer})`;
    if (!isCrxManaged && nativeStatus.available) {
      btnPrimaryAction.textContent = "⚡ 1-Click Kiểm tra & Tự cập nhật ngay";
      btnSecondaryAction.textContent = `🔁 Cài lại v${latestVer} (Kiểm thử tự động 100%)`;
      btnSecondaryAction.hidden = false;
    } else if (!isCrxManaged && fsSupported && !storedDirHandle) {
      btnPrimaryAction.textContent = "📂 Liên kết sẵn thư mục tiện ích để cập nhật 1 chạm";
      btnSecondaryAction.textContent = "🔄 Kiểm tra lại từ GitHub";
      btnSecondaryAction.hidden = false;
    } else if (!isCrxManaged && fsSupported && storedDirHandle) {
      btnPrimaryAction.textContent = "🔄 Kiểm tra bản mới từ GitHub";
      btnSecondaryAction.textContent = `🔁 Cài lại v${latestVer} ngay vào thư mục đã liên kết`;
      btnSecondaryAction.hidden = false;
    } else {
      btnPrimaryAction.textContent = "🔄 Kiểm tra bản mới từ GitHub";
      btnSecondaryAction.hidden = true;
    }
  }

  function formatFriendlyFsError(err, context = "general") {
    const name = String(err?.name || "");
    const origName = String(err?.originalName || name);
    const filePath = String(err?.filePath || "");
    const msg = String(err?.message || err || "Lỗi không xác định");
    if (context === "picker" && name === "AbortError") {
      return { canceled: true, text: "Đã hủy chọn thư mục." };
    }
    if (name === "FsWriteError" || (context === "write" && (origName === "AbortError" || origName === "SecurityError" || origName === "NoModificationAllowedError"))) {
      return {
        canceled: false,
        text:
          `Trình duyệt (Safe Browsing / Windows) đã chặn ghi tệp ${filePath ? `'${filePath}' ` : ""}qua File System Access API (${origName}). Để cập nhật mượt 100% không bao giờ bị trình duyệt chặn: mở thư mục tiện ích và nhấp đúp tệp Bat-TuDongCapNhat-100.bat (1 lần duy nhất, không cần Admin) rồi bấm 'Kiểm tra kích hoạt'!`
      };
    }
    if (name === "SecurityError" || /system files|sensitive/i.test(msg)) {
      return {
        canceled: false,
        text:
          "Trình duyệt chặn ghi trực tiếp vào thư mục hệ thống hoặc thư mục gốc (như Downloads/Desktop/AppData). Hãy chạy Bat-TuDongCapNhat-100.bat (1 lần duy nhất) để cập nhật tự động 100%, hoặc đặt thư mục OmniVault ở ổ riêng (VD: D:\\OmniVault-Extension)."
      };
    }
    if (name === "NotAllowedError") {
      return {
        canceled: false,
        text: "Bạn chưa cấp quyền ghi tệp cho thư mục tiện ích. Bấm lại nút cập nhật và chọn 'Chỉnh sửa tệp' khi trình duyệt hỏi."
      };
    }
    return { canceled: false, text: msg };
  }

  async function pickAndVerifyFolder() {
    if (!fsSupported) {
      showAlert("Trình duyệt không hỗ trợ chọn thư mục trực tiếp (File System Access API).", "error");
      return null;
    }
    try {
      const picked = await window.showDirectoryPicker({
        id: "omnivault-ext-dir",
        mode: "readwrite"
      });
      await OmniVaultUpdater.verifyTargetExtensionDirectory(picked, pinnedSpkiB64);
      await OmniVaultUpdater.saveDirectoryHandle(picked);
      await refreshFolderState();
      renderUI();
      return picked;
    } catch (e) {
      const formatted = formatFriendlyFsError(e, "picker");
      showAlert(formatted.text, formatted.canceled ? "info" : "error");
      return null;
    }
  }

  async function ensureWritableFolderHandle(forcePick = false) {
    let handle = forcePick ? null : storedDirHandle;
    if (!handle) {
      handle = await pickAndVerifyFolder();
      if (!handle) return null;
    }

    let perm = await OmniVaultUpdater.queryDirectoryPermission(handle);
    if (perm !== "granted") {
      try {
        perm = await OmniVaultUpdater.requestDirectoryPermission(handle);
      } catch (e) {
        const formatted = formatFriendlyFsError(e);
        showAlert(formatted.text, formatted.canceled ? "info" : "error");
        return null;
      }
    }

    if (perm !== "granted") {
      showAlert(
        "Cần quyền ghi (readwrite) trên thư mục tiện ích để tự giải nén bản mới. Vui lòng chọn 'Cho phép' khi trình duyệt hỏi.",
        "error"
      );
      return null;
    }

    // Re-verify ownership in case user moved/replaced contents of linked folder
    try {
      await OmniVaultUpdater.verifyTargetExtensionDirectory(handle, pinnedSpkiB64);
    } catch (e) {
      showAlert(String(e?.message || e), "error");
      return null;
    }

    await refreshFolderState();
    return handle;
  }

  async function runSelfUpdateFlow(allowReinstallLatest = false) {
    if (busy) return;
    setBusy(true);
    try {
      if (isCrxManaged) {
        showAlert("Đang yêu cầu trình duyệt áp dụng bản cập nhật CRX tự động...", "info");
        const res = await sendRuntimeMsg({ type: "APPLY_EXTENSION_UPDATE_NOW" });
        if (res?.reloading) {
          showAlert("✓ Đang nạp lại tiện ích với phiên bản mới nhất...", "success");
        } else {
          showAlert(
            res?.status === "throttled"
              ? "Trình duyệt đang chờ chu kỳ kiểm tra CRX, thử lại sau ít phút."
              : "Trình duyệt sẽ tự tải bản mới trong nền — kiểm tra lại sau giây lát.",
            "info"
          );
        }
        return;
      }

      // Tier 2: Native Messaging Host (100% auto, zero folder picker, zero permission prompts!)
      if (nativeStatus.available) {
        resetProgressSteps();
        progressCard.hidden = false;
        setStepState(stepDownload, "active", "1");
        stepDownloadText.textContent = "Đang kiểm tra thư mục, tải gói từ GitHub & xác thực SHA-256 + RSA-2048...";
        showAlert("Đang chạy cập nhật tự động 100% qua Native Host...", "info");

        const res = await sendRuntimeMsg({
          type: "RUN_NATIVE_SELF_UPDATE",
          allowSilentReload: true,
          force: Boolean(allowReinstallLatest)
        });
        if (!res || !res.ok) {
          markCurrentStepError();
          showAlert(res?.error || "Cập nhật qua Native Host thất bại.", "error");
          return;
        }
        if (res.alreadyUpToDate) {
          setStepState(stepDownload, "done", "✓");
          setStepState(stepVerify, "done", "✓");
          setStepState(stepWrite, "done", "✓");
          setStepState(stepReload, "done", "✓");
          stepReloadText.textContent = `Thư mục đã ở phiên bản mới nhất v${res.version}`;
          showAlert(`✓ Đang dùng phiên bản mới nhất (v${res.version}).`, "success");
          return;
        }

        setStepState(stepDownload, "done", "✓");
        setStepState(stepVerify, "done", "✓");
        setStepState(stepWrite, "done", "✓");
        setStepState(stepReload, "done", "✓");
        stepWriteText.textContent = `Đã ghi an toàn ${res.writtenCount || 0} tệp vào thư mục gốc`;
        stepReloadText.textContent = `Hoàn tất v${res.version} — đang tự nạp lại tiện ích...`;
        showAlert(
          `✓ Cập nhật tự động 100% thành công lên v${res.version}! Tiện ích đang tự nạp lại (giữ nguyên 100% mật khẩu).`,
          "success"
        );
        return;
      }

      if (!fsSupported) {
        openManualZipDownload();
        return;
      }

      const handle = await ensureWritableFolderHandle(false);
      if (!handle) return;

      // Refresh signed metadata from GitHub right before downloading
      const freshStatus = await sendRuntimeMsg({ type: "GET_EXTENSION_UPDATE_STATUS", force: true });
      if (freshStatus && freshStatus.ok) {
        updateStatus = freshStatus;
        renderUI();
      }
      if (!updateStatus || !updateStatus.ok) {
        showAlert("Không kết nối được GitHub để lấy thông tin bản cập nhật.", "error");
        return;
      }
      if (!updateStatus.hasUpdate && !allowReinstallLatest) {
        showAlert(`✓ Bạn đang dùng phiên bản mới nhất (v${updateStatus.currentVersion}).`, "success");
        return;
      }

      resetProgressSteps();
      progressCard.hidden = false;
      showAlert(`Đang cập nhật trực tiếp lên v${updateStatus.latestVersion}...`, "info");

      const result = await OmniVaultUpdater.performSelfUpdate({
        dirHandle: handle,
        updateInfo: updateStatus,
        pinnedSpkiB64,
        onProgress: applyProgressEvent
      });

      setStepState(stepReload, "done", "✓");
      stepReloadText.textContent = `Đã ghi ${result.writtenCount} tệp (v${result.version}) — đang nạp lại tiện ích...`;
      showAlert(
        `✓ Cập nhật thành công lên v${result.version}! Tiện ích đang tự nạp lại (giữ nguyên 100% mật khẩu).`,
        "success"
      );

      await sendRuntimeMsg({ type: "APPLY_EXTENSION_UPDATE_NOW" });
    } catch (e) {
      markCurrentStepError();
      const formatted = formatFriendlyFsError(e, "write");
      showAlert(formatted.text, formatted.canceled ? "info" : "error");
    } finally {
      setBusy(false);
      await refreshFolderState().catch(() => {});
      renderUI();
    }
  }

  async function checkUpdatesFromGitHub(force = true) {
    if (busy) return;
    setBusy(true);
    try {
      showAlert("Đang kiểm tra bản phát hành mới nhất từ GitHub...", "info");
      const resp = await sendRuntimeMsg({ type: "GET_EXTENSION_UPDATE_STATUS", force });
      if (resp) {
        updateStatus = resp;
        if (resp.ok && resp.hasUpdate) {
          showAlert(
            `Phát hiện bản mới v${resp.latestVersion} (bản hiện tại v${resp.currentVersion}).`,
            "info"
          );
        } else if (resp.ok) {
          showAlert(`✓ Bạn đang sử dụng bản mới nhất (v${resp.currentVersion}).`, "success");
        } else {
          showAlert(resp.error || "Không kiểm tra được GitHub.", "error");
        }
      }
    } finally {
      setBusy(false);
      await refreshFolderState().catch(() => {});
      renderUI();
    }
  }

  function openManualZipDownload() {
    const candidate = updateStatus?.unpackedZipUrl || updateStatus?.unpackedLatestUrl || updateStatus?.releaseHtmlUrl;
    const safeUrl = OmniVaultCore.isAllowedGitHubUpdateUrl(candidate)
      ? candidate
      : "https://github.com/Minhtuan0506/omnivault-extension/releases/latest";
    chrome.tabs.create({ url: safeUrl, active: true });
    showAlert(
      "Đã mở tải tệp .zip thủ công từ GitHub — sau khi giải nén đè vào thư mục tiện ích hãy bấm '🔄 Nạp lại tiện ích'.",
      "info"
    );
  }

  btnPickFolder.addEventListener("click", async () => {
    if (busy) return;
    setBusy(true);
    try {
      const picked = await pickAndVerifyFolder();
      if (picked) {
        showAlert(
          `✓ Đã liên kết thư mục "${picked.name}" (khớp khóa chính chủ OmniVault). Từ nay bạn có thể cập nhật 1 chạm!`,
          "success"
        );
      }
    } finally {
      setBusy(false);
      await refreshFolderState().catch(() => {});
      renderUI();
    }
  });

  btnForgetFolder.addEventListener("click", async () => {
    if (busy) return;
    await OmniVaultUpdater.clearStoredDirectoryHandle();
    await refreshFolderState();
    renderUI();
    showAlert("Đã gỡ liên kết thư mục tiện ích.", "info");
  });

  if (btnRecheckNative) {
    btnRecheckNative.addEventListener("click", async () => {
      if (busy) return;
      setBusy(true);
      try {
        showAlert("Đang kiểm tra kết nối Native Host (Bat-TuDongCapNhat-100.bat)...", "info");
        await refreshFolderState(true);
        renderUI();
        if (nativeStatus.available) {
          showAlert(
            `✓ Đã kích hoạt Tự động 100% thành công! Thư mục: ${nativeStatus.dirPath || nativeStatus.dirName}.`,
            "success"
          );
        } else {
          showAlert(
            "Chưa thấy Native Host trong Windows HKCU. Hãy nhấp đúp tệp Bat-TuDongCapNhat-100.bat ngay trong thư mục giải nén OmniVault rồi bấm kiểm tra lại.",
            "error"
          );
        }
      } finally {
        setBusy(false);
        renderUI();
      }
    });
  }

  if (chkAutoUpdateBg) {
    chkAutoUpdateBg.addEventListener("change", async () => {
      const enabled = Boolean(chkAutoUpdateBg.checked);
      const res = await sendRuntimeMsg({ type: "SET_AUTO_UPDATE_BG", enabled });
      if (res && res.ok) {
        nativeStatus.autoUpdateBgEnabled = res.autoUpdateBgEnabled;
        showAlert(
          res.autoUpdateBgEnabled
            ? "✓ Đã bật tự động cập nhật ngầm 100% khi có bản mới trên GitHub."
            : "Đã tắt tự động cập nhật ngầm (vẫn hỗ trợ cập nhật 1 chạm khi bấm nút).",
          "info"
        );
      }
    });
  }

  btnPrimaryAction.addEventListener("click", async () => {
    if (busy) return;
    if (!updateStatus || !updateStatus.ok) {
      await checkUpdatesFromGitHub(true);
      return;
    }
    if (updateStatus.hasUpdate) {
      await runSelfUpdateFlow(false);
      return;
    }
    if (!isCrxManaged && nativeStatus.available) {
      // 1-click check GitHub -> auto-update immediately if newer release appeared!
      setBusy(true);
      try {
        showAlert("Đang kiểm tra GitHub & tự cập nhật nếu có bản mới...", "info");
        const res = await sendRuntimeMsg({ type: "ONE_CLICK_CHECK_AND_UPDATE", allowSilentReload: true });
        if (res?.updateStatus) {
          updateStatus = res.updateStatus;
        }
        if (res?.nativeStatus?.ok) {
          nativeStatus = res.nativeStatus;
          nativeStatusFetchedAt = Date.now();
        }
        if (!res || !res.ok) {
          showAlert(res?.error || "Không kiểm tra được GitHub.", "error");
        } else if (res.updated) {
          showAlert(`✓ Đã tự tải & cập nhật lên v${res.version} — đang tự nạp lại tiện ích!`, "success");
        } else {
          showAlert(`✓ Thư mục đã ở phiên bản mới nhất (v${res.version || currentVersion}).`, "success");
        }
      } finally {
        setBusy(false);
        await refreshFolderState().catch(() => {});
        renderUI();
      }
      return;
    }
    if (!isCrxManaged && !nativeStatus.available && fsSupported && !storedDirHandle) {
      setBusy(true);
      try {
        const picked = await pickAndVerifyFolder();
        if (picked) {
          showAlert(
            `✓ Đã liên kết sẵn thư mục "${picked.name}". Khi có bản mới trên GitHub bạn chỉ cần bấm 1 chạm!`,
            "success"
          );
        }
      } finally {
        setBusy(false);
        renderUI();
      }
      return;
    }
    await checkUpdatesFromGitHub(true);
  });

  btnSecondaryAction.addEventListener("click", async () => {
    if (busy) return;
    if (
      updateStatus?.ok &&
      !updateStatus.hasUpdate &&
      !isCrxManaged &&
      (nativeStatus.available || (fsSupported && storedDirHandle))
    ) {
      await runSelfUpdateFlow(true);
      return;
    }
    await checkUpdatesFromGitHub(true);
  });

  btnDownloadZip.addEventListener("click", openManualZipDownload);

  btnReloadExt.addEventListener("click", async () => {
    if (busy) return;
    btnReloadExt.disabled = true;
    showAlert("Đang nạp lại tiện ích OmniVault...", "info");
    await sendRuntimeMsg({ type: "APPLY_EXTENSION_UPDATE_NOW" });
  });

  btnOpenRelease.addEventListener("click", () => {
    const candidate = updateStatus?.releaseHtmlUrl;
    const safeUrl = OmniVaultCore.isAllowedGitHubUpdateUrl(candidate)
      ? candidate
      : "https://github.com/Minhtuan0506/omnivault-extension/releases/latest";
    chrome.tabs.create({ url: safeUrl, active: true });
  });

  (async () => {
    await refreshFolderState();
    renderUI();

    const resp = await sendRuntimeMsg({ type: "GET_EXTENSION_UPDATE_STATUS", force: true });
    if (resp) {
      updateStatus = resp;
    }
    await refreshFolderState();
    renderUI();

    if (autoStartRequested && updateStatus?.ok && updateStatus.hasUpdate) {
      if (isCrxManaged || nativeStatus.available || (storedDirHandle && storedDirPermission === "granted")) {
        await runSelfUpdateFlow(false);
      } else {
        showAlert(
          storedDirHandle
            ? `Bấm "⚡ Cập nhật ngay lên v${updateStatus.latestVersion}" để xác nhận quyền ghi và tự động cập nhật ngay!`
            : `Bấm "📂 Chọn thư mục OmniVault & Cập nhật v${updateStatus.latestVersion}" (chỉ cần chọn 1 lần duy nhất).`,
          "info"
        );
        btnPrimaryAction.focus();
      }
    }
  })();
})();
