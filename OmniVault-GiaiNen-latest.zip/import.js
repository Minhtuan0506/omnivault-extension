(() => {
  const deviceBadge = document.getElementById("deviceBadge");
  const pairingCard = document.getElementById("pairingCard");
  const pairingCodeInput = document.getElementById("pairingCodeInput");
  const btnPairInline = document.getElementById("btnPairInline");
  const btnStartLocalInline = document.getElementById("btnStartLocalInline");

  const exportUrlLabel = document.getElementById("exportUrlLabel");
  const btnOpenBrowserExport = document.getElementById("btnOpenBrowserExport");
  const btnCopyExportUrl = document.getElementById("btnCopyExportUrl");

  const csvFileInput = document.getElementById("csvFileInput");
  const dropZone = document.getElementById("dropZone");
  const btnSelectFile = document.getElementById("btnSelectFile");
  const btnExportBackupCsv = document.getElementById("btnExportBackupCsv");
  const statusBox = document.getElementById("statusBox");

  let currentState = null;

  function detectBrowserExportUrl() {
    const ua = navigator.userAgent || "";
    if (ua.includes("Edg/")) {
      return "edge://wallet/passwords";
    }
    if (ua.includes("coc_coc_browser")) {
      return "coccoc://password-manager/settings";
    }
    if (navigator.brave) {
      return "brave://password-manager/settings";
    }
    return "chrome://password-manager/settings";
  }

  const browserExportUrl = detectBrowserExportUrl();
  exportUrlLabel.textContent = browserExportUrl;

  function showInfo(msg) {
    statusBox.hidden = false;
    statusBox.className = "banner info";
    statusBox.textContent = msg;
  }

  function showError(msg) {
    statusBox.hidden = false;
    statusBox.className = "banner error";
    statusBox.textContent = msg;
  }

  function showSuccessSummary(fileName, res) {
    statusBox.hidden = false;
    statusBox.className = "banner success";
    statusBox.innerHTML = "";

    const isLocal = Boolean(currentState && currentState.pairing && currentState.pairing.localOnly);
    const heading = document.createElement("div");
    heading.style.fontWeight = "800";
    heading.style.fontSize = "14.5px";
    heading.textContent = isLocal
      ? `✅ Đã nhập toàn bộ mật khẩu từ "${fileName}" vào Kho cục bộ Trình duyệt!`
      : `✅ Đã đưa toàn bộ mật khẩu từ "${fileName}" lên Máy chủ của App thành công!`;
    statusBox.appendChild(heading);

    const grid = document.createElement("div");
    grid.className = "metrics-grid";

    const cells = [
      { val: String(res.addedCount), lbl: "Tài khoản thêm mới" },
      { val: String(res.updatedCount), lbl: "Cập nhật / Gộp trùng" },
      { val: String(res.totalServerCount), lbl: isLocal ? "Tổng trong Kho cục bộ" : "Tổng trên Máy chủ App" }
    ];
    for (const c of cells) {
      const well = document.createElement("div");
      well.className = "metric-well";
      const v = document.createElement("div");
      v.className = "metric-val";
      v.textContent = c.val;
      const l = document.createElement("div");
      l.className = "metric-lbl";
      l.textContent = c.lbl;
      well.appendChild(v);
      well.appendChild(l);
      grid.appendChild(well);
    }
    statusBox.appendChild(grid);

    const note = document.createElement("div");
    note.className = "security-note";
    note.textContent =
      "🔒 Điện thoại của anh sẽ tự động nhận đầy đủ danh sách mật khẩu này từ Máy chủ. Anh nhớ xóa file .csv tạm trong thư mục Downloads để bảo mật nhé!";
    statusBox.appendChild(note);
  }

  async function refreshPairingUi() {
    currentState = await OmniVaultCore.loadExtensionState();
    if (currentState && currentState.pairing) {
      deviceBadge.textContent = currentState.pairing.localOnly
        ? "Chế độ: Kho cục bộ Trình duyệt"
        : `Đã kết nối: ${currentState.pairing.deviceName}`;
      deviceBadge.className = "status-pill";
      pairingCard.hidden = true;
      btnExportBackupCsv.hidden = !(currentState.items && currentState.items.length > 0);
    } else {
      deviceBadge.textContent = "Chưa kết nối điện thoại";
      deviceBadge.className = "status-pill unpaired";
      pairingCard.hidden = false;
      btnExportBackupCsv.hidden = true;
    }
  }

  if (btnStartLocalInline) {
    btnStartLocalInline.onclick = async () => {
      try {
        await OmniVaultCore.enableLocalStandaloneMode();
        await refreshPairingUi();
        showInfo("Đã bật Kho cục bộ trên trình duyệt! Anh có thể chọn file .CSV / .JSON bên dưới để nhập ngay.");
      } catch (e) {
        showError(String(e.message || e));
      }
    };
  }

  btnPairInline.onclick = async () => {
    const raw = (pairingCodeInput.value || "").trim();
    if (!raw) {
      showError("Vui lòng dán Mã Kết Nối (bắt đầu bằng OVB2- hoặc OVB1-) từ ứng dụng OmniVault trên điện thoại.");
      return;
    }
    btnPairInline.disabled = true;
    btnPairInline.textContent = "Đang kết nối...";
    try {
      const pairRes = await OmniVaultCore.pairWithCloudCode(raw);
      pairingCodeInput.value = "";
      await refreshPairingUi();
      showInfo(
        `Đã kết nối với thiết bị "${pairRes.pairing.deviceName}" (hiện có ${pairRes.itemCount} mật khẩu trên Máy chủ). Bây giờ anh có thể chọn file .CSV để đẩy toàn bộ lên!`
      );
    } catch (e) {
      showError(String(e.message || e));
    } finally {
      btnPairInline.disabled = false;
      btnPairInline.textContent = "Kết nối thiết bị ngay";
    }
  };

  btnOpenBrowserExport.onclick = async () => {
    try {
      await chrome.tabs.create({ url: browserExportUrl, active: true });
    } catch (_) {
      await navigator.clipboard.writeText(browserExportUrl);
      showInfo(
        `Đã chép "${browserExportUrl}" — anh mở tab mới và dán lên thanh địa chỉ để xuất file .CSV nhé.`
      );
    }
  };

  btnCopyExportUrl.onclick = async () => {
    try {
      await navigator.clipboard.writeText(browserExportUrl);
      showInfo(`Đã sao chép đường dẫn: ${browserExportUrl}`);
    } catch (_) {
      showError("Không thể sao chép tự động, anh hãy bôi đen dòng chữ xanh ở Bước 1.");
    }
  };

  const yieldToBrowser = () =>
    typeof scheduler !== "undefined" && typeof scheduler.yield === "function"
      ? scheduler.yield()
      : new Promise((resolve) => setTimeout(resolve, 0));

  async function processSelectedFile(file) {
    if (!file) return;
    await refreshPairingUi();
    if (currentState && currentState.locked) {
      showError("Tiện ích đang khóa bằng PIN! Hãy bấm biểu tượng OmniVault trên thanh công cụ để nhập PIN mở khóa trước.");
      return;
    }
    if (!currentState || !currentState.pairing) {
      pairingCard.hidden = false;
      pairingCodeInput.focus();
      showError("Anh vui lòng dán Mã Kết Nối (OVB2-... hoặc OVB1-...) ở khung trên trước để tiện ích biết đẩy lên máy nào nhé!");
      return;
    }

    btnSelectFile.disabled = true;
    showInfo(`⏳ Đang đọc "${file.name}", lọc trùng, mã hóa AES-256 và đẩy toàn bộ lên Máy chủ App...`);
    try {
      const text = await file.text();
      let lastProgressUiMs = 0;
      const parsedItems =
        typeof OmniVaultCore.parseBrowserPasswordsTextAsync === "function"
          ? await OmniVaultCore.parseBrowserPasswordsTextAsync(text, {
              yieldEvery: 100,
              yieldFn: yieldToBrowser,
              onProgress: (done, total) => {
                const now = Date.now();
                if (total > 200 && (done === total || now - lastProgressUiMs >= 120)) {
                  lastProgressUiMs = now;
                  showInfo(`⏳ Đang phân tích "${file.name}": ${done}/${total} dòng...`);
                }
              }
            })
          : OmniVaultCore.parseBrowserPasswordsText(text);
      await yieldToBrowser();
      showInfo(
        `⏳ Đang lọc trùng ${parsedItems.length} tài khoản, mã hóa AES-256-GCM và đồng bộ lên Máy chủ App...`
      );
      const res = await OmniVaultCore.importAndPushAllToServer(parsedItems);
      await refreshPairingUi();
      showSuccessSummary(file.name, res);
    } catch (e) {
      showError(String(e.message || e));
    } finally {
      btnSelectFile.disabled = false;
      csvFileInput.value = "";
    }
  }

  btnSelectFile.onclick = () => csvFileInput.click();
  dropZone.onclick = () => csvFileInput.click();

  csvFileInput.onchange = () => {
    const f = csvFileInput.files && csvFileInput.files[0];
    if (f) processSelectedFile(f);
  };

  dropZone.addEventListener("dragover", (ev) => {
    ev.preventDefault();
    dropZone.classList.add("dragover");
  });

  dropZone.addEventListener("dragleave", () => {
    dropZone.classList.remove("dragover");
  });

  dropZone.addEventListener("drop", (ev) => {
    ev.preventDefault();
    dropZone.classList.remove("dragover");
    const f = ev.dataTransfer && ev.dataTransfer.files && ev.dataTransfer.files[0];
    if (f) processSelectedFile(f);
  });

  btnExportBackupCsv.onclick = async () => {
    const st = await OmniVaultCore.loadExtensionState();
    if (st.locked) {
      showError("Tiện ích đang khóa bằng PIN! Hãy mở khóa trước khi xuất CSV.");
      return;
    }
    const csv = OmniVaultCore.exportVaultToChromeCsv(st.items || []);
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "omnivault_matkhau_trinhduyet.csv";
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  };

  refreshPairingUi();
})();
