// ============================================================================
// OmniVault WebAuthn / Passkey Page Bridge (MAIN world, document_start)
// Non-breaking W3C WebAuthn L3 navigator.credentials.get/create wrapper
// ============================================================================

(() => {
  "use strict";

  if (window !== window.top) return;

  function isLoopbackHost(hostname) {
    const h = String(hostname || "").toLowerCase().replace(/^\[|\]$/g, "");
    return h === "localhost" || h === "127.0.0.1" || h === "::1";
  }

  function isSecureWebAuthnOrigin() {
    if (location.protocol === "https:") return Boolean(location.hostname);
    if (location.protocol === "http:" && isLoopbackHost(location.hostname)) return true;
    return false;
  }

  if (!isSecureWebAuthnOrigin()) return;
  if (
    typeof navigator === "undefined" ||
    !navigator.credentials ||
    typeof navigator.credentials.get !== "function" ||
    typeof navigator.credentials.create !== "function"
  ) {
    return;
  }

  const HOOKED_CREDENTIALS = new WeakSet();
  if (HOOKED_CREDENTIALS.has(navigator.credentials)) return;

  const BRIDGE_CHANNEL = "omnivault_webauthn_bridge_v1";
  const CHECK_TIMEOUT_MS = 600;
  const origGet = navigator.credentials.get.bind(navigator.credentials);
  const origCreate = navigator.credentials.create.bind(navigator.credentials);

  function randomHex128() {
    const buf = new Uint8Array(16);
    crypto.getRandomValues(buf);
    let out = "";
    for (let i = 0; i < buf.length; i++) {
      out += buf[i].toString(16).padStart(2, "0");
    }
    return out;
  }

  function bytesToBase64Url(bytes) {
    if (!bytes || bytes.length === 0) return "";
    let bin = "";
    const CHUNK = 0x8000;
    for (let i = 0; i < bytes.length; i += CHUNK) {
      bin += String.fromCharCode.apply(null, bytes.subarray(i, i + CHUNK));
    }
    return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
  }

  function bufferSourceToB64Url(src) {
    if (!src) return "";
    if (typeof src === "string") return src.trim();
    if (src instanceof Uint8Array) return bytesToBase64Url(src);
    if (src instanceof ArrayBuffer) return bytesToBase64Url(new Uint8Array(src));
    if (ArrayBuffer.isView(src)) {
      return bytesToBase64Url(new Uint8Array(src.buffer, src.byteOffset, src.byteLength));
    }
    return "";
  }

  function b64UrlToArrayBuffer(b64url) {
    if (!b64url) return new ArrayBuffer(0);
    let s = String(b64url).trim().replace(/-/g, "+").replace(/_/g, "/");
    while (s.length % 4 !== 0) s += "=";
    const bin = atob(s);
    const u8 = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) {
      u8[i] = bin.charCodeAt(i);
    }
    return u8.buffer;
  }

  function createWithWebAuthnProto(ctorName, propsObj) {
    const Ctor = typeof globalThis !== "undefined" ? globalThis[ctorName] : undefined;
    const proto = typeof Ctor === "function" && Ctor.prototype ? Ctor.prototype : Object.prototype;
    const obj = Object.create(proto);
    const descriptors = {};
    for (const [key, value] of Object.entries(propsObj)) {
      descriptors[key] = {
        value,
        enumerable: true,
        configurable: true,
        writable: false
      };
    }
    Object.defineProperties(obj, descriptors);
    return obj;
  }

  function buildAssertionCredential(json) {
    const r = json.response || {};
    const rawId = b64UrlToArrayBuffer(json.rawId || json.id);
    const clientDataJSON = b64UrlToArrayBuffer(r.clientDataJSON);
    const authenticatorData = b64UrlToArrayBuffer(r.authenticatorData);
    const signature = b64UrlToArrayBuffer(r.signature);
    const userHandle = r.userHandle ? b64UrlToArrayBuffer(r.userHandle) : null;
    const extResults =
      json.clientExtensionResults && typeof json.clientExtensionResults === "object"
        ? { ...json.clientExtensionResults }
        : {};

    const responseObj = createWithWebAuthnProto("AuthenticatorAssertionResponse", {
      clientDataJSON,
      authenticatorData,
      signature,
      userHandle
    });

    return createWithWebAuthnProto("PublicKeyCredential", {
      id: String(json.id || ""),
      rawId,
      type: "public-key",
      authenticatorAttachment: String(json.authenticatorAttachment || "platform"),
      response: responseObj,
      getClientExtensionResults() {
        return { ...extResults };
      },
      toJSON() {
        return {
          id: String(json.id || ""),
          rawId: String(json.rawId || json.id || ""),
          type: "public-key",
          authenticatorAttachment: String(json.authenticatorAttachment || "platform"),
          clientExtensionResults: { ...extResults },
          response: {
            clientDataJSON: String(r.clientDataJSON || ""),
            authenticatorData: String(r.authenticatorData || ""),
            signature: String(r.signature || ""),
            ...(r.userHandle ? { userHandle: String(r.userHandle) } : {})
          }
        };
      }
    });
  }

  function buildAttestationCredential(json) {
    const r = json.response || {};
    const rawId = b64UrlToArrayBuffer(json.rawId || json.id);
    const clientDataJSON = b64UrlToArrayBuffer(r.clientDataJSON);
    const attestationObject = b64UrlToArrayBuffer(r.attestationObject);
    const authenticatorData = b64UrlToArrayBuffer(r.authenticatorData);
    const publicKeyBuf = r.publicKey ? b64UrlToArrayBuffer(r.publicKey) : null;
    const publicKeyAlgorithm = Number.isFinite(Number(r.publicKeyAlgorithm))
      ? Number(r.publicKeyAlgorithm)
      : -7;
    const transports = Array.isArray(r.transports) && r.transports.length > 0
      ? r.transports.map((t) => String(t))
      : ["internal", "hybrid"];
    const extResults =
      json.clientExtensionResults && typeof json.clientExtensionResults === "object"
        ? { ...json.clientExtensionResults }
        : {};

    const responseObj = createWithWebAuthnProto("AuthenticatorAttestationResponse", {
      clientDataJSON,
      attestationObject,
      getTransports() {
        return transports.slice();
      },
      getAuthenticatorData() {
        return authenticatorData.slice(0);
      },
      getPublicKey() {
        return publicKeyBuf ? publicKeyBuf.slice(0) : null;
      },
      getPublicKeyAlgorithm() {
        return publicKeyAlgorithm;
      }
    });

    return createWithWebAuthnProto("PublicKeyCredential", {
      id: String(json.id || ""),
      rawId,
      type: "public-key",
      authenticatorAttachment: String(json.authenticatorAttachment || "platform"),
      response: responseObj,
      getClientExtensionResults() {
        return { ...extResults };
      },
      toJSON() {
        return {
          id: String(json.id || ""),
          rawId: String(json.rawId || json.id || ""),
          type: "public-key",
          authenticatorAttachment: String(json.authenticatorAttachment || "platform"),
          clientExtensionResults: { ...extResults },
          response: {
            clientDataJSON: String(r.clientDataJSON || ""),
            attestationObject: String(r.attestationObject || ""),
            authenticatorData: String(r.authenticatorData || ""),
            publicKey: String(r.publicKey || ""),
            publicKeyAlgorithm,
            transports: transports.slice()
          }
        };
      }
    });
  }

  function requestViaExtensionBridge(action, payload, { promptTimeoutMs = 120_000, signal = null } = {}) {
    return new Promise((resolve) => {
      const reqId = randomHex128();
      const nonce = randomHex128();
      const pageOrigin = window.location.origin;
      let settled = false;
      let timer = null;

      const cleanup = () => {
        if (timer !== null) {
          clearTimeout(timer);
          timer = null;
        }
        window.removeEventListener("message", onMessage);
        if (signal && typeof signal.removeEventListener === "function") {
          signal.removeEventListener("abort", onAbort);
        }
      };

      const finish = (outcome) => {
        if (settled) return;
        settled = true;
        cleanup();
        resolve(outcome);
      };

      const sendAbortToContent = () => {
        try {
          window.postMessage(
            {
              channel: BRIDGE_CHANNEL,
              dir: "page_to_ext",
              action: "abort",
              reqId,
              nonce
            },
            pageOrigin
          );
        } catch (_) {}
      };

      const onAbort = () => {
        sendAbortToContent();
        finish({ status: "aborted", reason: signal ? signal.reason : undefined });
      };

      const onMessage = (ev) => {
        if (ev.source !== window || ev.origin !== pageOrigin) return;
        const d = ev.data;
        if (
          !d ||
          typeof d !== "object" ||
          d.channel !== BRIDGE_CHANNEL ||
          d.dir !== "ext_to_page" ||
          d.reqId !== reqId ||
          d.nonce !== nonce
        ) {
          return;
        }
        if (d.status === "prompting") {
          if (timer !== null) clearTimeout(timer);
          timer = setTimeout(() => {
            sendAbortToContent();
            finish({ status: "fallback" });
          }, promptTimeoutMs);
          return;
        }
        if (d.status === "ok" && d.credential) {
          finish({ status: "ok", credential: d.credential });
          return;
        }
        if (d.status === "cancelled") {
          finish({ status: "cancelled" });
          return;
        }
        if (d.status === "excluded") {
          finish({ status: "excluded" });
          return;
        }
        finish({ status: "fallback" });
      };

      window.addEventListener("message", onMessage);
      if (signal) {
        if (signal.aborted) {
          finish({ status: "aborted", reason: signal.reason });
          return;
        }
        if (typeof signal.addEventListener === "function") {
          signal.addEventListener("abort", onAbort, { once: true });
        }
      }

      timer = setTimeout(() => {
        sendAbortToContent();
        finish({ status: "fallback" });
      }, CHECK_TIMEOUT_MS);

      try {
        window.postMessage(
          {
            channel: BRIDGE_CHANNEL,
            dir: "page_to_ext",
            action,
            reqId,
            nonce,
            payload
          },
          pageOrigin
        );
      } catch (_) {
        finish({ status: "fallback" });
      }
    });
  }

  function hasUnsupportedWebAuthnExtensions(pk) {
    const exts = pk && pk.extensions && typeof pk.extensions === "object" ? pk.extensions : null;
    if (!exts) return false;
    return Boolean(exts.prf || exts.largeBlob);
  }

  function hasTransientUserActivation() {
    if (typeof navigator.userActivation === "object" && navigator.userActivation !== null) {
      return Boolean(navigator.userActivation.isActive);
    }
    return true;
  }

  async function wrappedCredentialsGet(options) {
    if (
      !options ||
      typeof options !== "object" ||
      !options.publicKey ||
      typeof options.publicKey !== "object" ||
      options.mediation === "conditional" ||
      (options.signal && options.signal.aborted) ||
      !hasTransientUserActivation()
    ) {
      return origGet(options);
    }

    const pk = options.publicKey;
    if (hasUnsupportedWebAuthnExtensions(pk)) {
      return origGet(options);
    }
    const challengeB64Url = bufferSourceToB64Url(pk.challenge);
    if (!challengeB64Url) {
      return origGet(options);
    }

    const allowCredentialIds = Array.isArray(pk.allowCredentials)
      ? pk.allowCredentials
          .map((c) => (c && c.id ? bufferSourceToB64Url(c.id) : ""))
          .filter(Boolean)
      : [];
    const promptTimeoutMs = Math.min(180_000, Math.max(30_000, Number(pk.timeout) || 120_000));

    const outcome = await requestViaExtensionBridge(
      "get",
      {
        rpId: typeof pk.rpId === "string" ? pk.rpId.trim() : "",
        challengeB64Url,
        allowCredentialIds,
        userVerification: typeof pk.userVerification === "string" ? pk.userVerification : "preferred"
      },
      { promptTimeoutMs, signal: options.signal || null }
    );

    if (outcome.status === "ok" && outcome.credential) {
      return buildAssertionCredential(outcome.credential);
    }
    if (outcome.status === "aborted") {
      throw outcome.reason || new DOMException("The operation was aborted.", "AbortError");
    }
    if (outcome.status === "cancelled") {
      throw new DOMException("The operation either timed out or was not allowed.", "NotAllowedError");
    }
    return origGet(options);
  }

  async function wrappedCredentialsCreate(options) {
    if (
      !options ||
      typeof options !== "object" ||
      !options.publicKey ||
      typeof options.publicKey !== "object" ||
      (options.signal && options.signal.aborted) ||
      !hasTransientUserActivation()
    ) {
      return origCreate(options);
    }

    const pk = options.publicKey;
    const authSel =
      pk.authenticatorSelection && typeof pk.authenticatorSelection === "object"
        ? pk.authenticatorSelection
        : {};
    if (authSel.authenticatorAttachment === "cross-platform" || hasUnsupportedWebAuthnExtensions(pk)) {
      return origCreate(options);
    }
    const challengeB64Url = bufferSourceToB64Url(pk.challenge);
    if (!challengeB64Url) {
      return origCreate(options);
    }

    const pubKeyCredParams = Array.isArray(pk.pubKeyCredParams)
      ? pk.pubKeyCredParams
          .filter((p) => p && typeof p === "object")
          .map((p) => ({ type: String(p.type || "public-key"), alg: Number(p.alg) }))
      : [];
    if (
      pubKeyCredParams.length > 0 &&
      !pubKeyCredParams.some((p) => p.type === "public-key" && p.alg === -7)
    ) {
      return origCreate(options);
    }

    const excludeCredentialIds = Array.isArray(pk.excludeCredentials)
      ? pk.excludeCredentials
          .map((c) => (c && c.id ? bufferSourceToB64Url(c.id) : ""))
          .filter(Boolean)
      : [];
    const rp = pk.rp && typeof pk.rp === "object" ? pk.rp : {};
    const user = pk.user && typeof pk.user === "object" ? pk.user : {};
    const exts = pk.extensions && typeof pk.extensions === "object" ? pk.extensions : {};
    const promptTimeoutMs = Math.min(180_000, Math.max(30_000, Number(pk.timeout) || 120_000));

    const outcome = await requestViaExtensionBridge(
      "create",
      {
        rpId: typeof rp.id === "string" ? rp.id.trim() : "",
        rpName: typeof rp.name === "string" ? rp.name.trim() : "",
        userIdB64Url: bufferSourceToB64Url(user.id),
        userName: typeof user.name === "string" ? user.name.trim() : "",
        userDisplayName: typeof user.displayName === "string" ? user.displayName.trim() : "",
        challengeB64Url,
        pubKeyCredParams,
        excludeCredentialIds,
        userVerification: typeof authSel.userVerification === "string" ? authSel.userVerification : "preferred",
        wantCredProps: Boolean(exts.credProps)
      },
      { promptTimeoutMs, signal: options.signal || null }
    );

    if (outcome.status === "ok" && outcome.credential) {
      return buildAttestationCredential(outcome.credential);
    }
    if (outcome.status === "excluded") {
      throw new DOMException(
        "The authenticator already contains one of the credentials specified in excludeCredentials.",
        "InvalidStateError"
      );
    }
    if (outcome.status === "aborted") {
      throw outcome.reason || new DOMException("The operation was aborted.", "AbortError");
    }
    if (outcome.status === "cancelled") {
      throw new DOMException("The operation either timed out or was not allowed.", "NotAllowedError");
    }
    return origCreate(options);
  }

  HOOKED_CREDENTIALS.add(navigator.credentials);
  try {
    Object.defineProperty(navigator.credentials, "get", {
      value: wrappedCredentialsGet,
      configurable: true,
      writable: true
    });
    Object.defineProperty(navigator.credentials, "create", {
      value: wrappedCredentialsCreate,
      configurable: true,
      writable: true
    });
  } catch (_) {
    try {
      navigator.credentials.get = wrappedCredentialsGet;
      navigator.credentials.create = wrappedCredentialsCreate;
    } catch (_) {}
  }
})();
