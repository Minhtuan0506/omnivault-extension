// ============================================================================
// OmniVault Content Script MV3 (2027 Standard) — Closed Shadow DOM & Autofill
// Supports React / Vue / Angular / Next.js / Shadow DOM & 2-Step SSO Logins
// ============================================================================

(() => {
  if (window !== window.top) return;

  function isLoopbackHost(hostname) {
    const h = String(hostname || "").toLowerCase().replace(/^\[|\]$/g, "");
    return h === "localhost" || h === "127.0.0.1" || h === "::1";
  }

  function isSafePageOrigin() {
    if (location.protocol === "https:") return true;
    if (location.protocol === "http:" && isLoopbackHost(location.hostname)) {
      return true;
    }
    return false;
  }

  // M8: Never initialize observers, listeners, or caches on unsafe non-HTTPS pages
  if (!isSafePageOrigin()) return;
  if (window.__omnivaultContentLoaded) return;
  window.__omnivaultContentLoaded = true;

  const STEP1_USER_TTL_MS = 300_000;
  const knownPasswordInputs = new WeakSet();
  const lifecycleAbort = typeof AbortController === "function" ? new AbortController() : null;
  const lifecycleSignal = lifecycleAbort ? lifecycleAbort.signal : undefined;
  let tornDown = false;
  let activeMenuEl = null;
  let activeMenuMode = "";
  let activeMenuFilterFn = null;
  let activeMenuAnchor = null;
  let activeMenuCleanup = null;
  let saveBannerEl = null;
  let passkeyModalEl = null;
  let activePasskeyReqId = "";
  let activePasskeyNonce = "";
  let activePasskeyCleanup = null;
  let domainMatchCache = { fetchedAt: 0, matches: [], paired: false, locked: false };
  let liveCredCache = { pwEl: null, username: "", password: "", updatedAt: 0 };
  let pendingUnlockAnchor = { input: null, isStep1User: false, savedAt: 0 };
  let step1UsernameMem = "";
  let step1UsernameSavedAt = 0;
  let unpairedHintShownInPage = false;
  let pendingMatchAnchor = null;
  let lastMatchTriggerEl = null;
  let lastMatchTriggerAt = 0;
  const pendingAckTimers = new Set();

  function clearLiveCredCache() {
    liveCredCache = { pwEl: null, username: "", password: "", updatedAt: 0 };
  }

  function cancelPendingAckTimers() {
    for (const tid of pendingAckTimers) {
      clearTimeout(tid);
    }
    pendingAckTimers.clear();
  }

  function isOwnOverlayEvent(e) {
    const t = e && e.target;
    if (!t) return false;
    if (activeMenuEl && (t === activeMenuEl || (activeMenuEl.contains && activeMenuEl.contains(t)))) {
      return true;
    }
    if (saveBannerEl && (t === saveBannerEl || (saveBannerEl.contains && saveBannerEl.contains(t)))) {
      return true;
    }
    if (passkeyModalEl && (t === passkeyModalEl || (passkeyModalEl.contains && passkeyModalEl.contains(t)))) {
      return true;
    }
    return false;
  }

  function safeSendMessage(payload, callback) {
    try {
      if (!chrome?.runtime?.id) {
        teardownContentScript();
        if (typeof callback === "function") callback(null);
        return;
      }
      chrome.runtime.sendMessage(payload, (res) => {
        if (chrome.runtime.lastError) {
          if (typeof callback === "function") callback(null);
          return;
        }
        if (typeof callback === "function") callback(res);
      });
    } catch (_) {
      if (!chrome?.runtime?.id) {
        teardownContentScript();
      }
      if (typeof callback === "function") callback(null);
    }
  }

  function setNativeInputValue(el, val) {
    if (!el) return;
    el.focus();
    const prevVal = el.value;
    const proto = Object.getPrototypeOf(el);
    const desc =
      Object.getOwnPropertyDescriptor(proto, "value") ||
      Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value");
    if (desc && desc.set) {
      desc.set.call(el, val);
    } else {
      el.value = val;
    }
    // Reset React 16-19 internal _valueTracker so controlled inputs commit state immediately
    if (el._valueTracker && typeof el._valueTracker.setValue === "function") {
      try {
        el._valueTracker.setValue(prevVal);
      } catch (_) {}
    }
    try {
      el.dispatchEvent(
        new InputEvent("input", { bubbles: true, cancelable: true, inputType: "insertText", data: val })
      );
    } catch (_) {
      el.dispatchEvent(new Event("input", { bubbles: true }));
    }
    el.dispatchEvent(new Event("change", { bubbles: true }));
    el.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, key: "Unidentified" }));
  }

  const knownShadowHosts = new Set();
  const observedShadowRoots = new WeakSet();
  const inputMetaCache = new WeakMap();
  const textSecurityCache = new WeakMap();
  const standaloneUserCache = new WeakMap();
  const MUTATION_DEBOUNCE_MS = 150;
  const MUTATION_MAX_WAIT_MS = 500;
  const MAX_PENDING_ADDED_NODES = 200;

  let domMutationEpoch = 1;
  let initialShadowScanDone = false;
  let cachedDocInputsEpoch = -1;
  let cachedDocInputs = [];
  let cachedHasVisiblePwEpoch = -1;
  let cachedHasVisiblePw = false;
  let cachedVisiblePwEl = null;

  let mutationDebounceTimer = null;
  let mutationFirstQueuedAt = 0;
  const pendingAddedNodes = new Set();
  let pendingHadRemovals = false;

  function invalidateDomInputCaches() {
    domMutationEpoch++;
    cachedDocInputsEpoch = -1;
    cachedHasVisiblePwEpoch = -1;
    cachedVisiblePwEl = null;
  }

  function observeShadowRootIfOpen(shadowRoot) {
    if (tornDown || !shadowRoot || observedShadowRoots.has(shadowRoot) || typeof MutationObserver !== "function") {
      return;
    }
    observedShadowRoots.add(shadowRoot);
    try {
      domObserver.observe(shadowRoot, { childList: true, subtree: true });
    } catch (_) {}
  }

  function inspectSubtreeForShadowHosts(rootNode, budget = { remaining: 400 }) {
    if (!rootNode || !(rootNode instanceof Element) || budget.remaining <= 0) return;
    if (rootNode === activeMenuEl || rootNode === saveBannerEl || rootNode === passkeyModalEl) return;
    budget.remaining--;
    if (rootNode.shadowRoot) {
      knownShadowHosts.add(rootNode);
      observeShadowRootIfOpen(rootNode.shadowRoot);
    }
    if (typeof document.createTreeWalker !== "function") return;
    try {
      const walker = document.createTreeWalker(rootNode, NodeFilter.SHOW_ELEMENT);
      let node;
      while ((node = walker.nextNode()) && budget.remaining > 0) {
        budget.remaining--;
        if (node.shadowRoot) {
          knownShadowHosts.add(node);
          observeShadowRootIfOpen(node.shadowRoot);
        }
      }
    } catch (_) {}
  }

  function flushDomMutations() {
    mutationDebounceTimer = null;
    mutationFirstQueuedAt = 0;
    if (tornDown) {
      pendingAddedNodes.clear();
      return;
    }
    if (!chrome?.runtime?.id) {
      teardownContentScript();
      return;
    }
    const budget = { remaining: 400 };
    if (pendingHadRemovals) {
      pendingHadRemovals = false;
      for (const host of Array.from(knownShadowHosts)) {
        if (!host || !host.isConnected || !host.shadowRoot) {
          knownShadowHosts.delete(host);
        }
      }
    }
    for (const node of pendingAddedNodes) {
      if (node && node.isConnected) {
        inspectSubtreeForShadowHosts(node, budget);
      }
    }
    pendingAddedNodes.clear();
    invalidateDomInputCaches();

    // Multi-step SPA transition detection: if a newly rendered password input took focus, refresh match cache
    const active = document.activeElement;
    if (
      active instanceof HTMLInputElement &&
      active !== activeMenuAnchor &&
      isSafePageOrigin() &&
      isPasswordLikeInput(active) &&
      isVisibleInput(active)
    ) {
      if (!activeMenuEl && domainMatchCache.paired && Date.now() - domainMatchCache.fetchedAt > 3000) {
        domainMatchCache.fetchedAt = 0;
      }
    }
  }

  const domObserver =
    typeof MutationObserver === "function"
      ? new MutationObserver((records) => {
          if (tornDown) return;
          if (!chrome?.runtime?.id) {
            teardownContentScript();
            return;
          }
          let sawRelevant = false;
          for (const rec of records) {
            if (rec.addedNodes && rec.addedNodes.length > 0) {
              for (const n of rec.addedNodes) {
                if (n instanceof Element && n !== activeMenuEl && n !== saveBannerEl && n !== passkeyModalEl) {
                  if (pendingAddedNodes.size < MAX_PENDING_ADDED_NODES) {
                    pendingAddedNodes.add(n);
                  }
                  sawRelevant = true;
                }
              }
            }
            if (rec.removedNodes && rec.removedNodes.length > 0) {
              for (const n of rec.removedNodes) {
                if (n instanceof Element && n !== activeMenuEl && n !== saveBannerEl && n !== passkeyModalEl) {
                  pendingHadRemovals = true;
                  sawRelevant = true;
                  break;
                }
              }
            }
          }
          if (!sawRelevant) return;
          const now = Date.now();
          if (mutationFirstQueuedAt === 0) {
            mutationFirstQueuedAt = now;
          }
          if (
            pendingAddedNodes.size >= MAX_PENDING_ADDED_NODES ||
            now - mutationFirstQueuedAt >= MUTATION_MAX_WAIT_MS
          ) {
            if (mutationDebounceTimer !== null) {
              clearTimeout(mutationDebounceTimer);
              mutationDebounceTimer = null;
            }
            flushDomMutations();
            return;
          }
          if (mutationDebounceTimer !== null) {
            clearTimeout(mutationDebounceTimer);
          }
          const remainingMaxWait = Math.max(0, MUTATION_MAX_WAIT_MS - (now - mutationFirstQueuedAt));
          mutationDebounceTimer = setTimeout(
            flushDomMutations,
            Math.min(MUTATION_DEBOUNCE_MS, remainingMaxWait)
          );
        })
      : null;

  function teardownContentScript() {
    if (tornDown) return;
    tornDown = true;
    try {
      if (lifecycleAbort) lifecycleAbort.abort();
    } catch (_) {}
    try {
      if (domObserver) domObserver.disconnect();
    } catch (_) {}
    if (mutationDebounceTimer !== null) {
      clearTimeout(mutationDebounceTimer);
      mutationDebounceTimer = null;
    }
    mutationFirstQueuedAt = 0;
    cancelPendingAckTimers();
    pendingAddedNodes.clear();
    knownShadowHosts.clear();
    closeInlineMenu();
    if (typeof activePasskeyCleanup === "function") {
      try {
        activePasskeyCleanup();
      } catch (_) {}
      activePasskeyCleanup = null;
    }
    if (passkeyModalEl) {
      try {
        passkeyModalEl.remove();
      } catch (_) {}
      passkeyModalEl = null;
    }
    activePasskeyReqId = "";
    activePasskeyNonce = "";
    if (saveBannerEl) {
      try {
        saveBannerEl.remove();
      } catch (_) {}
      saveBannerEl = null;
    }
    domainMatchCache = { fetchedAt: 0, matches: [], paired: false, locked: false };
    clearLiveCredCache();
    pendingUnlockAnchor = { input: null, isStep1User: false, savedAt: 0 };
    step1UsernameMem = "";
    step1UsernameSavedAt = 0;
    pendingMatchAnchor = null;
  }

  function startDomMutationObserver() {
    if (!domObserver || tornDown) return;
    const target = document.documentElement || document.body;
    if (target) {
      try {
        domObserver.observe(target, { childList: true, subtree: true });
      } catch (_) {}
    } else {
      document.addEventListener(
        "DOMContentLoaded",
        () => {
          if (tornDown) return;
          const root = document.documentElement || document.body;
          if (root) {
            try {
              domObserver.observe(root, { childList: true, subtree: true });
            } catch (_) {}
          }
        },
        { once: true, signal: lifecycleSignal }
      );
    }
  }

  startDomMutationObserver();

  function registerShadowHostsFromEvent(e) {
    if (!e || typeof e.composedPath !== "function") return;
    try {
      const path = e.composedPath();
      let addedAny = false;
      for (const node of path) {
        if (node && node instanceof ShadowRoot && node.host) {
          if (!knownShadowHosts.has(node.host)) {
            knownShadowHosts.add(node.host);
            observeShadowRootIfOpen(node);
            addedAny = true;
          }
        } else if (node && node.shadowRoot) {
          if (!knownShadowHosts.has(node)) {
            knownShadowHosts.add(node);
            observeShadowRootIfOpen(node.shadowRoot);
            addedAny = true;
          }
        }
      }
      if (addedAny) invalidateDomInputCaches();
    } catch (_) {}
  }

  function ensureInitialShadowHostScan() {
    if (initialShadowScanDone) return;
    initialShadowScanDone = true;
    const rootNode = document.documentElement || document.body;
    if (!rootNode || typeof document.createTreeWalker !== "function") return;
    inspectSubtreeForShadowHosts(rootNode, { remaining: 1000 });
  }

  function isElementActuallyVisible(el, requireEditable) {
    if (!el || el.disabled || (requireEditable && el.readOnly)) return false;
    if (el.isConnected === false) return false;
    // Modern 2026-2027 native Blink C++ visibility check (avoids 8x parent getComputedStyle reflows)
    if (typeof el.checkVisibility === "function") {
      if (!el.checkVisibility({ checkOpacity: true, checkVisibilityCSS: true })) {
        return false;
      }
      if (el.closest && el.closest("[inert], [aria-hidden='true']")) return false;
      const rect = el.getBoundingClientRect();
      return rect.width >= 30 && rect.height >= 14;
    }
    // Legacy fallback when checkVisibility is unavailable
    if (el.closest && el.closest("[inert], [aria-hidden='true'], [hidden]")) return false;
    const rect = el.getBoundingClientRect();
    if (rect.width < 30 || rect.height < 14) return false;
    let cur = el;
    for (let i = 0; i < 8 && cur && cur instanceof Element; i++) {
      const st = window.getComputedStyle(cur);
      if (st.display === "none" || st.visibility === "hidden" || Number(st.opacity) <= 0.05) {
        return false;
      }
      cur = cur.parentElement || (cur.getRootNode && cur.getRootNode().host) || null;
    }
    return true;
  }

  function isVisibleInput(el) {
    return isElementActuallyVisible(el, true);
  }

  function isVisibleReadableInput(el) {
    return isElementActuallyVisible(el, false);
  }

  function queryAllInputsDeep(root = document, depth = 0, seen = null) {
    if (!root || depth > 5) return [];
    if (depth === 0 && root === document) {
      ensureInitialShadowHostScan();
      if (cachedDocInputsEpoch === domMutationEpoch) {
        return cachedDocInputs;
      }
    }
    const visited = seen || new Set();
    if (visited.has(root)) return [];
    visited.add(root);

    const results = [];
    const direct = root.querySelectorAll ? root.querySelectorAll("input") : [];
    for (const inp of direct) {
      results.push(inp);
    }
    for (const host of knownShadowHosts) {
      if (!host || !host.isConnected || !host.shadowRoot) {
        knownShadowHosts.delete(host);
        continue;
      }
      if (root === document || (root.contains && root.contains(host))) {
        results.push(...queryAllInputsDeep(host.shadowRoot, depth + 1, visited));
      }
    }
    if (depth === 0 && root === document) {
      cachedDocInputs = results;
      cachedDocInputsEpoch = domMutationEpoch;
    }
    return results;
  }

  function hasVisiblePasswordOnPage() {
    if (cachedHasVisiblePwEpoch === domMutationEpoch) {
      if (!cachedHasVisiblePw) return false;
      if (cachedVisiblePwEl && cachedVisiblePwEl.isConnected && isVisibleInput(cachedVisiblePwEl)) {
        return true;
      }
    }
    const allInputs = queryAllInputsDeep(document);
    let foundPw = null;
    for (let i = 0; i < allInputs.length; i++) {
      const inp = allInputs[i];
      if (isPasswordLikeInput(inp) && isVisibleInput(inp)) {
        foundPw = inp;
        break;
      }
    }
    cachedHasVisiblePw = Boolean(foundPw);
    cachedVisiblePwEl = foundPw;
    cachedHasVisiblePwEpoch = domMutationEpoch;
    return cachedHasVisiblePw;
  }

  function normalizeVi(str) {
    return String(str || "")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[đĐ]/g, "d")
      .toLowerCase();
  }

  const NON_PASSWORD_INPUT_TYPES = new Set([
    "hidden",
    "submit",
    "button",
    "checkbox",
    "radio",
    "file",
    "image",
    "reset",
    "search",
    "email",
    "url",
    "date",
    "datetime-local",
    "month",
    "week",
    "time",
    "number",
    "range",
    "color"
  ]);
  const PASSWORD_CUE_REGEX = /(pass|pwd|mat.?khau|secret|mask|pin)/i;
  const OTP_CUE_REGEX =
    /(otp|totp|2fa|mfa|two.?factor|verification.?code|auth.?code|security.?code|ma.?xac.?thuc|ma.?otp|smart.?otp)/i;

  function getInputMetadata(el) {
    const ariaLabel = el.getAttribute ? el.getAttribute("aria-label") || "" : "";
    const sig = `${el.name || ""}\0${el.id || ""}\0${el.autocomplete || ""}\0${el.placeholder || ""}\0${ariaLabel}`;
    const cached = inputMetaCache.get(el);
    if (cached && cached.sig === sig) {
      return cached.meta;
    }
    const labelText = (el.labels && el.labels[0] ? el.labels[0].textContent : "") || ariaLabel;
    const meta = normalizeVi(
      `${el.name || ""} ${el.id || ""} ${el.autocomplete || ""} ${el.placeholder || ""} ${labelText}`
    );
    inputMetaCache.set(el, { sig, meta });
    return meta;
  }

  function isOtpLikeInput(el) {
    if (!(el instanceof HTMLInputElement)) return false;
    const ac = (el.autocomplete || "").toLowerCase();
    if (ac.includes("one-time-code")) return true;
    const meta = getInputMetadata(el);
    if (OTP_CUE_REGEX.test(meta)) {
      return true;
    }
    if ((el.type || "").toLowerCase() === "password" && PASSWORD_CUE_REGEX.test(meta)) {
      return false;
    }
    if (
      el.maxLength >= 1 &&
      el.maxLength <= 6 &&
      /(?:^|[^a-z0-9])(code|ma|digit|so)(?:[^a-z0-9]|$)/i.test(meta)
    ) {
      return true;
    }
    return false;
  }

  function isPasswordLikeInput(el) {
    if (!(el instanceof HTMLInputElement)) return false;
    const t = (el.type || "").toLowerCase();
    if (NON_PASSWORD_INPUT_TYPES.has(t)) {
      return false;
    }
    if (isOtpLikeInput(el)) return false;
    // Fast DOM properties checked BEFORE any getComputedStyle call!
    if (t === "password") {
      knownPasswordInputs.add(el);
      return true;
    }
    const ac = (el.autocomplete || "").toLowerCase();
    if (ac.includes("current-password") || ac.includes("new-password")) {
      knownPasswordInputs.add(el);
      return true;
    }
    if (knownPasswordInputs.has(el)) return true;

    const meta = getInputMetadata(el);
    const cls = typeof el.className === "string" ? el.className : "";
    const hasInlineTextSec = Boolean(el.style && el.style.webkitTextSecurity);
    if (!hasInlineTextSec && !PASSWORD_CUE_REGEX.test(meta) && !PASSWORD_CUE_REGEX.test(cls)) {
      return false;
    }
    const styleSig = `${cls}|${el.style ? el.style.cssText : ""}`;
    const cachedSec = textSecurityCache.get(el);
    if (cachedSec && cachedSec.sig === styleSig) {
      return cachedSec.masked;
    }
    try {
      const st = window.getComputedStyle(el);
      const masked = Boolean(st.webkitTextSecurity && st.webkitTextSecurity !== "none");
      textSecurityCache.set(el, { sig: styleSig, masked });
      if (masked) {
        knownPasswordInputs.add(el);
        return true;
      }
    } catch (_) {}
    return false;
  }

  function isNonLoginNoiseInput(el, meta) {
    if (el.type === "search" || el.type === "number" || el.type === "hidden") return true;
    if (el.closest('[role="search"]')) return true;
    if (
      /(search|tim.?kiem|filter|bo.?loc|chat|comment|binh.?luan|reply|promo|voucher|coupon|ma.?giam|otp|totp|2fa|verification|ma.?xac.?thuc|captcha)/.test(
        meta
      )
    ) {
      return true;
    }
    if (
      el.maxLength >= 4 &&
      el.maxLength <= 6 &&
      /(?:^|[^a-z0-9])(code|ma|pin|otp)(?:[^a-z0-9]|$)/.test(meta)
    ) {
      return true;
    }
    return false;
  }

  function isStandaloneLoginUsernameInput(el) {
    if (!(el instanceof HTMLInputElement)) return false;
    const t = (el.type || "text").toLowerCase();
    if (!["text", "email", "tel", ""].includes(t)) return false;

    const urlPath = `${location.hostname} ${location.pathname} ${location.hash}`.toLowerCase();
    const meta = getInputMetadata(el);
    const cached = standaloneUserCache.get(el);
    if (
      cached &&
      cached.epoch === domMutationEpoch &&
      cached.meta === meta &&
      cached.type === t &&
      cached.urlPath === urlPath
    ) {
      return cached.result;
    }

    const compute = () => {
      if (isNonLoginNoiseInput(el, meta)) return false;

      const ac = (el.autocomplete || "").toLowerCase();
      if (/(username|email|webauthn)/.test(ac)) return true;

      const strongUserCue =
        /(user|userid|username|login|identifier|account|email|e-mail|phone|mobile|sdt|so.?dien.?thoai|tai.?khoan|ten.?dang.?nhap|cif|ma.?khach.?hang)/.test(
          meta
        );
      if (!strongUserCue) return false;

      const urlIsAuth =
        /(login|signin|sign-in|auth|sso|oauth|account|id\.|passport|dang-nhap|dangnhap|digibank|ibank|ebank|smartbanking)/.test(
          urlPath
        );
      if (urlIsAuth) return true;

      const container = el.closest("form, [role='dialog'], main, section") || document.body;
      const btnText = normalizeVi(
        Array.from(container.querySelectorAll("button, input[type='submit'], [role='button']"))
          .slice(0, 8)
          .map((b) => b.textContent || b.value || "")
          .join(" ")
      );
      return /(dang.?nhap|tiep.?tuc|next|continue|sign.?in|log.?in)/.test(btnText);
    };

    const result = compute();
    standaloneUserCache.set(el, { epoch: domMutationEpoch, meta, type: t, urlPath, result });
    return result;
  }

  function resolveUsernameScope(pwInput) {
    if (!pwInput || pwInput === document.body) return document;
    const form = pwInput.closest ? pwInput.closest("form") : null;
    if (form) return form;
    let cur = pwInput.parentElement;
    for (let i = 0; i < 6 && cur; i++) {
      const inps = queryAllInputsDeep(cur);
      if (inps.length >= 2) return cur;
      cur = cur.parentElement;
    }
    return document;
  }

  function findUsernameFieldNear(pwInput, allowReadOnly = false) {
    const scope = resolveUsernameScope(pwInput);
    const visFn = allowReadOnly ? isVisibleReadableInput : isVisibleInput;
    const candidates = queryAllInputsDeep(scope).filter((el) => {
      if (!visFn(el) || el === pwInput || isPasswordLikeInput(el)) return false;
      const t = (el.type || "text").toLowerCase();
      return ["text", "email", "tel", ""].includes(t);
    });

    const scored = candidates.map((el) => {
      const meta = getInputMetadata(el);
      const ac = (el.autocomplete || "").toLowerCase();
      let score = 0;
      if (/(username|email|webauthn)/.test(ac)) score += 8;
      if (
        /(user|login|identifier|email|mail|phone|tel|sdt|so.?dien.?thoai|tai.?khoan|ten.?dang.?nhap|account|cif)/.test(
          meta
        )
      ) {
        score += 6;
      }
      if (
        pwInput &&
        pwInput !== document.body &&
        typeof el.compareDocumentPosition === "function" &&
        (el.compareDocumentPosition(pwInput) & Node.DOCUMENT_POSITION_FOLLOWING)
      ) {
        score += 2;
      }
      if (isNonLoginNoiseInput(el, meta)) score -= 12;
      return { el, score };
    });
    scored.sort((a, b) => b.score - a.score);
    return scored.length > 0 && scored[0].score >= 0 ? scored[0].el : null;
  }

  function getActiveStep1Username() {
    if (step1UsernameMem && Date.now() - step1UsernameSavedAt < STEP1_USER_TTL_MS) {
      return step1UsernameMem;
    }
    step1UsernameMem = "";
    step1UsernameSavedAt = 0;
    return "";
  }

  function extractBestUsernameNear(pwInput, opts = {}) {
    const usrEl = findUsernameFieldNear(pwInput, true);
    const direct = usrEl ? String(usrEl.value || "").trim() : "";
    if (direct) return direct;
    if (opts && opts.allowFallback === false) return "";
    if (Date.now() - liveCredCache.updatedAt < STEP1_USER_TTL_MS && liveCredCache.username) {
      return liveCredCache.username;
    }
    const s1 = getActiveStep1Username();
    if (s1) return s1;
    const idChip =
      typeof document.querySelector === "function"
        ? document.querySelector("[data-identifier], [data-email]")
        : null;
    if (idChip) {
      const chipVal = String(
        idChip.getAttribute("data-identifier") || idChip.getAttribute("data-email") || ""
      ).trim();
      if (chipVal) return chipVal;
    }
    return "";
  }

  function pickPrimaryPasswordInput(pwInputs) {
    const nonEmpty = (pwInputs || []).filter((inp) => inp && inp.value);
    if (nonEmpty.length === 0) return null;
    if (nonEmpty.length === 1) return nonEmpty[0];
    const preferredNew = nonEmpty.find((inp) => {
      const ac = (inp.autocomplete || "").toLowerCase();
      const meta = getInputMetadata(inp);
      if (ac.includes("new-password")) {
        return !/(confirm|repeat|retype|nhap.?lai|xac.?nhan)/i.test(meta);
      }
      return /(new|moi)/i.test(meta) && !/(confirm|repeat|retype|nhap.?lai|xac.?nhan)/i.test(meta);
    });
    return preferredNew || nonEmpty[nonEmpty.length - 1];
  }

  function extractCurrentPasswordNear(newPwEl, scopeRoot = null) {
    const newVal = newPwEl && newPwEl.value ? String(newPwEl.value) : "";
    if (!newVal) return "";
    const root = scopeRoot || (newPwEl ? resolveUsernameScope(newPwEl) : document);
    const filledPws = queryAllInputsDeep(root).filter(
      (inp) => isPasswordLikeInput(inp) && inp.value && inp !== newPwEl && inp.value !== newVal
    );
    if (filledPws.length === 0) return "";
    const explicitOld = filledPws.find((inp) => {
      const ac = (inp.autocomplete || "").toLowerCase();
      const meta = getInputMetadata(inp);
      return ac.includes("current-password") || /(current|old|hien.?tai|mat.?khau.?cu|\bcu\b)/i.test(meta);
    });
    return String((explicitOld || filledPws[0]).value || "");
  }

  function fillCredentialsOnPage(username, password, anchorInput = null) {
    const allInputs = queryAllInputsDeep(document);
    const pwInputs = allInputs.filter((el) => isPasswordLikeInput(el) && isVisibleInput(el));
    const pwField =
      anchorInput && isPasswordLikeInput(anchorInput) && isVisibleInput(anchorInput)
        ? anchorInput
        : pwInputs[0] || null;

    if (pwField) {
      const userField =
        anchorInput && !isPasswordLikeInput(anchorInput) && isVisibleInput(anchorInput)
          ? anchorInput
          : findUsernameFieldNear(pwField);
      let filledUser = false;
      let filledPw = false;
      if (userField && username) {
        setNativeInputValue(userField, username);
        filledUser = true;
      }
      if (password) {
        setNativeInputValue(pwField, password);
        filledPw = true;
      }
      if (filledUser || filledPw) {
        return { filled: true, mode: filledUser && filledPw ? "both" : "password_only" };
      }
    }

    // Multi-step login Step 1 (username/email/phone screen with no password field yet)
    if (username) {
      const targetUser =
        anchorInput &&
        !isPasswordLikeInput(anchorInput) &&
        isVisibleInput(anchorInput) &&
        isStandaloneLoginUsernameInput(anchorInput)
          ? anchorInput
          : allInputs.find((el) => isVisibleInput(el) && isStandaloneLoginUsernameInput(el)) ||
            findUsernameFieldNear(document.body);

      if (targetUser) {
        setNativeInputValue(targetUser, username);
        persistStep1Username(username);
        return { filled: true, mode: "username_only" };
      }
    }

    return { filled: false, mode: "none" };
  }

  function closeInlineMenu() {
    if (typeof activeMenuCleanup === "function") {
      try {
        activeMenuCleanup();
      } catch (_) {}
      activeMenuCleanup = null;
    }
    if (activeMenuEl) {
      activeMenuEl.remove();
      activeMenuEl = null;
    }
    activeMenuMode = "";
    activeMenuFilterFn = null;
    activeMenuAnchor = null;
  }

  const DROPDOWN_PAGE_SIZE = 40;
  const INLINE_MENU_CSS = `
    .ov-panel {
      position: fixed;
      z-index: 2147483646;
      background: rgba(255, 255, 255, 0.99);
      border: 1.5px solid #BBD0EA;
      border-radius: 12px;
      box-shadow: 0 12px 30px rgba(7, 14, 26, 0.18);
      padding: 6px;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      color: #070E1A;
      box-sizing: border-box;
      pointer-events: auto;
    }
    .ov-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 6px;
      padding: 4px 8px 6px;
      border-bottom: 1px solid #DCE8F8;
      font-size: 11.2px;
      font-weight: 800;
      color: #1D4ED8;
    }
    .ov-badge {
      background: #E6EFFD;
      color: #1D4ED8;
      border: 1px solid #BFD6F8;
      border-radius: 999px;
      padding: 1px 7px;
      font-size: 10.5px;
      font-weight: 800;
      white-space: nowrap;
      flex-shrink: 0;
    }
    .ov-search-wrap {
      padding: 5px 2px 2px;
    }
    .ov-search {
      width: 100%;
      box-sizing: border-box;
      padding: 6px 9px;
      border: 1.2px solid #BBD0EA;
      border-radius: 8px;
      background: #F8FBFF;
      color: #070E1A;
      font-size: 12px;
      font-weight: 600;
      outline: none;
      font-family: inherit;
    }
    .ov-list {
      overflow-y: auto;
      overscroll-behavior: contain;
      display: flex;
      flex-direction: column;
      gap: 2px;
      margin-top: 4px;
      padding-right: 2px;
    }
    .ov-row {
      display: flex;
      flex-direction: column;
      align-items: flex-start;
      width: 100%;
      border: none;
      background: transparent;
      cursor: pointer;
      padding: 5px 8px;
      border-radius: 7px;
      text-align: left;
      box-sizing: border-box;
      font-family: inherit;
    }
    .ov-row:hover,
    .ov-row.ov-active {
      background: #EAF2FC;
    }
    .ov-row.ov-active {
      outline: 1.5px solid #93BBF8;
      outline-offset: -1.5px;
    }
    .ov-title {
      font-size: 12.2px;
      font-weight: 800;
      color: #070E1A;
      width: 100%;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .ov-sub {
      font-size: 10.8px;
      font-weight: 600;
      color: #26364B;
      margin-top: 1px;
      width: 100%;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .ov-empty {
      padding: 10px 8px;
      text-align: center;
      font-size: 11.8px;
      color: #475B76;
      font-weight: 600;
    }
    .ov-lock-body {
      padding: 5px 2px 2px;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .ov-lock-btn {
      width: 100%;
      border: none;
      border-radius: 8px;
      padding: 7px 10px;
      background: #1D4ED8;
      color: #FFFFFF;
      font-size: 12px;
      font-weight: 800;
      cursor: pointer;
      font-family: inherit;
    }
    .ov-lock-btn:hover {
      background: #1E40AF;
    }
    @media (prefers-color-scheme: dark) {
      .ov-panel {
        background: rgba(15, 23, 42, 0.98);
        border-color: #334155;
        box-shadow: 0 14px 34px rgba(0, 0, 0, 0.55);
        color: #F1F5F9;
      }
      .ov-header {
        border-bottom-color: #1E293B;
        color: #93C5FD;
      }
      .ov-badge {
        background: #1E293B;
        color: #93C5FD;
        border-color: #334155;
      }
      .ov-search {
        background: #0B1220;
        border-color: #334155;
        color: #F1F5F9;
      }
      .ov-row:hover,
      .ov-row.ov-active {
        background: #1E293B;
      }
      .ov-row.ov-active {
        outline-color: #60A5FA;
      }
      .ov-title {
        color: #F8FAFC;
      }
      .ov-sub,
      .ov-empty {
        color: #94A3B8;
      }
      .ov-lock-btn {
        background: #2563EB;
      }
      .ov-lock-btn:hover {
        background: #1D4ED8;
      }
    }
  `;
  let sharedInlineMenuSheet = null;

  function getInlineMenuStyleSheet() {
    if (sharedInlineMenuSheet) return sharedInlineMenuSheet;
    if (typeof CSSStyleSheet === "function") {
      try {
        const sheet = new CSSStyleSheet();
        if (typeof sheet.replaceSync === "function") {
          sheet.replaceSync(INLINE_MENU_CSS);
          sharedInlineMenuSheet = sheet;
          return sheet;
        }
      } catch (_) {}
    }
    return null;
  }

  function prepareDomainMatches(rawList) {
    return (Array.isArray(rawList) ? rawList : []).map((m) => ({
      ...m,
      foldedUser: normalizeVi(String(m.username || "").trim()),
      foldedTitle: normalizeVi(String(m.service_name || "").trim())
    }));
  }

  function computeAnchorScreenRect(anchorInput) {
    try {
      const rect = anchorInput && anchorInput.getBoundingClientRect ? anchorInput.getBoundingClientRect() : null;
      const chromeTopOffset = Math.max(0, (window.outerHeight || 0) - (window.innerHeight || 0));
      const baseLeft = Number(window.screenX ?? window.screenLeft ?? 0) || 0;
      const baseTop = Number(window.screenY ?? window.screenTop ?? 0) || 0;
      return {
        screenLeft: Math.round(baseLeft + (rect ? rect.left : 80)),
        screenTop: Math.round(baseTop + chromeTopOffset + (rect ? rect.bottom + 8 : 120)),
        availLeft: Number(window.screen?.availLeft) || 0,
        availTop: Number(window.screen?.availTop) || 0,
        screenWidth: Number(window.screen?.availWidth || window.screen?.width || 0),
        screenHeight: Number(window.screen?.availHeight || window.screen?.height || 0)
      };
    } catch (_) {
      return null;
    }
  }

  function requestInlineUnlockForAnchor(anchorInput, isStep1User = false) {
    if (!isSafePageOrigin()) return;
    pendingUnlockAnchor = {
      input: anchorInput || null,
      isStep1User: Boolean(isStep1User),
      savedAt: Date.now()
    };
    const anchorRect = computeAnchorScreenRect(anchorInput);
    safeSendMessage({ type: "OPEN_INLINE_UNLOCK_PROMPT", anchorRect }, (res) => {
      if (res && res.alreadyUnlocked && anchorInput && anchorInput.isConnected) {
        const isPw = isPasswordLikeInput(anchorInput);
        const preferredUsername = isPw ? extractBestUsernameNear(anchorInput) : String(anchorInput.value || "").trim();
        safeSendMessage({ type: "GET_DOMAIN_MATCHES", preferredUsername }, (mRes) => {
          if (!mRes || !mRes.paired || mRes.locked) return;
          if (mRes.step1Username && !step1UsernameMem) {
            step1UsernameMem = String(mRes.step1Username).trim();
            step1UsernameSavedAt = Date.now();
          }
          const list = prepareDomainMatches(mRes.matches);
          domainMatchCache = { fetchedAt: Date.now(), matches: list, paired: true, locked: false };
          if (list.length > 0) {
            showInlineAutofillMenu(anchorInput, list, Boolean(isStep1User));
          }
        });
      }
    });
  }

  function computeControlledWheelDelta(ev, maxStepPx = 42, discreteScale = 0.36, touchpadScale = 0.55) {
    let raw = Number(ev && ev.deltaY) || 0;
    if (!Number.isFinite(raw) || raw === 0) return 0;
    if (ev.deltaMode === 1) {
      raw *= 16; // DOM_DELTA_LINE
    } else if (ev.deltaMode === 2) {
      raw *= 120; // DOM_DELTA_PAGE
    }
    const absRaw = Math.abs(raw);
    // Continuous, strictly monotonic transfer curve (no speed drop cliff at 35px!)
    const knee = 35;
    const kneeOut = knee * touchpadScale;
    const target120 = Math.min(maxStepPx, 120 * discreteScale);
    const tailSlope = target120 > kneeOut ? (target120 - kneeOut) / (120 - knee) : discreteScale;
    const mag = absRaw <= knee ? absRaw * touchpadScale : kneeOut + (absRaw - knee) * tailSlope;
    const clamped = Math.min(maxStepPx, mag);
    return raw < 0 ? -clamped : clamped;
  }

  function showInlineLockedPrompt(anchorInput, isStep1User = false) {
    if (!anchorInput || !isSafePageOrigin()) return;
    if (activeMenuEl && activeMenuAnchor === anchorInput && activeMenuMode === "locked") {
      return;
    }
    closeInlineMenu();

    const rect = anchorInput.getBoundingClientRect();
    const panelWidth = Math.max(204, Math.min(248, rect.width || 220));
    const spaceBelow = window.innerHeight - rect.bottom - 12;
    const spaceAbove = rect.top - 12;
    const placeAbove = spaceBelow < 96 && spaceAbove > spaceBelow;
    const leftPx = Math.max(8, Math.min(window.innerWidth - panelWidth - 8, rect.left));

    const host = document.createElement("div");
    // HIGH-EXT-01 / H6: Keep Light-DOM host geometry, display, and attributes strictly invariant (no data-ov-mode!)
    host.style.cssText =
      "all: initial; position: fixed; z-index: 2147483646; top: 0; left: 0; width: 0; height: 0; overflow: visible; pointer-events: none; display: block;";
    const shadow = host.attachShadow({ mode: "closed" });

    const sheet = getInlineMenuStyleSheet();
    if (sheet && "adoptedStyleSheets" in shadow) {
      try {
        shadow.adoptedStyleSheets = [sheet];
      } catch (_) {
        const styleEl = document.createElement("style");
        styleEl.textContent = INLINE_MENU_CSS;
        shadow.appendChild(styleEl);
      }
    } else {
      const styleEl = document.createElement("style");
      styleEl.textContent = INLINE_MENU_CSS;
      shadow.appendChild(styleEl);
    }

    const panel = document.createElement("div");
    panel.className = "ov-panel";
    panel.setAttribute("role", "dialog");
    panel.setAttribute("aria-label", "OmniVault đang khóa");
    panel.style.left = `${leftPx}px`;
    panel.style.width = `${panelWidth}px`;
    if (placeAbove) {
      panel.style.bottom = `${Math.max(8, window.innerHeight - rect.top + 5)}px`;
    } else {
      panel.style.top = `${Math.max(8, rect.bottom + 5)}px`;
    }
    for (const evtName of ["keydown", "keyup", "keypress"]) {
      panel.addEventListener(evtName, (ev) => ev.stopPropagation());
    }
    panel.addEventListener(
      "wheel",
      (ev) => {
        if (!ev.isTrusted || ev.ctrlKey) return;
        ev.preventDefault();
        ev.stopPropagation();
      },
      { passive: false }
    );

    const header = document.createElement("div");
    header.className = "ov-header";
    const headerTitle = document.createElement("span");
    headerTitle.textContent = "🔒 OmniVault đang khóa";
    header.appendChild(headerTitle);
    panel.appendChild(header);

    const body = document.createElement("div");
    body.className = "ov-lock-body";

    const unlockBtn = document.createElement("button");
    unlockBtn.type = "button";
    unlockBtn.className = "ov-lock-btn";
    unlockBtn.textContent = "🔓 Nhập PIN để mở khóa";
    let unlockTriggered = false;
    const onUnlockTrigger = (ev) => {
      if (!ev.isTrusted || unlockTriggered) return;
      unlockTriggered = true;
      ev.preventDefault();
      ev.stopPropagation();
      closeInlineMenu();
      requestInlineUnlockForAnchor(anchorInput, isStep1User);
    };
    unlockBtn.addEventListener("mousedown", onUnlockTrigger);
    unlockBtn.addEventListener("click", onUnlockTrigger);

    const onAnchorKeydown = (ev) => {
      if (!ev.isTrusted || ev.key !== "Escape") return;
      ev.preventDefault();
      closeInlineMenu();
    };
    anchorInput.addEventListener("keydown", onAnchorKeydown, true);

    body.appendChild(unlockBtn);
    panel.appendChild(body);

    shadow.appendChild(panel);
    document.documentElement.appendChild(host);
    activeMenuEl = host;
    activeMenuMode = "locked";
    activeMenuAnchor = anchorInput;
    activeMenuFilterFn = null;
    activeMenuCleanup = () => {
      anchorInput.removeEventListener("keydown", onAnchorKeydown, true);
    };
  }

  function showInlineAutofillMenu(anchorInput, matches, isStep1UserOnly = false) {
    closeInlineMenu();
    if (!matches || matches.length === 0 || !isSafePageOrigin()) return;

    const preparedMatches =
      typeof matches[0].foldedUser === "string" ? matches : prepareDomainMatches(matches);

    const rect = anchorInput.getBoundingClientRect();
    const showSearch = preparedMatches.length > 5;
    const panelWidth = Math.max(248, Math.min(312, rect.width));
    const spaceBelow = window.innerHeight - rect.bottom - 12;
    const spaceAbove = rect.top - 12;
    const placeAbove = spaceBelow < 210 && spaceAbove > spaceBelow;
    const availHeight = Math.max(165, Math.min(340, placeAbove ? spaceAbove : spaceBelow));
    const chromeHeight = showSearch ? 78 : 40;
    const listMaxHeight = Math.max(110, Math.min(252, availHeight - chromeHeight));
    const leftPx = Math.max(8, Math.min(window.innerWidth - panelWidth - 8, rect.left));

    const host = document.createElement("div");
    // HIGH-EXT-01: Keep Light-DOM host geometry & display strictly invariant so page JS cannot probe filter results.
    host.style.cssText =
      "all: initial; position: fixed; z-index: 2147483646; top: 0; left: 0; width: 0; height: 0; overflow: visible; pointer-events: none; display: block;";
    const shadow = host.attachShadow({ mode: "closed" });

    const sheet = getInlineMenuStyleSheet();
    if (sheet && "adoptedStyleSheets" in shadow) {
      try {
        shadow.adoptedStyleSheets = [sheet];
      } catch (_) {
        const styleEl = document.createElement("style");
        styleEl.textContent = INLINE_MENU_CSS;
        shadow.appendChild(styleEl);
      }
    } else {
      const styleEl = document.createElement("style");
      styleEl.textContent = INLINE_MENU_CSS;
      shadow.appendChild(styleEl);
    }

    const panel = document.createElement("div");
    panel.className = "ov-panel";
    panel.style.left = `${leftPx}px`;
    panel.style.width = `${panelWidth}px`;
    if (placeAbove) {
      panel.style.bottom = `${Math.max(8, window.innerHeight - rect.top + 5)}px`;
    } else {
      panel.style.top = `${Math.max(8, rect.bottom + 5)}px`;
    }
    for (const evtName of ["keydown", "keyup", "keypress"]) {
      panel.addEventListener(evtName, (ev) => ev.stopPropagation());
    }

    const header = document.createElement("div");
    header.className = "ov-header";
    const headerTitle = document.createElement("span");
    headerTitle.textContent = isStep1UserOnly
      ? "OmniVault — Chọn tài khoản (Bước 1)"
      : "OmniVault — Chọn tài khoản tự điền";
    const countBadge = document.createElement("span");
    countBadge.className = "ov-badge";
    countBadge.textContent = `${preparedMatches.length} TK`;
    header.appendChild(headerTitle);
    header.appendChild(countBadge);
    panel.appendChild(header);

    let searchBox = null;
    if (showSearch) {
      const searchWrap = document.createElement("div");
      searchWrap.className = "ov-search-wrap";
      searchBox = document.createElement("input");
      searchBox.className = "ov-search";
      searchBox.type = "text";
      searchBox.placeholder = `🔎 Tìm nhanh trong ${preparedMatches.length} tài khoản...`;
      searchBox.autocomplete = "off";
      searchBox.spellcheck = false;
      searchBox.addEventListener("mousedown", (ev) => ev.stopPropagation());
      searchBox.addEventListener("input", () => renderList(searchBox.value, true));
      searchWrap.appendChild(searchBox);
      panel.appendChild(searchWrap);
    }

    const listWrap = document.createElement("div");
    listWrap.className = "ov-list";
    listWrap.setAttribute("role", "listbox");
    listWrap.setAttribute("aria-label", "Danh sách tài khoản OmniVault");
    listWrap.style.maxHeight = `${listMaxHeight}px`;
    panel.appendChild(listWrap);

    // Smooth, controlled mouse-wheel scrolling (~1 row/notch) with sub-pixel Precision Touchpad accumulation!
    let wheelRem = 0;
    let lastWheelAt = 0;
    panel.addEventListener(
      "wheel",
      (ev) => {
        if (!ev.isTrusted || ev.ctrlKey) return;
        const scaledDelta = computeControlledWheelDelta(ev, 42, 0.36, 0.55);
        ev.preventDefault();
        ev.stopPropagation();
        if (scaledDelta !== 0 && listWrap.scrollHeight > listWrap.clientHeight) {
          const now = Date.now();
          if (now - lastWheelAt > 150 || (scaledDelta > 0 && wheelRem < 0) || (scaledDelta < 0 && wheelRem > 0)) {
            wheelRem = 0;
          }
          lastWheelAt = now;
          wheelRem += scaledDelta;
          const delta = Math.trunc(wheelRem + (wheelRem >= 0 ? 1e-9 : -1e-9));
          wheelRem -= delta;
          if (Math.abs(wheelRem) < 1e-9) wheelRem = 0;
          if (delta !== 0) {
            listWrap.scrollTop += delta;
          }
        }
      },
      { passive: false }
    );

    const isPwAnchor = isPasswordLikeInput(anchorInput);
    const useUserPrimary =
      preparedMatches.length > 1 ||
      preparedMatches.some(
        (it) =>
          it.domain &&
          String(it.service_name || "").trim().toLowerCase() === String(it.domain || "").trim().toLowerCase()
      );

    let currentFiltered = preparedMatches;
    let renderedCount = 0;
    let activeHighlightIdx = -1;
    let selectionHandled = false;

    const selectItem = (m) => {
      if (!m || selectionHandled) return;
      selectionHandled = true;
      closeInlineMenu();
      safeSendMessage(
        {
          type: "REQUEST_CREDENTIAL_FILL",
          itemId: m.id,
          step1Only: isStep1UserOnly
        },
        (res) => {
          if (!res || !res.ok) return;
          fillCredentialsOnPage(res.username || "", res.password || "", anchorInput);
        }
      );
    };

    const onRowPointerActivate = (ev) => {
      if (!ev.isTrusted) return;
      const targetEl = ev.target instanceof Element ? ev.target : ev.target?.parentElement;
      const btn = targetEl && targetEl.closest ? targetEl.closest("button.ov-row") : null;
      if (!btn) return;
      ev.preventDefault();
      ev.stopPropagation();
      const idx = Number(btn.dataset.ovIdx);
      const chosen = Number.isInteger(idx) ? currentFiltered[idx] : null;
      if (chosen) {
        selectItem(chosen);
      }
    };

    // Delegated mousedown + click handlers on list container (supports mouse, touch & assistive tech)
    listWrap.addEventListener("mousedown", onRowPointerActivate);
    listWrap.addEventListener("click", onRowPointerActivate);

    const appendNextBatch = () => {
      if (renderedCount >= currentFiltered.length) return;
      const end = Math.min(currentFiltered.length, renderedCount + DROPDOWN_PAGE_SIZE);
      const frag = document.createDocumentFragment();
      for (let i = renderedCount; i < end; i++) {
        const m = currentFiltered[i];
        const row = document.createElement("button");
        row.type = "button";
        row.className = "ov-row";
        row.setAttribute("role", "option");
        row.setAttribute("aria-selected", "false");
        row.dataset.ovIdx = String(i);

        const title = document.createElement("div");
        title.className = "ov-title";

        const sub = document.createElement("div");
        sub.className = "ov-sub";

        const starPrefix = m.is_favorite ? "★ " : "";
        if (m.username && useUserPrimary) {
          title.textContent = `${starPrefix}${m.username}`;
          const baseSub = m.service_name || m.domain || "Tài khoản đã lưu";
          sub.textContent = m.step1_matched ? `✓ Khớp bước 1 • ${baseSub}` : baseSub;
        } else {
          title.textContent = `${starPrefix}${m.service_name || "Tài khoản"}`;
          const domainTag =
            m.domain && !String(m.service_name || "").toLowerCase().includes(String(m.domain).toLowerCase())
              ? m.domain
              : "";
          const baseSub = domainTag
            ? `${m.username || "Điền mật khẩu"} • ${domainTag}`
            : m.username || "Điền mật khẩu đã lưu";
          sub.textContent = m.step1_matched ? `✓ Khớp bước 1 • ${baseSub}` : baseSub;
        }

        row.appendChild(title);
        row.appendChild(sub);
        frag.appendChild(row);
      }
      listWrap.appendChild(frag);
      renderedCount = end;
    };

    const setActiveHighlight = (nextIdx) => {
      if (currentFiltered.length === 0) {
        activeHighlightIdx = -1;
        return;
      }
      const wrapped = ((nextIdx % currentFiltered.length) + currentFiltered.length) % currentFiltered.length;
      while (renderedCount <= wrapped && renderedCount < currentFiltered.length) {
        appendNextBatch();
      }
      activeHighlightIdx = wrapped;
      const rows = listWrap.querySelectorAll("button.ov-row");
      for (let i = 0; i < rows.length; i++) {
        const isSel = Number(rows[i].dataset.ovIdx) === wrapped;
        rows[i].classList.toggle("ov-active", isSel);
        rows[i].setAttribute("aria-selected", isSel ? "true" : "false");
        if (isSel && typeof rows[i].scrollIntoView === "function") {
          try {
            rows[i].scrollIntoView({ block: "nearest" });
          } catch (_) {}
        }
      }
    };

    listWrap.addEventListener(
      "scroll",
      () => {
        if (
          renderedCount < currentFiltered.length &&
          listWrap.scrollTop + listWrap.clientHeight >= listWrap.scrollHeight - 40
        ) {
          appendNextBatch();
        }
      },
      { passive: true }
    );

    const renderList = (rawFilter = "", fromSearchBox = false) => {
      const qNorm = normalizeVi(String(rawFilter || "").trim());
      if (!qNorm) {
        currentFiltered = preparedMatches;
      } else if (!isPwAnchor) {
        currentFiltered = preparedMatches.filter(
          (m) => Boolean(m.foldedUser) && m.foldedUser.startsWith(qNorm)
        );
      } else {
        currentFiltered = preparedMatches.filter((m) =>
          m.foldedUser ? m.foldedUser.startsWith(qNorm) : m.foldedTitle.startsWith(qNorm)
        );
      }

      // Toggle visibility strictly inside closed ShadowRoot — NEVER mutate Light-DOM host.style.display!
      if (!isPwAnchor && !fromSearchBox && qNorm && currentFiltered.length === 0) {
        panel.style.display = "none";
      } else {
        panel.style.display = "block";
      }

      countBadge.textContent = qNorm
        ? `${currentFiltered.length}/${preparedMatches.length} TK`
        : `${preparedMatches.length} TK`;

      listWrap.textContent = "";
      listWrap.scrollTop = 0;
      renderedCount = 0;
      activeHighlightIdx = -1;

      if (currentFiltered.length === 0) {
        const emptyRow = document.createElement("div");
        emptyRow.className = "ov-empty";
        emptyRow.textContent = "Không có tài khoản nào bắt đầu bằng ký tự vừa nhập.";
        listWrap.appendChild(emptyRow);
        return;
      }

      appendNextBatch();
    };

    if (searchBox) {
      searchBox.addEventListener("keydown", (ev) => {
        if (ev.key === "Escape") {
          ev.preventDefault();
          closeInlineMenu();
          try {
            anchorInput.focus();
          } catch (_) {}
        } else if (ev.key === "ArrowDown" && ev.isTrusted && currentFiltered.length > 0) {
          ev.preventDefault();
          setActiveHighlight(activeHighlightIdx < 0 ? 0 : activeHighlightIdx + 1);
        } else if (ev.key === "ArrowUp" && ev.isTrusted && currentFiltered.length > 0) {
          ev.preventDefault();
          setActiveHighlight(activeHighlightIdx < 0 ? currentFiltered.length - 1 : activeHighlightIdx - 1);
        } else if (ev.key === "Enter" && ev.isTrusted && currentFiltered.length > 0) {
          ev.preventDefault();
          const chosenIdx = activeHighlightIdx >= 0 && activeHighlightIdx < currentFiltered.length ? activeHighlightIdx : 0;
          selectItem(currentFiltered[chosenIdx]);
        }
      });
    }

    const onAnchorKeydown = (ev) => {
      if (!ev.isTrusted || panel.style.display === "none") return;
      if (ev.key === "Escape") {
        ev.preventDefault();
        closeInlineMenu();
        return;
      }
      if (ev.key === "ArrowDown" && currentFiltered.length > 0) {
        ev.preventDefault();
        ev.stopPropagation();
        setActiveHighlight(activeHighlightIdx < 0 ? 0 : activeHighlightIdx + 1);
        return;
      }
      if (ev.key === "ArrowUp" && currentFiltered.length > 0) {
        ev.preventDefault();
        ev.stopPropagation();
        setActiveHighlight(activeHighlightIdx < 0 ? currentFiltered.length - 1 : activeHighlightIdx - 1);
        return;
      }
      if (ev.key === "Enter" && activeHighlightIdx >= 0 && activeHighlightIdx < currentFiltered.length) {
        ev.preventDefault();
        ev.stopPropagation();
        selectItem(currentFiltered[activeHighlightIdx]);
      }
    };
    anchorInput.addEventListener("keydown", onAnchorKeydown, true);

    let initVal = "";
    if (!isPwAnchor) {
      initVal = String(anchorInput.value || "");
    } else {
      const nearbyUser = extractBestUsernameNear(anchorInput);
      const nearFolded = normalizeVi(nearbyUser);
      if (nearFolded && preparedMatches.some((m) => m.foldedUser && m.foldedUser.startsWith(nearFolded))) {
        initVal = nearbyUser;
      }
    }
    if (searchBox && initVal) searchBox.value = initVal;
    renderList(initVal, false);

    shadow.appendChild(panel);
    document.documentElement.appendChild(host);
    activeMenuEl = host;
    activeMenuMode = "autofill";
    activeMenuAnchor = anchorInput;
    activeMenuCleanup = () => {
      anchorInput.removeEventListener("keydown", onAnchorKeydown, true);
    };
    activeMenuFilterFn = !isPwAnchor
      ? (typedVal) => {
          if (searchBox) searchBox.value = typedVal;
          renderList(typedVal, false);
        }
      : null;
  }

  function resolveEventElement(e) {
    if (typeof e.composedPath === "function") {
      const path = e.composedPath();
      if (Array.isArray(path) && path[0] instanceof Element) {
        return path[0];
      }
    }
    return e.target instanceof Element ? e.target : null;
  }

  function resolveEventInput(e) {
    const el = resolveEventElement(e);
    return el instanceof HTMLInputElement ? el : null;
  }

  function persistStep1Username(rawUser) {
    const u = String(rawUser || "").trim();
    if (!u) return;
    step1UsernameMem = u;
    step1UsernameSavedAt = Date.now();
    liveCredCache.username = u;
    liveCredCache.updatedAt = Date.now();
    safeSendMessage({ type: "SET_STEP1_USERNAME", username: u });
  }

  function updateLiveCredFromInput(el, precomputed = null) {
    if (!(el instanceof HTMLInputElement) || !isSafePageOrigin()) return;
    const isPw = precomputed && typeof precomputed.isPw === "boolean" ? precomputed.isPw : isPasswordLikeInput(el);
    if (isPw) {
      if (el.value) {
        const directUser = extractBestUsernameNear(el, { allowFallback: false });
        const hasCurrentPw = Boolean(extractCurrentPasswordNear(el));
        const resolvedUser =
          directUser || (hasCurrentPw ? "" : extractBestUsernameNear(el) || liveCredCache.username);
        liveCredCache = {
          pwEl: el,
          username: resolvedUser,
          password: el.value,
          updatedAt: Date.now()
        };
      }
      return;
    }
    const isStandaloneUser =
      precomputed && typeof precomputed.isStandaloneUser === "boolean"
        ? precomputed.isStandaloneUser
        : isStandaloneLoginUsernameInput(el);
    if (isStandaloneUser && el.value.trim()) {
      const u = el.value.trim();
      liveCredCache.username = u;
      liveCredCache.updatedAt = Date.now();
      const hasVisiblePw =
        precomputed && typeof precomputed.hasVisiblePw === "boolean"
          ? precomputed.hasVisiblePw
          : hasVisiblePasswordOnPage();
      if (!hasVisiblePw) {
        persistStep1Username(u);
      }
    }
  }

  function triggerLoginInputMenuIfNeeded(t) {
    if (tornDown || !t || !isVisibleInput(t) || !isSafePageOrigin()) return;
    if (activeMenuEl && activeMenuAnchor === t) return;
    const isPw = isPasswordLikeInput(t);
    const hasVisiblePwOnPage = isPw || hasVisiblePasswordOnPage();
    const isStandaloneUser = !isPw && isStandaloneLoginUsernameInput(t);
    const isStep1User = isStandaloneUser && !hasVisiblePwOnPage;
    const isPairedUserNextToPw =
      !isPw &&
      hasVisiblePwOnPage &&
      (isStandaloneUser || (Boolean(cachedVisiblePwEl) && findUsernameFieldNear(cachedVisiblePwEl) === t));

    if (!isPw && !isStep1User && !isPairedUserNextToPw) return;

    // H8: Deduplicate focusin + click double IPC on the same input within 250ms
    const now = Date.now();
    if (pendingMatchAnchor === t) return;
    if (lastMatchTriggerEl === t && now - lastMatchTriggerAt < 250) return;
    pendingMatchAnchor = t;
    lastMatchTriggerEl = t;
    lastMatchTriggerAt = now;

    const preferredUsername = isPw ? extractBestUsernameNear(t) : String(t.value || "").trim();
    safeSendMessage({ type: "GET_DOMAIN_MATCHES", preferredUsername }, (res) => {
      if (pendingMatchAnchor === t) pendingMatchAnchor = null;
      if (tornDown || !t.isConnected) return;
      if (!res || !res.paired) {
        domainMatchCache = { fetchedAt: Date.now(), matches: [], paired: false, locked: false };
        return;
      }
      if (res.locked) {
        domainMatchCache = { fetchedAt: 0, matches: [], paired: true, locked: true };
        showInlineLockedPrompt(t, isStep1User);
        return;
      }
      if (res.step1Username && !step1UsernameMem) {
        step1UsernameMem = String(res.step1Username).trim();
        step1UsernameSavedAt = Date.now();
      }
      const list = prepareDomainMatches(res.matches);
      domainMatchCache = { fetchedAt: Date.now(), matches: list, paired: true, locked: false };
      if (list.length > 0) {
        showInlineAutofillMenu(t, list, isStep1User);
      }
    });
  }

  document.addEventListener(
    "focusin",
    (e) => {
      if (!e.isTrusted) return;
      if (!chrome?.runtime?.id) {
        teardownContentScript();
        return;
      }
      registerShadowHostsFromEvent(e);
      if (isOwnOverlayEvent(e) || !isSafePageOrigin()) return;
      const t = resolveEventInput(e);
      triggerLoginInputMenuIfNeeded(t);
    },
    { capture: true, signal: lifecycleSignal }
  );

  document.addEventListener(
    "input",
    (e) => {
      if (!e.isTrusted) return;
      if (!chrome?.runtime?.id) {
        teardownContentScript();
        return;
      }
      if (isOwnOverlayEvent(e)) return;
      const el = resolveEventInput(e);
      if (!el || !isSafePageOrigin()) return;

      // Single-pass input handling (eliminates duplicate queryAllInputsDeep + visibility scans per keystroke)
      const isPw = isPasswordLikeInput(el);
      if (isPw) {
        updateLiveCredFromInput(el, { isPw: true });
        return;
      }

      if (el === activeMenuAnchor && activeMenuFilterFn) {
        const val = el.value || "";
        if (val.trim()) {
          liveCredCache.username = val.trim();
          liveCredCache.updatedAt = Date.now();
          if (!hasVisiblePasswordOnPage()) {
            persistStep1Username(val.trim());
          }
        }
        activeMenuFilterFn(val);
        return;
      }

      const isStandaloneUser = isStandaloneLoginUsernameInput(el);
      if (!isStandaloneUser) return;

      const hasVisiblePwOnPage = hasVisiblePasswordOnPage();
      updateLiveCredFromInput(el, {
        isPw: false,
        isStandaloneUser: true,
        hasVisiblePw: hasVisiblePwOnPage
      });

      if (!activeMenuEl && isVisibleInput(el)) {
        const isStep1User = !hasVisiblePwOnPage;
        const cacheFresh = Date.now() - domainMatchCache.fetchedAt < 12000;
        // H8: Respect 12s cache even when matches.length === 0 or !paired to prevent per-keystroke SW IPC storms!
        if (cacheFresh && !domainMatchCache.locked) {
          if (domainMatchCache.paired && domainMatchCache.matches.length > 0) {
            showInlineAutofillMenu(el, domainMatchCache.matches, isStep1User);
          }
        } else if (pendingMatchAnchor !== el) {
          pendingMatchAnchor = el;
          const preferredUsername = String(el.value || "").trim();
          safeSendMessage({ type: "GET_DOMAIN_MATCHES", preferredUsername }, (res) => {
            if (pendingMatchAnchor === el) pendingMatchAnchor = null;
            if (tornDown || !el.isConnected) return;
            if (!res || !res.paired) {
              domainMatchCache = { fetchedAt: Date.now(), matches: [], paired: false, locked: false };
              return;
            }
            if (res.locked) {
              domainMatchCache = { fetchedAt: 0, matches: [], paired: true, locked: true };
              showInlineLockedPrompt(el, isStep1User);
              return;
            }
            const list = prepareDomainMatches(res.matches);
            domainMatchCache = { fetchedAt: Date.now(), matches: list, paired: true, locked: false };
            if (list.length > 0) {
              showInlineAutofillMenu(el, list, isStep1User);
            }
          });
        }
      }
    },
    { capture: true, signal: lifecycleSignal }
  );

  document.addEventListener(
    "change",
    (e) => {
      if (!e.isTrusted) return;
      if (!chrome?.runtime?.id) {
        teardownContentScript();
        return;
      }
      if (isOwnOverlayEvent(e)) return;
      updateLiveCredFromInput(resolveEventInput(e));
    },
    { capture: true, signal: lifecycleSignal }
  );

  document.addEventListener(
    "mousedown",
    (e) => {
      if (activeMenuEl && !isOwnOverlayEvent(e) && resolveEventElement(e) !== activeMenuAnchor) {
        closeInlineMenu();
      }
    },
    { capture: true, signal: lifecycleSignal }
  );

  window.addEventListener(
    "scroll",
    (ev) => {
      if (!activeMenuEl) return;
      if (ev.target === activeMenuEl || (activeMenuEl.contains && activeMenuEl.contains(ev.target))) {
        return;
      }
      closeInlineMenu();
    },
    { capture: true, passive: true, signal: lifecycleSignal }
  );
  const onPageUnloadCleanup = () => {
    cancelPendingAckTimers();
    clearLiveCredCache();
  };
  window.addEventListener("pagehide", onPageUnloadCleanup, { signal: lifecycleSignal });
  window.addEventListener("beforeunload", onPageUnloadCleanup, { signal: lifecycleSignal });

  // Render auto-save / confirm-update / undo / locked notice inside closed Shadow DOM
  function showCaptureNoticeBanner(notice) {
    if (tornDown || !notice || !isSafePageOrigin()) return;
    if (notice.kind === "unpaired") {
      if (unpairedHintShownInPage) return;
      unpairedHintShownInPage = true;
      safeSendMessage({ type: "MARK_UNPAIRED_HINT_SHOWN" }, (res) => {
        if (tornDown) return;
        if (res && res.alreadyShown) return;
        mountCaptureNoticeBanner(notice);
      });
      return;
    }
    mountCaptureNoticeBanner(notice);
  }

  function mountCaptureNoticeBanner(notice) {
    if (tornDown || !notice || !isSafePageOrigin()) return;

    const mount = () => {
      if (!document.documentElement) return;
      if (saveBannerEl) saveBannerEl.remove();

      const outer = document.createElement("div");
      outer.style.cssText =
        "all: initial; position: fixed; top: 0; right: 0; width: 0; height: 0; overflow: visible; pointer-events: none; z-index: 2147483647;";
      const shadow = outer.attachShadow({ mode: "closed" });

      const styleEl = document.createElement("style");
      styleEl.textContent = `
        .ov-toast-box {
          position: fixed; top: 16px; right: 16px; z-index: 2147483647;
          width: 330px; background: #FFFFFF; border: 1.5px solid #BBD0EA;
          border-radius: 14px; box-shadow: 0 14px 34px rgba(7, 14, 26, 0.22);
          padding: 13px 15px; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
          color: #070E1A; box-sizing: border-box; pointer-events: auto;
        }
        .ov-toast-heading {
          font-size: 13.8px; font-weight: 800; color: #1D4ED8;
        }
        .ov-toast-heading.ok { color: #059669; }
        .ov-toast-heading.warn { color: #B45309; }
        .ov-toast-heading.muted { color: #475569; }
        .ov-toast-desc {
          font-size: 12.2px; font-weight: 600; color: #26364B;
          margin: 5px 0 11px; word-break: break-word; line-height: 1.4;
        }
        .ov-toast-actions {
          display: flex; gap: 8px; justify-content: flex-end;
        }
        .ov-toast-btn {
          padding: 6px 12px; border-radius: 9px; font-size: 12px; font-weight: 700;
          cursor: pointer; font-family: inherit;
        }
        .ov-toast-btn-primary {
          border: 1px solid #1D4ED8; background: #1D4ED8; color: #FFFFFF;
        }
        .ov-toast-btn-secondary {
          border: 1px solid #BBD0EA; background: #F1F5FB; color: #26364B;
        }
        .ov-toast-btn-danger {
          border: 1px solid #FCA5A5; background: #FEF2F2; color: #B91C1C;
        }
        @media (prefers-color-scheme: dark) {
          .ov-toast-box {
            background: #0F172A; border-color: #334155;
            box-shadow: 0 14px 34px rgba(0, 0, 0, 0.55); color: #F1F5F9;
          }
          .ov-toast-heading { color: #93C5FD; }
          .ov-toast-heading.ok { color: #34D399; }
          .ov-toast-heading.warn { color: #FBBF24; }
          .ov-toast-heading.muted { color: #94A3B8; }
          .ov-toast-desc { color: #CBD5E1; }
          .ov-toast-btn-primary {
            border-color: #2563EB; background: #2563EB; color: #FFFFFF;
          }
          .ov-toast-btn-secondary {
            border-color: #334155; background: #1E293B; color: #E2E8F0;
          }
          .ov-toast-btn-danger {
            border-color: #7F1D1D; background: #450A0A; color: #FCA5A5;
          }
        }
      `;
      shadow.appendChild(styleEl);

      const box = document.createElement("div");
      box.className = "ov-toast-box";
      box.setAttribute("role", notice.kind === "confirm_update" ? "dialog" : "alert");
      if (notice.kind !== "confirm_update") {
        box.setAttribute("aria-live", "polite");
      }

      const heading = document.createElement("div");
      heading.className = "ov-toast-heading";
      const desc = document.createElement("div");
      desc.className = "ov-toast-desc";

      const actions = document.createElement("div");
      actions.className = "ov-toast-actions";

      let dismissTimer = null;
      let activeDismissMs = 0;
      let isHovering = false;
      const clearDismissTimer = () => {
        if (dismissTimer) {
          clearTimeout(dismissTimer);
          dismissTimer = null;
        }
      };
      const scheduleDismiss = (ms) => {
        activeDismissMs = ms;
        clearDismissTimer();
        if (isHovering || ms <= 0) return;
        dismissTimer = setTimeout(() => {
          dismissTimer = null;
          if (outer.isConnected) outer.remove();
        }, ms);
      };
      box.addEventListener("mouseenter", () => {
        isHovering = true;
        clearDismissTimer();
      });
      box.addEventListener("mouseleave", () => {
        isHovering = false;
        if (activeDismissMs > 0) {
          scheduleDismiss(activeDismissMs);
        }
      });

      let dismissMs = 3000;
      const summaryLine = `${notice.host || location.hostname}${notice.username ? " • " + notice.username : ""}`;

      if (notice.kind === "confirm_update") {
        dismissMs = 30000;
        heading.textContent = "Cập nhật mật khẩu đã lưu?";
        desc.textContent = `${summaryLine} vừa đăng nhập hoặc đổi sang mật khẩu mới khác với bản đang lưu trong OmniVault.`;

        const confirmBtn = document.createElement("button");
        confirmBtn.type = "button";
        confirmBtn.className = "ov-toast-btn ov-toast-btn-primary";
        confirmBtn.textContent = "Cập nhật";

        const dismissBtn = document.createElement("button");
        dismissBtn.type = "button";
        dismissBtn.className = "ov-toast-btn ov-toast-btn-secondary";
        dismissBtn.textContent = "Giữ bản cũ";

        confirmBtn.addEventListener("click", (ev) => {
          if (!ev.isTrusted) return;
          confirmBtn.disabled = true;
          dismissBtn.disabled = true;
          confirmBtn.textContent = "Đang cập nhật...";
          safeSendMessage({ type: "CONFIRM_PENDING_UPDATE", proposalId: notice.noticeId }, (res) => {
            if (res && res.ok) {
              domainMatchCache = { fetchedAt: 0, matches: [], paired: true };
              box.setAttribute("role", "alert");
              heading.className = "ov-toast-heading ok";
              heading.textContent = "✓ OmniVault đã cập nhật mật khẩu";
              desc.textContent = summaryLine;
              confirmBtn.hidden = true;
              dismissBtn.hidden = true;
              if (res.noticeId) {
                const undoBtn = document.createElement("button");
                undoBtn.type = "button";
                undoBtn.className = "ov-toast-btn ov-toast-btn-danger";
                undoBtn.textContent = "Hoàn tác";
                undoBtn.addEventListener("click", (uev) => {
                  if (!uev.isTrusted) return;
                  clearDismissTimer();
                  undoBtn.disabled = true;
                  undoBtn.textContent = "Đang hoàn tác...";
                  safeSendMessage({ type: "UNDO_AUTO_SAVED_LOGIN", noticeId: res.noticeId }, (ures) => {
                    if (ures && ures.ok) {
                      domainMatchCache = { fetchedAt: 0, matches: [], paired: true };
                      heading.className = "ov-toast-heading muted";
                      heading.textContent = "Đã hoàn tác cập nhật mật khẩu";
                      undoBtn.hidden = true;
                      scheduleDismiss(1200);
                    } else {
                      undoBtn.textContent = "Lỗi hoàn tác";
                      scheduleDismiss(3000);
                    }
                  });
                });
                actions.prepend(undoBtn);
              }
              scheduleDismiss(3000);
            } else {
              dismissBtn.disabled = false;
              confirmBtn.textContent = res?.error || "Hết hạn — mở OmniVault để cập nhật";
            }
          });
        });

        dismissBtn.addEventListener("click", (ev) => {
          if (!ev.isTrusted) return;
          clearDismissTimer();
          safeSendMessage({ type: "DISMISS_PENDING_UPDATE", proposalId: notice.noticeId });
          outer.remove();
        });

        actions.appendChild(dismissBtn);
        actions.appendChild(confirmBtn);
      } else if (notice.kind === "auto_saved") {
        dismissMs = 3000;
        heading.className = "ov-toast-heading ok";
        heading.textContent =
          notice.mode === "updated"
            ? "✓ OmniVault đã cập nhật mật khẩu"
            : "✓ OmniVault đã tự lưu mật khẩu";
        desc.textContent = summaryLine;

        const undoBtn = document.createElement("button");
        undoBtn.type = "button";
        undoBtn.className = "ov-toast-btn ov-toast-btn-danger";
        undoBtn.textContent = "Hoàn tác";
        undoBtn.addEventListener("click", (ev) => {
          if (!ev.isTrusted) return;
          clearDismissTimer();
          undoBtn.disabled = true;
          undoBtn.textContent = "Đang hoàn tác...";
          safeSendMessage({ type: "UNDO_AUTO_SAVED_LOGIN", noticeId: notice.noticeId }, (res) => {
            if (res && res.ok) {
              heading.className = "ov-toast-heading muted";
              heading.textContent = "Đã hoàn tác lưu mật khẩu";
              undoBtn.hidden = true;
              scheduleDismiss(1200);
            } else {
              undoBtn.textContent = "Lỗi hoàn tác";
              scheduleDismiss(3000);
            }
          });
        });
        actions.appendChild(undoBtn);
      } else if (notice.kind === "locked_pending") {
        dismissMs = 12000;
        heading.className = "ov-toast-heading warn";
        heading.textContent = "🔒 Kho OmniVault đang khóa PIN";
        desc.textContent = `Vì bảo mật, mật khẩu của ${summaryLine} chưa được giữ tạm khi kho khóa. Mở khóa ngay để tự điền hoặc lưu tài khoản.`;
        const unlockNowBtn = document.createElement("button");
        unlockNowBtn.type = "button";
        unlockNowBtn.className = "ov-toast-btn ov-toast-btn-primary";
        unlockNowBtn.textContent = "🔓 Mở khóa ngay";
        unlockNowBtn.addEventListener("click", (ev) => {
          if (!ev.isTrusted) return;
          clearDismissTimer();
          outer.remove();
          requestInlineUnlockForAnchor(liveCredCache.pwEl || document.activeElement, false);
        });
        actions.appendChild(unlockNowBtn);
      } else {
        dismissMs = 10000;
        heading.textContent = "OmniVault chưa kết nối thiết bị";
        desc.textContent =
          "Bấm biểu tượng tiện ích OmniVault và dán Mã Kết Nối từ điện thoại để tự động lưu & đồng bộ mật khẩu.";
      }

      if (notice.kind !== "confirm_update") {
        const closeBtn = document.createElement("button");
        closeBtn.type = "button";
        closeBtn.className = "ov-toast-btn ov-toast-btn-secondary";
        closeBtn.textContent = "Đóng";
        closeBtn.addEventListener("click", (ev) => {
          if (!ev.isTrusted) return;
          clearDismissTimer();
          outer.remove();
        });
        actions.appendChild(closeBtn);
      }

      box.appendChild(heading);
      box.appendChild(desc);
      box.appendChild(actions);
      shadow.appendChild(box);
      document.documentElement.appendChild(outer);
      saveBannerEl = outer;

      scheduleDismiss(dismissMs);
    };

    if (document.documentElement) {
      mount();
    } else {
      document.addEventListener("DOMContentLoaded", mount, { once: true, signal: lifecycleSignal });
    }
  }

  function isLikelySubmitButton(btn) {
    if (!btn) return false;
    const rawType = btn.getAttribute ? btn.getAttribute("type") : null;
    const hasOwningForm = Boolean(btn.form || (btn.closest && btn.closest("form")));
    const btnType = (
      rawType ||
      (btn instanceof HTMLButtonElement && hasOwningForm
        ? "submit"
        : btn instanceof HTMLInputElement
        ? btn.type
        : "")
    ).toLowerCase();
    const aria = btn.getAttribute ? btn.getAttribute("aria-label") || "" : "";
    const title = btn.title || "";
    const id = btn.id || "";
    const cls = typeof btn.className === "string" ? btn.className : "";
    const txt = btn.textContent || "";
    const val = btn.value || "";
    const labelMeta = normalizeVi(`${aria} ${title} ${txt} ${val}`).trim();
    const idMeta = normalizeVi(id).trim();
    const btnMeta = normalizeVi(`${labelMeta} ${idMeta} ${cls}`).trim();
    // NEVER apply negative keyword filtering over arbitrary CSS className (`cls`)!
    const negCheckText = (labelMeta || idMeta)
      .replace(/(?:^|[^a-z0-9])(reset.?password|dat.?lai.?mat.?khau)(?:[^a-z0-9]|$)/gi, " ")
      .trim();

    if (
      negCheckText &&
      /(?:^|[^a-z0-9])(show|hide|view|toggle|visibility|eye|reveal|hien|an.?mat.?khau|clear|xoa|reset|cancel|huy|close|dong|back|quay.?lai|forgot|quen|help|tro.?giup|copy|sao.?chep|generate|tao.?mat.?khau)(?:[^a-z0-9]|$)/i.test(
        negCheckText
      )
    ) {
      return false;
    }

    const explicitAuthCue =
      /(?:^|[^a-z0-9])(dang.?nhap|dang.?ky|login|log.?in|sign.?in|signin|sign.?up|signup|register|doi.?mat.?khau|change.?password|reset.?password|dat.?lai.?mat.?khau|mat.?khau|password|auth|authenticate|logon|log.?on)(?:[^a-z0-9]|$)/i;
    const genericNonAuthCue =
      /(?:^|[^a-z0-9])(save|luu|next|tiep|tiep.?theo|tiep.?tuc|continue|done|xong|finish|hoan.?tat)(?:[^a-z0-9]|$)/i;

    // AF-03 / INV-06: Generic "save"/"luu"/"next"/"tiep" buttons must never trigger credential capture
    // unless explicitly paired with an authentication/password label.
    if (genericNonAuthCue.test(labelMeta) && !explicitAuthCue.test(labelMeta)) {
      return false;
    }

    if (btnType === "submit" || btnType === "image") {
      if (!rawType && !txt.trim()) {
        const rect = btn.getBoundingClientRect ? btn.getBoundingClientRect() : { width: 0 };
        if (
          rect.width > 0 &&
          rect.width < 46 &&
          !/(?:^|[^a-z0-9])(submit|login|signin|dang.?nhap|enter)(?:[^a-z0-9]|$)/i.test(btnMeta)
        ) {
          return false;
        }
      }
      return true;
    }

    return explicitAuthCue.test(btnMeta);
  }

  // Strictly for forms/dialogs that ALREADY contain a genuine visible filled <input type="password">
  // (e.g. Change Password / Reset Password pages whose button says "Lưu", "Save changes", "Cập nhật", "Xác nhận").
  function isPasswordChangeSubmitButton(btn, hasFilledPassword) {
    if (!btn || !hasFilledPassword) return false;
    const rawType = btn.getAttribute ? btn.getAttribute("type") : null;
    const hasOwningForm = Boolean(btn.form || (btn.closest && btn.closest("form")));
    const btnType = (
      rawType ||
      (btn instanceof HTMLButtonElement && hasOwningForm
        ? "submit"
        : btn instanceof HTMLInputElement
        ? btn.type
        : "")
    ).toLowerCase();
    const aria = btn.getAttribute ? btn.getAttribute("aria-label") || "" : "";
    const title = btn.title || "";
    const id = btn.id || "";
    const cls = typeof btn.className === "string" ? btn.className : "";
    const txt = btn.textContent || "";
    const val = btn.value || "";
    const labelMeta = normalizeVi(`${aria} ${title} ${txt} ${val}`).trim();
    const idMeta = normalizeVi(id).trim();
    const btnMeta = normalizeVi(`${labelMeta} ${idMeta} ${cls}`).trim();
    // NEVER apply negative keyword filtering over arbitrary CSS className (`cls`)!
    const negCheckText = (labelMeta || idMeta)
      .replace(/(?:^|[^a-z0-9])(reset.?password|dat.?lai.?mat.?khau)(?:[^a-z0-9]|$)/gi, " ")
      .trim();
    if (
      negCheckText &&
      /(?:^|[^a-z0-9])(show|hide|view|toggle|visibility|eye|reveal|hien|an.?mat.?khau|clear|xoa|reset|cancel|huy|close|dong|back|quay.?lai|forgot|quen|help|tro.?giup|copy|sao.?chep|generate|tao.?mat.?khau)(?:[^a-z0-9]|$)/i.test(
        negCheckText
      )
    ) {
      return false;
    }
    // M1: Block unrelated social / messaging / draft / sharing buttons even if a password field exists nearby
    if (
      /(?:^|[^a-z0-9])(theo.?doi|bo.?theo.?doi|follow|unfollow|gui.?tin.?nhan|tin.?nhan|nhan.?tin|send.?message|message|chat|binh.?luan|comment|reply|tra.?loi|luu.?nhap|save.?draft|draft|nhap|chia.?se|share|dang.?bai|bookmark|yeu.?thich|like|thich)(?:[^a-z0-9]|$)/i.test(
        labelMeta || idMeta
      )
    ) {
      return false;
    }
    if (btnType === "submit" || btnType === "image") {
      return true;
    }
    return /(?:^|[^a-z0-9])(save|save.?changes|luu|luu.?thay.?doi|cap.?nhat|update|xac.?nhan|confirm|dong.?y|hoan.?tat|finish|done|tiep.?tuc|continue|apply|ap.?dung|submit|doi.?mat.?khau|thay.?doi|change.?password|reset.?password|dat.?lai.?mat.?khau|change)(?:[^a-z0-9]|$)/i.test(
      labelMeta || btnMeta
    );
  }

  let lastCaptureSig = "";
  let lastCaptureAt = 0;

  function submitCapturedCredentialsNow(pwEl, scopeRoot = null) {
    if (tornDown || !isSafePageOrigin()) return;
    const fallbackPw = Date.now() - liveCredCache.updatedAt < 120_000 ? liveCredCache.password : "";
    const password = (pwEl && pwEl.value) || fallbackPw;
    if (!password) return;

    const refEl = pwEl || liveCredCache.pwEl || document.body;
    const currentPassword = pwEl ? extractCurrentPasswordNear(pwEl, scopeRoot) : "";
    const directUser = extractBestUsernameNear(refEl, { allowFallback: false });
    // H5: On multi-password change-password forms without a username input in scope,
    // NEVER fall back to stale Step-1 username or page-wide [data-email] — let background.js match via currentPassword!
    const isChangePasswordForm = Boolean(currentPassword && !directUser);
    const username = isChangePasswordForm ? "" : directUser || extractBestUsernameNear(refEl);
    const sig = `${location.hostname}|${username}|${password}|${currentPassword}`;
    const now = Date.now();
    if (sig === lastCaptureSig && now - lastCaptureAt < 2500) return;
    lastCaptureSig = sig;
    lastCaptureAt = now;

    // Clear in-memory Step-1 username so subsequent forms on the same SPA cannot inherit stale state
    step1UsernameMem = "";
    step1UsernameSavedAt = 0;

    safeSendMessage(
      { type: "SUBMIT_LOGIN_CAPTURE", username, password, currentPassword, isChangePasswordForm },
      (res) => {
        if (tornDown || !res) return;
        if (
          res.notice &&
          (res.status === "auto_saved" ||
            res.status === "confirm_update" ||
            res.status === "locked_pending" ||
            res.status === "unpaired")
        ) {
          showCaptureNoticeBanner(res.notice);
          // M4: Delay ACK_TAB_CAPTURE_NOTICE by 1200ms (cancelled on pagehide/beforeunload)
          // so fast post-login redirects re-display the banner on the destination page!
          const ackNoticeId = res.notice.noticeId;
          if (ackNoticeId) {
            const ackTimer = setTimeout(() => {
              pendingAckTimers.delete(ackTimer);
              if (!tornDown) {
                safeSendMessage({ type: "ACK_TAB_CAPTURE_NOTICE", noticeId: ackNoticeId });
              }
            }, 1200);
            pendingAckTimers.add(ackTimer);
          }
        }
      }
    );
    clearLiveCredCache();
  }

  document.addEventListener(
    "submit",
    (e) => {
      if (!e.isTrusted) return;
      if (!chrome?.runtime?.id) {
        teardownContentScript();
        return;
      }
      if (!isSafePageOrigin()) return;
      const form = resolveEventElement(e);
      if (!(form instanceof HTMLFormElement)) return;
      const formInputs = queryAllInputsDeep(form);
      let pw = pickPrimaryPasswordInput(
        formInputs.filter((inp) => Boolean(inp.value) && isPasswordLikeInput(inp))
      );
      if (
        !pw &&
        liveCredCache.pwEl &&
        Date.now() - liveCredCache.updatedAt < 5000 &&
        form.contains(liveCredCache.pwEl)
      ) {
        pw = liveCredCache.pwEl;
      }
      if (!pw) {
        const step1Usr = formInputs.find(
          (inp) => Boolean(inp.value && inp.value.trim()) && isStandaloneLoginUsernameInput(inp)
        );
        if (step1Usr) {
          persistStep1Username(step1Usr.value.trim());
        }
        return;
      }
      submitCapturedCredentialsNow(pw, form);
    },
    { capture: true, signal: lifecycleSignal }
  );

  // Capture modern SPA logins & password-change forms synchronously before frameworks clear fields or redirect
  document.addEventListener(
    "click",
    (e) => {
      if (!e.isTrusted) return;
      if (!chrome?.runtime?.id) {
        teardownContentScript();
        return;
      }
      registerShadowHostsFromEvent(e);
      if (!isSafePageOrigin()) return;
      const targetEl = resolveEventElement(e);
      if (targetEl instanceof HTMLInputElement && !activeMenuEl && !isOwnOverlayEvent(e)) {
        triggerLoginInputMenuIfNeeded(targetEl);
      }
      const btn =
        targetEl && targetEl.closest
          ? targetEl.closest(
              "button, input[type='submit'], input[type='button'], input[type='image'], [role='button'], a[class*='btn'], a[class*='login'], a[class*='submit'], a[href='#'], a[href^='javascript']"
            )
          : null;
      if (!btn) return;

      // H8: Check submit-button semantics BEFORE any DOM scan or visibility layout reflow!
      const isAuthBtn = isLikelySubmitButton(btn);
      const isPwChgBtn = !isAuthBtn && isPasswordChangeSubmitButton(btn, true);
      if (!isAuthBtn && !isPwChgBtn) return;

      const scopeRoot = btn.closest("form, [role='dialog'], main, section") || document;
      const scopeInputs = queryAllInputsDeep(scopeRoot);
      let pw = pickPrimaryPasswordInput(
        scopeInputs.filter((inp) => Boolean(inp.value) && isPasswordLikeInput(inp) && isVisibleInput(inp))
      );

      // M1: Only explicit auth buttons may fall back outside scopeRoot or to visible liveCredCache.pwEl;
      // generic change-password buttons ("Lưu"/"Cập nhật") strictly require a filled visible password in the SAME scopeRoot!
      if (!pw && isAuthBtn) {
        if (scopeRoot !== document) {
          pw = pickPrimaryPasswordInput(
            queryAllInputsDeep(document).filter(
              (inp) => Boolean(inp.value) && isPasswordLikeInput(inp) && isVisibleInput(inp)
            )
          );
        }
        if (
          !pw &&
          liveCredCache.password &&
          Date.now() - liveCredCache.updatedAt < 15_000 &&
          liveCredCache.pwEl &&
          liveCredCache.pwEl.isConnected &&
          isVisibleInput(liveCredCache.pwEl)
        ) {
          pw = liveCredCache.pwEl;
        }
      }

      if (pw) {
        submitCapturedCredentialsNow(pw, scopeRoot);
      } else if (isAuthBtn) {
        const step1Usr = scopeInputs.find(
          (inp) => Boolean(inp.value && inp.value.trim()) && isStandaloneLoginUsernameInput(inp) && isVisibleInput(inp)
        );
        if (step1Usr) {
          persistStep1Username(step1Usr.value.trim());
        }
      }
    },
    { capture: true, signal: lifecycleSignal }
  );

  document.addEventListener(
    "keydown",
    (e) => {
      if (!e.isTrusted) return;
      if (!chrome?.runtime?.id) {
        teardownContentScript();
        return;
      }
      if (e.key !== "Enter" || !isSafePageOrigin()) return;
      registerShadowHostsFromEvent(e);
      const target = resolveEventInput(e);
      if (!target) return;
      if (
        isPasswordLikeInput(target) &&
        (target.value || (liveCredCache.pwEl === target && liveCredCache.password))
      ) {
        const scope = target.closest("form, [role='dialog'], main, section") || document;
        const primaryPw =
          pickPrimaryPasswordInput(
            queryAllInputsDeep(scope).filter(
              (inp) => Boolean(inp.value) && isPasswordLikeInput(inp) && isVisibleInput(inp)
            )
          ) || target;
        submitCapturedCredentialsNow(primaryPw, scope);
        return;
      }
      if (isStandaloneLoginUsernameInput(target)) {
        const scope = target.closest("form, [role='dialog'], main, section") || document;
        const pw = pickPrimaryPasswordInput(
          queryAllInputsDeep(scope).filter(
            (inp) => Boolean(inp.value) && isPasswordLikeInput(inp) && isVisibleInput(inp)
          )
        );
        if (pw) {
          submitCapturedCredentialsNow(pw, scope);
        } else if (target.value.trim()) {
          persistStep1Username(target.value.trim());
        }
      }
    },
    { capture: true, signal: lifecycleSignal }
  );

  // Listen for direct 1-tap Autofill command from Popup and proactive capture notices pushed by Service Worker
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (sender && sender.id && sender.id !== chrome.runtime.id) return false;
    if (msg && msg.type === "FILL_LOGIN_NOW") {
      if (!isSafePageOrigin()) {
        sendResponse({ filled: false, mode: "unsafe_origin" });
        return true;
      }
      const res = fillCredentialsOnPage(msg.username || "", msg.password || "");
      sendResponse({ filled: res.filled, mode: res.mode });
      return true;
    }
    if (msg && msg.type === "SHOW_TAB_CAPTURE_NOTICE" && msg.notice) {
      if (!isSafePageOrigin()) {
        sendResponse({ ok: false, shown: false });
        return true;
      }
      showCaptureNoticeBanner(msg.notice);
      sendResponse({ ok: true, shown: true });
      return true;
    }
    if (msg && msg.type === "VAULT_UNLOCKED_REFRESH_AUTOFILL") {
      if (!isSafePageOrigin()) {
        sendResponse({ ok: false });
        return true;
      }
      domainMatchCache = { fetchedAt: 0, matches: [], paired: true, locked: false };
      closeInlineMenu();

      let targetInput =
        pendingUnlockAnchor.input &&
        Date.now() - pendingUnlockAnchor.savedAt < 300_000 &&
        pendingUnlockAnchor.input.isConnected &&
        isVisibleInput(pendingUnlockAnchor.input)
          ? pendingUnlockAnchor.input
          : null;
      let isStep1User = Boolean(pendingUnlockAnchor.isStep1User);

      if (!targetInput) {
        const allInputs = queryAllInputsDeep(document);
        const visPw = allInputs.find((el) => isPasswordLikeInput(el) && isVisibleInput(el));
        const visUser = allInputs.find((el) => !isPasswordLikeInput(el) && isStandaloneLoginUsernameInput(el) && isVisibleInput(el));
        targetInput = visUser || visPw || null;
        isStep1User = Boolean(visUser && !visPw);
      }

      if (targetInput) {
        try {
          targetInput.focus();
        } catch (_) {}
        const isPw = isPasswordLikeInput(targetInput);
        const preferredUsername = isPw ? extractBestUsernameNear(targetInput) : String(targetInput.value || "").trim();
        safeSendMessage({ type: "GET_DOMAIN_MATCHES", preferredUsername }, (res) => {
          if (!res || !res.paired || res.locked) return;
          const list = prepareDomainMatches(res.matches);
          domainMatchCache = { fetchedAt: Date.now(), matches: list, paired: true, locked: false };
          if (list.length > 0 && targetInput.isConnected) {
            showInlineAutofillMenu(targetInput, list, isStep1User);
          }
        });
      }
      sendResponse({ ok: true, refreshed: Boolean(targetInput) });
      return true;
    }
    return false;
  });

  // ============================================================================
  // Pillar 2: WebAuthn / Passkey Bridge (webauthn_page.js <-> content.js <-> SW)
  // Closed Shadow DOM confirmation cards with strict e.isTrusted & origin checks
  // ============================================================================
  const WEBAUTHN_BRIDGE_CHANNEL = "omnivault_webauthn_bridge_v1";

  function postWebAuthnBridgeReply(reqId, nonce, body) {
    if (!reqId || !nonce || !isSafePageOrigin()) return;
    try {
      window.postMessage(
        {
          channel: WEBAUTHN_BRIDGE_CHANNEL,
          dir: "ext_to_page",
          reqId,
          nonce,
          ...body
        },
        window.location.origin
      );
    } catch (_) {}
  }

  function closePasskeyPrompt() {
    if (typeof activePasskeyCleanup === "function") {
      try {
        activePasskeyCleanup();
      } catch (_) {}
      activePasskeyCleanup = null;
    }
    if (passkeyModalEl) {
      try {
        passkeyModalEl.remove();
      } catch (_) {}
      passkeyModalEl = null;
    }
    activePasskeyReqId = "";
    activePasskeyNonce = "";
  }

  function createPasskeyPromptShell({ reqId, nonce, titleText, subtitleText, onCancel }) {
    closePasskeyPrompt();
    if (!document.documentElement || tornDown || !isSafePageOrigin()) return null;

    const outer = document.createElement("div");
    outer.style.cssText =
      "all: initial; position: fixed; top: 0; right: 0; width: 0; height: 0; overflow: visible; pointer-events: none; z-index: 2147483647; display: block;";
    const shadow = outer.attachShadow({ mode: "closed" });

    const styleEl = document.createElement("style");
    styleEl.textContent = `
      .ov-pk-card {
        position: fixed;
        top: 16px;
        right: 16px;
        z-index: 2147483647;
        width: 332px;
        background: #FFFFFF;
        border: 1.5px solid #BBD0EA;
        border-radius: 14px;
        box-shadow: 0 14px 36px rgba(7, 14, 26, 0.24);
        padding: 13px 14px;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        color: #070E1A;
        box-sizing: border-box;
        pointer-events: auto;
      }
      .ov-pk-head {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: 8px;
      }
      .ov-pk-title {
        font-size: 13.4px;
        font-weight: 800;
        color: #1D4ED8;
        line-height: 1.3;
      }
      .ov-pk-close {
        border: 1px solid #CBD5E1;
        background: #F8FAFC;
        color: #475569;
        width: 22px;
        height: 22px;
        border-radius: 7px;
        font-size: 11px;
        font-weight: 800;
        cursor: pointer;
        flex-shrink: 0;
        line-height: 1;
        padding: 0;
      }
      .ov-pk-close:hover {
        background: #E2E8F0;
      }
      .ov-pk-sub {
        font-size: 11.4px;
        font-weight: 700;
        color: #26364B;
        margin: 4px 0 9px;
        word-break: break-word;
      }
      .ov-pk-desc {
        font-size: 11.4px;
        font-weight: 500;
        color: #334155;
        margin: 0 0 10px;
        line-height: 1.4;
      }
      .ov-pk-list {
        display: flex;
        flex-direction: column;
        gap: 6px;
        max-height: 200px;
        overflow-y: auto;
        margin-bottom: 9px;
      }
      .ov-pk-item {
        width: 100%;
        text-align: left;
        border: 1.2px solid #BFD6F8;
        background: linear-gradient(180deg, #FFFFFF 0%, #F3F8FF 100%);
        border-radius: 9px;
        padding: 7px 10px;
        cursor: pointer;
        font-family: inherit;
        box-sizing: border-box;
      }
      .ov-pk-item:hover:not(:disabled) {
        background: #E6EFFD;
        border-color: #60A5FA;
      }
      .ov-pk-item:disabled {
        opacity: 0.65;
        cursor: wait;
      }
      .ov-pk-item-name {
        font-size: 12.2px;
        font-weight: 800;
        color: #070E1A;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .ov-pk-item-meta {
        font-size: 10.8px;
        font-weight: 600;
        color: #334155;
        margin-top: 2px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .ov-pk-actions {
        display: flex;
        flex-direction: column;
        gap: 6px;
      }
      .ov-pk-btn {
        width: 100%;
        border-radius: 9px;
        padding: 7px 10px;
        font-size: 12px;
        font-weight: 700;
        cursor: pointer;
        font-family: inherit;
        box-sizing: border-box;
      }
      .ov-pk-btn-primary {
        border: 1px solid #1D4ED8;
        background: #1D4ED8;
        color: #FFFFFF;
      }
      .ov-pk-btn-primary:hover:not(:disabled) {
        background: #1E40AF;
      }
      .ov-pk-btn-secondary {
        border: 1px solid #BBD0EA;
        background: #F1F5FB;
        color: #26364B;
      }
      .ov-pk-btn-secondary:hover:not(:disabled) {
        background: #E2ECF9;
      }
      .ov-pk-btn:disabled {
        opacity: 0.65;
        cursor: wait;
      }
      @media (prefers-color-scheme: dark) {
        .ov-pk-card {
          background: #0F172A;
          border-color: #334155;
          box-shadow: 0 14px 36px rgba(0, 0, 0, 0.58);
          color: #F1F5F9;
        }
        .ov-pk-title {
          color: #93C5FD;
        }
        .ov-pk-close {
          border-color: #334155;
          background: #1E293B;
          color: #CBD5E1;
        }
        .ov-pk-close:hover {
          background: #334155;
        }
        .ov-pk-sub,
        .ov-pk-desc {
          color: #CBD5E1;
        }
        .ov-pk-item {
          border-color: #334155;
          background: linear-gradient(180deg, #1E293B 0%, #0F172A 100%);
        }
        .ov-pk-item:hover:not(:disabled) {
          background: #1E293B;
          border-color: #60A5FA;
        }
        .ov-pk-item-name {
          color: #F8FAFC;
        }
        .ov-pk-item-meta {
          color: #94A3B8;
        }
        .ov-pk-btn-primary {
          border-color: #2563EB;
          background: #2563EB;
        }
        .ov-pk-btn-primary:hover:not(:disabled) {
          background: #1D4ED8;
        }
        .ov-pk-btn-secondary {
          border-color: #334155;
          background: #1E293B;
          color: #E2E8F0;
        }
        .ov-pk-btn-secondary:hover:not(:disabled) {
          background: #334155;
        }
      }
    `;
    shadow.appendChild(styleEl);

    const card = document.createElement("div");
    card.className = "ov-pk-card";
    card.setAttribute("role", "dialog");
    card.setAttribute("aria-modal", "true");
    card.setAttribute("aria-label", titleText);
    for (const evtName of ["keydown", "keyup", "keypress", "mousedown", "click"]) {
      card.addEventListener(evtName, (ev) => ev.stopPropagation());
    }

    const head = document.createElement("div");
    head.className = "ov-pk-head";
    const title = document.createElement("div");
    title.className = "ov-pk-title";
    title.textContent = titleText;

    const closeBtn = document.createElement("button");
    closeBtn.type = "button";
    closeBtn.className = "ov-pk-close";
    closeBtn.title = "Đóng";
    closeBtn.setAttribute("aria-label", "Đóng hộp thoại Passkey");
    closeBtn.textContent = "✕";
    closeBtn.addEventListener("click", (ev) => {
      if (!ev.isTrusted) return;
      closePasskeyPrompt();
      if (typeof onCancel === "function") onCancel();
    });

    head.appendChild(title);
    head.appendChild(closeBtn);
    card.appendChild(head);

    if (subtitleText) {
      const sub = document.createElement("div");
      sub.className = "ov-pk-sub";
      sub.textContent = subtitleText;
      card.appendChild(sub);
    }

    const bodySlot = document.createElement("div");
    card.appendChild(bodySlot);

    shadow.appendChild(card);
    document.documentElement.appendChild(outer);

    const onEsc = (ev) => {
      if (!ev.isTrusted || ev.key !== "Escape") return;
      closePasskeyPrompt();
      if (typeof onCancel === "function") onCancel();
    };
    window.addEventListener("keydown", onEsc, true);

    passkeyModalEl = outer;
    activePasskeyReqId = reqId;
    activePasskeyNonce = nonce;
    activePasskeyCleanup = () => {
      window.removeEventListener("keydown", onEsc, true);
    };

    return { card, bodySlot, closeBtn };
  }

  function mountPasskeyGetPrompt({ reqId, nonce, passkeys, challengeB64Url, rpId, userVerification }) {
    let resolved = false;
    const replyOnce = (body) => {
      if (resolved) return;
      resolved = true;
      closePasskeyPrompt();
      postWebAuthnBridgeReply(reqId, nonce, body);
    };

    const shell = createPasskeyPromptShell({
      reqId,
      nonce,
      titleText: "🔑 Đăng nhập bằng Passkey OmniVault",
      subtitleText: passkeys[0]?.rpId || rpId || location.hostname,
      onCancel: () => replyOnce({ status: "cancelled" })
    });
    if (!shell) {
      replyOnce({ status: "fallback" });
      return;
    }

    const listEl = document.createElement("div");
    listEl.className = "ov-pk-list";
    const allButtons = [];

    for (const pk of passkeys) {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "ov-pk-item";

      const nameEl = document.createElement("div");
      nameEl.className = "ov-pk-item-name";
      nameEl.textContent = pk.userDisplayName || pk.userName || pk.serviceName || pk.rpId;

      const metaEl = document.createElement("div");
      metaEl.className = "ov-pk-item-meta";
      metaEl.textContent = pk.userName && pk.userName !== nameEl.textContent
        ? `${pk.userName} • ${pk.rpId}`
        : `${pk.serviceName || pk.rpName || pk.rpId} • ${pk.rpId}`;

      btn.appendChild(nameEl);
      btn.appendChild(metaEl);

      btn.addEventListener("click", (ev) => {
        if (!ev.isTrusted) return;
        for (const b of allButtons) b.disabled = true;
        metaEl.textContent = "Đang ký xác thực Passkey...";
        safeSendMessage(
          {
            type: "WEBAUTHN_ASSERT_PASSKEY",
            credentialIdB64Url: pk.credentialIdB64Url,
            challengeB64Url,
            rpId: rpId || pk.rpId,
            userVerification: userVerification || "preferred"
          },
          (assertRes) => {
            if (assertRes && assertRes.ok && assertRes.response) {
              replyOnce({ status: "ok", credential: assertRes.response });
            } else {
              replyOnce({ status: "fallback" });
            }
          }
        );
      });

      allButtons.push(btn);
      listEl.appendChild(btn);
    }

    const actions = document.createElement("div");
    actions.className = "ov-pk-actions";

    const fallbackBtn = document.createElement("button");
    fallbackBtn.type = "button";
    fallbackBtn.className = "ov-pk-btn ov-pk-btn-secondary";
    fallbackBtn.textContent = "Dùng Windows Hello / Trình duyệt";
    fallbackBtn.addEventListener("click", (ev) => {
      if (!ev.isTrusted) return;
      replyOnce({ status: "fallback" });
    });
    allButtons.push(fallbackBtn);
    actions.appendChild(fallbackBtn);

    shell.bodySlot.appendChild(listEl);
    shell.bodySlot.appendChild(actions);
  }

  function mountPasskeyCreatePrompt({ reqId, nonce, effectiveRpId, payload }) {
    let resolved = false;
    const replyOnce = (body) => {
      if (resolved) return;
      resolved = true;
      closePasskeyPrompt();
      postWebAuthnBridgeReply(reqId, nonce, body);
    };

    const userLabel = payload.userName || payload.userDisplayName || "";
    const shell = createPasskeyPromptShell({
      reqId,
      nonce,
      titleText: "🔑 Lưu Passkey vào OmniVault?",
      subtitleText: userLabel ? `${effectiveRpId} • ${userLabel}` : effectiveRpId,
      onCancel: () => replyOnce({ status: "cancelled" })
    });
    if (!shell) {
      replyOnce({ status: "fallback" });
      return;
    }

    const desc = document.createElement("div");
    desc.className = "ov-pk-desc";
    desc.textContent = "Tạo khóa Passkey ECDSA P-256 và đồng bộ mã hóa đầu-cuối giữa Trình duyệt và Điện thoại.";
    shell.bodySlot.appendChild(desc);

    const actions = document.createElement("div");
    actions.className = "ov-pk-actions";

    const saveBtn = document.createElement("button");
    saveBtn.type = "button";
    saveBtn.className = "ov-pk-btn ov-pk-btn-primary";
    saveBtn.textContent = "Lưu vào OmniVault";

    const fallbackBtn = document.createElement("button");
    fallbackBtn.type = "button";
    fallbackBtn.className = "ov-pk-btn ov-pk-btn-secondary";
    fallbackBtn.textContent = "Dùng trình duyệt / Khóa cứng";

    saveBtn.addEventListener("click", (ev) => {
      if (!ev.isTrusted) return;
      saveBtn.disabled = true;
      fallbackBtn.disabled = true;
      saveBtn.textContent = "Đang tạo Passkey...";
      safeSendMessage(
        {
          type: "WEBAUTHN_CREATE_PASSKEY",
          rpId: payload.rpId || effectiveRpId,
          rpName: payload.rpName || "",
          userIdB64Url: payload.userIdB64Url || "",
          userName: payload.userName || "",
          userDisplayName: payload.userDisplayName || "",
          challengeB64Url: payload.challengeB64Url || "",
          pubKeyCredParams: payload.pubKeyCredParams || [],
          excludeCredentialIds: Array.isArray(payload.excludeCredentialIds) ? payload.excludeCredentialIds : [],
          userVerification: payload.userVerification || "preferred",
          wantCredProps: Boolean(payload.wantCredProps)
        },
        (createRes) => {
          if (createRes && createRes.ok && createRes.response) {
            replyOnce({ status: "ok", credential: createRes.response });
          } else if (createRes && createRes.excluded) {
            replyOnce({ status: "excluded" });
          } else {
            replyOnce({ status: "fallback" });
          }
        }
      );
    });

    fallbackBtn.addEventListener("click", (ev) => {
      if (!ev.isTrusted) return;
      replyOnce({ status: "fallback" });
    });

    actions.appendChild(saveBtn);
    actions.appendChild(fallbackBtn);
    shell.bodySlot.appendChild(actions);
  }

  window.addEventListener(
    "message",
    (ev) => {
      if (tornDown || !isSafePageOrigin()) return;
      if (ev.source !== window || ev.origin !== window.location.origin) return;
      const d = ev.data;
      if (
        !d ||
        typeof d !== "object" ||
        d.channel !== WEBAUTHN_BRIDGE_CHANNEL ||
        d.dir !== "page_to_ext"
      ) {
        return;
      }
      const reqId = typeof d.reqId === "string" ? d.reqId.trim() : "";
      const nonce = typeof d.nonce === "string" ? d.nonce.trim() : "";
      if (!reqId || !nonce) return;

      if (d.action === "abort") {
        if (activePasskeyReqId === reqId && activePasskeyNonce === nonce) {
          closePasskeyPrompt();
        }
        return;
      }

      // Guard against unsolicited page postMessage modal spam & status oracle probing
      if (
        (typeof navigator !== "undefined" && navigator.userActivation && !navigator.userActivation.isActive) ||
        activePasskeyReqId
      ) {
        postWebAuthnBridgeReply(reqId, nonce, { status: "fallback" });
        return;
      }

      const payload = d.payload && typeof d.payload === "object" ? d.payload : {};

      if (d.action === "get") {
        safeSendMessage(
          {
            type: "WEBAUTHN_CHECK_AVAILABLE",
            mode: "get",
            rpId: typeof payload.rpId === "string" ? payload.rpId : "",
            allowCredentialIds: Array.isArray(payload.allowCredentialIds) ? payload.allowCredentialIds : [],
            userVerification: typeof payload.userVerification === "string" ? payload.userVerification : "preferred"
          },
          (res) => {
            if (tornDown || !res || !res.handled || !Array.isArray(res.passkeys) || res.passkeys.length === 0) {
              postWebAuthnBridgeReply(reqId, nonce, { status: "fallback" });
              return;
            }
            postWebAuthnBridgeReply(reqId, nonce, { status: "prompting" });
            mountPasskeyGetPrompt({
              reqId,
              nonce,
              passkeys: res.passkeys,
              challengeB64Url: String(payload.challengeB64Url || ""),
              rpId: typeof payload.rpId === "string" ? payload.rpId : "",
              userVerification: typeof payload.userVerification === "string" ? payload.userVerification : "preferred"
            });
          }
        );
        return;
      }

      if (d.action === "create") {
        safeSendMessage(
          {
            type: "WEBAUTHN_CHECK_AVAILABLE",
            mode: "create",
            rpId: typeof payload.rpId === "string" ? payload.rpId : "",
            excludeCredentialIds: Array.isArray(payload.excludeCredentialIds) ? payload.excludeCredentialIds : [],
            userVerification: typeof payload.userVerification === "string" ? payload.userVerification : "preferred"
          },
          (res) => {
            if (tornDown || !res || !res.handled) {
              postWebAuthnBridgeReply(reqId, nonce, { status: "fallback" });
              return;
            }
            if (res.excluded) {
              postWebAuthnBridgeReply(reqId, nonce, { status: "excluded" });
              return;
            }
            postWebAuthnBridgeReply(reqId, nonce, { status: "prompting" });
            mountPasskeyCreatePrompt({
              reqId,
              nonce,
              effectiveRpId: String(res.rpId || payload.rpId || location.hostname),
              payload
            });
          }
        );
      }
    },
    { signal: lifecycleSignal }
  );
})();
