@echo off
chcp 65001 >nul
set "BAT_SELF=%~f0"
net session >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
  powershell -NoProfile -ExecutionPolicy Bypass -Command "& { Start-Process -FilePath $env:BAT_SELF -Verb RunAs }"
  exit /b
)
powershell -NoProfile -ExecutionPolicy Bypass -Command "& { $raw = [IO.File]::ReadAllText($env:BAT_SELF, [Text.Encoding]::UTF8); $m = '###POWERSHELL_BELOW###'; $i = $raw.LastIndexOf($m); if ($i -lt 0) { throw 'Khong tim thay khoi PowerShell nhung trong tep bat.' }; $code = $raw.Substring($i + $m.Length); & ([ScriptBlock]::Create($code)) }"
set "PS_ERR=%ERRORLEVEL%"
echo.
pause
exit /b %PS_ERR%

###POWERSHELL_BELOW###
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$extId = "mflfmiibodbccokmmbfbngjbhgmiemco"
$policyValue = "mflfmiibodbccokmmbfbngjbhgmiemco;https://minhtuan0506.github.io/omnivault-extension/update.xml"
$regPaths = @(
  "HKLM:\SOFTWARE\Policies\Google\Chrome\ExtensionInstallForcelist",
  "HKLM:\SOFTWARE\Policies\Microsoft\Edge\ExtensionInstallForcelist",
  "HKLM:\SOFTWARE\Policies\BraveSoftware\Brave-Browser\ExtensionInstallForcelist",
  "HKLM:\SOFTWARE\Policies\CocCoc\Browser\ExtensionInstallForcelist"
)

Write-Host "=========================================================" -ForegroundColor Cyan
Write-Host "  CAI DAT OMNIVAULT TU DONG CAP NHAT TU GITHUB           " -ForegroundColor Cyan
Write-Host "  Extension ID: $extId" -ForegroundColor Green
Write-Host "=========================================================" -ForegroundColor Cyan

foreach ($rp in $regPaths) {
  if (-not (Test-Path $rp)) {
    New-Item -Path $rp -Force | Out-Null
  }
  $props = Get-ItemProperty -Path $rp
  $existingName = $null
  $maxIdx = 0
  foreach ($p in $props.PSObject.Properties) {
    if ($p.Name -match '^\d+$') {
      $idx = [int]$p.Name
      if ($idx -gt $maxIdx) { $maxIdx = $idx }
      if ([string]$p.Value -like "$extId;*") {
        $existingName = $p.Name
      }
    }
  }
  if ($existingName) {
    Set-ItemProperty -Path $rp -Name $existingName -Value $policyValue -Type String
    Write-Host "[+] Da cap nhat policy: $rp ($existingName)" -ForegroundColor Green
  } else {
    $nextName = [string]($maxIdx + 1)
    New-ItemProperty -Path $rp -Name $nextName -Value $policyValue -PropertyType String -Force | Out-Null
    Write-Host "[+] Da them policy: $rp ($nextName)" -ForegroundColor Green
  }
}

Write-Host ""
Write-Host "[OK] Hoan tat! Hay khoi dong lai Chrome / Edge / Brave / Coc Coc." -ForegroundColor Yellow
Write-Host "Luu y: Tren Windows khong Join Domain, Chrome/Edge co the chan Policy tu URL ngoai Cho;" -ForegroundColor Gray
Write-Host "       neu may nha khong nhan Policy, hay dung Cach B (OmniVault-GiaiNen-latest.zip + CapNhat-Tu-GitHub.bat)." -ForegroundColor Gray