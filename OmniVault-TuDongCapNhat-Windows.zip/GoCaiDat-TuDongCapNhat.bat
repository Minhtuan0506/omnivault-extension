@echo off
setlocal EnableExtensions
chcp 65001 >nul
set "BAT_SELF=%~f0"
net session >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
  "%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -Command "& { Start-Process -FilePath $env:BAT_SELF -Verb RunAs }"
  exit /b
)
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -Command "& { $raw = [IO.File]::ReadAllText($env:BAT_SELF, [Text.Encoding]::UTF8); $m = '###POWERSHELL_BELOW###'; $i = $raw.LastIndexOf($m); if ($i -lt 0) { throw 'Khong tim thay khoi PowerShell nhung trong tep bat.' }; $code = $raw.Substring($i + $m.Length); & ([ScriptBlock]::Create($code)) }"
set "PS_ERR=%ERRORLEVEL%"
echo.
pause
exit /b %PS_ERR%

###POWERSHELL_BELOW###
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$extId = "mflfmiibodbccokmmbfbngjbhgmiemco"
$regPaths = @(
  "HKLM:\SOFTWARE\Policies\Google\Chrome\ExtensionInstallForcelist",
  "HKLM:\SOFTWARE\Policies\Microsoft\Edge\ExtensionInstallForcelist",
  "HKLM:\SOFTWARE\Policies\BraveSoftware\Brave-Browser\ExtensionInstallForcelist",
  "HKLM:\SOFTWARE\Policies\CocCoc\Browser\ExtensionInstallForcelist"
)

foreach ($rp in $regPaths) {
  if (Test-Path $rp) {
    $props = Get-ItemProperty -Path $rp
    foreach ($p in $props.PSObject.Properties) {
      if ($p.Name -match '^\d+$' -and [string]$p.Value -like "$extId;*") {
        Remove-ItemProperty -Path $rp -Name $p.Name -ErrorAction SilentlyContinue
        Write-Host "[-] Da go policy: $rp ($($p.Name))" -ForegroundColor Yellow
      }
    }
  }
}
Write-Host "[OK] Da go cai dat Policy OmniVault thanh cong." -ForegroundColor Green