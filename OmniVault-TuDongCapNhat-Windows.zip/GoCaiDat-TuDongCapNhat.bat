@echo off
chcp 65001 >nul
set "BAT_SELF=%~f0"
net session >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)
set "PS_TMP=%TEMP%\ov_pol_rm_%RANDOM%.ps1"
(
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$raw = [IO.File]::ReadAllText($env:BAT_SELF, [Text.Encoding]::UTF8); $m = '###POWERSHELL_BELOW###'; $i = $raw.LastIndexOf($m); [IO.File]::WriteAllText($env:PS_TMP, $raw.Substring($i + $m.Length), [Text.UTF8Encoding]::new($false))"
  powershell -NoProfile -ExecutionPolicy Bypass -File "%PS_TMP%"
  del "%PS_TMP%" >nul 2>nul
  echo.
  pause
  exit /b
)

###POWERSHELL_BELOW###
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$extId = "mflfmiibodbccokmmbfbngjbhgmiemco"
$regPaths = @(
  "HKLM:\SOFTWARE\Policies\Google\Chrome\ExtensionInstallForcelist",
  "HKLM:\SOFTWARE\Policies\Microsoft\Edge\ExtensionInstallForcelist",
  "HKLM:\SOFTWARE\Policies\BraveSoftware\Brave-Browser\ExtensionInstallForcelist",
  "HKLM:\SOFTWARE\Policies\CocCoc\Browser\ExtensionInstallForcelist"
)

foreach ($rp in $regPaths) {
  if (Test-Path $rp) {
    $props = Get-ItemProperty -Path $rp
    foreach ($p in $props.PSObject.Properties) {
      if ($p.Name -match '^\d+$' -and [string]$p.Value -like "$extId;*") {
        Remove-ItemProperty -Path $rp -Name $p.Name -ErrorAction SilentlyContinue
        Write-Host "[-] Da go policy: $rp ($($p.Name))" -ForegroundColor Yellow
      }
    }
  }
}
Write-Host "[OK] Da go cai dat Policy OmniVault thanh cong." -ForegroundColor Green