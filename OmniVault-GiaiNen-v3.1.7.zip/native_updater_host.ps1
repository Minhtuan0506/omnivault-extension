﻿# OmniVault Extension — Native Messaging 100% Auto-Updater Host (Windows, Zero Admin)
# Strict Chromium Native Messaging stdio framing (4-byte LE uint32 length + UTF-8 JSON).
# Security:
#   - Pinned target directory ($PSScriptRoot) — NEVER accepts arbitrary paths over IPC
#   - Official GitHub URL allowlist only (Minhtuan0506/omnivault-extension)
#   - SHA-256 + RSA-2048 RSASSA-PKCS1-v1_5 verification against local manifest.json.key
#   - Zip-Slip, Zip-Bomb (<= 100 files, <= 10 MiB), and manifest-last atomic ordering

$ErrorActionPreference = "Stop"
$ProgressPreference    = "SilentlyContinue"
$WarningPreference     = "SilentlyContinue"
$VerbosePreference     = "SilentlyContinue"
$InformationPreference = "SilentlyContinue"

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Add-Type -AssemblyName System.IO.Compression | Out-Null
Add-Type -AssemblyName System.IO.Compression.FileSystem | Out-Null

$ExtDir      = $PSScriptRoot
$Utf8NoBom   = New-Object System.Text.UTF8Encoding($false)
$MaxMsgBytes = 65536
$MaxZipBytes = 10 * 1024 * 1024
$MaxEntries  = 100
$HostVersion = "1.0.0"

$ReleaseApiUrl   = "https://api.github.com/repos/Minhtuan0506/omnivault-extension/releases/latest"
$PagesVersionUrl = "https://minhtuan0506.github.io/omnivault-extension/version.json"
$PagesZipUrl     = "https://minhtuan0506.github.io/omnivault-extension/OmniVault-GiaiNen-latest.zip"

$StdIn  = [Console]::OpenStandardInput()
$StdOut = [Console]::OpenStandardOutput()

function Read-ExactBytes {
    param([System.IO.Stream]$Stream, [int]$Count)
    $buf = New-Object byte[] $Count
    $off = 0
    while ($off -lt $Count) {
        $n = $Stream.Read($buf, $off, $Count - $off)
        if ($n -le 0) { return $null }
        $off += $n
    }
    return $buf
}

function Read-NativeMessage {
    $lenBytes = Read-ExactBytes -Stream $StdIn -Count 4
    if ($null -eq $lenBytes) { return $null }
    $msgLen = [BitConverter]::ToInt32($lenBytes, 0)
    if ($msgLen -le 0 -or $msgLen -gt $MaxMsgBytes) {
        throw "Invalid native message length: $msgLen"
    }
    $payloadBytes = Read-ExactBytes -Stream $StdIn -Count $msgLen
    if ($null -eq $payloadBytes) { return $null }
    $jsonText = $Utf8NoBom.GetString($payloadBytes)
    return ($jsonText | ConvertFrom-Json)
}

function Write-NativeMessage {
    param([hashtable]$Payload)
    $json = $Payload | ConvertTo-Json -Depth 8 -Compress
    $bytes = $Utf8NoBom.GetBytes($json)
    $lenBytes = [BitConverter]::GetBytes([int]$bytes.Length)
    $StdOut.Write($lenBytes, 0, 4)
    $StdOut.Write($bytes, 0, $bytes.Length)
    $StdOut.Flush()
}

function Test-AllowedGitHubUrl {
    param([string]$Url)
    if ([string]::IsNullOrWhiteSpace($Url)) { return $false }
    try {
        $u = [Uri]$Url.Trim()
        if ($u.Scheme -ne "https") { return $false }
        if (-not [string]::IsNullOrEmpty($u.UserInfo)) { return $false }
        $h = $u.Host.ToLowerInvariant()
        if ($h -eq "github.com") {
            return ($u.AbsolutePath -match '^/Minhtuan0506/omnivault-extension(?:/|$)')
        }
        if ($h -eq "minhtuan0506.github.io") {
            return ($u.AbsolutePath -match '^/omnivault-extension(?:/|$)')
        }
        return $false
    } catch {
        return $false
    }
}

function Compare-SemVer {
    param([string]$A, [string]$B)
    $pa = ($A -replace '^[vV]', '').Split('.') | ForEach-Object { [int]$_ }
    $pb = ($B -replace '^[vV]', '').Split('.') | ForEach-Object { [int]$_ }
    $n = [Math]::Max($pa.Length, $pb.Length)
    for ($i = 0; $i -lt $n; $i++) {
        $va = if ($i -lt $pa.Length) { $pa[$i] } else { 0 }
        $vb = if ($i -lt $pb.Length) { $pb[$i] } else { 0 }
        if ($va -ne $vb) { return ($va - $vb) }
    }
    return 0
}

function Read-DerLen {
    param([byte[]]$Buf, [ref]$Pos)
    $b = $Buf[$Pos.Value]; $Pos.Value++
    if (($b -band 0x80) -eq 0) { return [int]$b }
    $num = $b -band 0x7F
    if ($num -lt 1 -or $num -gt 4) { throw "Invalid DER length" }
    $val = 0
    for ($i = 0; $i -lt $num; $i++) {
        $val = ($val -shl 8) -bor $Buf[$Pos.Value]
        $Pos.Value++
    }
    return $val
}

function ConvertFrom-SpkiToRsa {
    param([string]$SpkiB64)
    $der = [Convert]::FromBase64String($SpkiB64.Trim())
    $p = 0
    if ($der[$p++] -ne 0x30) { throw "SPKI missing outer SEQUENCE" }
    $null = Read-DerLen $der ([ref]$p)
    if ($der[$p++] -ne 0x30) { throw "SPKI missing AlgorithmIdentifier" }
    $algLen = Read-DerLen $der ([ref]$p); $p += $algLen
    if ($der[$p++] -ne 0x03) { throw "SPKI missing BIT STRING" }
    $null = Read-DerLen $der ([ref]$p)
    if ($der[$p++] -ne 0x00) { throw "SPKI BIT STRING nonzero padding" }
    if ($der[$p++] -ne 0x30) { throw "SPKI missing RSAPublicKey SEQUENCE" }
    $null = Read-DerLen $der ([ref]$p)
    if ($der[$p++] -ne 0x02) { throw "SPKI missing modulus INTEGER" }
    $modLen = Read-DerLen $der ([ref]$p)
    $mod = New-Object byte[] $modLen
    [Array]::Copy($der, $p, $mod, 0, $modLen); $p += $modLen
    if ($mod.Length -gt 1 -and $mod[0] -eq 0x00) {
        $trimmed = New-Object byte[] ($mod.Length - 1)
        [Array]::Copy($mod, 1, $trimmed, 0, $trimmed.Length)
        $mod = $trimmed
    }
    if ($der[$p++] -ne 0x02) { throw "SPKI missing exponent INTEGER" }
    $expLen = Read-DerLen $der ([ref]$p)
    $exp = New-Object byte[] $expLen
    [Array]::Copy($der, $p, $exp, 0, $expLen)
    $rsaParams = New-Object System.Security.Cryptography.RSAParameters
    $rsaParams.Modulus  = $mod
    $rsaParams.Exponent = $exp
    $rsa = New-Object System.Security.Cryptography.RSACryptoServiceProvider
    $rsa.ImportParameters($rsaParams)
    return $rsa
}

function Get-FileSha256Lower {
    param([string]$FilePath)
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        $fs = [System.IO.File]::OpenRead($FilePath)
        try {
            $hash = $sha.ComputeHash($fs)
            return ([BitConverter]::ToString($hash) -replace '-', '').ToLowerInvariant()
        } finally {
            $fs.Dispose()
        }
    } finally {
        $sha.Dispose()
    }
}

function Download-AllowedFileWithLimit {
    param([string]$Url, [string]$DestPath, [int]$LimitBytes)
    if (-not (Test-AllowedGitHubUrl $Url)) {
        throw "Rejected untrusted download URL: $Url"
    }
    $req = [System.Net.HttpWebRequest]::Create($Url)
    $req.UserAgent = "OmniVault-Native-Updater/$HostVersion"
    $req.Timeout = 30000
    $req.ReadWriteTimeout = 30000
    $req.AllowAutoRedirect = $true
    $req.MaximumAutomaticRedirections = 5
    $resp = $req.GetResponse()
    try {
        if ($resp.ContentLength -gt $LimitBytes) {
            throw "Download exceeds 10 MB safety limit"
        }
        $inStream = $resp.GetResponseStream()
        $outStream = [System.IO.File]::Open($DestPath, [System.IO.FileMode]::Create, [System.IO.FileAccess]::Write)
        try {
            $buf = New-Object byte[] 16384
            $total = 0
            while ($true) {
                $n = $inStream.Read($buf, 0, $buf.Length)
                if ($n -le 0) { break }
                $total += $n
                if ($total -gt $LimitBytes) {
                    throw "Download stream exceeds 10 MB safety limit"
                }
                $outStream.Write($buf, 0, $n)
            }
        } finally {
            $outStream.Dispose()
            $inStream.Dispose()
        }
    } finally {
        $resp.Dispose()
    }
}

function Fetch-JsonTextFromUrl {
    param([string]$Url)
    $req = [System.Net.HttpWebRequest]::Create($Url)
    $req.UserAgent = "OmniVault-Native-Updater/$HostVersion"
    $req.Accept = "application/vnd.github+json, application/json"
    $req.Timeout = 20000
    $resp = $req.GetResponse()
    try {
        $sr = New-Object System.IO.StreamReader($resp.GetResponseStream(), $Utf8NoBom)
        try {
            return $sr.ReadToEnd()
        } finally {
            $sr.Dispose()
        }
    } finally {
        $resp.Dispose()
    }
}

function Invoke-SelfUpdate {
    $manifestPath = Join-Path $ExtDir "manifest.json"
    if (-not (Test-Path $manifestPath)) {
        throw "Khong tim thay manifest.json trong thu muc tien ich."
    }
    $localManifest = [System.IO.File]::ReadAllText($manifestPath, $Utf8NoBom) | ConvertFrom-Json
    $pinnedKey = [string]$localManifest.key
    if ([string]::IsNullOrWhiteSpace($pinnedKey)) {
        throw "Thieu khoa cong khai manifest.json.key de xac thuc goi cap nhat."
    }
    $pinnedKey = $pinnedKey.Trim()

    # 1. Fetch signed version.json metadata (prefer Release asset, fallback GitHub Pages)
    $verJsonUrl = ""
    $releaseZipUrl = ""
    try {
        $relRaw = Fetch-JsonTextFromUrl $ReleaseApiUrl
        $relObj = $relRaw | ConvertFrom-Json
        if ($relObj -and $relObj.assets) {
            foreach ($a in @($relObj.assets)) {
                $aname = [string]$a.name
                $aurl  = [string]$a.browser_download_url
                if ($aname -match '^version\.json$' -and (Test-AllowedGitHubUrl $aurl)) {
                    $verJsonUrl = $aurl
                } elseif ($aname -match 'OmniVault-GiaiNen-.*\.zip$' -and (Test-AllowedGitHubUrl $aurl)) {
                    $releaseZipUrl = $aurl
                }
            }
        }
    } catch {}

    $vj = $null
    $metaUrls = @()
    if ($verJsonUrl) { $metaUrls += $verJsonUrl }
    $metaUrls += ($PagesVersionUrl + "?t=" + [DateTimeOffset]::UtcNow.ToUnixTimeSeconds())
    foreach ($mu in $metaUrls) {
        try {
            $raw = Fetch-JsonTextFromUrl $mu
            $candidate = $raw | ConvertFrom-Json
            if ($candidate -and $candidate.version -and $candidate.zip_sha256 -and $candidate.signature_rsa_b64) {
                $vj = $candidate
                break
            }
        } catch {}
    }
    if ($null -eq $vj) {
        throw "Khong tai duoc sieu du lieu chu ky so version.json tu GitHub."
    }

    $latestVer   = ([string]$vj.version -replace '^[vV]', '').Trim()
    $expectedSha = ([string]$vj.zip_sha256).Trim().ToLowerInvariant()
    $sigRsaB64   = ([string]$vj.signature_rsa_b64).Trim()
    if ($latestVer -notmatch '^\d+\.\d+\.\d+$') {
        throw "Phien ban trong version.json khong hop le."
    }
    if ($expectedSha -notmatch '^[0-9a-f]{64}$') {
        throw "Ma SHA-256 trong version.json khong hop le."
    }

    # 2. Download ZIP from allowlisted GitHub endpoints (Release first, Pages mirror fallback)
    $zipCandidates = @()
    if ($releaseZipUrl -and (Test-AllowedGitHubUrl $releaseZipUrl)) { $zipCandidates += $releaseZipUrl }
    if ($vj.unpacked_zip_url -and (Test-AllowedGitHubUrl ([string]$vj.unpacked_zip_url))) {
        if ($zipCandidates -notcontains [string]$vj.unpacked_zip_url) { $zipCandidates += [string]$vj.unpacked_zip_url }
    }
    $mirrorUrl = if ($vj.unpacked_latest -and (Test-AllowedGitHubUrl ([string]$vj.unpacked_latest))) {
        [string]$vj.unpacked_latest
    } else {
        $PagesZipUrl
    }
    if ($zipCandidates -notcontains $mirrorUrl) { $zipCandidates += $mirrorUrl }

    $tmpDir = Join-Path $env:TEMP ("omnivault_native_upd_" + [Guid]::NewGuid().ToString("N"))
    $null = New-Item -ItemType Directory -Force -Path $tmpDir
    try {
        $zipPath = Join-Path $tmpDir "update.zip"
        $verified = $false
        $lastErr = "Khong tai duoc goi ZIP."

        foreach ($candUrl in $zipCandidates) {
            try {
                if (Test-Path $zipPath) { Remove-Item -Force $zipPath }
                Download-AllowedFileWithLimit -Url $candUrl -DestPath $zipPath -LimitBytes $MaxZipBytes
                $actualSha = Get-FileSha256Lower $zipPath
                if ($actualSha -ne $expectedSha) {
                    throw "Ma SHA-256 goi ZIP khong khop!"
                }
                $canonicalBytes = $Utf8NoBom.GetBytes("omnivault-ext-zip-v1|$latestVer|$actualSha")
                $sigBytes = [Convert]::FromBase64String($sigRsaB64)
                $rsa = ConvertFrom-SpkiToRsa $pinnedKey
                try {
                    $sigOk = $rsa.VerifyData($canonicalBytes, [System.Security.Cryptography.CryptoConfig]::MapNameToOID("SHA256"), $sigBytes)
                } finally {
                    $rsa.Dispose()
                }
                if (-not $sigOk) {
                    throw "Chu ky so RSA-2048 KHONG HOP LE!"
                }
                $verified = $true
                break
            } catch {
                $lastErr = $_.Exception.Message
            }
        }
        if (-not $verified) {
            throw $lastErr
        }

        # 3. Extract ZIP safely into staging folder with Zip-Slip & Zip-Bomb guards
        $stageDir = Join-Path $tmpDir "stage"
        $null = New-Item -ItemType Directory -Force -Path $stageDir
        $stageFullRoot = [System.IO.Path]::GetFullPath($stageDir)
        if (-not $stageFullRoot.EndsWith("\")) { $stageFullRoot += "\" }

        $stagedRelFiles = New-Object System.Collections.Generic.List[string]
        $seenLower = New-Object System.Collections.Generic.HashSet[string]
        $totalUncomp = [long]0

        $arch = [System.IO.Compression.ZipFile]::OpenRead($zipPath)
        try {
            if ($arch.Entries.Count -eq 0 -or $arch.Entries.Count -gt $MaxEntries) {
                throw "So luong tep trong ZIP khong hop le ($($arch.Entries.Count))."
            }
            foreach ($entry in $arch.Entries) {
                $rawName = [string]$entry.FullName
                if ([string]::IsNullOrWhiteSpace($rawName)) { continue }
                if ($rawName.Contains([char]0) -or $rawName.Contains("\") -or $rawName.Contains(":") -or $rawName.StartsWith("/")) {
                    throw "Phat hien duong dan nguy hiem (Zip-Slip): $rawName"
                }
                if ($rawName.EndsWith("/")) { continue }
                $segs = $rawName.Split("/")
                foreach ($seg in $segs) {
                    if ([string]::IsNullOrEmpty($seg) -or $seg -eq "." -or $seg -eq "..") {
                        throw "Phat hien duong dan vuot cap (Zip-Slip): $rawName"
                    }
                    $baseUpper = ($seg.Split(".")[0]).ToUpperInvariant()
                    if ($baseUpper -match '^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])$') {
                        throw "Ten tep khong hop le tren Windows: $rawName"
                    }
                }
                $lower = $rawName.ToLowerInvariant()
                if (-not $seenLower.Add($lower)) {
                    throw "Phat hien tep trung lap trong ZIP: $rawName"
                }

                $destPath = [System.IO.Path]::GetFullPath((Join-Path $stageDir ($rawName -replace '/', '\')))
                if (-not $destPath.StartsWith($stageFullRoot, [System.StringComparison]::OrdinalIgnoreCase)) {
                    throw "Chan ghi tep ngoai thu muc dich (Zip-Slip): $rawName"
                }
                $parentDir = Split-Path -Parent $destPath
                if (-not (Test-Path $parentDir)) {
                    $null = New-Item -ItemType Directory -Force -Path $parentDir
                }

                $inS = $entry.Open()
                $outS = [System.IO.File]::Open($destPath, [System.IO.FileMode]::Create, [System.IO.FileAccess]::Write)
                try {
                    $buf = New-Object byte[] 16384
                    while ($true) {
                        $n = $inS.Read($buf, 0, $buf.Length)
                        if ($n -le 0) { break }
                        $totalUncomp += $n
                        if ($totalUncomp -gt $MaxZipBytes) {
                            throw "Goi ZIP vuot gioi han giai nen an toan 10 MB."
                        }
                        $outS.Write($buf, 0, $n)
                    }
                } finally {
                    $outS.Dispose()
                    $inS.Dispose()
                }
                $stagedRelFiles.Add($rawName)
            }
        } finally {
            $arch.Dispose()
        }

        # 4. Verify staged manifest.json key & version match BEFORE modifying ExtDir
        $stagedManifestPath = Join-Path $stageDir "manifest.json"
        if (-not (Test-Path $stagedManifestPath)) {
            throw "Goi cap nhat thieu manifest.json."
        }
        $newManifest = [System.IO.File]::ReadAllText($stagedManifestPath, $Utf8NoBom) | ConvertFrom-Json
        if (([string]$newManifest.key).Trim() -ne $pinnedKey) {
            throw "Khoa manifest.json.key trong goi moi khong khop — huy de bao toan du lieu!"
        }
        if ((Compare-SemVer ([string]$newManifest.version) $latestVer) -ne 0) {
            throw "Phien ban trong manifest.json khong khop phien ban da ky."
        }

        # 5. Atomic write order: all non-manifest files FIRST, manifest.json LAST (preserve native_updater_host.json)
        $ordered = New-Object System.Collections.Generic.List[string]
        foreach ($rel in $stagedRelFiles) {
            if ($rel.ToLowerInvariant() -ne "manifest.json") {
                $ordered.Add($rel)
            }
        }
        $ordered.Add("manifest.json")

        $written = 0
        foreach ($rel in $ordered) {
            $src = Join-Path $stageDir ($rel -replace '/', '\')
            $dst = Join-Path $ExtDir ($rel -replace '/', '\')
            $dstParent = Split-Path -Parent $dst
            if (-not (Test-Path $dstParent)) {
                $null = New-Item -ItemType Directory -Force -Path $dstParent
            }
            # Skip overwriting identical active cmd/ps1 wrapper to avoid unnecessary file handle churn
            if (($rel.ToLowerInvariant() -eq "native_updater_host.cmd" -or $rel.ToLowerInvariant() -eq "native_updater_host.ps1") -and (Test-Path $dst)) {
                if ((Get-FileSha256Lower $src) -eq (Get-FileSha256Lower $dst)) {
                    $written++
                    continue
                }
            }
            Copy-Item -Force -Path $src -Destination $dst
            $written++
        }

        return @{
            ok           = $true
            version      = $latestVer
            writtenCount = $written
            sha256       = $expectedSha
        }
    } finally {
        Remove-Item -Recurse -Force -Path $tmpDir -ErrorAction SilentlyContinue
    }
}

try {
    $msg = Read-NativeMessage
    if ($null -eq $msg) { exit 0 }

    $action = [string]$msg.action
    if ($action -eq "ping") {
        $manifestPath = Join-Path $ExtDir "manifest.json"
        if (-not (Test-Path $manifestPath)) {
            Write-NativeMessage @{ ok = $false; ready = $false; error = "Khong tim thay manifest.json trong thu muc cai dat." }
            exit 0
        }
        $m = [System.IO.File]::ReadAllText($manifestPath, $Utf8NoBom) | ConvertFrom-Json
        if ([string]::IsNullOrWhiteSpace([string]$m.key)) {
            Write-NativeMessage @{ ok = $false; ready = $false; error = "manifest.json thieu khoa cong khai key." }
            exit 0
        }
        Write-NativeMessage @{
            ok             = $true
            ready          = $true
            hostVersion    = $HostVersion
            dirName        = (Split-Path -Leaf $ExtDir)
            currentVersion = [string]$m.version
        }
        exit 0
    }

    if ($action -eq "update") {
        $res = Invoke-SelfUpdate
        Write-NativeMessage $res
        exit 0
    }

    Write-NativeMessage @{ ok = $false; error = "Lenh khong duoc ho tro: $action" }
} catch {
    try {
        Write-NativeMessage @{ ok = $false; error = [string]$_.Exception.Message }
    } catch {}
}
