@echo off
chcp 65001 >nul
setlocal EnableDelayedExpansion
set "BAT_SELF=%~f0"
set "EXT_DIR=%~dp0"
set "MODE_ARG=%~1"

powershell -NoProfile -ExecutionPolicy Bypass -Command "& { $raw = [IO.File]::ReadAllText($env:BAT_SELF, [Text.Encoding]::UTF8); $m = '###POWERSHELL_BELOW###'; $i = $raw.LastIndexOf($m); if ($i -lt 0) { throw 'Khong tim thay khoi PowerShell.' }; $code = $raw.Substring($i + $m.Length); & ([ScriptBlock]::Create($code)) }"
set "ERR=!ERRORLEVEL!"
echo.
pause
exit /b !ERR!

###POWERSHELL_BELOW###
$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)

$ExtDir = $env:EXT_DIR.TrimEnd('\')
$ModeArg = [string]$env:MODE_ARG
$HostName = "vn.canhan.omnivault.updater"
$ExtId = "mflfmiibodbccokmmbfbngjbhgmiemco"
$HostJsonPath = Join-Path $ExtDir "native_updater_host.json"
$HostCmdPath  = Join-Path $ExtDir "native_updater_host.cmd"
$HostPs1Path  = Join-Path $ExtDir "native_updater_host.ps1"
$ManifestPath = Join-Path $ExtDir "manifest.json"

$RegPaths = @(
    "HKCU:\Software\Google\Chrome\NativeMessagingHosts\$HostName",
    "HKCU:\Software\Microsoft\Edge\NativeMessagingHosts\$HostName",
    "HKCU:\Software\BraveSoftware\Brave-Browser\NativeMessagingHosts\$HostName",
    "HKCU:\Software\CocCoc\Browser\NativeMessagingHosts\$HostName",
    "HKCU:\Software\Vivaldi\NativeMessagingHosts\$HostName",
    "HKCU:\Software\Chromium\NativeMessagingHosts\$HostName"
)

if ($ModeArg -match '^(?:/go|--uninstall|-u)$') {
    Write-Host "============================================================" -ForegroundColor Yellow
    Write-Host "  OMNIVAULT — GO KICH HOAT TU DONG CAP NHAT 100% (HKCU)     " -ForegroundColor Yellow
    Write-Host "============================================================" -ForegroundColor Yellow
    foreach ($rp in $RegPaths) {
        if (Test-Path $rp) {
            Remove-Item -Path $rp -Recurse -Force -ErrorAction SilentlyContinue
            Write-Host "  [-] Da go: $rp" -ForegroundColor Gray
        }
    }
    if (Test-Path $HostJsonPath) { Remove-Item -Force $HostJsonPath -ErrorAction SilentlyContinue }
    Write-Host "[+] Da go thanh cong (tien ich van co the cap nhat thu cong bang chon thu muc)." -ForegroundColor Green
    exit 0
}

Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  OMNIVAULT — KICH HOAT TU DONG CAP NHAT 100% (KHONG ADMIN) " -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "[*] Thu muc tien ich : $ExtDir" -ForegroundColor Gray

if (-not (Test-Path $ManifestPath) -or -not (Test-Path $HostCmdPath) -or -not (Test-Path $HostPs1Path)) {
    Write-Host "[LOI] Vui long chay file nay NGAY TRONG thu muc giai nen chua manifest.json cua OmniVault!" -ForegroundColor Red
    exit 1
}

# 1. Ghi file manifest Native Messaging Host co dinh vao dung Extension ID OmniVault
$hostManifest = [ordered]@{
    name            = $HostName
    description     = "OmniVault Extension 100% Auto-Updater Host (SHA-256 + RSA-2048 Verified)"
    path            = $HostCmdPath
    type            = "stdio"
    allowed_origins = @("chrome-extension://$ExtId/")
}
[System.IO.File]::WriteAllText($HostJsonPath, ($hostManifest | ConvertTo-Json -Depth 4), $Utf8NoBom)
Write-Host "[+] Da tao cau hinh Native Host: native_updater_host.json" -ForegroundColor Green

# 2. Dang ky khoa HKCU cho tat ca trinh duyet Chromium (KHONG can quyen Admin!)
foreach ($rp in $RegPaths) {
    $null = New-Item -Path $rp -Force
    Set-ItemProperty -Path $rp -Name "(Default)" -Value $HostJsonPath
}
Write-Host "[+] Da dang ky HKCU cho Chrome, Edge, Brave, Coc Coc, Vivaldi & Chromium." -ForegroundColor Green

# 3. Tu kiem thu giao thuc Native Messaging (ping) ngay lap tuc
Write-Host "[*] Dang kiem thu ket noi Native Host..." -ForegroundColor Yellow
$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = $HostCmdPath
$psi.UseShellExecute = $false
$psi.CreateNoWindow = $true
$psi.RedirectStandardInput = $true
$psi.RedirectStandardOutput = $true
$psi.RedirectStandardError = $true
$proc = [System.Diagnostics.Process]::Start($psi)
try {
    $pingBytes = $Utf8NoBom.GetBytes('{"action":"ping"}')
    $lenBytes = [BitConverter]::GetBytes([int]$pingBytes.Length)
    $proc.StandardInput.BaseStream.Write($lenBytes, 0, 4)
    $proc.StandardInput.BaseStream.Write($pingBytes, 0, $pingBytes.Length)
    $proc.StandardInput.BaseStream.Flush()
    $proc.StandardInput.Close()

    $outLenBuf = New-Object byte[] 4
    $readLen = $proc.StandardOutput.BaseStream.Read($outLenBuf, 0, 4)
    if ($readLen -ne 4) { throw "Khong doc duoc phan hoi tu Native Host." }
    $respLen = [BitConverter]::ToInt32($outLenBuf, 0)
    $respBuf = New-Object byte[] $respLen
    $off = 0
    while ($off -lt $respLen) {
        $n = $proc.StandardOutput.BaseStream.Read($respBuf, $off, $respLen - $off)
        if ($n -le 0) { break }
        $off += $n
    }
    $proc.WaitForExit(10000) | Out-Null
    $respObj = ($Utf8NoBom.GetString($respBuf, 0, $off)) | ConvertFrom-Json
    if (-not $respObj.ok -or -not $respObj.ready) {
        throw "Kiem thu Native Host that bai: $($respObj.error)"
    }
    Write-Host "[+] Kiem thu THANH CONG! Phien ban hien tai: v$($respObj.currentVersion) ($($respObj.dirName))" -ForegroundColor Green
} finally {
    if (-not $proc.HasExited) { $proc.Kill() }
    $proc.Dispose()
}

Write-Host ""
Write-Host "============================================================" -ForegroundColor Green
Write-Host "  HOAN TAT! TU NAY TIEN ICH OMNIVAULT TU CAP NHAT 100%!     " -ForegroundColor Green
Write-Host "  - Khong bao gio phai chon thu muc hay bam xac nhan quyen. " -ForegroundColor White
Write-Host "  - Tu dong cap nhat ngam khi co ban moi tren GitHub, hoac  " -ForegroundColor White
Write-Host "    bam 1 cham 'Cap nhat ngay' ngay tren giao dien tien ich." -ForegroundColor White
Write-Host "  - (Muon go kich hoat: chay 'Bat-TuDongCapNhat-100.bat /go')" -ForegroundColor Gray
Write-Host "============================================================" -ForegroundColor Green
